function Verify-Roles {
    param (
        [PSCustomObject]$ServicePrincipal,
        [hashtable] $msgTable
    )
    
    [bool] $isCompliantR = $false  

    [bool] $isCompliantMPA = $false  
    Write-Output "10"
   [string] $TenantId = (Get-AzContext).Tenant.Id
  #  [string] $TenantId = "0941c449-5d94-4f74-88df-a45517d63b36"    
  Write-Output "13"
    [string] $ManagementScope = "/providers/Microsoft.Management/managementGroups/" + $TenantId    
    Write-Output "15"
    [string] $MarketplaceScope = "/providers/Microsoft.Marketplace"
    Write-Output "16"
    [string] $SPNObjectID = $ServicePrincipal.ServicePrincipalNameID
    Write-Output "17"
    $CostManagmentReader =  Get-AzRoleAssignment | Where-Object { $_.ObjectId -eq $SPNObjectID -and $_.RoleDefinitionName -eq "Cost Management Reader" -and $_.Scope -eq $ManagementScope } -ErrorAction SilentlyContinue
    Write-Output "21"
    $PrivateMarketplaceAdmin = Get-AzRoleAssignment -Scope $MarketplaceScope | Where-Object { $_.ObjectId -eq $SPNObjectID -and $_.RoleDefinitionName -eq "Marketplace Admin" } -ErrorAction SilentlyContinue 

    if ([string]::IsNullOrEmpty($CostManagmentReader)) {

        $isCompliantR = $false
        Write-Output "27"
        $ServicePrincipal.ComplianceComments += $msgTable.ServicePrincipalNameHasNoReaderRole
    }
    else {

        $isCompliantR = $true
        Write-Output "33"
        $ServicePrincipal.ComplianceComments += $msgTable.ServicePrincipalNameHasReaderRole
    }
    if ([string]::IsNullOrEmpty($PRivateMarketplaceAdmin)) {

        $isCompliantMPA = $false
        Write-Output "39"
        $ServicePrincipal.ComplianceComments += $msgTable.ServicePrincipalNameHasNoMarketPlaceAdminRole
    }
    else {
        $isCompliantMPA = $true
        Write-Output "44"
        $ServicePrincipal.ComplianceComments += $msgTable.ServicePrincipalNameHasMarketPlaceAdminRole
    }
    Write-Output "47"
    $ServicePrincipal.ComplianceStatus = $isCompliantR -and $isCompliantMPA
}
    
function Check-DepartmentServicePrincipalName {
    param (
        [string] $SPNID = "0000000000",
        [string] $ControlName, 
        [string] $ItemName, 
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime)
        
    [bool] $IsCompliant = $false

    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    Write-Output "65"
    $servicePrincipalName = [PSCustomObject]@{
        ServicePrincipalNameAPPID = $msgTable.NoSPN   
        ServicePrincipalNameID    = $null
        ComplianceStatus          = $false
        ComplianceComments        = $null
    } 
    Write-Output "72"
    $SPNObject = Get-AzADServicePrincipal -ApplicationId $SPNID -ErrorAction SilentlyContinue

    if ([string]::IsNullOrEmpty($SPNObject)) {
        $servicePrincipalName.ServicePrincipalNameAPPID = $msgTable.NoSPN
        $servicePrincipalName.ServicePrincipalNameID = $null
        $ServicePrincipalName.ComplianceStatus = $false
        $servicePrincipalName.ComplianceComments = $msgTable.NoSPN
    } 
    else {
        $urlPath = "/servicePrincipals/" + $SPNObject.Id
        try {
            $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop 
                   
            if ($response.statusCode -eq 200) {
                $servicePrincipalName.ServicePrincipalNameAPPID = $SPNObject.AppId
                $servicePrincipalName.ServicePrincipalNameID = $SPNObject.Id
                $servicePrincipalName.ComplianceComments = $msgTable.SPNExist
                $servicePrincipalName.ComplianceStatus = $true
                
                Verify-Roles -ServicePrincipal $servicePrincipalName -msgTable $msgTable
           
            }
            elseif ($respons.statusCode -eq 400) {
                $IsCompliant = $false
                $ServicePrincipalName.ComplianceStatus = $IsCompliant
                $ServicePrincipalName.ComplianceComments = $msgTable.NoSPN  
            }
        }
        catch {
            $ErrorList.Add("Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_" )
            Write-Error "Error: Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"
            $IsCompliant = $false
            $ServicePrincipalName.ComplianceComments = $msgTable.NoSPN
        } 
    }
    $Results = [pscustomobject]@{
        ControlName      = $ControlName  
        ComplianceStatus = $servicePrincipalName.ComplianceStatus
        ItemName         = $ItemName
        itsgcode         = $itsgcode
        Comments         = $servicePrincipalName.ComplianceComments
        ReportTime       = $ReportTime
    }
    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $Results 
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput 
}

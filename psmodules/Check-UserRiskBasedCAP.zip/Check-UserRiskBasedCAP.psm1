function Test-IsNullOrEmptyArray {
    <#
    .SYNOPSIS
        Helper function to check if a value is null or an empty array.
        Handles both null values and empty arrays returned by Microsoft Graph API.
    #>
    param(
        [AllowNull()]
        $Value
    )
    
    if ($null -eq $Value) {
        return $true
    }
    
    if ($Value -is [array] -and $Value.Count -eq 0) {
        return $true
    }
    
    if ($Value -is [string] -and [string]::IsNullOrEmpty($Value)) {
        return $true
    }
    
    return $false
}

function Test-CommonFilters {
    param(
        [PSCustomObject]$policy,
        [string] $FirstBreakGlassID,
        [string] $SecondBreakGlassID

    )

    
    # check for a conditional access policy which meets these requirements:
    # 1. state =  'enabled'
    # 2. includedUsers = 'All'
    # 3. applications.includedApplications = 'All'
    # 4. grantControls.builtInControls contains 'mfa' and 'passwordChange'
    # 5. clientAppTypes contains 'all' or all individual types selected: 'browser', 'mobileAppsAndDesktopClients', 'exchangeActiveSync', 'other'
    # 6. userRiskLevels = 'high'
    # 7. signInRiskLevels = @() or null
    # 8. platforms = null
    # 9. locations = null
    # 10. devices = null
    # 11. clientApplications = null
    # 12. signInFrequency.frequencyInterval = 'everyTime'
    # 13. signInFrequency.isEnabled = true only if signIn is not block. If block → sessionControls must be empty/null
    # 14. signInFrequency.authenticationType = 'primaryAndSecondaryAuthentication'
    # 15. includeGroups = null or empty
    # 16. excludeApplications = null or empty
    # 17. includeRoles = null or empty
    # 18. excludeRoles = null or empty
    # 19. includeGuestsOrExternalUsers = null
    # 20. excludeGuestsOrExternalUsers = null
    # 21. excludeUsers/excludeGroups
    $validPolicies =  $policy | Where-Object {
        (
            $_.state -eq "enabled" -and
            $_.conditions.users.includeUsers -contains 'All' -and
            $_.conditions.users.excludeUsers.Count -le 2 -and
            $_.conditions.users.excludeUsers -contains $FirstBreakGlassID -and
            $_.conditions.users.excludeUsers -contains $SecondBreakGlassID -and
            ($_.conditions.applications.includeApplications -contains 'All' -or
            $_.conditions.applications.includeApplications -contains 'MicrosoftAdminPortals') -and
            (
                (
                    $_.grantControls.builtInControls -contains 'mfa' -and
                    $_.grantControls.builtInControls -contains 'passwordChange'
                ) -or
                $_.grantControls.builtInControls -contains 'block'
            ) -and
            ($_.conditions.clientAppTypes -contains 'all'  -or 
                ($_.conditions.clientAppTypes -contains 'browser' -and
                    $_.conditions.clientAppTypes -contains 'mobileAppsAndDesktopClients' -and
                    $_.conditions.clientAppTypes -contains 'exchangeActiveSync' -and
                    $_.conditions.clientAppTypes -contains 'other')) -and
            $_.conditions.userRiskLevels -contains 'high' -and
            (
                # IF block → sessionControls must be empty
                (
                    $_.grantControls.builtInControls -contains 'block' -and
                    (Test-IsNullOrEmptyArray $_.sessionControls)
                ) -or
                # ELSE → sessionControls must exist and be configured
                (
                    -not ($_.grantControls.builtInControls -contains 'block') -and
                    -not (Test-IsNullOrEmptyArray $_.sessionControls) -and
                    $_.sessionControls.signInFrequency.frequencyInterval -contains 'everyTime' -and
                    $_.sessionControls.signInFrequency.authenticationType -contains 'primaryAndSecondaryAuthentication' -and
                    $_.sessionControls.signInFrequency.isEnabled -eq $true
                )
            ) -and
            (Test-IsNullOrEmptyArray $_.conditions.signInRiskLevels) -and
            (Test-IsNullOrEmptyArray $_.conditions.platforms) -and
            (Test-IsNullOrEmptyArray $_.conditions.locations) -and
            (Test-IsNullOrEmptyArray $_.conditions.devices) -and
            (Test-IsNullOrEmptyArray $_.conditions.clientApplications) -and
            (Test-IsNullOrEmptyArray $_.conditions.users.includeGroups) -and
            (Test-IsNullOrEmptyArray $_.conditions.applications.excludeApplications) -and
            (Test-IsNullOrEmptyArray $_.conditions.users.includeRoles) -and
            (Test-IsNullOrEmptyArray $_.conditions.users.excludeRoles) -and
            (Test-IsNullOrEmptyArray $_.conditions.users.includeGuestsOrExternalUsers) -and
            (Test-IsNullOrEmptyArray $_.conditions.users.excludeGuestsOrExternalUsers)
        )
    }
    return $validPolicies
} 
    
function Get-UserRiskBasedCAP {
    param (      
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [Parameter(Mandatory=$true)]
        [string] $FirstBreakGlassUPN,
        [Parameter(Mandatory=$true)] 
        [string] $SecondBreakGlassUPN,
        [string] $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false    
    )
    $IsCompliant = $false
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList

    # Check 1: Password Changes –Conditional Access Policy
    $IsCompliantPasswordCAP = $false

    # Get conditional access policies (using paginated query to handle >100 policies)
    $CAPUrl = '/identity/conditionalAccess/policies'
    try {
        $response = Invoke-GraphQueryEX -urlPath $CAPUrl -ErrorAction Stop
        $caps = if ($response.Content -and $response.Content.value) { $response.Content.value } else { @() }
    }
    catch {
        $Errorlist.Add("Failed to call Microsoft Graph REST API at URL '$CAPUrl'; returned error message: $_")
        Write-Warning "Error: Failed to call Microsoft Graph REST API at URL '$CAPUrl'; returned error message: $_"
    }
    Write-Host "Existing CAP count $($caps.count)"

    # Get break glass account IDs directly by UPN (2 targeted calls instead of fetching all users)
    $FirstBreakGlassID = $null
    $SecondBreakGlassID = $null

    $encodedUPN1 = [System.Uri]::EscapeDataString($FirstBreakGlassUPN)
    $bgUserUrlPath1 = "/users/$encodedUPN1"
    try {
        $response = Invoke-GraphQueryEX -urlPath $bgUserUrlPath1 -ErrorAction Stop
        if ($response.Content) {
            $userData = if ($response.Content.value) { $response.Content.value } else { $response.Content }
            $FirstBreakGlassID = if ($userData -is [array]) { $userData[0].id } else { $userData.id }
        }
    }
    catch {
        $errorMsg = "Failed to resolve break glass UPN '$FirstBreakGlassUPN'; error: $_"
        $ErrorList.Add($errorMsg)
        Write-Warning $errorMsg
    }

    $encodedUPN2 = [System.Uri]::EscapeDataString($SecondBreakGlassUPN)
    $bgUserUrlPath2 = "/users/$encodedUPN2"
    try {
        $response = Invoke-GraphQueryEX -urlPath $bgUserUrlPath2 -ErrorAction Stop
        if ($response.Content) {
            $userData = if ($response.Content.value) { $response.Content.value } else { $response.Content }
            $SecondBreakGlassID = if ($userData -is [array]) { $userData[0].id } else { $userData.id }
        }
    }
    catch {
        $errorMsg = "Failed to resolve break glass UPN '$SecondBreakGlassUPN'; error: $_"
        $ErrorList.Add($errorMsg)
        Write-Warning $errorMsg
    }

    # Diagnostic logging for break glass account resolution
    Write-Host "Break Glass UPN 1: $FirstBreakGlassUPN -> ID: $FirstBreakGlassID"
    Write-Host "Break Glass UPN 2: $SecondBreakGlassUPN -> ID: $SecondBreakGlassID"
    if ([string]::IsNullOrEmpty($FirstBreakGlassID)) {
        Write-Warning "Could not resolve FirstBreakGlassUPN '$FirstBreakGlassUPN' to a user ID"
    }
    if ([string]::IsNullOrEmpty($SecondBreakGlassID)) {
        Write-Warning "Could not resolve SecondBreakGlassUPN '$SecondBreakGlassUPN' to a user ID"
    }

    # Get group memberships for each BG account directly via /users/{id}/memberOf
    # (2 targeted calls instead of fetching ALL groups + ALL members of every group)
    $bg1Groups = @()
    $bg2Groups = @()

    if (-not [string]::IsNullOrEmpty($FirstBreakGlassID)) {
        $memberOfUrl1 = "/users/$FirstBreakGlassID/memberOf"
        try {
            $response = Invoke-GraphQueryEX -urlPath $memberOfUrl1 -ErrorAction Stop
            if ($response.Content -and $response.Content.value) {
                $bg1Groups = @($response.Content.value |
                    Where-Object { $_.'@odata.type' -eq '#microsoft.graph.group' } |
                    Select-Object -ExpandProperty id)
            }
        }
        catch {
            $errorMsg = "Failed to get group memberships for '$FirstBreakGlassUPN'; error: $_"
            $ErrorList.Add($errorMsg)
            Write-Error "Error: $errorMsg"
        }
    }

    if (-not [string]::IsNullOrEmpty($SecondBreakGlassID)) {
        $memberOfUrl2 = "/users/$SecondBreakGlassID/memberOf"
        try {
            $response = Invoke-GraphQueryEX -urlPath $memberOfUrl2 -ErrorAction Stop
            if ($response.Content -and $response.Content.value) {
                $bg2Groups = @($response.Content.value |
                    Where-Object { $_.'@odata.type' -eq '#microsoft.graph.group' } |
                    Select-Object -ExpandProperty id)
            }
        }
        catch {
            $errorMsg = "Failed to get group memberships for '$SecondBreakGlassUPN'; error: $_"
            $ErrorList.Add($errorMsg)
            Write-Error "Error: $errorMsg"
        }
    }

    # Find groups that contain BOTH BG accounts
    $commonBGGroups = @($bg1Groups | Where-Object { $bg2Groups -contains $_ } | Select-Object -Unique)

    # Diagnostic logging for BG group membership
    Write-Host "BG1 is in $($bg1Groups.Count) group(s): $($bg1Groups -join ', ')"
    Write-Host "BG2 is in $($bg2Groups.Count) group(s): $($bg2Groups -join ', ')"
    Write-Host "Common groups containing both BG accounts: $($commonBGGroups.Count)"

    if ($commonBGGroups.Count -gt 0) {
        Write-Host "Both BG accounts share group(s): $($commonBGGroups -join ', ')"
        $uniqueGroupIdBG = $commonBGGroups
    } else {
        Write-Host "BG accounts do NOT share any common group"
        $uniqueGroupIdBG = $null
    }
    
    # check for a conditional access policy which meets the requirements
    # Note: Test-CommonFilters already validates that BG accounts are excluded by user ID (excludeUsers)
    # If BG accounts share a common group, we accept EITHER:
    #   - Policy excludes one of the common BG groups (excludeGroups contains the group)
    #   - OR Policy excludes BG users individually (excludeUsers) with no extra groups excluded
    # This provides flexibility for customers who exclude BG accounts by user ID rather than group
    
    $validPolicies = @(Test-CommonFilters -policy $caps -FirstBreakGlassID $FirstBreakGlassID -SecondBreakGlassID $SecondBreakGlassID)
    Write-Host "Policies passing common filters: $($validPolicies.Count)"
    
    if ($validPolicies.Count -gt 0){
        if ($commonBGGroups.Count -gt 0){
            # Both BG accounts share at least one group - accept either group exclusion OR user exclusion with no extra groups
            $validPolicies = @($validPolicies | Where-Object {
                # Option 1: Policy excludes at least one of the common BG groups
                $policyExcludesCommonGroup = $false
                foreach ($bgGroup in $commonBGGroups) {
                    if ($_.conditions.users.excludeGroups -contains $bgGroup) {
                        $policyExcludesCommonGroup = $true
                        break
                    }
                }
                # Also verify excludeGroups only contains BG groups (no extra groups)
                $onlyBGGroupsExcluded = $true
                if (-not (Test-IsNullOrEmptyArray $_.conditions.users.excludeGroups)) {
                    foreach ($excludedGroup in $_.conditions.users.excludeGroups) {
                        if ($commonBGGroups -notcontains $excludedGroup) {
                            $onlyBGGroupsExcluded = $false
                            break
                        }
                    }
                }
                
                ($policyExcludesCommonGroup -and $onlyBGGroupsExcluded) -or
                # Option 2: Policy excludes BG users individually (already validated in Test-CommonFilters)
                #           and has no excludeGroups (to avoid excluding additional users unintentionally)
                (Test-IsNullOrEmptyArray $_.conditions.users.excludeGroups)
            })
            Write-Host "Policies after BG exclusion check (group or user): $($validPolicies.Count)"
        }
        else{
            # BG accounts do not share any group - excludeGroups must be empty
            $validPolicies = @($validPolicies | Where-Object {
                (Test-IsNullOrEmptyArray $_.conditions.users.excludeGroups)
            })
            Write-Host "Policies after excludeGroups empty check: $($validPolicies.Count)"
        }
    }


    Write-Host "validPolicies.count: $($validPolicies.count)"
    if ($validPolicies.Count -gt 0){
        $IsCompliantPasswordCAP = $true
    }
    else {
        # Failed. Reason: No policies meet the requirements
        $IsCompliantPasswordCAP = $false
    }

    if ($IsCompliantPasswordCAP -eq $true){
        $IsCompliant = $IsCompliantPasswordCAP
        $Comments = $msgTable.isCompliant + " " + $msgTable.compliantC1
    }
    else{
        $Comments = $msgTable.isNotCompliant + " " + $msgTable.nonCompliantC1
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        Comments         = $Comments
        ItemName         = $ItemName
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    # Add profile information if MCUP feature is enabled
    if ($EnableMultiCloudProfiles) {
        $result = Add-ProfileInformation -Result $PsObject -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subscriptionId -ErrorList $ErrorList
        Write-Host "$result"
    }

    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput
}
# SIG # Begin signature block
# MIIxfgYJKoZIhvcNAQcCoIIxbzCCMWsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDzy99nzSCm5oNJ
# gtM0c6SMxr6xBz9muYD5d/7AxR9sgKCCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0eMIIdGgIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# 5xfg2QFZoLtF+dmXQsJ931eTCyPFjMY/YLUaUDlv2cwwDQYJKoZIhvcNAQEBBQAE
# ggIAAQrzcQJ3V62WqA5Q9Q3BciTErZ8fP+JJ5N3zpYrgUWBix7IWPtr9xP2uMFRt
# 8G+8gNTnoD7R4OM7D56xH4vFo2QEdlvdplrjlQfHgGbwhlkrMS2ji9uZmpAd2c8M
# /x0StENBU1K2OhG+VsDSof9G4lWVQWyne53+qbW4j0rnnG90DB065hNy31fHpiZE
# 5AVSMpK2WpsYYVtfNmgVLAce9vybv98VkoL5PCl/izPOy5gD/rVM2oag/WFrGw9G
# AJRm56J37uW26Nw2zl3CYpB7yf1fP97/Et9HBJkwAPnVc7U0W8vG3W6PXQUJHLHf
# NIqUd37NZ5yNExTZemhH4xjzfcnUVe8bop5Mljb2El6rZBwJsha8H+FdW4D6cB9B
# uufrNCz1/Hkq6QNpzUDmdmFLcYN1I8yxQ6LOPuDIjPAUPBU5DSNqozRPOMYjCmEU
# dYHjoXIuIq2DckPvC4VdAgcIB+i8PYttmMbohGzNTzTFwmj0/R2jqEMbtDuiEhW8
# DYkrdXPt7f13XbPeEX8eUeamnipRW+daA0wFCos9m0MQcQ+hsrqHhJmdRabP5Tyc
# Tc8xx7uBdpk8y7w4RCdsPYa1vM1FeBR1duus5jaT/TcXmPRkrcvUVYSXNpdpTJOS
# 988bbCHd7wtIJ5TWQViGrkFEs2zxGrD/Mr69KsQ+sEPDhtuhghnrMIIZ5wYKKwYB
# BAGCNwMDATGCGdcwghnTBgkqhkiG9w0BBwKgghnEMIIZwAIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH3BgsqhkiG9w0BCRABBKCB5wSB5DCB4QIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCBtqI2DZz4Ahpj4s0EXU1b/lpjnVTDLpgF2PeZ3MSIv
# egIUJh1yDUtHQIe8ZK3vdxjq7lcvxRsYDzIwMjYwNzIxMTc0NTU3WqB2pHQwcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDkdyZWF0ZXIgTG9uZG9uMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzN6CCFBcwggbiMIIEyqADAgECAhEA507yVbBQT/rbpt/3
# /IujFTANBgkqhkiG9w0BAQwFADBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIENBIFI0MTAeFw0yNjAzMjUwMDAwMDBaFw0zNzA2MjQyMzU5NTlaMHIxCzAJ
# BgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIFNpZ25lciBSMzcwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCy
# /8NtS9xQ2UUtBRF32bj7VK3n4m50Uqjk/zTciSziYV40H1LKah0/oEklYG42E4VC
# P3DvsBUB6DmpCkDZ0jCnZBPIEevaH15ZJOQwFWP2ZXr5YjlJpb68Nlbs+ElNvKx3
# 2/1YHde3qqUSLybjulxPLz6T85+HOIqK7M1Bep8LspyhEP/q6nw5kGxTSrGvufme
# H+JF8CnVBcVMFA40FlIYh0cDJVFhhfTfdWgLy/vWuLMQoKkf3s/FvByf16r0rtby
# Hm/iemwxSioJL9zyZDDKUNAbHXl0dhXo2VxUV2NcPXWXuoKsjL+6cfk6Vm2DHnxA
# lFdFsaBDIF1JOkSnC6PeLlBznZn2buF3vIIYJcq6N/zeFRCk4/HXDz7zgRsRRMdU
# B+rhyk5FoZaBjw0nLq3GZ3fClLUx5es5pUAxzNODMBn7JkFYip2BAGBPER5eV0RO
# hk6tGTG+fUiMiV+vgjg1YnP5FvnYWyEtWeQD/B2hp3vz0RvtdkM0p3igyadzrfpO
# Bq5ppVk/YsuhTQkP99ivneHAGfi5e7lmxJ+meoBPrRLuzMmb81rzzbESjJHMsn5R
# Vtc6Ucs7rcMqQC13PUIO7BbGBETV2ufCmV6lPTp3P7XJOvmnUCRTPbVvMTpxP/z+
# SOHg4/OCBhiqs4FA9+4oQvlkk9w32NGASli9GWrm5wIDAQABo4IBjjCCAYowHwYD
# VR0jBBgwFoAUOnSlDGfGQlDC/bX8x7spNIL0erkwHQYDVR0OBBYEFGEQ6XoSr1HE
# hdTyz6R0D1DNIK/4MA4GA1UdDwEB/wQEAwIGwDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEoGA1UdIARDMEEwCAYGZ4EMAQQCMDUGDCsGAQQB
# sjEBAgEDCDAlMCMGCCsGAQUFBwIBFhdodHRwczovL3NlY3RpZ28uY29tL0NQUzBK
# BgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29Q
# dWJsaWNUaW1lU3RhbXBpbmdDQVI0MS5jcmwwegYIKwYBBQUHAQEEbjBsMEUGCCsG
# AQUFBzAChjlodHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1l
# U3RhbXBpbmdDQVI0MS5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
# Z28uY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAD6j2N0azN+hl6k6bKB5/U6VuSOs93
# ZBb3Pczy9VtBIKu4947Z5GwL0aFngIxl+GSuLFrJgPruBCRvKJEJsm7kv+LQ1COV
# CEG9tZ+IRtr4ocUoa53lgdFaENlS0N4wgkZkbQEPv+x+1lSjYh+T4JeL9mUznT7E
# rc6Sp5dWLka5sMP/m3GZi6oJPdPcsCKWagH7m2H2xDGIyHJC5PdH9phvi/Kmhkkt
# iSVTNNqVeV5bWdX2zhRE6UTfz0IcMoCL996lFIydXxOCE4MNDHDM0as4lnTiT/KH
# MccO6l8c9TnUVgmpci9ar1IABZ2U1XUkYjGGSn9MC3EHDP9V39VuBVvZ33/BEV/E
# WSRrf07T7jFplKX+gQr/UOqPGMlE7ZJ72UaUkNJy7bVl3bcLKzdpjIHzLkf/4MVa
# 1V7w8wqCv5W4gOnRGTlud5UMARbRM8BPxR/CXYXoMmIOD8pmTk2axgRL4LG8Xtuc
# hISdCHRmtacAmLGq5XSYSVTHTXADlO48iDKh3HM2r98LSF6f0sG12d8V9Jn7C3wD
# UieOxuKj4MdWrW+hiJU2kF87v6eH00HgCFFc2V0+CvfOCMn7juzS41jLaINcBlKW
# Q/fKb/uDLfWOW73z1I2lFY7Xj8tQ1XYtK5eREjWItM8jpl1cbQOc88btR+0XS2Tm
# boE/141+va2PWzCCBqcwggSPoAMCAQICEQCQrAhyIP3Fp8RrXMcN9z0GMA0GCSqG
# SIb3DQEBDAUAMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0
# ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBS
# NDYwHhcNMjYwMzI1MDAwMDAwWhcNNDEwMzI0MjM1OTU5WjBVMQswCQYDVQQGEwJH
# QjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1
# YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAK7kSqIBrYIcYvlmLVuaA8zw1RfBhkn4G1CoemzjcYtML6yNUvKm
# wGH7y6/5MuSC1UYP/+9KYDSqvMQt/1hEKHYxMAD9oZpBkoaDQFEKbOJHelsKe+Ba
# O0ZcENTKfePcraVkA7wrGAW2XHA5gQCQv4IKori/3PNOXxnDMOk8yIMgVrlMeTxq
# fWJ4XkjT1xc2s9DD7URHWWJOFobTPoWs6mrDFlaY9FlAHDYTfbzvxQHVsvRmn3W+
# 5ZmCwyk02I8KgGPT/UX4sTz41GiR+ppwUjQXa1+2tEHZbsdAKUtH3OPEVtZvlt7a
# tx4h83IdRR8oYi8wjY3OjFKXFecWpQbzzsPxbUKPwMWiTrzwkrFa8dH/1pDKRJt3
# 71W62PfqKPayCr/XbnBOlRn8CALSmHnRtGzuAWtTJpcT3BKw6oy8IIL6wSbu938F
# 6ZIbRNIc1dKbIJtr4ULN6R5ZfTdNEhwXctqp3RHDbg4fuOl6LjNoaFwjud92EEDh
# zxFJzE1jqN4csceZIwxOT1aqfsfh0uFQE/lgTBuBs3i6/WL2W1OceWLy3XEdXRK1
# f0EWCuea6dNfX2RRdjUfk5EltFnJkN2+bWhnK14OPRKcyjOv5hKZ0iV4NRNd1+hj
# tva1rPyzb5Bs7EvFxqEQhgZbOq7qH3nm0rBwA0dxniBOYCFPdu246JCxAgMBAAGj
# ggFuMIIBajAfBgNVHSMEGDAWgBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAdBgNVHQ4E
# FgQUOnSlDGfGQlDC/bX8x7spNIL0erkwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwIwYDVR0gBBwwGjAIBgZn
# gQwBBAIwDgYMKwYBBAGyMQECAQMIMEwGA1UdHwRFMEMwQaA/oD2GO2h0dHA6Ly9j
# cmwuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYu
# Y3JsMHwGCCsGAQUFBwEBBHAwbjBHBggrBgEFBQcwAoY7aHR0cDovL2NydC5zZWN0
# aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0YW1waW5nUm9vdFI0Ni5wN2MwIwYI
# KwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29tMA0GCSqGSIb3DQEBDAUA
# A4ICAQAy3lJHZvGeA2b43yhzoarvobHVzbfl+RfuPDwej0wCQkYAN6scTt2GwFe2
# 2qbOCv/tllqFlLKQZE+E9jVyuPTbyQHwrM7R0oLapAEDC1+CowsqSRf/ptira5Pf
# d4PoHICnb9coPQtyZmHSQp5y9IGvqWf1qNfq7V2fHZ8DvEQrLUzeoGF9BJRYu2Oz
# acW3QQtUum3NOVf0gPRwv6I4991uhncJ6VP4lcpUpHZKB7R3hiIUC09mR9KjzPVn
# XHvL9n2bAwiUECfK5Zezhiw27F2tgi39DETfU8M4n0N6xLgFzsf05M5GURX8C9+I
# X9V6kpmmKtrUzMti4LD66gtmf+mSm934K81NL6YQeMEk1rpYrWPypcW76Mir6wb1
# AgseLIHqn/GkeuQm7zOTDf3f5WoX14qVNjZWNHF3JxkutV6ZnhinfCLfdv5bnwKW
# UfceqOajCVntI6uCbHxjBg6SCsexc5AfIGno7gVFvwifT4XONPsSUaJ71XsJ+Evc
# iVUVnjOO4qxm0fWJTd8a7jP8mc4ZPqwJvQFtOp7+6G+kUJAF0fnE8YgD8uttBReN
# Ta1YmAeFMiqc38e8fI4eLm0zjM/eeGCHasnoqqrbGwcF41iz9HXzFDwN4iD5z3QS
# hp6HRiU3UpTwDJiiXcr0z6pjl7PyzJ3/tmWtGehV7CAfc/WlyzCCBoIwggRqoAMC
# AQICEDbCsL18Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTIxMDMyMjAwMDAwMFoX
# DTM4MDExODIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28g
# TGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBS
# b290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAIid2LlFZ50d
# 3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYsyAhTXiDQkiUvpVdYqZ1u
# YoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXVydmhx7Dx4IBrAou7hNGs
# KioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjthgF7Hjx4vvyVDQGsd5Ka
# rLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1gASn/hp6IuHJorEu6Eop
# oB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35ZvxQw6zid61qmrlD/IbKJA
# 6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6KdOpuzVDR3ZUwxDKL1wCA
# xgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhLRPb7YkzM8/6NnWH3T9Cl
# mcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb49zYHr7ALL8bAJyPDmub
# NqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRKKsxCG1t6tG9oj7liwPdd
# XEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5e45NuzAHteORlsSuDt5t
# 4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjggEWMIIBEjAfBgNVHSMEGDAW
# gBRTeb9aqitKz1SA4dibwJ3ysgNmyzAdBgNVHQ4EFgQU9ndq3T/9ARP/FqFsggIv
# 0Ao9FCUwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wEwYDVR0lBAww
# CgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMFAGA1UdHwRJMEcwRaBDoEGG
# P2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9VU0VSVHJ1c3RSU0FDZXJ0aWZpY2F0
# aW9uQXV0aG9yaXR5LmNybDA1BggrBgEFBQcBAQQpMCcwJQYIKwYBBQUHMAGGGWh0
# dHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcNAQEMBQADggIBAA6+ZUHt
# aES45aHF1BGH5Lc7JYzrftrIF5Ht2PFDxKKFOct/awAEWgHQMVHol9ZLSyd/pYMb
# aC0IZ+XBW9xhdkkmUV/KbUOiL7g98M/yzRyqUOZ1/IY7Ay0YbMniIibJrPcgFp73
# WDnRDKtVutShPSZQZAdtFwXnuiWl8eFARK3PmLqEm9UsVX+55DbVIz33Mbhba0HU
# TEYv3yJ1fwKGxPBsP/MgTECimh7eXomvMm0/GPxX2uhwCcs/YLxDnBdVVlxvDjHj
# O1cuwbOpkiJGHmLXXVNbsdXUC2xBrq9fLrfe8IBsA4hopwsCj8hTuwKXJlSTrZcP
# RVSccP5i9U28gZ7OMzoJGlxZ5384OKm0r568Mo9TYrqzKeKZgFo0fj2/0iHbj55h
# c20jfxvK3mQi+H7xpbzxZOFGm/yVQkpo+ffv5gdhp+hv1GDsvJOtJinJmgGbBFZI
# ThbqI+MHvAmMmkfb3fTxmSkop2mSJL1Y2x/955S29Gu0gSJIkc3z30vU/iXrMpWx
# 2tS7UVfVP+5tKuzGtgkP7d/doqDrLF1u6Ci3TpjAZdeLLlRQZm867eVeXED58LXd
# 1Dk6UvaAhvmWYXoiLz4JA5gPBcz7J311uahxCweNxE+xxxR3kT0WKzASo5G/PyDe
# z6NHdIUKBeE3jDPs2ACc6CkJ1Sji4PKWVT0/MYIEkzCCBI8CAQEwajBVMQswCQYD
# VQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0
# aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MQIRAOdO8lWwUE/626bf9/yL
# oxUwDQYJYIZIAWUDBAICBQCgggH6MBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAcBgkqhkiG9w0BCQUxDxcNMjYwNzIxMTc0NTU3WjA/BgkqhkiG9w0BCQQxMgQw
# /4ulu7/YLofB/H8l1mYh6C2AL48do1rHZA4BaPSpM9aiFdtf1fpGGApAxW0rzSUg
# MIIBewYLKoZIhvcNAQkQAgwxggFqMIIBZjCCAWIwFgQU6XgYqSjaFQqf4b+czHqr
# uaAO7qwwgYgEFGXDKGlvfU5QLP0Dx8IGlxjK+/dPMHAwW6RZMFcxCzAJBgNVBAYT
# AkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28g
# UHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBSNDYCEQCQrAhyIP3Fp8RrXMcN9z0G
# MIG8BBSFPWMtk4KCYXzQkDXEkd6SwULaxzCBozCBjqSBizCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0plcnNleSBDaXR5MR4w
# HAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNVBAMTJVVTRVJUcnVz
# dCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkCEDbCsL18Gzrno7PdNsvJdWgw
# DQYJKoZIhvcNAQEBBQAEggIAKRu+hgYk2ZP/P/9zrz7CD1OQWAcQRD9Gz8wk/9H6
# 1E1JfnTmXqvyBKb7aKNT2ntgElqVMNZ2c4J4QMVgRhMBUHz+ugvQ3e7PQ942iLu4
# GnMZJ2XCGjD4lyuJADubWzwHLOcpyT8vgGC/TZflWnqaUN8m0HAB2754TT1Hr7hJ
# NhVRV9tzUAAWCncQU9UEruLOFSDZ4mB1sCHabN2RpX66maLeFB30g5F2hheQyGEx
# RY0edzsjx/J2SCQq7HUjCdHbQ3qH2nqHeUL0APsLp9nBmiMAua3tN7DVErcT/xSa
# NGGsMyFs3e8haju7E03ap879mOa/bnZzl+1Osb9CZT6/lKyBZxTV6movL2rZkCSY
# Tt3EK9AXbSRk6ngGrl6REOeZnNhVXTVzAX5RMgEQFDZfarPPGhh1qrH2fzYYugR1
# GQQjmmZHE4Ce3UYARorq6P2JXRBuE6yJ5OYAOXXGQTRV50rZOtnr8xRCMQNo9+hu
# +WffCTKqOtvdJzoQpUgNx37PoDZoYA1ZFlBF1dUQBzpcB4yYNa7Fik0EmTaPt72u
# 1l1tEQtYMPrIcHo1hP5DMgW1RSdfmac0ZQLE8cNzOIM2rwvbin14rqjRN3jyo/ZF
# bEEsjNaHp6YmucyR++iC821tVWaLPXNBe7YwmLzqQeYE1ULJ4QiF4uncpRu/SZ57
# PQk=
# SIG # End signature block

function Get-NetworkWatcherStatus {
    param (
        [Parameter(Mandatory=$false)]
        [string]
        $token,
        [Parameter(Mandatory=$true)]
        [string]
        $ControlName,
        [string] $itsgcode,
        [Parameter(Mandatory=$false)]
        [string]
        $ExcludedVNets,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory=$true)]
        [string]
        $CBSSubscriptionName,
        [Parameter(Mandatory=$false)]
        [switch]
        $debuginfo,
        [string] 
        $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false    
    )
    $evalResult = $null
    $ExcludeVnetTag="GR9-ExcludeVNetFromCompliance"
    [System.Collections.ArrayList]$RegionList = @()
    [System.Collections.ArrayList]$ErrorList = @()


    try {
        $subs=Get-AzSubscription -ErrorAction Stop | Where-Object {$_.State -eq 'Enabled'}  
    }
    catch {
        $ErrorList.Add("Failed to execute the 'Get-AzSubscription' command--verify your permissions and the installion of the Az.Accounts module; returned error message: $_" )
        throw "Error: Failed to execute the 'Get-AzSubscription'--verify your permissions and the installion of the Az.Accounts module; returned error message: $_"                
    }
    if ($null -ne $ExcludedVNets)
    {
        $ExcludedVNetsList=$ExcludedVNets.Split(",")
    }
    foreach ($sub in $subs)
    {
        Write-Verbose "Selecting subscription..."
        Select-AzSubscription -SubscriptionObject $sub | Out-Null

        if ($EnableMultiCloudProfiles) {        
            $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $sub.Id
        }

        $allVNETs=Get-AzVirtualNetwork
        $includedVNETs=$allVNETs | Where-Object { $_.Tag.$ExcludeVnetTag -ine 'true' -and $_.Name -notin $ExcludedVNetsList }
        Write-Debug "Found $($allVNETs.count) VNets total; $($includedVNETs.count) not excluded by tag or -ExcludedVNets parameter."

        $nonExcludedVnetRegions = @()
        if ($includedVNETs.count -gt 0)
        {
            foreach ($VNet in $includedVNETs)
            {
                Write-Debug "Working on VNET '$($VNet.Name)'..."
                # add vnet region to regions list - used in checking for network watcher in that region
                $nonExcludedVnetRegions += $VNet.Location  
            }

            # check if network watcher is enabled in the region
            $comments = $null
            $ComplianceStatus = $true
            ForEach ($region in ($nonExcludedVnetRegions | Get-Unique)) {
                $nw = Get-AzNetworkWatcher -Location $region -ErrorAction SilentlyContinue
                if ($nw) {
                    $Comments = $msgTable.networkWatcherEnabled -f $region
                }
                else {
                    $ComplianceStatus = $false
                    $Comments = $msgTable.networkWatcherNotEnabled -f $region
                }
                # Create PSOBject with Information.
                $RegionObject = [PSCustomObject]@{ 
                    SubscriptionName  = $sub.Name 
                    ComplianceStatus = $ComplianceStatus
                    Comments = $Comments
                    ItemName = $msgTable.networkWatcherConfig
                    itsgcode = $itsgcode
                    ControlName = $ControlName
                    ReportTime = $ReportTime
                }
                if ($EnableMultiCloudProfiles -and $null -ne $evalResult) {
                    Add-ProfileEvaluationResult -RegionObject $RegionObject -evalResult $evalResult -ErrorList $ErrorList
                }
                $RegionList.Add($RegionObject) | Out-Null
            }
        }
        else {
            $ComplianceStatus = $true
            $RegionObject = [PSCustomObject]@{ 
                SubscriptionName  = $sub.Name 
                ComplianceStatus = $ComplianceStatus
                Comments = $msgTable.networkWatcherConfigNoRegions
                ItemName = $msgTable.networkWatcherConfig
                itsgcode = $itsgcode
                ControlName = $ControlName
                ReportTime = $ReportTime
            }
            if ($EnableMultiCloudProfiles -and $null -ne $evalResult) {
                Add-ProfileEvaluationResult -RegionObject $RegionObject -evalResult $evalResult -ErrorList $ErrorList
            }
            $RegionList.Add($RegionObject) | Out-Null
        }
    }
    if ($debuginfo){ 
        Write-Output "Listing $($RegionList.Count) List members."
    }
    #Creates Results object:
    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $RegionList 
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput
}

function Add-ProfileEvaluationResult {
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$RegionObject,
                
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$evalResult,
        
        [Parameter(Mandatory=$true)]
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )
    
    if (!$evalResult.ShouldEvaluate) {
        if(!$evalResult.ShouldAvailable ){
            if ($evalResult.Profile -gt 0) {
                $RegionObject.ComplianceStatus = "Not Applicable"
                $RegionObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $RegionObject.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration availability")
            }
        } else {
            if ($evalResult.Profile -gt 0) {
                $RegionObject.ComplianceStatus = "Not Applicable"
                $RegionObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $RegionObject.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        }
    }
    else {
        $RegionObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
    }
}


# SIG # Begin signature block
# MIIwagYJKoZIhvcNAQcCoIIwWzCCMFcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBTkOlmFHGofy74
# V3Lnu5sPQcJtSbfYkqLwAibAUnRIS6CCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxghwKMIIcBgIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# g9yOVsXrRCo6E58D3fpv2cpP99JkttKvN68HAwfQP5gwDQYJKoZIhvcNAQEBBQAE
# ggIAcHSsrXAJWDHsF2E+N0lOFx5HVdGwxFvRsdsrr4OOz9ab1+FwLweKcAz465cM
# IPflD3g/GtWe9yVbkd8vECUqTZ1MkoTi56L49IFEj05YA5AwubYd3VXM6PteB+Y3
# 2MLGKJSL9TVyGEBYS4bBvfY5rJ7DFKxenaIGN+AE3Fnwbgx6D1nmpOf58OXWsPfD
# FawhsPpiXMzgdQDHeFZ2eRLClrLkLlHosF71rFEULpl5NfYSzqaLj+hiMPdbGRc7
# 2+mBc6j6MwRh1ngbqI5CkaUaExWNX5gDPa9aX9RZ4w55choV9QHpFALXAzGk98ZQ
# dafa7x6RRMt5i20ioBlSGVBNIrI4a8WWI00ZRR9AR6rFlAnZ0hr+Il0QPsD2Z9Qd
# 2dufgMI8IGLVEYnYWLONwmLNWEEllT+ehPLm5EVP5XVuMyPZrq4f179Qu7hv9GwG
# imSJ66r7KGbFNuyjhsB1LPHElWZm6fjXM2HyEl760VjMiSGgqiwBLK5IK2mQcV5l
# k7vu0n82/K3KcFJXZ6UxPYS/E3y6Znw/FwqFOKkmCbZyPO/q13Zh+nDREfnMT9Bz
# 11Qd2ro5TT1jeoQvbZuLcX0cYkd6HZpB0kPYecp3LYf6l7WBpKUHcSyEnpxoTLf6
# CygoDAor3T8be4mgs7xx0ERxOl+DnbojclGeMDIllVt0XfOhghjXMIIY0wYKKwYB
# BAGCNwMDATGCGMMwghi/BgkqhkiG9w0BBwKgghiwMIIYrAIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH3BgsqhkiG9w0BCRABBKCB5wSB5DCB4QIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCBJG/lmrxGYoUT9+IjYWQzMJT0mFHeadb7Ni1HqT7Wv
# XgIUafxk+MZlmnWnFhTjT8cLn33n2eoYDzIwMjYwMjE4MjAzNzQ2WqB2pHQwcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDldlc3QgWW9ya3NoaXJlMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzNqCCEwQwggZiMIIEyqADAgECAhEApCk7bh7d16c0CIet
# ek63JDANBgkqhkiG9w0BAQwFADBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIENBIFIzNjAeFw0yNTAzMjcwMDAwMDBaFw0zNjAzMjEyMzU5NTlaMHIxCzAJ
# BgNVBAYTAkdCMRcwFQYDVQQIEw5XZXN0IFlvcmtzaGlyZTEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIFNpZ25lciBSMzYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDT
# hJX0bqRTePI9EEt4Egc83JSBU2dhrJ+wY7JgReuff5KQNhMuzVytzD+iXazATVPM
# HZpH/kkiMo1/vlAGFrYN2P7g0Q8oPEcR3h0SftFNYxxMh+bj3ZNbbYjwt8f4DsSH
# PT+xp9zoFuw0HOMdO3sWeA1+F8mhg6uS6BJpPwXQjNSHpVTCgd1gOmKWf12HSfSb
# njl3kDm0kP3aIUAhsodBYZsJA1imWqkAVqwcGfvs6pbfs/0GE4BJ2aOnciKNiIV1
# wDRZAh7rS/O+uTQcb6JVzBVmPP63k5xcZNzGo4DOTV+sM1nVrDycWEYS8bSS0lCS
# eclkTcPjQah9Xs7xbOBoCdmahSfg8Km8ffq8PhdoAXYKOI+wlaJj+PbEuwm6rHcm
# 24jhqQfQyYbOUFTKWFe901VdyMC4gRwRAq04FH2VTjBdCkhKts5Py7H73obMGrxN
# 1uGgVyZho4FkqXA8/uk6nkzPH9QyHIED3c9CGIJ098hU4Ig2xRjhTbengoncXUeo
# /cfpKXDeUcAKcuKUYRNdGDlf8WnwbyqUblj4zj1kQZSnZud5EtmjIdPLKce8UhKl
# 5+EEJXQp1Fkc9y5Ivk4AZacGMCVG0e+wwGsjcAADRO7Wga89r/jJ56IDK773LdIs
# L3yANVvJKdeeS6OOEiH6hpq2yT+jJ/lHa9zEdqFqMwIDAQABo4IBjjCCAYowHwYD
# VR0jBBgwFoAUX1jtTDF6omFCjVKAurNhlxmiMpswHQYDVR0OBBYEFIhhjKEqN2SB
# KGChmzHQjP0sAs5PMA4GA1UdDwEB/wQEAwIGwDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEoGA1UdIARDMEEwNQYMKwYBBAGyMQECAQMIMCUw
# IwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGlnby5jb20vQ1BTMAgGBmeBDAEEAjBK
# BgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29Q
# dWJsaWNUaW1lU3RhbXBpbmdDQVIzNi5jcmwwegYIKwYBBQUHAQEEbjBsMEUGCCsG
# AQUFBzAChjlodHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1l
# U3RhbXBpbmdDQVIzNi5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
# Z28uY29tMA0GCSqGSIb3DQEBDAUAA4IBgQACgT6khnJRIfllqS49Uorh5ZvMSxNE
# k4SNsi7qvu+bNdcuknHgXIaZyqcVmhrV3PHcmtQKt0blv/8t8DE4bL0+H0m2tgKE
# lpUeu6wOH02BjCIYM6HLInbNHLf6R2qHC1SUsJ02MWNqRNIT6GQL0Xm3LW7E6hDZ
# mR8jlYzhZcDdkdw0cHhXjbOLsmTeS0SeRJ1WJXEzqt25dbSOaaK7vVmkEVkOHsp1
# 6ez49Bc+Ayq/Oh2BAkSTFog43ldEKgHEDBbCIyba2E8O5lPNan+BQXOLuLMKYS3i
# kTcp/Qw63dxyDCfgqXYUhxBpXnmeSO/WA4NwdwP35lWNhmjIpNVZvhWoxDL+PxDd
# pph3+M5DroWGTc1ZuDa1iXmOFAK4iwTnlWDg3QNRsRa9cnG3FBBpVHnHOEQj4GMk
# rOHdNDTbonEeGvZ+4nSZXrwCW4Wv2qyGDBLlKk3kUW1pIScDCpm/chL6aUbnSsrt
# bepdtbCLiGanKVR/KC1gsR0tC6Q0RfWOI4owggYUMIID/KADAgECAhB6I67aU2mW
# D5HIPlz0x+M/MA0GCSqGSIb3DQEBDAUAMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQK
# Ew9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUg
# U3RhbXBpbmcgUm9vdCBSNDYwHhcNMjEwMzIyMDAwMDAwWhcNMzYwMzIxMjM1OTU5
# WjBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYD
# VQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFIzNjCCAaIwDQYJ
# KoZIhvcNAQEBBQADggGPADCCAYoCggGBAM2Y2ENBq26CK+z2M34mNOSJjNPvIhKA
# VD7vJq+MDoGD46IiM+b83+3ecLvBhStSVjeYXIjfa3ajoW3cS3ElcJzkyZlBnwDE
# JuHlzpbN4kMH2qRBVrjrGJgSlzzUqcGQBaCxpectRGhhnOSwcjPMI3G0hedv2eNm
# GiUbD12OeORN0ADzdpsQ4dDi6M4YhoGE9cbY11XxM2AVZn0GiOUC9+XE0wI7CQKf
# OUfigLDn7i/WeyxZ43XLj5GVo7LDBExSLnh+va8WxTlA+uBvq1KO8RSHUQLgzb1g
# bL9Ihgzxmkdp2ZWNuLc+XyEmJNbD2OIIq/fWlwBp6KNL19zpHsODLIsgZ+WZ1AzC
# s1HEK6VWrxmnKyJJg2Lv23DlEdZlQSGdF+z+Gyn9/CRezKe7WNyxRf4e4bwUtrYE
# 2F5Q+05yDD68clwnweckKtxRaF0VzN/w76kOLIaFVhf5sMM/caEZLtOYqYadtn03
# 4ykSFaZuIBU9uCSrKRKTPJhWvXk4CllgrwIDAQABo4IBXDCCAVgwHwYDVR0jBBgw
# FoAU9ndq3T/9ARP/FqFsggIv0Ao9FCUwHQYDVR0OBBYEFF9Y7UwxeqJhQo1SgLqz
# YZcZojKbMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAGAQH/AgEAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBMBgNVHR8ERTBDMEGg
# P6A9hjtodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3Rh
# bXBpbmdSb290UjQ2LmNybDB8BggrBgEFBQcBAQRwMG4wRwYIKwYBBQUHMAKGO2h0
# dHA6Ly9jcnQuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jv
# b3RSNDYucDdjMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0aWdvLmNvbTAN
# BgkqhkiG9w0BAQwFAAOCAgEAEtd7IK0ONVgMnoEdJVj9TC1ndK/HYiYh9lVUacah
# RoZ2W2hfiEOyQExnHk1jkvpIJzAMxmEc6ZvIyHI5UkPCbXKspioYMdbOnBWQUn73
# 3qMooBfIghpR/klUqNxx6/fDXqY0hSU1OSkkSivt51UlmJElUICZYBodzD3M/SFj
# eCP59anwxs6hwj1mfvzG+b1coYGnqsSz2wSKr+nDO+Db8qNcTbJZRAiSazr7KyUJ
# Go1c+MScGfG5QHV+bps8BX5Oyv9Ct36Y4Il6ajTqV2ifikkVtB3RNBUgwu/mSiSU
# ice/Jp/q8BMk/gN8+0rNIE+QqU63JoVMCMPY2752LmESsRVVoypJVt8/N3qQ1c6F
# ibbcRabo3azZkcIdWGVSAdoLgAIxEKBeNh9AQO1gQrnh1TA8ldXuJzPSuALOz1Uj
# b0PCyNVkWk7hkhVHfcvBfI8NtgWQupiaAeNHe0pWSGH2opXZYKYG4Lbukg7HpNi/
# KqJhue2Keak6qH9A8CeEOB7Eob0Zf+fU+CCQaL0cJqlmnx9HCDxF+3BLbUufrV64
# EbTI40zqegPZdA+sXCmbcZy6okx/SjwsusWRItFA3DE8MORZeFb6BmzBtqKJ7l93
# 9bbKBy2jvxcJI98Va95Q5JnlKor3m0E7xpMeYRriWklUPsetMSf2NvUQa/E5vVye
# fQIwggaCMIIEaqADAgECAhA2wrC9fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBDAUA
# MIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxML
# SmVyc2V5IENpdHkxHjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwG
# A1UEAxMlVVNFUlRydXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0y
# MTAzMjIwMDAwMDBaFw0zODAxMTgyMzU5NTlaMFcxCzAJBgNVBAYTAkdCMRgwFgYD
# VQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRp
# bWUgU3RhbXBpbmcgUm9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCIndi5RWedHd3ouSaBmlRUwHxJBZvMWhUP2ZQQRLRBQIF3FJmp1OR2LMgI
# U14g0JIlL6VXWKmdbmKGRDILRxEtZdQnOh2qmcxGzjqemIk8et8sE6J+N+Gl1cnZ
# ocew8eCAawKLu4TRrCoqCAT8uRjDeypoGJrruH/drCio28aqIVEn45NZiZQI7YYB
# ex48eL78lQ0BrHeSmqy1uXe9xN04aG0pKG9ki+PC6VEfzutu6Q3IcZZfm00r9YAE
# p/4aeiLhyaKxLuhKKaAdQjRaf/h6U13jQEV1JnUTCm511n5avv4N+jSVwd+Wb8UM
# Os4netapq5Q/yGyiQOgjsP/JRUj0MAT9YrcmXcLgsrAimfWY3MzKm1HCxcquinTq
# bs1Q0d2VMMQyi9cAgMYC9jKc+3mW62/yVl4jnDcw6ULJsBkOkrcPLUwqj7poS0T2
# +2JMzPP+jZ1h90/QpZnBkhdtixMiWDVgh60KmLmzXiqJc6lGwqoUqpq/1HVHm+Pc
# 2B6+wCy/GwCcjw5rmzajLbmqGygEgaj/OLoanEWP6Y52Hflef3XLvYnhEY4kSirM
# QhtberRvaI+5YsD3XVxHGBjlIli5u+NrLedIxsE88WzKXqZjj9Zi5ybJL2WjeXuO
# TbswB7XjkZbErg7ebeAQUQiS/uRGZ58NHs57ZPUfECcgJC+v2wIDAQABo4IBFjCC
# ARIwHwYDVR0jBBgwFoAUU3m/WqorSs9UgOHYm8Cd8rIDZsswHQYDVR0OBBYEFPZ3
# at0//QET/xahbIICL9AKPRQlMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTAD
# AQH/MBMGA1UdJQQMMAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBQBgNV
# HR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLnVzZXJ0cnVzdC5jb20vVVNFUlRydXN0
# UlNBQ2VydGlmaWNhdGlvbkF1dGhvcml0eS5jcmwwNQYIKwYBBQUHAQEEKTAnMCUG
# CCsGAQUFBzABhhlodHRwOi8vb2NzcC51c2VydHJ1c3QuY29tMA0GCSqGSIb3DQEB
# DAUAA4ICAQAOvmVB7WhEuOWhxdQRh+S3OyWM637ayBeR7djxQ8SihTnLf2sABFoB
# 0DFR6JfWS0snf6WDG2gtCGflwVvcYXZJJlFfym1Doi+4PfDP8s0cqlDmdfyGOwMt
# GGzJ4iImyaz3IBae91g50QyrVbrUoT0mUGQHbRcF57olpfHhQEStz5i6hJvVLFV/
# ueQ21SM99zG4W2tB1ExGL98idX8ChsTwbD/zIExAopoe3l6JrzJtPxj8V9rocAnL
# P2C8Q5wXVVZcbw4x4ztXLsGzqZIiRh5i111TW7HV1AtsQa6vXy633vCAbAOIaKcL
# Ao/IU7sClyZUk62XD0VUnHD+YvVNvIGezjM6CRpcWed/ODiptK+evDKPU2K6syni
# mYBaNH49v9Ih24+eYXNtI38byt5kIvh+8aW88WThRpv8lUJKaPn37+YHYafob9Rg
# 7LyTrSYpyZoBmwRWSE4W6iPjB7wJjJpH29308ZkpKKdpkiS9WNsf/eeUtvRrtIEi
# SJHN899L1P4l6zKVsdrUu1FX1T/ubSrsxrYJD+3f3aKg6yxdbugot06YwGXXiy5U
# UGZvOu3lXlxA+fC13dQ5OlL2gIb5lmF6Ii8+CQOYDwXM+yd9dbmocQsHjcRPsccU
# d5E9FiswEqORvz8g3s+jR3SFCgXhN4wz7NgAnOgpCdUo4uDyllU9PzGCBJIwggSO
# AgEBMGowVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEs
# MCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSMzYCEQCk
# KTtuHt3XpzQIh616TrckMA0GCWCGSAFlAwQCAgUAoIIB+TAaBgkqhkiG9w0BCQMx
# DQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDIxODIwMzc0NlowPwYJ
# KoZIhvcNAQkEMTIEMEkVRRYn2O/fNnDJ5OUNoK745fu5mzEJbJnEOP15q12XFU4p
# ev8J/vRYXVVUhsaFhzCCAXoGCyqGSIb3DQEJEAIMMYIBaTCCAWUwggFhMBYEFDjJ
# FIEQRLTcZj6T1HRLgUGGqbWxMIGHBBTGrlTkeIbxfD1VEkiMacNKevnC3TBvMFuk
# WTBXMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYD
# VQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2AhB6I67a
# U2mWD5HIPlz0x+M/MIG8BBSFPWMtk4KCYXzQkDXEkd6SwULaxzCBozCBjqSBizCB
# iDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0pl
# cnNleSBDaXR5MR4wHAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNV
# BAMTJVVTRVJUcnVzdCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkCEDbCsL18
# Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEBBQAEggIAW6Arkdml7f5v/CW9PgHUCude
# GAA1Hu9CZoMjVLj6Mm2GtCGWRZKgNIj5DWTx/38HCV8sMfVX/e6o87RSFSrzRum1
# 9uRJaEuw3DSP/0sLIo6H/efn+7jQkatmiVvalSak3mbw6VMd7+DorQUEyfdTkF0+
# icwCt34NSmdLlYqpSxTKQO3Kgr3rOvPbrIaBFR0LcJN6f5tYL/N0Qa01b2DPhbxV
# PKI63qASled6zpCcOQbwH+yg15mj5Sn6WQhaR3A2WgHjOLHUb8hpA64KsBBK11d7
# ejECI2HFQs81l8kdftuTNG2kkVWI8hp7weNA0NomyZ+sQXKLf+9+eb8Rn9hyAm6g
# Hch8pwtWCqt0UW/PtycoZaP3y0zuQCfp0OWY4roHhFUdCBrgSZF97WcLKOm1tTjP
# lNnXTfBlr24/8l9B0THFvVkgB+h625OhYDt39P9n14q296lrtCb/nGaEDYf8P2T5
# h2+nuq7tjf9ESr7xdluaVSiznTb0scKRr86tn5Z6zx80DHwlp/B3TIOYw8juM6mj
# zjxcGY/ccIq//2jjKVTsBS5qVz4wH9+jKR75P0cnXOEMhHL7thmephY4cxsgbuDc
# Bfh5ODx2iDn2+8LFq2s1IK/zi3InTYwxXPcgPfsis5lbO6TobT7D/qmWSLiGqNul
# cjGfBOa57/q4gtrcCqE=
# SIG # End signature block

function Find-ReceiverValues{
    param (
        [Object[]] $actionGroups
    )

    if ($null -eq $actionGroups -or $actionGroups.Count -eq 0) {
        Write-Error "No action groups provided to Find-ReceiverValues"
        return @()
    }

    $allReceiversWithValues = @()
    
    # Iterate through each action group
    foreach ($actionGroup in $actionGroups) {
        if ($null -eq $actionGroup) {
            Write-Verbose "Skipping null action group"
            continue
        }
        
        try {
            # Filter the properties to find the receivers with values
            $receiversWithValues = $actionGroup.PSObject.properties | Where-Object {
                $_.Name -like "*Receiver*" -and 
                $_.MemberType -eq 'Property' -and 
                $null -ne $_.Value -and 
                $_.Value.Count -gt 0
            }
            
            if ($receiversWithValues.Count -gt 0) {
                $allReceiversWithValues += [PSCustomObject]@{
                    ActionGroupName = $actionGroup.Name
                    Receivers = $receiversWithValues
                    ReceiverCount = $receiversWithValues.Count
                }
                Write-Verbose "Found $($receiversWithValues.Count) receivers in action group: $($actionGroup.Name)"
            }
            else {
                Write-Verbose "No configured receivers found in action group: $($actionGroup.Name)"
            }
        }
        catch {
            Write-Error "Error processing action group $($actionGroup.Name): $_"
        }
    }
    
    Write-Verbose "Total action groups with receivers: $($allReceiversWithValues.Count)"
    return $allReceiversWithValues
}

function CompareKQLQueryToPattern{
    param (
        [string] $pattern,
        [string] $targetQuery
    )

    if ([string]::IsNullOrWhiteSpace($pattern)) {
        Write-Warning "Pattern is null or empty"
        return $false
    }
    
    if ([string]::IsNullOrWhiteSpace($targetQuery)) {
        Write-Warning "Target query is null or empty"
        return $false
    }

    try {        
        $isMatch = $targetQuery -imatch $pattern
        
        Write-Verbose "Pattern matching: '$pattern' against '$normalizedTargetQuery' = $isMatch"
        
        return $isMatch
    }
    catch {
        Write-Error "Error in pattern matching: $_"
        return $false
    }
}

function Check-AlertsMonitor {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$LAWResourceId,
        [Parameter(Mandatory=$true)]
        [string]$FirstBreakGlassUPN,
        [Parameter(Mandatory=$true)]
        [string]$SecondBreakGlassUPN,
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [string]$itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [string] 
        $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] 
        $EnableMultiCloudProfiles # default to false
    )
    

    $IsCompliant = $false
    $signInLogsCompliance = $false
    $auditLogsCompliance = $false
    $Comments = ""
    [System.Collections.ArrayList]$ErrorList = New-Object System.Collections.ArrayList

    #Queries that will be used in alert rules
    # Escape UPNs to prevent regex injection
    $escapedFirstUPN = [regex]::Escape($FirstBreakGlassUPN)
    $escapedSecondUPN = [regex]::Escape($SecondBreakGlassUPN)
    
    $BreakGlassAccountQueries = @(
        # Pattern 1: Explicit OR conditions – only matches if *both* distinct UPNs are present
        "SigninLogs\s*\|\s*where.*UserPrincipalName\s*(?:==|=~|contains)\s+`"$escapedFirstUPN`"\s+or\s+UserPrincipalName\s*(?:==|=~|contains)\s+`"$escapedSecondUPN`".*"
        ,
        "SigninLogs\s*\|\s*where.*UserPrincipalName\s*(?:==|=~|contains)\s+`"$escapedSecondUPN`"\s+or\s+UserPrincipalName\s*(?:==|=~|contains)\s+`"$escapedFirstUPN`".*"
        ,
        # Pattern 2: IN/HAS_ANY clause – both UPNs must appear inside the list (order doesn’t matter)
        "SigninLogs\s*\|\s*where.*UserPrincipalName\s*(?:in|has_any)\s*\((?=[^)]*`"$escapedFirstUPN`")(?=[^)]*`"$escapedSecondUPN`")[^)]*\)"
    )
    $BreakGlassAccountQueryMatchPattern = "`($($BreakGlassAccountQueries -join '|')`)"

    $AuditLogsQueries = @(
        # 1) Single-value form (==, =~, contains) — flexible spaces
        'AuditLogs\s*\|\s*where\s+(?:OperationName|ActivityDisplayName)\s+(?:==|=~|contains)\s+"(?:Update|Add|Delete)\s+conditional access policy"\s*',

        # 2) in()/has_any() list form — order-agnostic, requires ALL THREE present somewhere in (...)
        (
            'AuditLogs\s*\|\s*where\s+(?:OperationName|ActivityDisplayName)\s+(?:in|has_any)\s*\(' +
            '(?=[^)]*"Update\s+conditional access policy")' +
            '(?=[^)]*"Add\s+conditional access policy")' +
            '(?=[^)]*"Delete\s+conditional access policy")' +
            '[^)]*\)'
        )
    )
    $CAPQueryMatchPattern = "`($($AuditLogsQueries -join '|')`)"

    # Parse LAW Resource ID
    $lawParts = $LAWResourceId -split '/'
    
    $subscriptionId = $lawParts[2]
    $resourceGroupName = $lawParts[4]
    $lawName = $lawParts[-1]
    
    Write-Verbose "Parsed LAW Resource ID: Subscription=$subscriptionId, ResourceGroup=$resourceGroupName, Workspace=$lawName"

    try{
        Select-AzSubscription -Subscription $subscriptionId -ErrorAction Stop | Out-Null
    }
    catch {
        [void]$ErrorList.Add("Failed to execute the 'Select-AzSubscription' command with subscription ID '$($subscriptionId)'--`
            ensure you have permissions to the subscription, the ID is correct, and that it exists in this tenant; returned `
            error message: $_")
        #    ensure you have permissions to the subscription, the ID is correct, and that it exists in this tenant; returned `
        #    error message: $_"
        throw "Error: Failed to execute the 'Select-AzSubscription' command with subscription ID '$($subscriptionId)'--ensure `
            you have permissions to the subscription, the ID is correct, and that it exists in this tenant; returned error message: $_"
    }

    try {
        #Type of logs to check
        $SignInLogs = @('SignInLogs')
        $AuditLogs = @('AuditLogs')

        #Retrieve diagnostic settings to check for logs
        $diagnosticSettings = get-AADDiagnosticSettings
        $matchingSetting = $diagnosticSettings | Where-Object { $_.properties.workspaceId -eq $LAWResourceId } | Select-Object -First 1

        if($matchingSetting){
            $enabledLogs = $matchingSetting.properties.logs | Where-Object { $_.enabled -eq $true } | Select-Object -ExpandProperty category
            $missingSignInLogs = $SignInLogs | Where-Object { $_ -notin $enabledLogs }
            $missingAuditLogs = $AuditLogs | Where-Object { $_ -notin $enabledLogs }
        }
        else{
            $missingSignInLogs = $SignInLogs
            $missingAuditLogs = $AuditLogs
        }

        # Check missing logs for SignInLogs and AuditLogs
        if ($missingSignInLogs.Count -gt 0) {
            $Comments += $msgTable.signInlogsNotCollected + " Missing logs: $($missingSignInLogs -join ', ')"
        }

        if ($missingAuditLogs.Count -gt 0) {
            $Comments += $msgTable.auditlogsNotCollected + " Missing logs: $($missingAuditLogs -join ', ')"
        }
    }
    catch {
        if ($_.Exception.Message -like "*ResourceNotFound*") {
            $Comments += $msgTable.nonCompliantLaw -f $lawName
            $ErrorList += "Log Analytics Workspace not found: $_"
        }
        else {
            $ErrorList += "Error accessing Log Analytics Workspace: $_"
        }
    }

    # Check signInLogs and auditLogs alerts and action groups for breakglass accounts

    # Check alert rules exist
    try{
        $alertRules = Get-AzScheduledQueryRule -ResourceGroupName $resourceGroupName
        if ($alertRules.Count -le 0) {
            $Comments += $msgTable.noAlertRules -f $resourceGroupName
            $ErrorList += "No alert rules found in resource group: $resourceGroupName"
            Write-Error "No alert rules found in resource group: $resourceGroupName"
        }
        else {
            Write-Verbose "Found $($alertRules.Count) alert rules in resource group: $resourceGroupName"
        }
    }   
    catch {
        $Comments += $msgTable.noAlertRules -f $resourceGroupName
        $ErrorList += "Get-AzScheduledQueryRule could not find alert rules for the resource group: $_"
        Write-Error "Error retrieving alert rules: $_"
    }

    # Check action groups exist.  Only keep action groups with configured receivers
    try {
        $actionGroups = Get-AzActionGroup -ResourceGroupName $resourceGroupName
        if ($actionGroups.Count -le 0) {
            $Comments += $msgTable.noActionGroups -f $resourceGroupName
            $ErrorList += "No action groups found in resource group: $resourceGroupName"
        }
        else {
            $receiversWithValues = Find-ReceiverValues $actionGroups
            $actionGroupsWithReceivers = $actionGroups | Where-Object { $_.Name -in $receiversWithValues.ActionGroupName }
            $actionGroupIds = $actionGroupsWithReceivers.Id | ForEach-Object{ $_.ToLower() }
            
            if ($actionGroupsWithReceivers.Count -le 0) {
                $Comments += $msgTable.noActionGroupsForBGaccts
                $ErrorList += "No action groups with configured receivers found in resource group: $resourceGroupName"
            }
        }
    }
    catch {
        $Comments += $msgTable.noActionGroups -f $resourceGroupName
        $ErrorList += "Get-AzActionGroup could not find action groups for the resource group: $_"
        Write-Error "Error retrieving action groups: $_"
    }

    if ($alertRules.Count -gt 0 -and $actionGroups.Count -gt 0) {
        # check break glass compliance
        $signInLogsCompliance = $false
        
        try {
            # Select alert rules with a query that matches the pattern for break glass accounts
            $bgAlertRules = $alertRules | Where-Object {
                $_.CriterionAllOf -and
                $_.CriterionAllOf.Count -gt 0 -and
                (CompareKQLQueryToPattern -pattern $BreakGlassAccountQueryMatchPattern -targetQuery $_.CriterionAllOf.Query)
            }
            
            Write-Verbose "Found $($bgAlertRules.Count) alert rules matching break glass account patterns"
            
            if ($bgAlertRules.Count -le 0) {
                $Comments += $msgTable.noAlertRuleforBGaccts
                Write-Verbose "No alert rules found matching break glass account patterns"
            }
            else {
                # Normalize the action group IDs for BG alerts (guarding against null/empty values) so missing groups trigger the right comment
                $bgActionGroupIds = foreach ($rule in $bgAlertRules) {
                    foreach ($actionGroupId in @($rule.ActionGroup)) {
                        if ([string]::IsNullOrWhiteSpace($actionGroupId)) { continue }
                        $actionGroupId.ToLower()
                    }
                }
                $bgActionGroupIds = $bgActionGroupIds | Where-Object { $_ -in $actionGroupIds }
                
                Write-Verbose "Found $($bgActionGroupIds.Count) action groups with receivers for break glass alert rules"
                
                if ($bgActionGroupIds.Count -gt 0) {
                    $signInLogsCompliance = $true # we found alert rules with a query that matches the BG query pattern and with action groups with configured receivers
                    Write-Verbose "Break glass compliance: TRUE - Found alert rules with proper action groups"
                }
                else {
                    $Comments += $msgTable.noActionGroupsForBGaccts
                    Write-Verbose "Break glass compliance: FALSE - No action groups with receivers found"
                }
            }
        }
        catch {
            $ErrorList += "Error processing break glass alert rules: $_"
            Write-Error "Error processing break glass alert rules: $_"
        }

        # check conditional access policy compliance
        $auditLogsCompliance = $false
        
        try {
            # Select alert rules with a query that matches the pattern for conditional access policies
            $capAlertRules = $alertRules | Where-Object {
                $_.CriterionAllOf -and
                $_.CriterionAllOf.Count -gt 0 -and
                (CompareKQLQueryToPattern -pattern $CAPQueryMatchPattern -targetQuery $_.CriterionAllOf.Query)
            }
            
            Write-Verbose "Found $($capAlertRules.Count) alert rules matching conditional access policy patterns"
            
            if ($capAlertRules.Count -le 0) {
                $Comments += $msgTable.noAlertRuleforCaps
                Write-Verbose "No alert rules found matching conditional access policy patterns"
            }
            else {
                # Apply the same normalization for CAP alerts so missing action groups surface the expected comment
                $capActionGroupIds = foreach ($rule in $capAlertRules) {
                    foreach ($actionGroupId in @($rule.ActionGroup)) {
                        if ([string]::IsNullOrWhiteSpace($actionGroupId)) { continue }
                        $actionGroupId.ToLower()
                    }
                }
                $capActionGroupIds = $capActionGroupIds | Where-Object { $_ -in $actionGroupIds }
                
                Write-Verbose "Found $($capActionGroupIds.Count) action groups with receivers for conditional access policy alert rules"
                
                if ($capActionGroupIds.Count -gt 0) {
                    $auditLogsCompliance = $true # we found alert rules with a query that matches the CAP query pattern and with action groups with configured receivers
                    Write-Verbose "Conditional access policy compliance: TRUE - Found alert rules with proper action groups"
                }
                else {
                    $Comments += $msgTable.noActionGroupsForAuditLogs
                    Write-Verbose "Conditional access policy compliance: FALSE - No action groups with receivers found"
                }
            }
        }
        catch {
            $ErrorList += "Error processing conditional access policy alert rules: $_"
            Write-Error "Error processing conditional access policy alert rules: $_"
        }
    }

    # CONDITION: If both checks are compliant then set the control as compliant
    if($signInLogsCompliance -and $auditLogsCompliance){
        $IsCompliant = $true
    }

    Write-Verbose "=== Compliance Summary ==="
    Write-Verbose "Sign-in Logs Compliance: $signInLogsCompliance"
    Write-Verbose "Audit Logs Compliance: $auditLogsCompliance"
    Write-Verbose "Overall Compliance: $IsCompliant"
    Write-Verbose "Error Count: $($ErrorList.Count)"

    if($IsCompliant){
        $Comments = $msgTable.compliantAlerts
        Write-Verbose "Result: COMPLIANT - All alert monitoring requirements met"
    }else{
        $Comments = $msgTable.isNotCompliant + ' ' + $Comments
        Write-Verbose "Result: NON-COMPLIANT - Alert monitoring requirements not met"
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName = $ControlName
        Comments = $Comments
        ItemName = $ItemName
        ReportTime = $ReportTime
        itsgcode = $itsgcode
    }

    # Add profile information if MCUP feature is enabled
    if ($EnableMultiCloudProfiles) {
        $result = Add-ProfileInformation -Result $PsObject -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subscriptionId -ErrorList $ErrorList
        Write-Host "Compliance Output: $result"
    }

    $moduleOutput = [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors = $ErrorList
    }

    return $moduleOutput
}
# SIG # Begin signature block
# MIIxfwYJKoZIhvcNAQcCoIIxcDCCMWwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDUAPE0rXuQ/2Hu
# 8pNhEofbXMglpmo3HIs48semlufsp6CCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0fMIIdGwIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# 9U9yhUye+7C4lC12RB3heqEzU4VUZC8BlU2i8RKsYH4wDQYJKoZIhvcNAQEBBQAE
# ggIAGsdwFjj2+9XQqnHqSKFlABIKOBQeVdNMLorksEQfEYJM7if/Hkn5X+G7fX1w
# NSK1MW+EigHJ6cAoC8wn3yVuV0KHAgQZzFoX/0FefmsQEKkkcrZ/ajOxrRwTxMoX
# gGQw4cz5nAkPzxXiXl3Oui4s3tFv6GJTWLgXHAQBFpIT8wkS3l9Os2N1qy84AllR
# kxnk3USJTkf6WIgUP+Cadu4nwdRVd5YX0mLK+zcX+be/L4enYMMe1U0hP9NXcsQ3
# a6+Cm1hrEu11yvfDegIt0WR5BCNpdTo46DviP8CJ4B2Q7dXaJMZuXzvTDhERbQji
# tpFBcx9l9m07JwAo8k5G1ziatj4k79mLdWjRJvFXlpnHOLOFTeyh55fts5UaGJSc
# XBI986zxDf40WEJu88I4IDWCPpw1iOZxAB+j2xVqrrrzTipqYgUOFNQ9pvfIQYRJ
# UECyy06A5gETRA2EluQok1NZbeYIz3DqqJ2ETrRm2Y/2JfC+dhRZoBgc32kCstpR
# G5tX79ruqQD7/ixnFJa1/w4i05x1TczQIcJ5SRSd0KsYV/xf49Pjua4c9C0XEBej
# RFO9iaJh/m6s1NVp+GawwaETR8Ri6Z6ECqFTNB6jGIqCR0T49/S3BGzYMtZSoZ+j
# lmwryQ3HNvHs29VepzMnECHdH+LDbz/iRWIN6Ozt6+vkEW6hghnsMIIZ6AYKKwYB
# BAGCNwMDATGCGdgwghnUBgkqhkiG9w0BBwKgghnFMIIZwQIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH4BgsqhkiG9w0BCRABBKCB6ASB5TCB4gIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCBwpROZq2+bDyUEv8sMowa+FgacGtBtHo7jxLnUh3DK
# zwIVAKeoPD75wO2CeLdWcuC6F60NeuW0GA8yMDI2MDcyMTE3NDMzOVqgdqR0MHIx
# CzAJBgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMP
# U2VjdGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0
# YW1waW5nIFNpZ25lciBSMzegghQXMIIG4jCCBMqgAwIBAgIRAOdO8lWwUE/626bf
# 9/yLoxUwDQYJKoZIhvcNAQEMBQAwVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBDQSBSNDEwHhcNMjYwMzI1MDAwMDAwWhcNMzcwNjI0MjM1OTU5WjByMQsw
# CQYDVQQGEwJHQjEXMBUGA1UECBMOR3JlYXRlciBMb25kb24xGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBTaWduZXIgUjM3MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# sv/DbUvcUNlFLQURd9m4+1St5+JudFKo5P803Iks4mFeNB9SymodP6BJJWBuNhOF
# Qj9w77AVAeg5qQpA2dIwp2QTyBHr2h9eWSTkMBVj9mV6+WI5SaW+vDZW7PhJTbys
# d9v9WB3Xt6qlEi8m47pcTy8+k/OfhziKiuzNQXqfC7KcoRD/6up8OZBsU0qxr7n5
# nh/iRfAp1QXFTBQONBZSGIdHAyVRYYX033VoC8v71rizEKCpH97Pxbwcn9eq9K7W
# 8h5v4npsMUoqCS/c8mQwylDQGx15dHYV6NlcVFdjXD11l7qCrIy/unH5OlZtgx58
# QJRXRbGgQyBdSTpEpwuj3i5Qc52Z9m7hd7yCGCXKujf83hUQpOPx1w8+84EbEUTH
# VAfq4cpORaGWgY8NJy6txmd3wpS1MeXrOaVAMczTgzAZ+yZBWIqdgQBgTxEeXldE
# ToZOrRkxvn1IjIlfr4I4NWJz+Rb52FshLVnkA/wdoad789Eb7XZDNKd4oMmnc636
# TgauaaVZP2LLoU0JD/fYr53hwBn4uXu5ZsSfpnqAT60S7szJm/Na882xEoyRzLJ+
# UVbXOlHLO63DKkAtdz1CDuwWxgRE1drnwplepT06dz+1yTr5p1AkUz21bzE6cT/8
# /kjh4OPzggYYqrOBQPfuKEL5ZJPcN9jRgEpYvRlq5ucCAwEAAaOCAY4wggGKMB8G
# A1UdIwQYMBaAFDp0pQxnxkJQwv21/Me7KTSC9Hq5MB0GA1UdDgQWBBRhEOl6Eq9R
# xIXU8s+kdA9QzSCv+DAOBgNVHQ8BAf8EBAMCBsAwDAYDVR0TAQH/BAIwADAWBgNV
# HSUBAf8EDDAKBggrBgEFBQcDCDBKBgNVHSAEQzBBMAgGBmeBDAEEAjA1BgwrBgEE
# AbIxAQIBAwgwJTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMw
# SgYDVR0fBEMwQTA/oD2gO4Y5aHR0cDovL2NybC5zZWN0aWdvLmNvbS9TZWN0aWdv
# UHVibGljVGltZVN0YW1waW5nQ0FSNDEuY3JsMHoGCCsGAQUFBwEBBG4wbDBFBggr
# BgEFBQcwAoY5aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGlt
# ZVN0YW1waW5nQ0FSNDEuY3J0MCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0
# aWdvLmNvbTANBgkqhkiG9w0BAQwFAAOCAgEAA+o9jdGszfoZepOmygef1OlbkjrP
# d2QW9z3M8vVbQSCruPeO2eRsC9GhZ4CMZfhkrixayYD67gQkbyiRCbJu5L/i0NQj
# lQhBvbWfiEba+KHFKGud5YHRWhDZUtDeMIJGZG0BD7/sftZUo2Ifk+CXi/ZlM50+
# xK3OkqeXVi5GubDD/5txmYuqCT3T3LAilmoB+5th9sQxiMhyQuT3R/aYb4vypoZJ
# LYklUzTalXleW1nV9s4UROlE389CHDKAi/fepRSMnV8TghODDQxwzNGrOJZ04k/y
# hzHHDupfHPU51FYJqXIvWq9SAAWdlNV1JGIxhkp/TAtxBwz/Vd/VbgVb2d9/wRFf
# xFkka39O0+4xaZSl/oEK/1DqjxjJRO2Se9lGlJDScu21Zd23Cys3aYyB8y5H/+DF
# WtVe8PMKgr+VuIDp0Rk5bneVDAEW0TPAT8Ufwl2F6DJiDg/KZk5NmsYES+CxvF7b
# nISEnQh0ZrWnAJixquV0mElUx01wA5TuPIgyodxzNq/fC0hen9LBtdnfFfSZ+wt8
# A1Injsbio+DHVq1voYiVNpBfO7+nh9NB4AhRXNldPgr3zgjJ+47s0uNYy2iDXAZS
# lkP3ym/7gy31jlu989SNpRWO14/LUNV2LSuXkRI1iLTPI6ZdXG0DnPPG7UftF0tk
# 5m6BP9eNfr2tj1swgganMIIEj6ADAgECAhEAkKwIciD9xafEa1zHDfc9BjANBgkq
# hkiG9w0BAQwFADBXMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1p
# dGVkMS4wLAYDVQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3Qg
# UjQ2MB4XDTI2MDMyNTAwMDAwMFoXDTQxMDMyNDIzNTk1OVowVTELMAkGA1UEBhMC
# R0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQ
# dWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDEwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQCu5EqiAa2CHGL5Zi1bmgPM8NUXwYZJ+BtQqHps43GLTC+sjVLy
# psBh+8uv+TLkgtVGD//vSmA0qrzELf9YRCh2MTAA/aGaQZKGg0BRCmziR3pbCnvg
# WjtGXBDUyn3j3K2lZAO8KxgFtlxwOYEAkL+CCqK4v9zzTl8ZwzDpPMiDIFa5THk8
# an1ieF5I09cXNrPQw+1ER1liThaG0z6FrOpqwxZWmPRZQBw2E32878UB1bL0Zp91
# vuWZgsMpNNiPCoBj0/1F+LE8+NRokfqacFI0F2tftrRB2W7HQClLR9zjxFbWb5be
# 2rceIfNyHUUfKGIvMI2NzoxSlxXnFqUG887D8W1Cj8DFok688JKxWvHR/9aQykSb
# d+9Vutj36ij2sgq/125wTpUZ/AgC0ph50bRs7gFrUyaXE9wSsOqMvCCC+sEm7vd/
# BemSG0TSHNXSmyCba+FCzekeWX03TRIcF3Laqd0Rw24OH7jpei4zaGhcI7nfdhBA
# 4c8RScxNY6jeHLHHmSMMTk9Wqn7H4dLhUBP5YEwbgbN4uv1i9ltTnHli8t1xHV0S
# tX9BFgrnmunTX19kUXY1H5ORJbRZyZDdvm1oZyteDj0SnMozr+YSmdIleDUTXdfo
# Y7b2taz8s2+QbOxLxcahEIYGWzqu6h955tKwcANHcZ4gTmAhT3btuOiQsQIDAQAB
# o4IBbjCCAWowHwYDVR0jBBgwFoAU9ndq3T/9ARP/FqFsggIv0Ao9FCUwHQYDVR0O
# BBYEFDp0pQxnxkJQwv21/Me7KTSC9Hq5MA4GA1UdDwEB/wQEAwIBhjASBgNVHRMB
# Af8ECDAGAQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMCMGA1UdIAQcMBowCAYG
# Z4EMAQQCMA4GDCsGAQQBsjEBAgEDCDBMBgNVHR8ERTBDMEGgP6A9hjtodHRwOi8v
# Y3JsLnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3RhbXBpbmdSb290UjQ2
# LmNybDB8BggrBgEFBQcBAQRwMG4wRwYIKwYBBQUHMAKGO2h0dHA6Ly9jcnQuc2Vj
# dGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYucDdjMCMG
# CCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0aWdvLmNvbTANBgkqhkiG9w0BAQwF
# AAOCAgEAMt5SR2bxngNm+N8oc6Gq76Gx1c235fkX7jw8Ho9MAkJGADerHE7dhsBX
# ttqmzgr/7ZZahZSykGRPhPY1crj028kB8KzO0dKC2qQBAwtfgqMLKkkX/6bYq2uT
# 33eD6ByAp2/XKD0LcmZh0kKecvSBr6ln9ajX6u1dnx2fA7xEKy1M3qBhfQSUWLtj
# s2nFt0ELVLptzTlX9ID0cL+iOPfdboZ3CelT+JXKVKR2Sge0d4YiFAtPZkfSo8z1
# Z1x7y/Z9mwMIlBAnyuWXs4YsNuxdrYIt/QxE31PDOJ9DesS4Bc7H9OTORlEV/Avf
# iF/VepKZpira1MzLYuCw+uoLZn/pkpvd+CvNTS+mEHjBJNa6WK1j8qXFu+jIq+sG
# 9QILHiyB6p/xpHrkJu8zkw393+VqF9eKlTY2VjRxdycZLrVemZ4Yp3wi33b+W58C
# llH3HqjmowlZ7SOrgmx8YwYOkgrHsXOQHyBp6O4FRb8In0+FzjT7ElGie9V7CfhL
# 3IlVFZ4zjuKsZtH1iU3fGu4z/JnOGT6sCb0BbTqe/uhvpFCQBdH5xPGIA/LrbQUX
# jU2tWJgHhTIqnN/HvHyOHi5tM4zP3nhgh2rJ6Kqq2xsHBeNYs/R18xQ8DeIg+c90
# Eoaeh0YlN1KU8AyYol3K9M+qY5ez8syd/7ZlrRnoVewgH3P1pcswggaCMIIEaqAD
# AgECAhA2wrC9fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBDAUAMIGIMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxMLSmVyc2V5IENpdHkx
# HjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwGA1UEAxMlVVNFUlRy
# dXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0yMTAzMjIwMDAwMDBa
# Fw0zODAxMTgyMzU5NTlaMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdv
# IExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcg
# Um9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCIndi5RWed
# Hd3ouSaBmlRUwHxJBZvMWhUP2ZQQRLRBQIF3FJmp1OR2LMgIU14g0JIlL6VXWKmd
# bmKGRDILRxEtZdQnOh2qmcxGzjqemIk8et8sE6J+N+Gl1cnZocew8eCAawKLu4TR
# rCoqCAT8uRjDeypoGJrruH/drCio28aqIVEn45NZiZQI7YYBex48eL78lQ0BrHeS
# mqy1uXe9xN04aG0pKG9ki+PC6VEfzutu6Q3IcZZfm00r9YAEp/4aeiLhyaKxLuhK
# KaAdQjRaf/h6U13jQEV1JnUTCm511n5avv4N+jSVwd+Wb8UMOs4netapq5Q/yGyi
# QOgjsP/JRUj0MAT9YrcmXcLgsrAimfWY3MzKm1HCxcquinTqbs1Q0d2VMMQyi9cA
# gMYC9jKc+3mW62/yVl4jnDcw6ULJsBkOkrcPLUwqj7poS0T2+2JMzPP+jZ1h90/Q
# pZnBkhdtixMiWDVgh60KmLmzXiqJc6lGwqoUqpq/1HVHm+Pc2B6+wCy/GwCcjw5r
# mzajLbmqGygEgaj/OLoanEWP6Y52Hflef3XLvYnhEY4kSirMQhtberRvaI+5YsD3
# XVxHGBjlIli5u+NrLedIxsE88WzKXqZjj9Zi5ybJL2WjeXuOTbswB7XjkZbErg7e
# beAQUQiS/uRGZ58NHs57ZPUfECcgJC+v2wIDAQABo4IBFjCCARIwHwYDVR0jBBgw
# FoAUU3m/WqorSs9UgOHYm8Cd8rIDZsswHQYDVR0OBBYEFPZ3at0//QET/xahbIIC
# L9AKPRQlMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLnVzZXJ0cnVzdC5jb20vVVNFUlRydXN0UlNBQ2VydGlmaWNh
# dGlvbkF1dGhvcml0eS5jcmwwNQYIKwYBBQUHAQEEKTAnMCUGCCsGAQUFBzABhhlo
# dHRwOi8vb2NzcC51c2VydHJ1c3QuY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAOvmVB
# 7WhEuOWhxdQRh+S3OyWM637ayBeR7djxQ8SihTnLf2sABFoB0DFR6JfWS0snf6WD
# G2gtCGflwVvcYXZJJlFfym1Doi+4PfDP8s0cqlDmdfyGOwMtGGzJ4iImyaz3IBae
# 91g50QyrVbrUoT0mUGQHbRcF57olpfHhQEStz5i6hJvVLFV/ueQ21SM99zG4W2tB
# 1ExGL98idX8ChsTwbD/zIExAopoe3l6JrzJtPxj8V9rocAnLP2C8Q5wXVVZcbw4x
# 4ztXLsGzqZIiRh5i111TW7HV1AtsQa6vXy633vCAbAOIaKcLAo/IU7sClyZUk62X
# D0VUnHD+YvVNvIGezjM6CRpcWed/ODiptK+evDKPU2K6synimYBaNH49v9Ih24+e
# YXNtI38byt5kIvh+8aW88WThRpv8lUJKaPn37+YHYafob9Rg7LyTrSYpyZoBmwRW
# SE4W6iPjB7wJjJpH29308ZkpKKdpkiS9WNsf/eeUtvRrtIEiSJHN899L1P4l6zKV
# sdrUu1FX1T/ubSrsxrYJD+3f3aKg6yxdbugot06YwGXXiy5UUGZvOu3lXlxA+fC1
# 3dQ5OlL2gIb5lmF6Ii8+CQOYDwXM+yd9dbmocQsHjcRPsccUd5E9FiswEqORvz8g
# 3s+jR3SFCgXhN4wz7NgAnOgpCdUo4uDyllU9PzGCBJMwggSPAgEBMGowVTELMAkG
# A1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2Vj
# dGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDECEQDnTvJVsFBP+tum3/f8
# i6MVMA0GCWCGSAFlAwQCAgUAoIIB+jAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDcyMTE3NDMzOVowPwYJKoZIhvcNAQkEMTIE
# MCYnl0wAQyePZFAQ9kvEOVUicUgYG/6KRxzRr6WJ0EJF6qA8JvK9ytx4hNpNx7J8
# 1TCCAXsGCyqGSIb3DQEJEAIMMYIBajCCAWYwggFiMBYEFOl4GKko2hUKn+G/nMx6
# q7mgDu6sMIGIBBRlwyhpb31OUCz9A8fCBpcYyvv3TzBwMFukWTBXMQswCQYDVQQG
# EwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQDEyVTZWN0aWdv
# IFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2AhEAkKwIciD9xafEa1zHDfc9
# BjCBvAQUhT1jLZOCgmF80JA1xJHeksFC2scwgaMwgY6kgYswgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5AhA2wrC9fBs656Oz3TbLyXVo
# MA0GCSqGSIb3DQEBAQUABIICAEFma/wQt1aFcTDM1yF1wpRPHO4az+4JMJ/VhidC
# bCCgxFBhAJp3ilMy1xxQkYjDO5bsyc6qPYJVQYn9YXKatlCwlm1SBzwtAo3C/g8H
# EoBMDvpGj9c8AGo80nB/ziffP+THzqVcHrClQWse1TNEkh9t8Ll30exZen1afg3M
# 1Udx5zDcVGgeniiSF6dJW6CM5M/MMj5A5bEcyNvcnX9ovmHzleWprEyGO1MV4MzQ
# 0x/IvuSk3toG+f472S6yHYkowoLT1pz7fatdY90od2nFNRCUspxuC3QmJ4emzvf7
# yN+gb74KhuOtjL0jvCx8bbMBZpKmBgjXoKaqNVqx0HoWEc0NCbLDkTVoDbnseFE5
# 7OCkAb7i6/9C6zm0LU515Lei9UdsPSBuMVIj6G8+PrDlaDTrsr8k1wPIsGUtxHtN
# wqTMQIhuCx/W2fV3Q2Yc1UNgXCXzF6pkcx6/knIdFjkwgMfR5hLRh5kHQSrJ9gRm
# CkJVvvycuLl1qhZl9mHzuvW2CEJN2+FF+mn61a68OZS9WfYjufMWf3OC8uWZM7Qm
# CU3RHaJqWy6VeMz1g9NudjR7+IsDk0hfHP/9F0THOgO74OlFc8g9hk8ayj75ygIL
# rWLgJIh6Voknf9KsIDikD0ydoSkQrMPyq1Pfjw82iKSfVkDfw6QhyLUVDzSZKYyW
# B2BA
# SIG # End signature block

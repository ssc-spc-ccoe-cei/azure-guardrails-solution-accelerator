function Check-ApplicationGatewayCertificateValidity {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName, 
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID, 
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName, 
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $IsCompliant = $false
    $Comments = ""
    
    [PSCustomObject] $PsObject = New-Object System.Collections.ArrayList
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $ApprovedCAList = @()

  # --------------------------------
    # Check if document exists in blob
    # --------------------------------
    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName
    $subName = ""

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
        $subName  = (Get-AzContext).Subscription.Name
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        # Use Entra/RBAC blob access because the Guardrails storage account no longer allows Shared Key auth.
        $StorageContext = New-ConnectedStorageContext -storageaccountName $StorageAccountName
    }
    catch {
        $storageErrorMessage = "Could not connect to storage account '$storageAccountName' in resource group '$resourceGroupName' of subscription '$SubscriptionID'; verify that the storage account exists and that you have permissions to it. Error: $_"
        $ErrorList.Add($storageErrorMessage) | Out-Null

        return [PSCustomObject]@{
            ComplianceResults = $null
            Errors            = $ErrorList
        }
    }

    $baseFileNameFound = $false
    $blobFound = $false

    try {
        # Fail fast on blob RBAC issues so they are reported as storage access problems instead of missing files.
        $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -ErrorAction Stop
        
        $fileNamesList = @()
        $blobs | ForEach-Object {
            $fileNamesList += $_.Name
        }
        $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
        if ( $matchingFiles.count -lt 1 ){
            # check if any fileName matches without the extension
            $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
            
            $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
            if ($BaseFileNamesMatch.Count -gt 0){
                $baseFileNameFound = $true
            }
        }
        else {
            # also covers the use case if more than 1 appropriate files are uploaded
            
            # check for procedure doc in blob storage account
            $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -Blob $DocumentName_new -ErrorAction Stop

            If ($blobs) {
                $blobFound = $true
                # Read the content of the blob and save CA names into array
                $blobContent = Get-AzStorageBlobContent -Container $ContainerName -Blob $DocumentName_new -Context $StorageContext -Force -ErrorAction Stop
                $ApprovedCAList = Get-Content $blobContent.Name | Where-Object { $_ -match '\S' } | ForEach-Object { $_.Trim() }

            }
        }
    }
    catch {
        $storageErrorMessage = "Could not read from storage account '$storageAccountName' container '$ContainerName' in resource group '$resourceGroupName' of subscription '$SubscriptionID'; verify that blob data access is available. Error: $_"
        $ErrorList.Add($storageErrorMessage) | Out-Null

        return [PSCustomObject]@{
            ComplianceResults = $null
            Errors            = $ErrorList
        }
    }
      

    # ----------------------
    # Case 1: uploaded fileName is correct but has wrong extension
    # ----------------------
    if ($baseFileNameFound){
        # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
        $Comments += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false

        $C = [PSCustomObject]@{
            SubscriptionName = $subName
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput

    }
    elseif ($blobFound){
    # ----------------------
    # Case 2: file exists in blob storage
    # ----------------------
        $Comments += $msgTable.approvedCAFileFound -f $DocumentName
    }
    else {
        # ----------------------
        # Case 3: file does not exist in blob storage
        # ----------------------
        $Comments += $msgTable.approvedCAFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false
        
        $C= [PSCustomObject]@{
            SubscriptionName = $subName
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput
    }

    # ----------------------
    # Case 2: Correct document exists (i.e. blobfound) - proceed with checking App Gateway certificate validity for subscriptions
    # ----------------------

    # Get all subscriptions in tenant scope
    $subscriptions = Get-AzSubscription

    foreach ($subscription in $subscriptions) {

        # Set the context to the current subscription
        Set-AzContext -Subscription $subscription.Id | Out-Null

        #initialize for each subscription
        $appGatewaysFound = $false
        $isSubCompliant = $true
        $subComments = ""
        $NotEvaluated = $false


        # Get Application Gateways in the current subscription
        $appGateways = Get-AzApplicationGateway

        if ($appGateways.Count -gt 0) {
            $appGatewaysFound = $true
            foreach ($appGateway in $appGateways) {
                # 4a. Check for SSL Certificates in listeners
                $listeners = Get-AzApplicationGatewayHttpListener -ApplicationGateway $appGateway
                $sslListeners = $listeners | Where-Object { $_.SslCertificate -ne $null }
                
                if ($sslListeners.Count -eq 0) {
                    $subComments += " " + $msgTable.noSslListenersFound -f $appGateway.Name
                    $isSubCompliant = $false
                    continue
                }

                foreach ($listener in $sslListeners) {
                    # Extract the certificate name from the Id
                    $certName = $listener.SslCertificate.Id.Split('/')[-1]

                    # 3. Check certificate validity
                    $cert = Get-AzApplicationGatewaySslCertificate -ApplicationGateway $appGateway -Name $certName
                    Write-Verbose "Cert is $cert"
                    Write-Verbose "Cert.PublicCertData exists: $($cert.PublicCertData -ne $null)"
                    Write-Verbose "Cert.KeyVaultSecretId exists: $($cert.KeyVaultSecretId -ne $null)"
                    
                    # Check if certificate is stored in Key Vault first
                    Write-Verbose "Looking for certificate name: $certName"
                    Write-Verbose "Available SSL certificates: $($appGateway.SslCertificates.Name -join ', ')"
                    $matchingCert = $appGateway.SslCertificates | Where-Object { $_.Name -eq $certName }
                    Write-Verbose "Matching certificate found: $($matchingCert -ne $null)"
                    $keyVaultSecretId = $matchingCert | Select-Object -ExpandProperty KeyVaultSecretId
                    
                    if ($keyVaultSecretId) {
                        Write-Verbose "Processing Key Vault certificate"
                        # Certificate is stored in Key Vault - need to retrieve and validate it
                        # Parse the Key Vault URL: https://testappgateway.vault.azure.net/secrets/myapp
                        $keyVaultUrlParts = $keyVaultSecretId -split '/'
                        # Strip .vault.azure.net and any explicit port (e.g. :443) from the hostname
                        $keyVaultName = $keyVaultUrlParts[2] -replace '\.vault\.azure\.net(:\d+)?$', ''
                        # Use last non-empty segment to handle URLs with a trailing slash
                        $secretName = ($keyVaultUrlParts | Where-Object { $_ -ne '' } | Select-Object -Last 1)
                                                
                        # Validate that we have the required values
                        if ([string]::IsNullOrEmpty($keyVaultName) -or [string]::IsNullOrEmpty($secretName)) {
                            Write-Warning "Failed to parse Key Vault URL properly"
                            $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to parse Key Vault URL '$keyVaultSecretId' for listener '$($listener.Name)'. Expected format: https://[vaultname].vault.azure.net/secrets/[secretname].")
                            # Set Compliant to Non compliant as this is a parsing issue
                            $isSubCompliant = $false
                            continue
                        }
                        $kvAccessResult = Test-KeyVaultAccess -KeyVaultName $keyVaultName -SecretName $secretName
                        if (-not $kvAccessResult.Success) {
                            Write-Warning "KeyVault access not successful."
                            $subComments += " " + $msgTable.keyVaultCertValidationFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("No access to Key Vault '$keyVaultName' for listener '$($listener.Name)'. The CAC Automation Account managed identity requires 'Key Vault Secrets User' permissions on this Key Vault. Error: $($kvAccessResult.Error).")
                            # Don't set isSubCompliant to true - set NotEvaluated flag
                            $NotEvaluated = $true
                            continue
                        }
                        try {
                            $keyVaultCert = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName -ErrorAction Stop
                            
                            if ($keyVaultCert.SecretValue) {
                                # Convert SecureString to plain text first, then to certificate
                                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($keyVaultCert.SecretValue)
                                $plainTextSecret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                                [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
                                # Convert secret value to certificate
                                try {
                                    $certBytes = [System.Convert]::FromBase64String($plainTextSecret)
                                    $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                                    $certCollection.Import($certBytes)
                                    $x509cert = $certCollection[0]
                                    Write-Verbose "Successfully imported certificate from Key Vault"
                                }
                                catch [System.FormatException] {                                    
                                    Write-Error "Base64 conversion failed: $($_.Exception.Message)"
                                    $ErrorList.Add("Base64 conversion failed: $($_.Exception.Message)")
                                    continue
                                }
                                
                                # Validate certificate expiration
                                if ($x509cert.NotAfter -le (Get-Date)) {
                                    $subComments += " " + $msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                    $isSubCompliant = $false
                                }
                                
                                # Check if certificate is from an approved CA
                                $isApprovedCA = $false
                                foreach ($approvedCA in $ApprovedCAList) {
                                    if ($x509cert.Issuer -like "*$approvedCA*" -or $approvedCA -like "*$($x509cert.Issuer)*") {
                                        $isApprovedCA = $true
                                        break
                                    }
                                }
                                
                                if (-not $isApprovedCA) {
                                    $subComments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $x509cert.Issuer
                                    $isSubCompliant = $false
                                }
                            }
                            else {
                                Write-Verbose "KeyVault secret has no value."
                                $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                                $ErrorList.Add("Key Vault secret '$secretName' in vault '$keyVaultName' has no value for listener '$($listener.Name)'.")
                                $isSubCompliant = $false
                            }
                        }
                        catch {
                            Write-Verbose "KeyVault certificate retrieval failed"
                            $subComments += " " + $msgTable.keyVaultCertRetrievalFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to retrieve certificate from Key Vault '$keyVaultName' for listener '$($listener.Name)': $_ .")
                             $isSubCompliant = $false
                        }
                    }
                    elseif ($cert.PublicCertData) {
                        Write-Verbose "Processing direct certificate (not in Key Vault)"
                        # Certificate is uploaded directly to Application Gateway
                        try {
                            $certBytes = [System.Convert]::FromBase64String($cert.PublicCertData)
                            $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                            $certCollection.Import($certBytes)
                            $x509cert = $certCollection[0]
                        
                            if ($x509cert.NotAfter -le (Get-Date)) {
                                $subComments += " " +$msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                $isSubCompliant = $false
                            }

                            # Check if certificate is from an approved CA
                            $isApprovedCA = $false
                            foreach ($approvedCA in $ApprovedCAList) {
                                if ($x509cert.Issuer -like "*$approvedCA*" -or $approvedCA -like "*$($x509cert.Issuer)*") {
                                    $isApprovedCA = $true
                                    break
                                }
                            }

                            if (-not $isApprovedCA) {
                                $subComments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $x509cert.Issuer
                                $isSubCompliant = $false
                            }
                        }
                        catch {
                            $subComments += " " + $msgTable.unableToProcessCertData -f $listener.Name, $appGateway.Name, $_.Exception.Message
                            $isSubCompliant = $false
                        }
                    }
                    else {
                        Write-Verbose "Certificate has no PublicCertData and no KeyVaultSecretId"
                        $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                        $isSubCompliant = $false
                    }
                }

                # 3. Check HTTPS backend settings for well-known CA certificates
                $httpsBackendSettings = $appGateway.BackendHttpSettingsCollection | 
                    Where-Object { $_.Protocol -eq 'Https' }

                if ($httpsBackendSettings.Count -eq 0) {
                    $subComments += " " + $msgTable.noHttpsBackendSettingsFound -f $appGateway.Name
                } else {
                    $allWellKnownCA = $true
                    foreach ($backendSetting in $httpsBackendSettings) {
                        if ($backendSetting.TrustedRootCertificates.Count -gt 0) {
                            # Manual trusted root certs are present — this backend setting is not using
                            # a built-in well-known CA, so clear the gateway-level flag regardless of
                            # whether the roots turn out to be approved or not.
                            $allWellKnownCA = $false

                            # Separately, check every root cert against the ApprovedCAList.
                            # Department-approved CAs (e.g. internal government PKI roots) must be
                            # configured as manual trusted roots because Azure does not include them
                            # in its built-in trust store.
                            $allRootCertsApproved = $true
                            foreach ($trustedRootCertRef in $backendSetting.TrustedRootCertificates) {
                                $rootCertName = $trustedRootCertRef.Id.Split('/')[-1]
                                $rootCertObj  = $appGateway.TrustedRootCertificates | Where-Object { $_.Name -eq $rootCertName }

                                if ($rootCertObj -and $rootCertObj.Data) {
                                    try {
                                        $rootCertBytes = [System.Convert]::FromBase64String($rootCertObj.Data)
                                        $rootX509      = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @(,$rootCertBytes)

                                        $isApprovedRootCA = $false
                                        foreach ($approvedCA in $ApprovedCAList) {
                                            if ($rootX509.Subject -like "*$approvedCA*" -or $approvedCA -like "*$($rootX509.Subject)*") {
                                                $isApprovedRootCA = $true
                                                break
                                            }
                                        }

                                        if (-not $isApprovedRootCA) {
                                            $allRootCertsApproved = $false
                                            $subComments += " " + $msgTable.manualTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                                        }
                                    }
                                    catch {
                                        $allRootCertsApproved = $false
                                        $subComments += " " + $msgTable.unableToProcessCertData -f $backendSetting.Name, $appGateway.Name, $_.Exception.Message
                                    }
                                } else {
                                    $allRootCertsApproved = $false
                                    $subComments += " " + $msgTable.manualTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                                }
                            }

                            # $allRootCertsApproved drives compliance directly — independent of $allWellKnownCA
                            if ($allRootCertsApproved) {
                                $subComments += " " + $msgTable.approvedTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                            } else {
                                $isSubCompliant = $false
                            }
                        }
                    }

                    if ($allWellKnownCA) {
                        $subComments += " " + $msgTable.allBackendSettingsUseWellKnownCA -f $appGateway.Name
                    }
                }
            }
        }
    
    
        # Determine per-subscription compliance status and Comments
        if (-not $appGatewaysFound) {
            $subComments = $msgTable.noAppGatewayFound -f $subscription.Name
            $IsCompliant = $true
            Write-Verbose "No app gateways found - Comments: $Comments"
        }
        else {
            $IsCompliant = $isSubCompliant
            if (-not $NotEvaluated) {
                Write-Verbose "App gateways found - IsCompliant: $IsCompliant, allCompliant: $allCompliant"
                if ($IsCompliant){
                    $subComments= $msgTable.allCertificatesValid
                }
            }
            elseif($NotEvaluated){
                $IsCompliant = "Not Available"
                Write-Verbose "App gateways found but certificate validation could not be completed due to errors accessing certificate data - IsCompliant: $IsCompliant, Comments: $subComments"
            }
        }
        
        # Add evaluation info for each subscription
        $C = [PSCustomObject]@{
            SubscriptionName   = $subscription.Name
            ComplianceStatus   = $IsCompliant 
            ControlName        = $ControlName
            Comments           = $subComments
            ItemName           = $ItemName
            ReportTime         = $ReportTime
            itsgcode           = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subscription.Id -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }

    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
    return $moduleOutput
}

function Test-KeyVaultAccess {
    param (
        [Parameter(Mandatory=$true)]
        [string]$KeyVaultName,
        [Parameter(Mandatory=$true)]
        [string]$SecretName
    )
    $result = @{ Success = $false; Error = $null }
    try {
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -ErrorAction Stop
        $result.Success = $true
    } catch {
        $result.Error = $_.Exception.Message
    }
    return $result
}
# SIG # Begin signature block
# MIIxfgYJKoZIhvcNAQcCoIIxbzCCMWsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAlfF31Sorexi6V
# DaqKvqPSZPTK8m6tmXJIhpHd38D/A6CCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0eMIIdGgIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# 0NxV5Epo/Hbnhk9Tz4DP5vGqTlyh0hRCsHVjo7CAVN8wDQYJKoZIhvcNAQEBBQAE
# ggIAA48gZkkpsPYtXhzHy19sMcXz422cESK6Sz0MtF2SLK7O4cGVYQ8QC6KmERz5
# NfKOPDNy4XggqIdWrXssP6H8NpTnqQnasVURt2p8u+RZcl6Ej9HD2yX6fL2ynLk6
# A11WLBuW4N0wehtcup+/5FXVzozChPOMNQ6IovWRo/hL1X7WO53BZk4TBRWvC/Nk
# HkYDqtvCUOsxY3n+OUueM/EWzVJZsAC20WHD2pi6eosF8+mhStEI7hE0obxc/AJO
# ukmBP18NI/vfFcIRgDffmhUk5YTrku7pLuCsq0eQrM5yLEbFh9EQvbmoBoPG0uyV
# KZ93WiFJjFRqDxDRoqF4dk4oVw3ohG4ivHh8UYil20hWEZJEJ7Msi79gcKZsbLjA
# rI5SLkaU6TNvsTwL95gvKd1eRHRYF3YqOpSPtvhyRj867qSxURufxcgyGEBib/IK
# DKMFdO6FctZpcba51Hbx6gKm2TE2Lq4KFd47tIi9RDcHbwdycQ8n+fFzWMhtPt77
# YXVFyKxJkCFoY/JWXNb25hjBU+1YYaFlxx5E6hGztFacu/JWPoU4thb8hqKOQgmj
# XBwnge/QXciosja/WCxIAUUPM4V6t4JFdD4dtQ8MNbiaCVR+ttMHn7d6bS6lCQYo
# njwy2fLscbfcZ20IZFndswAIxL1iYoozU+1Yk1t+tACRvO6hghnrMIIZ5wYKKwYB
# BAGCNwMDATGCGdcwghnTBgkqhkiG9w0BBwKgghnEMIIZwAIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH3BgsqhkiG9w0BCRABBKCB5wSB5DCB4QIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCA/yB+WGlYn0Ro8RvuLCH3FJxGTXIVPUGjqde1s387d
# WQIUem7rJTGFm0PsL8mnRX4U1H7OWPwYDzIwMjYwNzE0MTU1MTA2WqB2pHQwcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDkdyZWF0ZXIgTG9uZG9uMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzN6CCFBcwggbiMIIEyqADAgECAhEA507yVbBQT/rbpt/3
# /IujFTANBgkqhkiG9w0BAQwFADBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIENBIFI0MTAeFw0yNjAzMjUwMDAwMDBaFw0zNzA2MjQyMzU5NTlaMHIxCzAJ
# BgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIFNpZ25lciBSMzcwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCy
# /8NtS9xQ2UUtBRF32bj7VK3n4m50Uqjk/zTciSziYV40H1LKah0/oEklYG42E4VC
# P3DvsBUB6DmpCkDZ0jCnZBPIEevaH15ZJOQwFWP2ZXr5YjlJpb68Nlbs+ElNvKx3
# 2/1YHde3qqUSLybjulxPLz6T85+HOIqK7M1Bep8LspyhEP/q6nw5kGxTSrGvufme
# H+JF8CnVBcVMFA40FlIYh0cDJVFhhfTfdWgLy/vWuLMQoKkf3s/FvByf16r0rtby
# Hm/iemwxSioJL9zyZDDKUNAbHXl0dhXo2VxUV2NcPXWXuoKsjL+6cfk6Vm2DHnxA
# lFdFsaBDIF1JOkSnC6PeLlBznZn2buF3vIIYJcq6N/zeFRCk4/HXDz7zgRsRRMdU
# B+rhyk5FoZaBjw0nLq3GZ3fClLUx5es5pUAxzNODMBn7JkFYip2BAGBPER5eV0RO
# hk6tGTG+fUiMiV+vgjg1YnP5FvnYWyEtWeQD/B2hp3vz0RvtdkM0p3igyadzrfpO
# Bq5ppVk/YsuhTQkP99ivneHAGfi5e7lmxJ+meoBPrRLuzMmb81rzzbESjJHMsn5R
# Vtc6Ucs7rcMqQC13PUIO7BbGBETV2ufCmV6lPTp3P7XJOvmnUCRTPbVvMTpxP/z+
# SOHg4/OCBhiqs4FA9+4oQvlkk9w32NGASli9GWrm5wIDAQABo4IBjjCCAYowHwYD
# VR0jBBgwFoAUOnSlDGfGQlDC/bX8x7spNIL0erkwHQYDVR0OBBYEFGEQ6XoSr1HE
# hdTyz6R0D1DNIK/4MA4GA1UdDwEB/wQEAwIGwDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEoGA1UdIARDMEEwCAYGZ4EMAQQCMDUGDCsGAQQB
# sjEBAgEDCDAlMCMGCCsGAQUFBwIBFhdodHRwczovL3NlY3RpZ28uY29tL0NQUzBK
# BgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29Q
# dWJsaWNUaW1lU3RhbXBpbmdDQVI0MS5jcmwwegYIKwYBBQUHAQEEbjBsMEUGCCsG
# AQUFBzAChjlodHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1l
# U3RhbXBpbmdDQVI0MS5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
# Z28uY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAD6j2N0azN+hl6k6bKB5/U6VuSOs93
# ZBb3Pczy9VtBIKu4947Z5GwL0aFngIxl+GSuLFrJgPruBCRvKJEJsm7kv+LQ1COV
# CEG9tZ+IRtr4ocUoa53lgdFaENlS0N4wgkZkbQEPv+x+1lSjYh+T4JeL9mUznT7E
# rc6Sp5dWLka5sMP/m3GZi6oJPdPcsCKWagH7m2H2xDGIyHJC5PdH9phvi/Kmhkkt
# iSVTNNqVeV5bWdX2zhRE6UTfz0IcMoCL996lFIydXxOCE4MNDHDM0as4lnTiT/KH
# MccO6l8c9TnUVgmpci9ar1IABZ2U1XUkYjGGSn9MC3EHDP9V39VuBVvZ33/BEV/E
# WSRrf07T7jFplKX+gQr/UOqPGMlE7ZJ72UaUkNJy7bVl3bcLKzdpjIHzLkf/4MVa
# 1V7w8wqCv5W4gOnRGTlud5UMARbRM8BPxR/CXYXoMmIOD8pmTk2axgRL4LG8Xtuc
# hISdCHRmtacAmLGq5XSYSVTHTXADlO48iDKh3HM2r98LSF6f0sG12d8V9Jn7C3wD
# UieOxuKj4MdWrW+hiJU2kF87v6eH00HgCFFc2V0+CvfOCMn7juzS41jLaINcBlKW
# Q/fKb/uDLfWOW73z1I2lFY7Xj8tQ1XYtK5eREjWItM8jpl1cbQOc88btR+0XS2Tm
# boE/141+va2PWzCCBqcwggSPoAMCAQICEQCQrAhyIP3Fp8RrXMcN9z0GMA0GCSqG
# SIb3DQEBDAUAMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0
# ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBS
# NDYwHhcNMjYwMzI1MDAwMDAwWhcNNDEwMzI0MjM1OTU5WjBVMQswCQYDVQQGEwJH
# QjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1
# YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAK7kSqIBrYIcYvlmLVuaA8zw1RfBhkn4G1CoemzjcYtML6yNUvKm
# wGH7y6/5MuSC1UYP/+9KYDSqvMQt/1hEKHYxMAD9oZpBkoaDQFEKbOJHelsKe+Ba
# O0ZcENTKfePcraVkA7wrGAW2XHA5gQCQv4IKori/3PNOXxnDMOk8yIMgVrlMeTxq
# fWJ4XkjT1xc2s9DD7URHWWJOFobTPoWs6mrDFlaY9FlAHDYTfbzvxQHVsvRmn3W+
# 5ZmCwyk02I8KgGPT/UX4sTz41GiR+ppwUjQXa1+2tEHZbsdAKUtH3OPEVtZvlt7a
# tx4h83IdRR8oYi8wjY3OjFKXFecWpQbzzsPxbUKPwMWiTrzwkrFa8dH/1pDKRJt3
# 71W62PfqKPayCr/XbnBOlRn8CALSmHnRtGzuAWtTJpcT3BKw6oy8IIL6wSbu938F
# 6ZIbRNIc1dKbIJtr4ULN6R5ZfTdNEhwXctqp3RHDbg4fuOl6LjNoaFwjud92EEDh
# zxFJzE1jqN4csceZIwxOT1aqfsfh0uFQE/lgTBuBs3i6/WL2W1OceWLy3XEdXRK1
# f0EWCuea6dNfX2RRdjUfk5EltFnJkN2+bWhnK14OPRKcyjOv5hKZ0iV4NRNd1+hj
# tva1rPyzb5Bs7EvFxqEQhgZbOq7qH3nm0rBwA0dxniBOYCFPdu246JCxAgMBAAGj
# ggFuMIIBajAfBgNVHSMEGDAWgBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAdBgNVHQ4E
# FgQUOnSlDGfGQlDC/bX8x7spNIL0erkwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwIwYDVR0gBBwwGjAIBgZn
# gQwBBAIwDgYMKwYBBAGyMQECAQMIMEwGA1UdHwRFMEMwQaA/oD2GO2h0dHA6Ly9j
# cmwuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYu
# Y3JsMHwGCCsGAQUFBwEBBHAwbjBHBggrBgEFBQcwAoY7aHR0cDovL2NydC5zZWN0
# aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0YW1waW5nUm9vdFI0Ni5wN2MwIwYI
# KwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29tMA0GCSqGSIb3DQEBDAUA
# A4ICAQAy3lJHZvGeA2b43yhzoarvobHVzbfl+RfuPDwej0wCQkYAN6scTt2GwFe2
# 2qbOCv/tllqFlLKQZE+E9jVyuPTbyQHwrM7R0oLapAEDC1+CowsqSRf/ptira5Pf
# d4PoHICnb9coPQtyZmHSQp5y9IGvqWf1qNfq7V2fHZ8DvEQrLUzeoGF9BJRYu2Oz
# acW3QQtUum3NOVf0gPRwv6I4991uhncJ6VP4lcpUpHZKB7R3hiIUC09mR9KjzPVn
# XHvL9n2bAwiUECfK5Zezhiw27F2tgi39DETfU8M4n0N6xLgFzsf05M5GURX8C9+I
# X9V6kpmmKtrUzMti4LD66gtmf+mSm934K81NL6YQeMEk1rpYrWPypcW76Mir6wb1
# AgseLIHqn/GkeuQm7zOTDf3f5WoX14qVNjZWNHF3JxkutV6ZnhinfCLfdv5bnwKW
# UfceqOajCVntI6uCbHxjBg6SCsexc5AfIGno7gVFvwifT4XONPsSUaJ71XsJ+Evc
# iVUVnjOO4qxm0fWJTd8a7jP8mc4ZPqwJvQFtOp7+6G+kUJAF0fnE8YgD8uttBReN
# Ta1YmAeFMiqc38e8fI4eLm0zjM/eeGCHasnoqqrbGwcF41iz9HXzFDwN4iD5z3QS
# hp6HRiU3UpTwDJiiXcr0z6pjl7PyzJ3/tmWtGehV7CAfc/WlyzCCBoIwggRqoAMC
# AQICEDbCsL18Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTIxMDMyMjAwMDAwMFoX
# DTM4MDExODIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28g
# TGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBS
# b290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAIid2LlFZ50d
# 3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYsyAhTXiDQkiUvpVdYqZ1u
# YoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXVydmhx7Dx4IBrAou7hNGs
# KioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjthgF7Hjx4vvyVDQGsd5Ka
# rLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1gASn/hp6IuHJorEu6Eop
# oB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35ZvxQw6zid61qmrlD/IbKJA
# 6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6KdOpuzVDR3ZUwxDKL1wCA
# xgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhLRPb7YkzM8/6NnWH3T9Cl
# mcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb49zYHr7ALL8bAJyPDmub
# NqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRKKsxCG1t6tG9oj7liwPdd
# XEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5e45NuzAHteORlsSuDt5t
# 4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjggEWMIIBEjAfBgNVHSMEGDAW
# gBRTeb9aqitKz1SA4dibwJ3ysgNmyzAdBgNVHQ4EFgQU9ndq3T/9ARP/FqFsggIv
# 0Ao9FCUwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wEwYDVR0lBAww
# CgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMFAGA1UdHwRJMEcwRaBDoEGG
# P2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9VU0VSVHJ1c3RSU0FDZXJ0aWZpY2F0
# aW9uQXV0aG9yaXR5LmNybDA1BggrBgEFBQcBAQQpMCcwJQYIKwYBBQUHMAGGGWh0
# dHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcNAQEMBQADggIBAA6+ZUHt
# aES45aHF1BGH5Lc7JYzrftrIF5Ht2PFDxKKFOct/awAEWgHQMVHol9ZLSyd/pYMb
# aC0IZ+XBW9xhdkkmUV/KbUOiL7g98M/yzRyqUOZ1/IY7Ay0YbMniIibJrPcgFp73
# WDnRDKtVutShPSZQZAdtFwXnuiWl8eFARK3PmLqEm9UsVX+55DbVIz33Mbhba0HU
# TEYv3yJ1fwKGxPBsP/MgTECimh7eXomvMm0/GPxX2uhwCcs/YLxDnBdVVlxvDjHj
# O1cuwbOpkiJGHmLXXVNbsdXUC2xBrq9fLrfe8IBsA4hopwsCj8hTuwKXJlSTrZcP
# RVSccP5i9U28gZ7OMzoJGlxZ5384OKm0r568Mo9TYrqzKeKZgFo0fj2/0iHbj55h
# c20jfxvK3mQi+H7xpbzxZOFGm/yVQkpo+ffv5gdhp+hv1GDsvJOtJinJmgGbBFZI
# ThbqI+MHvAmMmkfb3fTxmSkop2mSJL1Y2x/955S29Gu0gSJIkc3z30vU/iXrMpWx
# 2tS7UVfVP+5tKuzGtgkP7d/doqDrLF1u6Ci3TpjAZdeLLlRQZm867eVeXED58LXd
# 1Dk6UvaAhvmWYXoiLz4JA5gPBcz7J311uahxCweNxE+xxxR3kT0WKzASo5G/PyDe
# z6NHdIUKBeE3jDPs2ACc6CkJ1Sji4PKWVT0/MYIEkzCCBI8CAQEwajBVMQswCQYD
# VQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0
# aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MQIRAOdO8lWwUE/626bf9/yL
# oxUwDQYJYIZIAWUDBAICBQCgggH6MBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAcBgkqhkiG9w0BCQUxDxcNMjYwNzE0MTU1MTA2WjA/BgkqhkiG9w0BCQQxMgQw
# 7YzKisUW43bd1Tl531lbelLYFroa2Aracu02qokNaF4265gpYuwjJLBHmoMeVyrW
# MIIBewYLKoZIhvcNAQkQAgwxggFqMIIBZjCCAWIwFgQU6XgYqSjaFQqf4b+czHqr
# uaAO7qwwgYgEFGXDKGlvfU5QLP0Dx8IGlxjK+/dPMHAwW6RZMFcxCzAJBgNVBAYT
# AkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28g
# UHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBSNDYCEQCQrAhyIP3Fp8RrXMcN9z0G
# MIG8BBSFPWMtk4KCYXzQkDXEkd6SwULaxzCBozCBjqSBizCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0plcnNleSBDaXR5MR4w
# HAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNVBAMTJVVTRVJUcnVz
# dCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkCEDbCsL18Gzrno7PdNsvJdWgw
# DQYJKoZIhvcNAQEBBQAEggIAEdgt6nCVXfZC4NXjlMd/e7OOfAyoiiCCZeEk9w/F
# NXTLMriFE7jgootJz8VoKUav05v9JZFbEitY4pP6fIzODICsj2jVT0QMhbAQmjBG
# K5iU3Bb7j+UsWRAwSf5CkNRa+9FmFz2iHZLUm5J279h/0wH31oQwtORLf8Vr8SIn
# dxiGo8YBIF0/RDM5eq9ZcYx0cJrkxcKHSyK8Jw/MMLqhQfBI2GHRkOgoDM/YBLrR
# HML+O5gzu6HjgGBNMn2Av9OTsJ1Q2HxLl3ZuUBPucdsEHGxmF1CJISyWQ62jv9Dm
# YHOjRoCEnrkuC60DA7zuWd8Y5AdrSDx32xUOdqXeGKbj6zNjhM1/3iRwdRWBW3J8
# Ors2v8NNCTmAA6YnYrA8bwqHUr659wM8cE5bhPFz/ZkwPH3l39/8HnlHUb/CuF8b
# cTHD3MTF6EjfYBuMKY9F5Xc2V6m6NK0lb8y6cH0rhuUsKIyNuwEg8lcSjJl+dg07
# zGQNDYzrM2avBnVAGFyy8Gj0RssBdxL15No2quu4//lG/3IxowRAS5DOJYB8sZwn
# HM4UkyPOaYqF+4O+XQ9MHbHnYf+WitsItDkw9W2ZFxTD95vQI445+3olwTLQ6iqb
# 16XEn66/qnLTUXSmpOEHor6Wo62DxRpvdalJigcK+Vbxp4jFNjj8Nacyo7QB8T0e
# O7M=
# SIG # End signature block

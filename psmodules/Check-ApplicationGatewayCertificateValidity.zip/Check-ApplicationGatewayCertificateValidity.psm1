function Check-ApplicationGatewayCertificateValidity {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName, 
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID, 
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName, 
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $IsCompliant = $false
    $Comments = ""
    
    [PSCustomObject] $PsObject = New-Object System.Collections.ArrayList
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $ApprovedCAList = @()

    # --------------------------------
    # Check if document exists in blob
    # --------------------------------
    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName
    $subName = ""

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
        $subName  = (Get-AzContext).Subscription.Name
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        # Use Entra/RBAC blob access because the Guardrails storage account no longer allows Shared Key auth.
        $StorageContext = New-ConnectedStorageContext -storageaccountName $StorageAccountName
    }
    catch {
        $storageErrorMessage = "Could not connect to storage account '$storageAccountName' in resource group '$resourceGroupName' of subscription '$SubscriptionID'; verify that the storage account exists and that you have permissions to it. Error: $_"
        $ErrorList.Add($storageErrorMessage) | Out-Null

        return [PSCustomObject]@{
            ComplianceResults = $null
            Errors            = $ErrorList
        }
    }

    $baseFileNameFound = $false
    $blobFound = $false

    try {
        # Fail fast on blob RBAC issues so they are reported as storage access problems instead of missing files.
        $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -ErrorAction Stop
        
        $fileNamesList = @()
        $blobs | ForEach-Object {
            $fileNamesList += $_.Name
        }
        $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
        if ( $matchingFiles.count -lt 1 ){
            # check if any fileName matches without the extension
            $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
            
            $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
            if ($BaseFileNamesMatch.Count -gt 0){
                $baseFileNameFound = $true
            }
        }
        else {
            # also covers the use case if more than 1 appropriate files are uploaded
            
            # check for procedure doc in blob storage account
            $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -Blob $DocumentName_new -ErrorAction Stop

            If ($blobs) {
                $blobFound = $true
                # Read the content of the blob and save CA names into array
                $blobContent = Get-AzStorageBlobContent -Container $ContainerName -Blob $DocumentName_new -Context $StorageContext -Force -ErrorAction Stop
                $ApprovedCAList = Get-Content $blobContent.Name | Where-Object { $_ -match '\S' } | ForEach-Object { $_.Trim() }

            }
        }
    }
    catch {
        $storageErrorMessage = "Could not read from storage account '$storageAccountName' container '$ContainerName' in resource group '$resourceGroupName' of subscription '$SubscriptionID'; verify that blob data access is available. Error: $_"
        $ErrorList.Add($storageErrorMessage) | Out-Null

        return [PSCustomObject]@{
            ComplianceResults = $null
            Errors            = $ErrorList
        }
    }
    

    # ----------------------
    # Case 1: uploaded fileName is correct but has wrong extension
    # ----------------------
    if ($baseFileNameFound){
        # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
        $Comments += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false

        $C = [PSCustomObject]@{
            SubscriptionName = $subName
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput

    }
    elseif ($blobFound){
    # ----------------------
    # Case 2: file exists in blob storage
    # ----------------------
        $Comments += $msgTable.approvedCAFileFound -f $DocumentName
    }
    else {
        # ----------------------
        # Case 3: file does not exist in blob storage
        # ----------------------
        $Comments += $msgTable.approvedCAFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false
        
        $C= [PSCustomObject]@{
            SubscriptionName = $subName
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput
    }

    # ----------------------
    # Case 2: Correct document exists (i.e. blobfound) - proceed with checking App Gateway certificate validity for subscriptions
    # ----------------------

    # Get all subscriptions in tenant scope
    # $subscriptions = Get-AzSubscription
    $allSubscriptions = Get-AzSubscription
    $subscriptions = $allSubscriptions | Where-Object { $_.State -eq 'Enabled' }
    $skippedSubscriptions = $allSubscriptions | Where-Object { $_.State -ne 'Enabled' }

    foreach ($skippedSubscription in $skippedSubscriptions) {
        $notEvaluatedResult = [PSCustomObject]@{
            SubscriptionName    = $skippedSubscription.Name
            ComplianceStatus    = false
            Comments            = ""
            ItemName            = $ItemName
            ControlName         = $ControlName
            ReportTime          = $ReportTime
            itsgcode            = $itsgcode
        }
        $notEvaluatedResult = Set-SubscriptionNotEvaluatedStatus -Result $notEvaluatedResult -SubscriptionName $skippedSubscription.Name -msgTable $msgTable
        $PsObject.Add($notEvaluatedResult) | Out-Null
    }

    foreach ($subscription in $subscriptions) {

        # Set the context to the current subscription
        Set-AzContext -Subscription $subscription.Id | Out-Null

        #initialize for each subscription
        $appGatewaysFound = $false
        $isSubCompliant = $true
        $subComments = ""
        $NotEvaluated = $false


        # Get Application Gateways in the current subscription
        $appGateways = Get-AzApplicationGateway

        if ($appGateways.Count -gt 0) {
            $appGatewaysFound = $true
            foreach ($appGateway in $appGateways) {
                # 4a. Check for SSL Certificates in listeners
                $listeners = Get-AzApplicationGatewayHttpListener -ApplicationGateway $appGateway
                $sslListeners = $listeners | Where-Object { $_.SslCertificate -ne $null }
                
                if ($sslListeners.Count -eq 0) {
                    $subComments += " " + $msgTable.noSslListenersFound -f $appGateway.Name
                    $isSubCompliant = $false
                    continue
                }

                foreach ($listener in $sslListeners) {
                    # Extract the certificate name from the Id
                    $certName = $listener.SslCertificate.Id.Split('/')[-1]

                    # 3. Check certificate validity
                    $cert = Get-AzApplicationGatewaySslCertificate -ApplicationGateway $appGateway -Name $certName
                    Write-Verbose "Cert is $cert"
                    Write-Verbose "Cert.PublicCertData exists: $($cert.PublicCertData -ne $null)"
                    Write-Verbose "Cert.KeyVaultSecretId exists: $($cert.KeyVaultSecretId -ne $null)"
                    
                    # Check if certificate is stored in Key Vault first
                    Write-Verbose "Looking for certificate name: $certName"
                    Write-Verbose "Available SSL certificates: $($appGateway.SslCertificates.Name -join ', ')"
                    $matchingCert = $appGateway.SslCertificates | Where-Object { $_.Name -eq $certName }
                    Write-Verbose "Matching certificate found: $($matchingCert -ne $null)"
                    $keyVaultSecretId = $matchingCert | Select-Object -ExpandProperty KeyVaultSecretId
                    
                    if ($keyVaultSecretId) {
                        Write-Verbose "Processing Key Vault certificate"
                        # Certificate is stored in Key Vault - need to retrieve and validate it
                        # Parse the Key Vault URL: https://testappgateway.vault.azure.net/secrets/myapp
                        $keyVaultUrlParts = $keyVaultSecretId -split '/'
                        # Strip .vault.azure.net and any explicit port (e.g. :443) from the hostname
                        $keyVaultName = $keyVaultUrlParts[2] -replace '\.vault\.azure\.net(:\d+)?$', ''
                        # Use last non-empty segment to handle URLs with a trailing slash
                        $secretName = ($keyVaultUrlParts | Where-Object { $_ -ne '' } | Select-Object -Last 1)
                                                
                        # Validate that we have the required values
                        if ([string]::IsNullOrEmpty($keyVaultName) -or [string]::IsNullOrEmpty($secretName)) {
                            Write-Warning "Failed to parse Key Vault URL properly"
                            $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to parse Key Vault URL '$keyVaultSecretId' for listener '$($listener.Name)'. Expected format: https://[vaultname].vault.azure.net/secrets/[secretname].")
                            # Set Compliant to Non compliant as this is a parsing issue
                            $isSubCompliant = $false
                            continue
                        }
                        $kvAccessResult = Test-KeyVaultAccess -KeyVaultName $keyVaultName -SecretName $secretName
                        if (-not $kvAccessResult.Success) {
                            Write-Warning "KeyVault access not successful."
                            $subComments += " " + $msgTable.keyVaultCertValidationFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("No access to Key Vault '$keyVaultName' for listener '$($listener.Name)'. The CAC Automation Account managed identity requires 'Key Vault Secrets User' permissions on this Key Vault. Error: $($kvAccessResult.Error).")
                            # Don't set isSubCompliant to true - set NotEvaluated flag
                            $NotEvaluated = $true
                            continue
                        }
                        try {
                            $keyVaultCert = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName -ErrorAction Stop
                            
                            if ($keyVaultCert.SecretValue) {
                                # Convert SecureString to plain text first, then to certificate
                                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($keyVaultCert.SecretValue)
                                $plainTextSecret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                                [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
                                # Convert secret value to certificate
                                try {
                                    $certBytes = [System.Convert]::FromBase64String($plainTextSecret)
                                    $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                                    $certCollection.Import($certBytes)

                                    $x509cert = Get-LeafCertificate -CertificateCollection $certCollection

                                    Write-Verbose "Successfully imported certificate from Key Vault"
                                }
                                catch [System.FormatException] {                                    
                                    Write-Error "Base64 conversion failed: $($_.Exception.Message)"
                                    $ErrorList.Add("Base64 conversion failed: $($_.Exception.Message)")
                                    continue
                                }
                                
                                # Validate certificate expiration
                                if ($x509cert.NotAfter -le (Get-Date)) {
                                    $subComments += " " + $msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                    $isSubCompliant = $false
                                }
                                
                                # Check if certificate chains up to an approved CA
                                $caResult = Test-CertificateAuthorityApproved -Certificate $x509cert -CertificateCollection $certCollection -ApprovedCAList $ApprovedCAList

                                if (-not $caResult.IsApproved) {
                                    $issuerDetail = "$($x509cert.Issuer) [$($caResult.ChainPath)]"
                                    $subComments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $issuerDetail
                                    $isSubCompliant = $false
                                }
                            }
                            else {
                                Write-Verbose "KeyVault secret has no value."
                                $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                                $ErrorList.Add("Key Vault secret '$secretName' in vault '$keyVaultName' has no value for listener '$($listener.Name)'.")
                                $isSubCompliant = $false
                            }
                        }
                        catch {
                            Write-Verbose "KeyVault certificate retrieval failed"
                            $subComments += " " + $msgTable.keyVaultCertRetrievalFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to retrieve certificate from Key Vault '$keyVaultName' for listener '$($listener.Name)': $_ .")
                             $isSubCompliant = $false
                        }
                    }
                    elseif ($cert.PublicCertData) {
                        Write-Verbose "Processing direct certificate (not in Key Vault)"
                        # Certificate is uploaded directly to Application Gateway
                        try {
                            $certBytes = [System.Convert]::FromBase64String($cert.PublicCertData)
                            $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                            $certCollection.Import($certBytes)

                            $x509cert = Get-LeafCertificate -CertificateCollection $certCollection

                            if ($x509cert.NotAfter -le (Get-Date)) {
                                $subComments += " " +$msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                $isSubCompliant = $false
                            }

                            # Check if certificate chains up to an approved CA
                            $caResult = Test-CertificateAuthorityApproved -Certificate $x509cert -CertificateCollection $certCollection -ApprovedCAList $ApprovedCAList

                            if (-not $caResult.IsApproved) {
                                $issuerDetail = "$($x509cert.Issuer) [$($caResult.ChainPath)]"
                                $subComments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $issuerDetail
                                $isSubCompliant = $false
                            }
                        }
                        catch {
                            $subComments += " " + $msgTable.unableToProcessCertData -f $listener.Name, $appGateway.Name, $_.Exception.Message
                            $isSubCompliant = $false
                        }
                    }
                    else {
                        Write-Verbose "Certificate has no PublicCertData and no KeyVaultSecretId"
                        $subComments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                        $isSubCompliant = $false
                    }
                }

                # 3. Check HTTPS backend settings for well-known CA certificates
                $httpsBackendSettings = $appGateway.BackendHttpSettingsCollection | 
                    Where-Object { $_.Protocol -eq 'Https' }

                if ($httpsBackendSettings.Count -eq 0) {
                    $subComments += " " + $msgTable.noHttpsBackendSettingsFound -f $appGateway.Name
                } else {
                    $allWellKnownCA = $true
                    foreach ($backendSetting in $httpsBackendSettings) {
                        if ($backendSetting.TrustedRootCertificates.Count -gt 0) {
                            # Manual trusted root certs are present — this backend setting is not using
                            # a built-in well-known CA, so clear the gateway-level flag regardless of
                            # whether the roots turn out to be approved or not.
                            $allWellKnownCA = $false

                            # Separately, check every root cert against the ApprovedCAList.
                            # Department-approved CAs (e.g. internal government PKI roots) must be
                            # configured as manual trusted roots because Azure does not include them
                            # in its built-in trust store.
                            $allRootCertsApproved = $true
                            foreach ($trustedRootCertRef in $backendSetting.TrustedRootCertificates) {
                                $rootCertName = $trustedRootCertRef.Id.Split('/')[-1]
                                $rootCertObj  = $appGateway.TrustedRootCertificates | Where-Object { $_.Name -eq $rootCertName }

                                if ($rootCertObj -and $rootCertObj.Data) {
                                    try {
                                        $rootCertBytes = [System.Convert]::FromBase64String($rootCertObj.Data)
                                        $rootX509      = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @(,$rootCertBytes)

                                        $isApprovedRootCA = $false
                                        foreach ($approvedCA in $ApprovedCAList) {
                                            if ($rootX509.Subject -like "*$approvedCA*" -or $approvedCA -like "*$($rootX509.Subject)*") {
                                                $isApprovedRootCA = $true
                                                break
                                            }
                                        }

                                        if (-not $isApprovedRootCA) {
                                            $allRootCertsApproved = $false
                                            $subComments += " " + $msgTable.manualTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                                        }
                                    }
                                    catch {
                                        $allRootCertsApproved = $false
                                        $subComments += " " + $msgTable.unableToProcessCertData -f $backendSetting.Name, $appGateway.Name, $_.Exception.Message
                                    }
                                } else {
                                    $allRootCertsApproved = $false
                                    $subComments += " " + $msgTable.manualTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                                }
                            }

                            # $allRootCertsApproved drives compliance directly — independent of $allWellKnownCA
                            if ($allRootCertsApproved) {
                                $subComments += " " + $msgTable.approvedTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                            } else {
                                $isSubCompliant = $false
                            }
                        }
                    }

                    if ($allWellKnownCA) {
                        $subComments += " " + $msgTable.allBackendSettingsUseWellKnownCA -f $appGateway.Name
                    }
                }
            }
        }
    
    
        # Determine per-subscription compliance status and Comments
        if (-not $appGatewaysFound) {
            $subComments = $msgTable.noAppGatewayFound -f $subscription.Name
            $IsCompliant = $true
            Write-Verbose "No app gateways found - Comments: $Comments"
        }
        else {
            $IsCompliant = $isSubCompliant
            if (-not $NotEvaluated) {
                Write-Verbose "App gateways found - IsCompliant: $IsCompliant, allCompliant: $allCompliant"
                if ($IsCompliant){
                    $subComments= $msgTable.allCertificatesValid
                }
            }
            elseif($NotEvaluated){
                $IsCompliant = "Not Available"
                Write-Verbose "App gateways found but certificate validation could not be completed due to errors accessing certificate data - IsCompliant: $IsCompliant, Comments: $subComments"
            }
        }
        
        # Add evaluation info for each subscription
        $C = [PSCustomObject]@{
            SubscriptionName   = $subscription.Name
            ComplianceStatus   = $IsCompliant 
            ControlName        = $ControlName
            Comments           = $subComments
            ItemName           = $ItemName
            ReportTime         = $ReportTime
            itsgcode           = $itsgcode
        }

        # Add profile information if MCUP feature is enabled
        if ($EnableMultiCloudProfiles) {
            $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subscription.Id -ErrorList $ErrorList
            Write-Host "$result"
            $PsObject.Add($result) | Out-Null
        } else {
            $PsObject.Add($C) | Out-Null
        }

    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
    return $moduleOutput
}

function Test-KeyVaultAccess {
    param (
        [Parameter(Mandatory=$true)]
        [string]$KeyVaultName,
        [Parameter(Mandatory=$true)]
        [string]$SecretName
    )
    $result = @{ Success = $false; Error = $null }
    try {
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -ErrorAction Stop
        $result.Success = $true
    } catch {
        $result.Error = $_.Exception.Message
    }
    return $result
}

function Get-LeafCertificate {
    <#
    .SYNOPSIS
        Returns the end-entity (leaf) certificate from an imported certificate collection.
    .DESCRIPTION
        A PFX or PKCS#7 payload uploaded to an Application Gateway can hold the leaf certificate
        plus one or more CA certificates, in any order, so the collection cannot be indexed blindly.
        The leaf is the certificate whose Subject is not the Issuer of any other certificate in
        the collection.
    #>
    param (
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2[]] $CertificateCollection
    )

    $leaf = $CertificateCollection | Where-Object {
        $subject    = $_.Subject
        $thumbprint = $_.Thumbprint
        -not ($CertificateCollection | Where-Object { $_.Issuer -eq $subject -and $_.Thumbprint -ne $thumbprint })
    } | Select-Object -First 1

    if (-not $leaf) {
        Write-Verbose "Could not identify the leaf certificate in the collection; falling back to the first certificate."
        $leaf = $CertificateCollection[0]
    }

    return $leaf
}

function Test-CertificateAuthorityApproved {
    <#
    .SYNOPSIS
        Determines whether a certificate chains up to a Certificate Authority on the approved CA list.
    .DESCRIPTION
        The approved CA list names trust anchors (for example 'ISRG Root X1'), but publicly trusted
        certificates are nearly always signed by an intermediate CA (for example Let's Encrypt 'R10').
        Comparing only the leaf certificate's immediate issuer therefore reports legitimate
        certificates as unapproved, so every CA in the certificate's trust chain is considered.

        Authorities are gathered from three sources so that a match is still possible when the
        chain cannot be completed: the leaf's immediate issuer, the certificates bundled alongside
        the leaf, and the chain built by the platform. The Issuer of the top-most bundled CA
        certificate names the root even when the root certificate itself was not uploaded.
    .OUTPUTS
        PSCustomObject with IsApproved, MatchedCA and ChainPath properties.
    #>
    param (
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2] $Certificate,
        [System.Security.Cryptography.X509Certificates.X509Certificate2[]] $CertificateCollection,
        [string[]] $ApprovedCAList
    )

    $authorities = [System.Collections.Generic.List[string]]::new()
    $chainPath   = [System.Collections.Generic.List[string]]::new()

    $authorities.Add($Certificate.Issuer)

    if ($CertificateCollection) {
        foreach ($bundledCert in $CertificateCollection) {
            if ($bundledCert.Thumbprint -ne $Certificate.Thumbprint) {
                $authorities.Add($bundledCert.Subject)
            }
            $authorities.Add($bundledCert.Issuer)
        }
    }

    $chain = $null
    try {
        $chain = [System.Security.Cryptography.X509Certificates.X509Chain]::new()
        # Revocation endpoints are not reliably reachable from the Automation sandbox, and an
        # expired or untrusted chain must still be walked so its CAs can be compared to the list.
        $chain.ChainPolicy.RevocationMode = [System.Security.Cryptography.X509Certificates.X509RevocationMode]::NoCheck
        $chain.ChainPolicy.VerificationFlags = [System.Security.Cryptography.X509Certificates.X509VerificationFlags]::AllowUnknownCertificateAuthority
        # Bound the AIA lookup used to locate a missing issuer.
        $chain.ChainPolicy.UrlRetrievalTimeout = [TimeSpan]::FromSeconds(15)

        if ($CertificateCollection) {
            foreach ($bundledCert in $CertificateCollection) {
                if ($bundledCert.Thumbprint -ne $Certificate.Thumbprint) {
                    $null = $chain.ChainPolicy.ExtraStore.Add($bundledCert)
                }
            }
        }

        $null = $chain.Build($Certificate)

        foreach ($element in $chain.ChainElements) {
            $chainPath.Add($element.Certificate.Subject)
            $authorities.Add($element.Certificate.Subject)
            $authorities.Add($element.Certificate.Issuer)
        }
    }
    catch {
        Write-Verbose "Unable to build the trust chain for '$($Certificate.Subject)': $($_.Exception.Message)"
    }
    finally {
        if ($chain) { $chain.Dispose() }
    }

    if ($chainPath.Count -eq 0) {
        $chainPath.Add($Certificate.Subject)
    }

    # An empty entry on either side of the comparison turns the wildcard match into "*", which
    # would approve every certificate.
    $candidateAuthorities = $authorities | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    $matchedCA = $null
    foreach ($approvedCA in $ApprovedCAList) {
        if ([string]::IsNullOrWhiteSpace($approvedCA)) { continue }

        foreach ($authority in $candidateAuthorities) {
            if ($authority -like "*$approvedCA*" -or $approvedCA -like "*$authority*") {
                $matchedCA = $approvedCA
                break
            }
        }

        if ($matchedCA) { break }
    }

    return [PSCustomObject]@{
        IsApproved = [bool]$matchedCA
        MatchedCA  = $matchedCA
        ChainPath  = ($chainPath -join ' > ')
    }
}
function Check-ApplicationGatewayCertificateValidity {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName, 
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID, 
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName, 
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $IsCompliant = $false
    $Comments = ""
    $ErrorList = [System.Collections.ArrayList]@()
    $ApprovedCAList = @()

    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        $StorageAccount = Get-Azstorageaccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ErrorAction Stop
    }
    catch {
        $ErrorList.Add("Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_")
        Write-Error "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_"
    }

    $baseFileNameFound = $false
    $blobFound = $false

    # Get a list of filenames uploaded in the blob storage
    $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageAccount.Context
    
    $fileNamesList = @()
    $blobs | ForEach-Object {
        $fileNamesList += $_.Name
    }
    $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
    if ( $matchingFiles.count -lt 1 ){
        # check if any fileName matches without the extension
        $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
        
        $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
        if ($BaseFileNamesMatch.Count -gt 0){
            $baseFileNameFound = $true
        }
    }
    else {
        # also covers the use case if more than 1 appropriate files are uploaded
        
        # check for procedure doc in blob storage account
        $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageAccount.Context -Blob $DocumentName_new

        If ($blobs) {
            $blobFound = $true
            # Read the content of the blob and save CA names into array
            $blobContent = Get-AzStorageBlobContent -Container $ContainerName -Blob $DocumentName_new -Context $StorageAccount.Context -Force
            $ApprovedCAList = Get-Content $blobContent.Name | Where-Object { $_ -match '\S' } | ForEach-Object { $_.Trim() }

        }
    }

    # Use case: uploaded fileName is correct but has wrong extension
    if ($baseFileNameFound){
        # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
        $Comments += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false

        $PsObject = [PSCustomObject]@{
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        if ($EnableMultiCloudProfiles) {
            Set-ProfileEvaluation -PsObject $PsObject -ErrorList $ErrorList -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput

    }
    elseif ($blobFound){
        $Comments += $msgTable.approvedCAFileFound -f $DocumentName
    }
    else {
        $Comments += $msgTable.approvedCAFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
        $IsCompliant = $false
        
        $PsObject = [PSCustomObject]@{
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }

        if ($EnableMultiCloudProfiles) {
            Set-ProfileEvaluation -PsObject $PsObject -ErrorList $ErrorList -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
        }
    
        $moduleOutput = [PSCustomObject]@{ 
            ComplianceResults = $PsObject
            Errors            = $ErrorList
        }
        return $moduleOutput
    }

    # Get all subscriptions
    $subscriptions = Get-AzSubscription

    $allCompliant = $true
    $appGatewaysFound = $false
    $NotEvaluated = $false

    foreach ($subscription in $subscriptions) {
        # Set the context to the current subscription
        Set-AzContext -Subscription $subscription.Id | Out-Null

        # Get Application Gateways in the current subscription
        $appGateways = Get-AzApplicationGateway

        if ($appGateways.Count -gt 0) {
            $appGatewaysFound = $true
            foreach ($appGateway in $appGateways) {
                # 2. Check for SSL Certificates in listeners
                $listeners = Get-AzApplicationGatewayHttpListener -ApplicationGateway $appGateway
                $sslListeners = $listeners | Where-Object { $_.SslCertificate -ne $null }
                
                if ($sslListeners.Count -eq 0) {
                    $Comments += " " + $msgTable.noSslListenersFound -f $appGateway.Name
                    $allCompliant = $false
                    continue
                }

                foreach ($listener in $sslListeners) {
                    # Extract the certificate name from the Id
                    $certName = $listener.SslCertificate.Id.Split('/')[-1]

                    # 3. Check certificate validity
                    $cert = Get-AzApplicationGatewaySslCertificate -ApplicationGateway $appGateway -Name $certName
                    Write-Verbose "Cert is $cert"
                    Write-Verbose "Cert.PublicCertData exists: $($cert.PublicCertData -ne $null)"
                    Write-Verbose "Cert.KeyVaultSecretId exists: $($cert.KeyVaultSecretId -ne $null)"
                    
                    # Check if certificate is stored in Key Vault first
                    Write-Verbose "Looking for certificate name: $certName"
                    Write-Verbose "Available SSL certificates: $($appGateway.SslCertificates.Name -join ', ')"
                    $matchingCert = $appGateway.SslCertificates | Where-Object { $_.Name -eq $certName }
                    Write-Verbose "Matching certificate found: $($matchingCert -ne $null)"
                    $keyVaultSecretId = $matchingCert | Select-Object -ExpandProperty KeyVaultSecretId
                    
                    if ($keyVaultSecretId) {
                        Write-Verbose "Processing Key Vault certificate"
                        # Certificate is stored in Key Vault - need to retrieve and validate it
                        # Parse the Key Vault URL: https://testappgateway.vault.azure.net/secrets/myapp
                        $keyVaultUrlParts = $keyVaultSecretId -split '/'
                        $keyVaultName = $keyVaultUrlParts[2] -replace '\.vault\.azure\.net', ''
                        $secretName = $keyVaultUrlParts[-1]
                        
                        # Validate that we have the required values
                        if ([string]::IsNullOrEmpty($keyVaultName) -or [string]::IsNullOrEmpty($secretName)) {
                            Write-Warning "Failed to parse Key Vault URL properly"
                            $Comments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to parse Key Vault URL '$keyVaultSecretId' for listener '$($listener.Name)'. Expected format: https://[vaultname].vault.azure.net/secrets/[secretname].")
                            # Set Compliant to Non compliant as this is a parsing issue
                            $allCompliant = $false
                            continue
                        }
                        $kvAccessResult = Test-KeyVaultAccess -KeyVaultName $keyVaultName -SecretName $secretName
                        if (-not $kvAccessResult.Success) {
                            Write-Warning "KeyVault access not successful."
                            $Comments += " " + $msgTable.keyVaultCertValidationFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("No access to Key Vault '$keyVaultName' for listener '$($listener.Name)'. The CAC Automation Account managed identity requires 'Key Vault Secrets User' permissions on this Key Vault. Error: $($kvAccessResult.Error).")
                            # Don't set allCompliant to true - set NotEvaluated flag
                            $NotEvaluated = $true
                            continue
                        }
                        try {
                            $keyVaultCert = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName -ErrorAction Stop
                            
                            if ($keyVaultCert.SecretValue) {
                                # Convert SecureString to plain text first, then to certificate
                                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($keyVaultCert.SecretValue)
                                $plainTextSecret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                                [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
                                # Convert secret value to certificate
                                try {
                                    $certBytes = [System.Convert]::FromBase64String($plainTextSecret)
                                    $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                                    $certCollection.Import($certBytes)
                                    $x509cert = $certCollection[0]
                                    Write-Verbose "Successfully imported certificate from Key Vault"
                                }
                                catch [System.FormatException] {                                    
                                    Write-Error "Base64 conversion failed: $($_.Exception.Message)"
                                    $ErrorList.Add("Base64 conversion failed: $($_.Exception.Message)")
                                    continue
                                }
                                
                                # Validate certificate expiration
                                if ($x509cert.NotAfter -le (Get-Date)) {
                                    $Comments += " " + $msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                    $allCompliant = $false
                                }
                                
                                # Check if certificate is from an approved CA
                                $isApprovedCA = $false
                                foreach ($approvedCA in $ApprovedCAList) {
                                    if ($x509cert.Issuer -like "*$approvedCA*" -or $approvedCA -like "*$($x509cert.Issuer)*") {
                                        $isApprovedCA = $true
                                        break
                                    }
                                }
                                
                                if (-not $isApprovedCA) {
                                    $Comments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $x509cert.Issuer
                                    $allCompliant = $false
                                }
                            }
                            else {
                                Write-Verbose "KeyVault secret has no value."
                                $Comments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                                $ErrorList.Add("Key Vault secret '$secretName' in vault '$keyVaultName' has no value for listener '$($listener.Name)'.")
                                $allCompliant = $false
                            }
                        }
                        catch {
                            Write-Verbose "KeyVault certificate retrieval failed"
                            $Comments += " " + $msgTable.keyVaultCertRetrievalFailed -f $listener.Name, $appGateway.Name
                            $ErrorList.Add("Failed to retrieve certificate from Key Vault '$keyVaultName' for listener '$($listener.Name)': $_ .")
                             $allCompliant = $false
                        }
                    }
                    elseif ($cert.PublicCertData) {
                        Write-Verbose "Processing direct certificate (not in Key Vault)"
                        # Certificate is uploaded directly to Application Gateway
                        try {
                            $certBytes = [System.Convert]::FromBase64String($cert.PublicCertData)
                            $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                            $certCollection.Import($certBytes)
                            $x509cert = $certCollection[0]
                        
                            if ($x509cert.NotAfter -le (Get-Date)) {
                                $Comments += " " +$msgTable.expiredCertificateFound -f $listener.Name, $appGateway.Name
                                $allCompliant = $false
                            }

                            # Check if certificate is from an approved CA
                            $isApprovedCA = $false
                            foreach ($approvedCA in $ApprovedCAList) {
                                if ($x509cert.Issuer -like "*$approvedCA*" -or $approvedCA -like "*$($x509cert.Issuer)*") {
                                    $isApprovedCA = $true
                                    break
                                }
                            }

                            if (-not $isApprovedCA) {
                                $Comments += " " + $msgTable.unapprovedCAFound -f $listener.Name, $appGateway.Name, $x509cert.Issuer
                                $allCompliant = $false
                            }
                        }
                        catch {
                            $Comments += " " + $msgTable.unableToProcessCertData -f $listener.Name, $appGateway.Name, $_.Exception.Message
                            $allCompliant = $false
                        }
                    }
                    else {
                        Write-Verbose "Certificate has no PublicCertData and no KeyVaultSecretId"
                        $Comments += " " + $msgTable.unableToRetrieveCertData -f $listener.Name, $appGateway.Name
                        $allCompliant = $false
                    }
                }

                # 3. Check HTTPS backend settings for well-known CA certificates
                $httpsBackendSettings = $appGateway.BackendHttpSettingsCollection | 
                    Where-Object { $_.Protocol -eq 'Https' }

                if ($httpsBackendSettings.Count -eq 0) {
                    $Comments += " " + $msgTable.noHttpsBackendSettingsFound -f $appGateway.Name
                } else {
                    $allWellKnownCA = $true
                    foreach ($backendSetting in $httpsBackendSettings) {
                        if ($backendSetting.TrustedRootCertificates.Count -gt 0) {
                            $Comments += " " + $msgTable.manualTrustedRootCertsFound -f $appGateway.Name, $backendSetting.Name
                            $allWellKnownCA = $false
                        }
                    }

                    if ($allWellKnownCA) {
                        $Comments += " " + $msgTable.allBackendSettingsUseWellKnownCA -f $appGateway.Name
                    } else {
                        $allCompliant = $false
                    }
                }
            }
        }
    }
    
    if (-not $appGatewaysFound) {
        $Comments = $msgTable.noAppGatewayFound
        $IsCompliant = $true
        Write-Verbose "No app gateways found - Comments: $Comments"
    } else {
        $IsCompliant = $allCompliant
        if (-not $NotEvaluated) {
            Write-Verbose "App gateways found - IsCompliant: $IsCompliant, allCompliant: $allCompliant"
            if ($IsCompliant) {
                $Comments = $msgTable.allCertificatesValid
            }
        }
    }
    

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = if ($NotEvaluated) { "Not Available" } else { $IsCompliant }
        ControlName      = $ControlName
        Comments         = $Comments
        ItemName         = $ItemName
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    if ($EnableMultiCloudProfiles) {
        Set-ProfileEvaluation -PsObject $PsObject -ErrorList $ErrorList -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
    return $moduleOutput
}

function Test-KeyVaultAccess {
    param (
        [Parameter(Mandatory=$true)]
        [string]$KeyVaultName,
        [Parameter(Mandatory=$true)]
        [string]$SecretName
    )
    $result = @{ Success = $false; Error = $null }
    try {
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -ErrorAction Stop
        $result.Success = $true
    } catch {
        $result.Error = $_.Exception.Message
    }
    return $result
}

function Set-ProfileEvaluation {
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$PsObject,
        [Parameter(Mandatory=$true)]
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList,
        [Parameter(Mandatory=$true)]
        [string]$CloudUsageProfiles,
        [Parameter(Mandatory=$true)]
        [string]$ModuleProfiles
    )

    $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
    if (!$evalResult.ShouldEvaluate) {
        if(!$evalResult.ShouldAvailable ){
            if ($evalResult.Profile -gt 0) {
                $PsObject.ComplianceStatus = "Not Applicable"
                $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile -Force
                $PsObject.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
            } else {
                # Add error to ErrorList instead of throwing
                 [void]$ErrorList.Add("Error occurred while evaluating profile configuration availability")
            }
        } else {
            if ($evalResult.Profile -gt 0) {
                $PsObject.ComplianceStatus = "Not Applicable"
                $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile -Force
                $PsObject.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
            } else {
                # Add error to ErrorList instead of throwing
                [void]$ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        }
    } else {
        $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile -Force
    }
}
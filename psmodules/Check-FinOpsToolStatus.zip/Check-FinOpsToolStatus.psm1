function Check-FinOpsToolStatus {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    [bool] $IsCompliant = $true
    [string] $Comments = ""
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList

    # Check 1: Verify Service Principal existence
    $spnExists = Check-ServicePrincipalExists "CloudabilityUtilizationDataCollector"
    if (-not $spnExists) {
        $IsCompliant = $false
        $Comments += $msgTable.SPNNotExist + " "
    }
    else {
        # Check 2: Verify Permissions (only if SPN exists)
        $hasCorrectPermissions = Check-ServicePrincipalPermissions "CloudabilityUtilizationDataCollector"
        if (-not $hasCorrectPermissions) {
            $IsCompliant = $false
            $Comments += $msgTable.SPNIncorrectPermissions + " "
        }
    }

    # # Check 3: Verify Roles
    # $hasCorrectRoles = Check-ServicePrincipalRoles "CloudabilityUtilizationDataCollector"
    # if (-not $hasCorrectRoles) {
    #     $IsCompliant = $false
    #     $Comments += $msgTable.SPNIncorrectRoles + " "
    # }

    if ($IsCompliant) {
        $Comments = $msgTable.FinOpsToolCompliant
    } else {
        $Comments = $msgTable.FinOpsToolNonCompliant -f $Comments.Trim()
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        Comments         = $Comments
        ItemName         = $ItemName
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    # Add profile information if MCUP feature is enabled
    if ($EnableMultiCloudProfiles) {
        $result = Add-ProfileInformation -Result $PsObject -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
        $PsObject = $result
    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
    return $moduleOutput
}

function Check-ServicePrincipalExists {
    param (
        [string] $spnName
    )
    try {
        $urlPath = "/servicePrincipals?`$filter=displayName eq '$spnName'"
        $response = Invoke-GraphQueryEX -urlPath $urlPath -ErrorAction Stop
        $data = $response.Content.value
                
        if ($null -ne $data -and $data.Count -gt 0) {
            return $true
        } else {
            Write-Warning "SPN '$spnName' not found"
            return $false
        }
    }
    catch {
        Write-Error "Error checking Service Principal existence: $_"
        return $false
    }
}

function Check-ServicePrincipalPermissions {
    param (
        [string] $spnName
    )
    try {
        # First, get the Service Principal
        $urlPath = "/servicePrincipals?`$filter=displayName eq '$spnName'"
        $response = Invoke-GraphQueryEX -urlPath $urlPath -ErrorAction Stop
        $spnList = $response.Content.value
        
        if ($null -eq $spnList -or $spnList.Count -eq 0) {
            Write-Warning "Service Principal '$spnName' not found"
            return $false
        }
        
        $spn = $spnList[0]

        # Get the oauth2PermissionGrants
        $urlPath = "/servicePrincipals/{0}/oauth2PermissionGrants" -f $spn.id
        $permissionResponse = Invoke-GraphQueryEX -urlPath $urlPath -ErrorAction Stop
        $permissionGrants = $permissionResponse.Content.value
        
        # Check delegated permissions (oauth2PermissionGrants)
        $delegatedPermissions = @()
        foreach ($grant in $permissionGrants) {
            $delegatedPermissions += $grant.scope -split ' '
        }

        Write-Verbose "Found delegated permissions: $($delegatedPermissions -join ', ')"

        # Define required permissions to check
        $requiredPermissions = @(
            "User.Read",              # for Microsoft Graph
            "user_impersonation"      # for Azure Resource Manager and Partner Center
        )

        foreach ($required in $requiredPermissions) {
            if ($delegatedPermissions -notcontains $required) {
                Write-Warning "Missing required permission: $required"
                return $false
            }
        }

        return $true
    }
    catch {
        Write-Error "Error checking Service Principal permissions: $_"
        return $false
    }
}

# function Check-ServicePrincipalRoles {
#     param (
#         [string] $spnName
#     )
#     try {
#         # First, get the Service Principal's Object ID
#         $urlPath = "/servicePrincipals?`$filter=displayName eq '$spnName'"
#         $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop
#         $spnObjectId = $response.Content.value[0].id

#         # Now, check for the required role assignments
#         $urlPath = "/roleManagement/directory/roleAssignments?`$filter=principalId eq '$spnObjectId'"
#         $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop
#         $roleAssignments = $response.Content.value

#         $cloudAppAdminRoleId = "158c047a-c907-4556-b7ef-446551a6b5f7" # Object ID for Cloud Application Administrator role
#         $reportsReaderRoleId = "4a5d8f65-41da-4de4-8968-e035b65339cf" # Object ID for Reports Reader role

#         $hasCloudAppAdminRole = $roleAssignments | Where-Object { $_.roleDefinitionId -eq $cloudAppAdminRoleId }
#         $hasReportsReaderRole = $roleAssignments | Where-Object { $_.roleDefinitionId -eq $reportsReaderRoleId }

#         return ($null -ne $hasCloudAppAdminRole) -and ($null -ne $hasReportsReaderRole)
#     }
#     catch {
#         Write-Error "Error checking Service Principal roles: $_"
#         return $false
#     }
# }
# SIG # Begin signature block
# MIIwagYJKoZIhvcNAQcCoIIwWzCCMFcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBXQh6Dndu6hOiV
# OnHMNov75ZRro1+PcMrMH7fb31UkFqCCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxghwKMIIcBgIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# US9cDKVVYkEwQR9a2r8X0RuXMtM6xJq+ThYKo6BTaKgwDQYJKoZIhvcNAQEBBQAE
# ggIALExrsX54I1jAsDxZQJgt6LwJ/TURgrvV4pPorp+1aGbdavjDRMqFFb5pTNNC
# rWS97ZijXCLBQFeonNfYqVtgjyBeYjqWcAt5aqHuHAonIjnHBQvBcRSs+GVHeWPv
# hmGtVhq3IJD8hIXIoLzuun9cCvvzt79q0c568PYsooHQqEPrtrOSLCvwLC5jxyP+
# SQw4jRd5U869TZQ4BcoB115Ec3HcRMNzyXZb6ye1jSsdwRVV34YmsGi9dhst62G/
# Ltl3/QJhBCAfvU4iVpLVyjEqJHNPxq9vgAMUrjlIanTifsNw3D40TrICRjdlW/6T
# vJK1wwlokhL5kyb7inZQRcLbAl9o1DoaaOntGVaSaC8V9pMPo/Nhcm3sfqmG6B/v
# s2sYBn+C84Z010bunrBZEGjJe0o9xBwrFMjyKvbNgCH3n+hMPCsZLY7+Jc5Picpv
# TtwOyDxiSWD+AJsBWIEYto3DiormSM/Qp242VbLsjZV5pF6uAwaaP5+/vXI820Sz
# 3IHnrB1aJOSr1CWPDJPRy8PUI9uat3aRH3eKN4bWZvkJBYd40biiJjQmOHveqb8u
# ex27EuJQ+m5kJBnGZoIW00tDyRfUHHihFe718QAoCdox1juVI1Tz9FCuFazTB5HP
# YnjXfUOMr2pdLIIiBj7aIRplmP7624JSlwYynzY6csBcqsahghjXMIIY0wYKKwYB
# BAGCNwMDATGCGMMwghi/BgkqhkiG9w0BBwKgghiwMIIYrAIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH3BgsqhkiG9w0BCRABBKCB5wSB5DCB4QIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCC29ovFSqnkC2CCaZoQpxSp2/2PGI42ebPt+UvWmhfK
# 6AIUN/RfIPJUotdPHAoBfdL36iemiuAYDzIwMjYwNTI4MTI1MjMxWqB2pHQwcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDldlc3QgWW9ya3NoaXJlMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzNqCCEwQwggZiMIIEyqADAgECAhEApCk7bh7d16c0CIet
# ek63JDANBgkqhkiG9w0BAQwFADBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIENBIFIzNjAeFw0yNTAzMjcwMDAwMDBaFw0zNjAzMjEyMzU5NTlaMHIxCzAJ
# BgNVBAYTAkdCMRcwFQYDVQQIEw5XZXN0IFlvcmtzaGlyZTEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIFNpZ25lciBSMzYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDT
# hJX0bqRTePI9EEt4Egc83JSBU2dhrJ+wY7JgReuff5KQNhMuzVytzD+iXazATVPM
# HZpH/kkiMo1/vlAGFrYN2P7g0Q8oPEcR3h0SftFNYxxMh+bj3ZNbbYjwt8f4DsSH
# PT+xp9zoFuw0HOMdO3sWeA1+F8mhg6uS6BJpPwXQjNSHpVTCgd1gOmKWf12HSfSb
# njl3kDm0kP3aIUAhsodBYZsJA1imWqkAVqwcGfvs6pbfs/0GE4BJ2aOnciKNiIV1
# wDRZAh7rS/O+uTQcb6JVzBVmPP63k5xcZNzGo4DOTV+sM1nVrDycWEYS8bSS0lCS
# eclkTcPjQah9Xs7xbOBoCdmahSfg8Km8ffq8PhdoAXYKOI+wlaJj+PbEuwm6rHcm
# 24jhqQfQyYbOUFTKWFe901VdyMC4gRwRAq04FH2VTjBdCkhKts5Py7H73obMGrxN
# 1uGgVyZho4FkqXA8/uk6nkzPH9QyHIED3c9CGIJ098hU4Ig2xRjhTbengoncXUeo
# /cfpKXDeUcAKcuKUYRNdGDlf8WnwbyqUblj4zj1kQZSnZud5EtmjIdPLKce8UhKl
# 5+EEJXQp1Fkc9y5Ivk4AZacGMCVG0e+wwGsjcAADRO7Wga89r/jJ56IDK773LdIs
# L3yANVvJKdeeS6OOEiH6hpq2yT+jJ/lHa9zEdqFqMwIDAQABo4IBjjCCAYowHwYD
# VR0jBBgwFoAUX1jtTDF6omFCjVKAurNhlxmiMpswHQYDVR0OBBYEFIhhjKEqN2SB
# KGChmzHQjP0sAs5PMA4GA1UdDwEB/wQEAwIGwDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEoGA1UdIARDMEEwNQYMKwYBBAGyMQECAQMIMCUw
# IwYIKwYBBQUHAgEWF2h0dHBzOi8vc2VjdGlnby5jb20vQ1BTMAgGBmeBDAEEAjBK
# BgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29Q
# dWJsaWNUaW1lU3RhbXBpbmdDQVIzNi5jcmwwegYIKwYBBQUHAQEEbjBsMEUGCCsG
# AQUFBzAChjlodHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1l
# U3RhbXBpbmdDQVIzNi5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
# Z28uY29tMA0GCSqGSIb3DQEBDAUAA4IBgQACgT6khnJRIfllqS49Uorh5ZvMSxNE
# k4SNsi7qvu+bNdcuknHgXIaZyqcVmhrV3PHcmtQKt0blv/8t8DE4bL0+H0m2tgKE
# lpUeu6wOH02BjCIYM6HLInbNHLf6R2qHC1SUsJ02MWNqRNIT6GQL0Xm3LW7E6hDZ
# mR8jlYzhZcDdkdw0cHhXjbOLsmTeS0SeRJ1WJXEzqt25dbSOaaK7vVmkEVkOHsp1
# 6ez49Bc+Ayq/Oh2BAkSTFog43ldEKgHEDBbCIyba2E8O5lPNan+BQXOLuLMKYS3i
# kTcp/Qw63dxyDCfgqXYUhxBpXnmeSO/WA4NwdwP35lWNhmjIpNVZvhWoxDL+PxDd
# pph3+M5DroWGTc1ZuDa1iXmOFAK4iwTnlWDg3QNRsRa9cnG3FBBpVHnHOEQj4GMk
# rOHdNDTbonEeGvZ+4nSZXrwCW4Wv2qyGDBLlKk3kUW1pIScDCpm/chL6aUbnSsrt
# bepdtbCLiGanKVR/KC1gsR0tC6Q0RfWOI4owggYUMIID/KADAgECAhB6I67aU2mW
# D5HIPlz0x+M/MA0GCSqGSIb3DQEBDAUAMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQK
# Ew9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUg
# U3RhbXBpbmcgUm9vdCBSNDYwHhcNMjEwMzIyMDAwMDAwWhcNMzYwMzIxMjM1OTU5
# WjBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYD
# VQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFIzNjCCAaIwDQYJ
# KoZIhvcNAQEBBQADggGPADCCAYoCggGBAM2Y2ENBq26CK+z2M34mNOSJjNPvIhKA
# VD7vJq+MDoGD46IiM+b83+3ecLvBhStSVjeYXIjfa3ajoW3cS3ElcJzkyZlBnwDE
# JuHlzpbN4kMH2qRBVrjrGJgSlzzUqcGQBaCxpectRGhhnOSwcjPMI3G0hedv2eNm
# GiUbD12OeORN0ADzdpsQ4dDi6M4YhoGE9cbY11XxM2AVZn0GiOUC9+XE0wI7CQKf
# OUfigLDn7i/WeyxZ43XLj5GVo7LDBExSLnh+va8WxTlA+uBvq1KO8RSHUQLgzb1g
# bL9Ihgzxmkdp2ZWNuLc+XyEmJNbD2OIIq/fWlwBp6KNL19zpHsODLIsgZ+WZ1AzC
# s1HEK6VWrxmnKyJJg2Lv23DlEdZlQSGdF+z+Gyn9/CRezKe7WNyxRf4e4bwUtrYE
# 2F5Q+05yDD68clwnweckKtxRaF0VzN/w76kOLIaFVhf5sMM/caEZLtOYqYadtn03
# 4ykSFaZuIBU9uCSrKRKTPJhWvXk4CllgrwIDAQABo4IBXDCCAVgwHwYDVR0jBBgw
# FoAU9ndq3T/9ARP/FqFsggIv0Ao9FCUwHQYDVR0OBBYEFF9Y7UwxeqJhQo1SgLqz
# YZcZojKbMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAGAQH/AgEAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBMBgNVHR8ERTBDMEGg
# P6A9hjtodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3Rh
# bXBpbmdSb290UjQ2LmNybDB8BggrBgEFBQcBAQRwMG4wRwYIKwYBBQUHMAKGO2h0
# dHA6Ly9jcnQuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jv
# b3RSNDYucDdjMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0aWdvLmNvbTAN
# BgkqhkiG9w0BAQwFAAOCAgEAEtd7IK0ONVgMnoEdJVj9TC1ndK/HYiYh9lVUacah
# RoZ2W2hfiEOyQExnHk1jkvpIJzAMxmEc6ZvIyHI5UkPCbXKspioYMdbOnBWQUn73
# 3qMooBfIghpR/klUqNxx6/fDXqY0hSU1OSkkSivt51UlmJElUICZYBodzD3M/SFj
# eCP59anwxs6hwj1mfvzG+b1coYGnqsSz2wSKr+nDO+Db8qNcTbJZRAiSazr7KyUJ
# Go1c+MScGfG5QHV+bps8BX5Oyv9Ct36Y4Il6ajTqV2ifikkVtB3RNBUgwu/mSiSU
# ice/Jp/q8BMk/gN8+0rNIE+QqU63JoVMCMPY2752LmESsRVVoypJVt8/N3qQ1c6F
# ibbcRabo3azZkcIdWGVSAdoLgAIxEKBeNh9AQO1gQrnh1TA8ldXuJzPSuALOz1Uj
# b0PCyNVkWk7hkhVHfcvBfI8NtgWQupiaAeNHe0pWSGH2opXZYKYG4Lbukg7HpNi/
# KqJhue2Keak6qH9A8CeEOB7Eob0Zf+fU+CCQaL0cJqlmnx9HCDxF+3BLbUufrV64
# EbTI40zqegPZdA+sXCmbcZy6okx/SjwsusWRItFA3DE8MORZeFb6BmzBtqKJ7l93
# 9bbKBy2jvxcJI98Va95Q5JnlKor3m0E7xpMeYRriWklUPsetMSf2NvUQa/E5vVye
# fQIwggaCMIIEaqADAgECAhA2wrC9fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBDAUA
# MIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxML
# SmVyc2V5IENpdHkxHjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwG
# A1UEAxMlVVNFUlRydXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0y
# MTAzMjIwMDAwMDBaFw0zODAxMTgyMzU5NTlaMFcxCzAJBgNVBAYTAkdCMRgwFgYD
# VQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRp
# bWUgU3RhbXBpbmcgUm9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCIndi5RWedHd3ouSaBmlRUwHxJBZvMWhUP2ZQQRLRBQIF3FJmp1OR2LMgI
# U14g0JIlL6VXWKmdbmKGRDILRxEtZdQnOh2qmcxGzjqemIk8et8sE6J+N+Gl1cnZ
# ocew8eCAawKLu4TRrCoqCAT8uRjDeypoGJrruH/drCio28aqIVEn45NZiZQI7YYB
# ex48eL78lQ0BrHeSmqy1uXe9xN04aG0pKG9ki+PC6VEfzutu6Q3IcZZfm00r9YAE
# p/4aeiLhyaKxLuhKKaAdQjRaf/h6U13jQEV1JnUTCm511n5avv4N+jSVwd+Wb8UM
# Os4netapq5Q/yGyiQOgjsP/JRUj0MAT9YrcmXcLgsrAimfWY3MzKm1HCxcquinTq
# bs1Q0d2VMMQyi9cAgMYC9jKc+3mW62/yVl4jnDcw6ULJsBkOkrcPLUwqj7poS0T2
# +2JMzPP+jZ1h90/QpZnBkhdtixMiWDVgh60KmLmzXiqJc6lGwqoUqpq/1HVHm+Pc
# 2B6+wCy/GwCcjw5rmzajLbmqGygEgaj/OLoanEWP6Y52Hflef3XLvYnhEY4kSirM
# QhtberRvaI+5YsD3XVxHGBjlIli5u+NrLedIxsE88WzKXqZjj9Zi5ybJL2WjeXuO
# TbswB7XjkZbErg7ebeAQUQiS/uRGZ58NHs57ZPUfECcgJC+v2wIDAQABo4IBFjCC
# ARIwHwYDVR0jBBgwFoAUU3m/WqorSs9UgOHYm8Cd8rIDZsswHQYDVR0OBBYEFPZ3
# at0//QET/xahbIICL9AKPRQlMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTAD
# AQH/MBMGA1UdJQQMMAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBQBgNV
# HR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLnVzZXJ0cnVzdC5jb20vVVNFUlRydXN0
# UlNBQ2VydGlmaWNhdGlvbkF1dGhvcml0eS5jcmwwNQYIKwYBBQUHAQEEKTAnMCUG
# CCsGAQUFBzABhhlodHRwOi8vb2NzcC51c2VydHJ1c3QuY29tMA0GCSqGSIb3DQEB
# DAUAA4ICAQAOvmVB7WhEuOWhxdQRh+S3OyWM637ayBeR7djxQ8SihTnLf2sABFoB
# 0DFR6JfWS0snf6WDG2gtCGflwVvcYXZJJlFfym1Doi+4PfDP8s0cqlDmdfyGOwMt
# GGzJ4iImyaz3IBae91g50QyrVbrUoT0mUGQHbRcF57olpfHhQEStz5i6hJvVLFV/
# ueQ21SM99zG4W2tB1ExGL98idX8ChsTwbD/zIExAopoe3l6JrzJtPxj8V9rocAnL
# P2C8Q5wXVVZcbw4x4ztXLsGzqZIiRh5i111TW7HV1AtsQa6vXy633vCAbAOIaKcL
# Ao/IU7sClyZUk62XD0VUnHD+YvVNvIGezjM6CRpcWed/ODiptK+evDKPU2K6syni
# mYBaNH49v9Ih24+eYXNtI38byt5kIvh+8aW88WThRpv8lUJKaPn37+YHYafob9Rg
# 7LyTrSYpyZoBmwRWSE4W6iPjB7wJjJpH29308ZkpKKdpkiS9WNsf/eeUtvRrtIEi
# SJHN899L1P4l6zKVsdrUu1FX1T/ubSrsxrYJD+3f3aKg6yxdbugot06YwGXXiy5U
# UGZvOu3lXlxA+fC13dQ5OlL2gIb5lmF6Ii8+CQOYDwXM+yd9dbmocQsHjcRPsccU
# d5E9FiswEqORvz8g3s+jR3SFCgXhN4wz7NgAnOgpCdUo4uDyllU9PzGCBJIwggSO
# AgEBMGowVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEs
# MCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSMzYCEQCk
# KTtuHt3XpzQIh616TrckMA0GCWCGSAFlAwQCAgUAoIIB+TAaBgkqhkiG9w0BCQMx
# DQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDUyODEyNTIzMVowPwYJ
# KoZIhvcNAQkEMTIEMMA5QUzVoPIUGsT1vgN3nmL5nXBxYnlPseeNDfB7AkqZ1ER8
# AgKogmkiQBjxU4pOYjCCAXoGCyqGSIb3DQEJEAIMMYIBaTCCAWUwggFhMBYEFDjJ
# FIEQRLTcZj6T1HRLgUGGqbWxMIGHBBTGrlTkeIbxfD1VEkiMacNKevnC3TBvMFuk
# WTBXMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYD
# VQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2AhB6I67a
# U2mWD5HIPlz0x+M/MIG8BBSFPWMtk4KCYXzQkDXEkd6SwULaxzCBozCBjqSBizCB
# iDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0pl
# cnNleSBDaXR5MR4wHAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNV
# BAMTJVVTRVJUcnVzdCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkCEDbCsL18
# Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEBBQAEggIAcqLU35oSYI+nbZOLB/S21ZzT
# YNxdM6s8IOcReiWeNWLqb2w6Box9n9N+OztkZut2fEeZJXef7VqspOkZ3Vb0mf2l
# SYeELIth0n9rcrUvzrVd0+hGZIBrucEF3YXwiEEeuudSTCV5xFfg2uEfQFXvoRxF
# 5f1+jzH9A5iEVpzPq0wznvhUNQwHtqBzkF5KrZsBes5fY4X4PP+8S+bOM8sMxOdj
# enEu5b9aWJHpY28uilsDX3K3/dZG9p3MOXcJx7xxty1wF6yK5XiycI5bRI2MI4o+
# 9rrV4wb/6Q4TXYdui4PcbWBzja+7jSEMVhsiVkauN5XgW+DV5qgaCcyGn+2BWiEx
# uDkJQI0Pik/xCWe/xF1f06vlnRjYjPldympI1o4e4Wb9lxhQ3G25WQVnV9F7a2kr
# Ctxw6d/eCTUkuARDhyBlybu0C+nrBVu0BZ5A5+0pH4bPZxxLUoz7+4SEc3D2Ud/X
# MYWcUgffI73IeFS3C/TN6cU0t4Bbu2IceHxPj/aL3twXO6P9vtgs4i9qwsA1E4Eb
# T8ZX2aojLNx3wIW8dwPcj38vW55U7DTeELihVzt+7fOkpDBZOjqrTxpoII8naog6
# YmXaiwDtpJ2+Rb1JUV414Gjhv/97vJQHY2XfPQ/pqygF1Yi9M79Z4+YNPPeuhxQL
# INj1EY9gUOi0EBL45IA=
# SIG # End signature block

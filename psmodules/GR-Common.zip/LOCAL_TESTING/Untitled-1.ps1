### Option 1(Existing main branch): WORKS but incorrect AdditionalResults  in local execution *******************************
$newMatchedUserList = $matchedUserUpdated | ForEach-Object {
    $hasPrivilegedRole = $privilegedRolesSubscriptionLevel -contains $_.RoleDefinitionName
    $hasPrivilegedRoleString = if ($hasPrivilegedRole) {'True'} else {'False'}
    $_ | Add-Member -MemberType NoteProperty -Name privilegedRole -Value $hasPrivilegedRoleString -PassThru
}

### Option 2 (my branch): Errors in runbook run But AdditionalResults table shows correct in local execution  **************************
$newMatchedUserList = @()
foreach ($user in $matchedUserUpdated) {
    $roleName = $user.RoleDefinitionName.Trim()
    
    # Output the role name and the list of privileged roles for debugging
    Write-Host "Checking role: '$roleName'"
    Write-Host "Privileged roles list: $($privilegedRolesSubscriptionLevel -join ', ')"
    
    # # Check if the role name is in the list of privileged roles
    # $hasPrivilegedRole = $false
    # foreach($role in $roleName){
    #     Write-Host "role is $role"
    #     $isPrivilegedRole = $privilegedRolesSubscriptionLevel | Where-Object { $_.Trim().ToLower() -eq $role.ToLower() }
    #     if($isPrivilegedRole){
    #         $hasPrivilegedRole = $true
    #         Write-Host "hasPrivilegedRole: $hasPrivilegedRole"
    #         break
    #     }
    # }

    # $hasPrivilegedRole = $privilegedRolesSubscriptionLevel -contains $user.RoleDefinitionName
    $hasPrivilegedRole = $user.RoleDefinitionName | Where-Object { $privilegedRolesSubscriptionLevel -contains $_ } | Measure-Object | Select-Object -ExpandProperty Count
    $hasPrivilegedRoleString = if ($hasPrivilegedRole -gt 0) {'True'} else {'False'}

    # # Convert the result to 'True' or 'False' string
    # $hasPrivilegedRoleString = if ($hasPrivilegedRole) {'True'} else {'False'}
    
    # Create a new object with the existing properties and the new property
    $newUser = $user.PSObject.Copy()
    $newUser | Add-Member -MemberType NoteProperty -Name privilegedRole -Value $hasPrivilegedRoleString -PassThru
    
    # Add the updated object to the array
    $newMatchedUserList += $newUser
}
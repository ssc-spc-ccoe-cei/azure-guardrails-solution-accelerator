function get-tagValue {
    param (
        [string] $tagKey,
        [System.Object] $object
    )
    $tagString = get-tagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}
function get-tagstring ($object) {
    if ($object.Tag.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = ""
        $tKeys = $object.tag | Select-Object -ExpandProperty keys
        $tValues = $object.Tag | Select-Object -ExpandProperty values
        $index = 0
        if ($object.Tag.Count -eq 1) {
            $tagstring = "$tKeys=$tValues"
        }
        else {
            foreach ($tkey in $tkeys) {
                $tagstring += "$tkey=$($tValues[$index]);"
                $index++
            }
        }
    }
    return $tagstring.Trim(";")
}
function get-rgtagstring ($object) {
    if ($object.Tags.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = ""
        $tKeys = $object.tags | Select-Object -ExpandProperty keys
        $tValues = $object.Tags | Select-Object -ExpandProperty values
        $index = 0
        if ($object.Tags.Count -eq 1) {
            $tagstring = "$tKeys=$tValues"
        }
        else {
            foreach ($tkey in $tkeys) {
                $tagstring += "$tkey=$($tValues[$index]);"
                $index++
            }
        }
    }
    return $tagstring.Trim(";")
}
function get-rgtagValue {
    param (
        [string] $tagKey,
        [System.Object] $object
    )
    $tagString = get-rgtagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}
function copy-toBlob {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName,
        [Parameter(Mandatory = $false)]
        [switch]
        $force
    )
    try {
        $saParams = @{
            ResourceGroupName = $resourcegroup
            Name              = $storageaccountName
        }
        $scParams = @{
            Container = $containerName
        }
        $bcParams = @{
            File = $FilePath
            Blob = ($FilePath | Split-Path -Leaf)
        }
        if ($force)
        { Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Set-AzStorageBlobContent @bcParams -Force | Out-Null }
        else { Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Set-AzStorageBlobContent @bcParams | Out-Null }
    }
    catch {
        Write-Error $_.Exception.Message
    }
}
function get-blobs {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup
    )
    $psModulesContainerName = "psmodules"
    try {
        $saParams = @{
            ResourceGroupName = $resourcegroup
            Name              = $storageaccountName
        }
        $scParams = @{
            Container = $psModulesContainerName
        }
        return (Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Get-AzStorageBlob)
    }
    catch {
        Write-Error $_.Exception.Message
    }
}

function read-blob {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName,
        [Parameter(Mandatory = $false)]
        [switch]
        $force
    )
    $Context = (Get-AzStorageAccount -ResourceGroupName $resourcegroup -Name $storageaccountName).Context
    $blobParams = @{
        Blob        = 'modules.json'
        Container   = $containerName
        Destination = $FilePath
        Context     = $Context
        Force       = $true
    }
    Get-AzStorageBlobContent @blobParams
}

Function Add-LogEntry {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [ValidateSet("Critical", "Error", "Warning", "Information", "Debug")]
        [string]
        $severity,

        # message details (string)
        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $message,

        # module name
        [Parameter(Mandatory = $false)]
        [string]
        $moduleName = (Split-Path -Path $MyInvocation.ScriptName -Leaf),

        # additional values in hashtable
        [Parameter(Mandatory = $false)]
        [hashtable]
        $additionalValues = @{},

        # exception log type - this is the Log Analytics table name
        [Parameter(Mandatory = $false)]
        [string]
        $exceptionLogTable = "GuardrailsComplianceException",

        # guardrails exception workspace GUID
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceGuid,

        # guardrails exception workspace shared key
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey
    )

    # build log entry object, convert to json
    $entryHash = @{
        "message"    = $message
        "moduleName" = $moduleName
        "severity"   = $severity
    } + $additionalValues
    
    $entryJson = ConvertTo-Json -inputObject $entryHash -Depth 20

    # log event to Log Analytics workspace by REST API via the OMSIngestionAPI community PS module
    Send-OMSAPIIngestionFile  -customerId $workspaceGuid `
        -sharedkey $workspaceKey `
        -body $entryJson `
        -logType $exceptionLogTable `
        -TimeStampField Get-Date 

}

Function Add-TenantInfo {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_TenantInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $true)]
        [string]
        $TenantId,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentName,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentNumber,
        [Parameter(Mandatory = $true)]
        [string]
        $cloudUsageProfiles,
        [Parameter(Mandatory = $true)]
        [string]
        $tenantName
    )
    $tenantInfo = Get-GSAAutomationVariable("tenantDomainUPN")

    $object = [PSCustomObject]@{ 
        TenantDomain       = $tenantInfo
        DepartmentTenantID = $TenantId
        DepartmentTenantName= $tenantName
        ReportTime         = $ReportTime
        DepartmentName     = $DepartmentName
        DepartmentNumber   = $DepartmentNumber
        cloudUsageProfiles = $cloudUsageProfiles
    }
    if ($debug) { Write-Output $tenantInfo }
    $JSON = ConvertTo-Json -inputObject $object

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}

function Add-LogAnalyticsResults {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_Results",
        [Parameter(Mandatory = $false)]
        [array]
        $Results
    )

    $JSON = ConvertTo-Json -inputObject $Results

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}

function Check-GAAuthenticationMethods {
    param (
        [string] $StorageAccountName,
        [string] $ContainerName, 
        [string] $ResourceGroupName,
        [string] $SubscriptionID, 
        [string[]] $DocumentName, 
        [string] $ControlName, 
        [string]$ItemName,
        [hashtable] $msgTable, 
        [string]$itsgcode,
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null

    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName
    
    try {
        Set-AzContext -Subscription $SubscriptionID | out-null
    }
    catch{
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        $StorageAccount = Get-Azstorageaccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ErrorAction Stop
    }
    catch {
        $ErrorList.Add("Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_")

        throw "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_"
    }

    $mfaCounter = 0
    $commentsArray = @()
    $globalAdminUPNs = @()

    $GAUPNsMFA = @()

    ForEach ($docName in $DocumentName_new) {
        $blob = Get-AzStorageBlob -Container $ContainerName -Context $StorageAccount.Context -Blob $docName -ErrorAction SilentlyContinue

        If ($null -eq $blob) {            
            # a blob with the name $DocumentName was not located in the specified storage account
            $errorMsg = "Could not get blob from storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the blob exists and that you have permissions to it. Error: $_"
            $ErrorList.Add($errorMsg) 
            #Write-Error "Error: $errorMsg"                 
            $commentsArray += $msgTable.procedureFileNotFound -f $ItemName, $docName, $ContainerName, $StorageAccountName
        }
        else {
            try {
                $blobContent = $blob.ICloudBlob.DownloadText()
                # Further processing of $blobContent...
            } catch {
                $errorMsg = "Error downloading content from blob '$docName': $_"
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"                    
            }
            if ([string]::IsNullOrWhiteSpace($blobContent)) {
                $commentsArray += $msgTable.globalAdminFileEmpty -f $docName
            }
            elseif ($blobContent -ieq 'N/A' -or`
                    $blobContent -ieq 'NA') {
                $commentsArray += $msgTable.globalAdminNotExist -f $docName
            }
            else {
                # Blob content is present and needs to be parsed
                # Parses the UPNs and sanitizes them
                $result = Parse-BlobContent -blobContent $blobContent
                $globalAdminUPNs = $result.GlobalAdminUPNs
            }
        }   
    }

    
    if ($globalAdminUPNs.Count -ge 2) {
        
        ForEach ($globalAdminAccount in $globalAdminUPNs) {
            $urlPath = '/users/' + $globalAdminAccount + '/authentication/methods'
            
            # create hidden format UPN
            $hiddenUPN = Hide-Email -email $globalAdminAccount
            
            
            try {
                $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop

            }
            catch {
                $errorMsg = "Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"
            }

            # # To check if MFA is setup for a user, we're checking various authentication methods:
            # # 1. #microsoft.graph.microsoftAuthenticatorAuthenticationMethod
            # # 2. #microsoft.graph.phoneAuthenticationMethod
            # # 3. #microsoft.graph.passwordAuthenticationMethod - not considered for MFA
            # # 4. #microsoft.graph.emailAuthenticationMethod - not considered for MFA
            # # 5. #microsoft.graph.fido2AuthenticationMethod
            # # 6. #microsoft.graph.softwareOathAuthenticationMethod

            if ($null -ne $response) {
                $data = $response.Content
                if ($null -ne $data -and $null -ne $data.value) {
                    $authenticationmethods = $data.value
                    
                    $authFound = $false
                    foreach ($authmeth in $authenticationmethods) {                        
                        if (($($authmeth.'@odata.type') -eq "#microsoft.graph.phoneAuthenticationMethod") -or `
                            ($($authmeth.'@odata.type') -eq "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod") -or`
                            ($($authmeth.'@odata.type') -eq "#microsoft.graph.fido2AuthenticationMethod" ) -or`
                            ($($authmeth.'@odata.type') -eq "#microsoft.graph.softwareOathAuthenticationMethod" ) ) {
                                
                                # need to keep track of each GA mfa in counter and compare it to count
                                $mfaCounter += 1
                                $authFound = $true
                                # atleast one auth method is true - so we move to the next UPN 
                                break
                        }
                    }
                    if($authFound){
                        # This message is being used for debugging
                        Write-Host "Auth method found for $globalAdminAccount"
                    }
                    else{
                        # This message is being used for debugging
                        Write-Host "$globalAdminAccount does not have MFA enabled"

                        # Create an instance of inner list object
                        $GAUPNtemplate = [PSCustomObject]@{
                            UPN  = $globalAdminAccount
                            MFAStatus   = $false
                            MFAComments = $hiddenUPN 
                        }
                        # Add the list to GA MFA list
                        $GAUPNsMFA += $GAUPNtemplate
                    }
                }
                else {
                    $errorMsg = "No authentication methods data found for $globalAdminAccount"                
                    $ErrorList.Add($errorMsg)
                    Write-Error "Error: $errorMsg"    
                }
            }
            else {
                $errorMsg = "Failed to get response from Graph API for $globalAdminAccount"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"    
            }    
        }
    }

    # Condition: GA UPN list has less than 2 UPN
    if ($globalAdminUPNs.Count -lt 2) {
        $commentsArray += $msgTable.globalAdminMinAccnts
    }
    # Condition: GA UPN list has > 2 UPNs and all are MFA enabled
    elseif($globalAdminUPNs.Count -ge 2 -and $mfaCounter -eq $globalAdminUPNs.Count) {
        $commentsArray += $msgTable.globalAdminMFAPassAndMin2Accnts
        $IsCompliant = $true
    }
    # Condition: GA UPN list has > 2 UPNs and not all UPNs are MFA enabled
    else{
        # This will be used for debugging
        if($GAUPNsMFA.Count -eq 0){
            Write-Host "Something is wrong as GAUPNsMFA Count equals 0. This output should only execute if there is an error populating GAUPNsMFA"
        }
        else{
            # only one UPN is not MFA enable
            if ( $GAUPNsMFA.Count -eq 1 ) {
                $commentsArray += $msgTable.globalAdminAccntsMFADisabled1 -f $GAUPNsMFA[0].MFAComments
            }
            # None are MFA enabled
            elseif ( $GAUPNsMFA.Count -eq $globalAdminUPNs.Count) {
                $commentsArray += $msgTable.globalAdminAccntsMFADisabled3
            }
            # 2 or more UPNs in the list are not MFA enabled
            else {
                $hiddenUPNsString = ""
                for ($i =0; $i -lt $GAUPNsMFA.Count; $i++) {
                    $hiddenUPNsString += $GAUPNsMFA[$i].MFAComments + ", "
                }
                $hiddenUPNsString = $hiddenUPNsString.TrimEnd(', ')
                $commentsArray += $msgTable.globalAdminAccntsMFADisabled2 -f $hiddenUPNsString
            }
        }
    }
    
    $Comments = $commentsArray -join ";"

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        DocumentName     = $DocumentName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }
    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput

}

function Check-DocumentExistsInStorage {
    [Alias('Check-DocumentsExistInStorage')]
    param (
        [string] $StorageAccountName,
        [string] $ContainerName, 
        [string] $ResourceGroupName,
        [string] $SubscriptionID, 
        [string[]] $DocumentName, 
        [string] $ControlName, 
        [string]$ItemName,
        [hashtable] $msgTable, 
        [string]$itsgcode,
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null

    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        #Add-LogEntry 'Error' 
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        $StorageAccount = Get-Azstorageaccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ErrorAction Stop
    }
    catch {
        $ErrorList.Add("Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_")
        #Add-LogEntry 'Error' "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        #    subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_" `
        #    -workspaceKey $workspaceKey -workspaceGuid $WorkSpaceID
        Write-Error "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_"
    }

    $docMissing = $false
    $commentsArray = @()
    $blobFound = $false
   
    ForEach ($docName in $DocumentName_new) {
        # check for procedure doc in blob storage account
        $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageAccount.Context -Blob $docName -ErrorAction SilentlyContinue

        If ($blobs) {
            $blobFound = $true
            break
        }
    }

    if ($blobFound){
        # a blob with the name $attestationFileName was located in the specified storage account
        $commentsArray += $msgTable.procedureFileFound -f $docName
    }
    else {
        # no blob with the name $attestationFileName was found in the specified storage account
        $docMissing = $true
        $commentsArray += $msgTable.procedureFileNotFound -f $ItemName, $DocumentName[0], $ContainerName, $StorageAccountName
    }

    $Comments = $commentsArray -join ";"

    If ($docMissing) {
        $IsCompliant = $false
    }
    Else {
        $IsCompliant = $true
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        DocumentName     = $DocumentName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }
    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput

}

function Check-UpdateAvailable {
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_VersionInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $false)]
        [string]
        $ResourceGroupName
    )
    #fetches current public version (from repo...maybe should download the zip...)
    $latestRelease = Invoke-RestMethod 'https://api.github.com/repos/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases/latest' -Verbose:$false
    $tagsFileURI = "https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/raw/{0}/setup/tags.json" -f $latestRelease.name
    $tags = Invoke-RestMethod $tagsFileURI -Verbose:$false

    if ([string]::IsNullOrEmpty($ResourceGroupName)) {
        $ResourceGroupName = Get-AutomationVariable -Name "ResourceGroupName"
    }
    $rg=Get-AzResourceGroup -Name $ResourceGroupName 

    $deployedVersion=$rg.Tags["ReleaseVersion"]
    $currentVersion = $tags.ReleaseVersion

    try {
        # script version numbers of surrounding characters and then converted to a version object
        $deployedVersionVersion = [version]::Parse(($deployedVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
        $currentVersionVersion = [version]::Parse(($currentVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
    }
    catch {
        Write-Error "Error: Failed to convert version numbers to version objects. Error: $_"
    }

    if ($debug) { Write-Output "Resource Group Tag (deployed version): $deployedVersion; $deployedVersionVersion"}
    if ($debug) { Write-Output "Latest available version from GitHub: $currentVersion; $currentVersionVersion"}
    
    if ($deployedVersionVersion -lt $currentVersionVersion)
    {
        $updateNeeded=$true
    }
    else {
        $updateNeeded = $false
    }
    $object = [PSCustomObject]@{ 
        DeployedVersion = $deployedVersion
        AvailableVersion = $currentVersion
        UpdateNeeded= $updateNeeded
        ReportTime = $ReportTime
    }
    $JSON = ConvertTo-Json -inputObject $object

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}
function get-itsgdata {
    [CmdletBinding()]
    param (
        [Parameter()]
        [string]
        $URL,
        [string] $WorkSpaceID,
        [string] $workspaceKey,
        [string] $LogType = "GRITSGControls",
        [switch] $DebugCode
    )
    (Invoke-WebRequest -UseBasicParsing $URL).Content | out-file tempitsg.csv
    $Header = "Family", "Control ID", "Enhancement", "Name", "Class", "Definition", "Supplemental Guidance,References"
    $itsgtempinfo = Import-Csv ./tempitsg.csv -Header $Header
    $itsginfo = $itsgtempinfo | Select-Object Name, Definition, @{Name = "itsgcode"; Expression = { ($_.Family + $_."Control ID" + $_.Enhancement).replace("`t", "") } }
    $JSONcontrols = ConvertTo-Json -inputObject $itsginfo
    
    if ($DebugCode) {
        $JSONcontrols
    }

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSONcontrols `
        -logType $LogType `
        -TimeStampField Get-Date
}
function New-LogAnalyticsData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [array] 
        $Data,
        [Parameter()]
        [string]
        $WorkSpaceID,
        [Parameter()]
        [string]
        $WorkSpaceKey,
        [Parameter()]
        [string]
        $LogType
    )
    $JsonObject = convertTo-Json -inputObject $Data -Depth 3

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JsonObject `
        -logType $LogType `
        -TimeStampField Get-Date  
}

function Hide-Email {
    param (
        [string]$email
    )

    $parts = $email -split '@'
    if ($parts.Length -eq 2) {
        $username = $parts[0]
        $domain = $parts[1]

        $hiddenUsername = $username[0] + ($username.Substring(1, $username.Length - 2) -replace '.', '#') + $username[-1]
        $hiddenDomain = $domain[0] + ($domain.Substring(1, $domain.Length - 5) -replace '.', '#') + $domain[-4] + $domain[-3] + $domain[-2] + $domain[-1]

        $hiddenEmail = "$hiddenUsername@$hiddenDomain"
        return $hiddenEmail
    } else {
        return "Invalid email format"
    }
}

function Parse-BlobContent {
    param (
        [string]$blobContent
    )

    # Check if blob content is retrieved
    if (-not $blobContent) {
        throw "Failed to retrieve blob content or blob is empty."
    }

    # Split content into lines
    $lines = $blobContent -split "`r`n|`n|,|;|,\s|;\s"

    $filteredLines = $lines | Where-Object { $_ -match '\S' -and $_ -like "*@*" } | ForEach-Object { $_ -replace '\s' }

    # Initialize an empty array
    $globalAdminUPNs = @()

    # Check each line, remove the hyphen (if any), and add to array
    foreach ($line in $filteredLines) {
        if ($line.StartsWith("-")) {
            # Remove the leading hyphen and any potential whitespace after it
            $trimmedLine = $line.Substring(1)
        } 
        else{
            $trimmedLine = $line
        }
        $trimmedLine = $trimmedLine.Trim()
        $globalAdminUPNs += $trimmedLine
    }

    $result = New-Object PSObject -Property @{
        GlobalAdminUPNs = $globalAdminUPNs
    }

    return $result
}

function Invoke-GraphQuery {
    param(
        # URL path (ex: /users)
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string]
        $urlPath
    )

    try {
        $uri = "https://graph.microsoft.com/v1.0$urlPath" -as [uri]
        
        $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop

    }
    catch {
        Write-Error "An error occured constructing the URI or while calling Graph query for URI GET '$uri': $($_.Exception.Message)"
    }
    
    @{
        Content    = $response.Content | ConvertFrom-Json
        StatusCode = $response.StatusCode

    }

}

# Function to add other possible file extension(s) to the module file names
function add-documentFileExtensions {
    param (
        [string[]] $DocumentName,
        [string]$ItemName

    )

    if ($ItemName.ToLower() -eq 'network architecture diagram'){
        $fileExtensions = @(".pdf", ".png", ".jpeg", ".vsdx")
    }
    elseif ($ItemName.ToLower() -eq 'global administrators accounts mfa check') {
        $fileExtensions = @(".txt")
    }
    else {
        $fileExtensions = @(".txt",".docx", ".doc")
    }
    
    $DocumentName_new = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($fileExt in $fileExtensions) {
        $DocumentName_new.Add($DocumentName[0] + $fileExt)
    }

    return $DocumentName_new
}

# endregion


# SIG # Begin signature block
# MIItIwYJKoZIhvcNAQcCoIItFDCCLRACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCpVg9gXCj8y1k1
# Hgxgdq5QOFqvMM68vAf6mgLHJBCQx6CCFpIwggQ+MIIDJqADAgECAgRKU4woMA0G
# CSqGSIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwg
# SW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5
# MDcGA1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVk
# IHVzZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkgLSBHMjAeFw0wOTA3MDcxNzI1NTRaFw0zMDEyMDcxNzU1NTRaMIG+
# MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMf
# U2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIw
# MDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MTIwMAYD
# VQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHMjCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALqEtnLbngxr4pnpMAGnduoy
# uJVBGsnaYU5Ycs/+9oJ5v3NhBgqlJ9izX9NFThxy1k4y8nKKD/eDGdBqgIAARR6w
# x+eavxJXJxyjaC8Kh71qaw5eZfMcd9XUhY1wIbSzMueLotWGOQKxuNJHzuTJScQ7
# p977VH1XvvDobsJ5sjoLVeJQmBYyE1wveFbBwpSz8lrkJ5qfJNfG7NCbJYLjzMLE
# RcWMl3oGayoRn6kKbkg7b9vUERlC948Hv/VTX5w+9Bcs5mmsTjJMYnfqt+jluzS8
# GYuunFHnt361U7EzIuVtz3A8Gvrim2e2g/SNpa9iTE3gWKxkNBID+LaNlGMkpHEC
# AwEAAaNCMEAwDgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFGpyJnrQHu995ztpUdRsjZ+QEmarMA0GCSqGSIb3DQEBCwUAA4IBAQB5nx2W
# xrZ5PyKNh9OHAwRgamuaLlmJcxGsQ9H1E/+NOSvA8r1PcIypL+oXxAtUntQblpgz
# PKitYqIAdqtZaW4GHX7EuUSNmK8S1GHbChlGR/Pr92PBQAVApdK39LWaNr+piHaI
# BFUEK5yHfxo3PH4tpRrY1Ileyr2sPWzYba/V83YPzTuIOCKdbJOaxD2/ghtlP6YP
# Xar85bIVyrWtxrw90ITo6gZysE05Mni/PhGcC6SdmiHz8JsLMHjbwdyHQ/68Y5rK
# xcIcyceN/zsSWAjmtj3seixO+4OWzgw8aYdUc6RzwpP/URCsFVQB2PwFsYmhf3SD
# mknX3E57ikhvi0X2MIIF3zCCBMegAwIBAgIQTkDkN1Tt5owAAAAAUdOUfzANBgkq
# hkiG9w0BAQsFADCBvjELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1c3QsIElu
# Yy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVzdC5uZXQvbGVnYWwtdGVybXMxOTA3
# BgNVBAsTMChjKSAyMDA5IEVudHJ1c3QsIEluYy4gLSBmb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTEyMDAGA1UEAxMpRW50cnVzdCBSb290IENlcnRpZmljYXRpb24gQXV0
# aG9yaXR5IC0gRzIwHhcNMjEwNTA3MTU0MzQ1WhcNMzAxMTA3MTYxMzQ1WjBpMQsw
# CQYDVQQGEwJVUzEWMBQGA1UECgwNRW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50
# cnVzdCBDb2RlIFNpZ25pbmcgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAt
# IENTQlIxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAp4GP9xRFtmJD
# 8tiu0yVeSE9Rv8V9n1AcNdHWfmEqlBltJ0akphpd91RRaoAixqhmdU1Ug8leaBur
# 9ltksK2tIL1U70ZrbQLnRa519o6KuTIui7h3HFJNeYhfpToYyVAslyctv9oAfWN/
# 7zLsRodj25qfw1ohNnv5m9XKoG5yLPzh8Z5wTQhWFW+Qq/tIurnXwYJ4hWUuf7XJ
# wOIUtzcRQQbiiuCo9uV+tngFAcNg7U8HQS4KE0njkJt/3b36rL9kUdFcm7T1XOdc
# /zubpaAa130JssK3/24cvMh95ukr/HKzFOlKVRKEnEQldR32KvBPpSA9aCXrYZd8
# D+W2PfOuw8ERvBuOzOBHMF5CAIZx41isBsplH3uUpktXZwx+Xq14Z1tV417rx9js
# TG6Gy/Pc+J+HqnJYEg99pvj4Qjk7PCzkMk1JjODhAMI4oJz6hD5B3G5WrsYaW/Rn
# aAUBzRu/roe8nVP2Lui2a+SZ3sVPh1io0mUeyB/Vcm7uWRxXOwlyndfKt5DGzXtF
# kpFCA0x9P8ryqrjCDobzEJ9GLqRmhmhaaBhwKTgRgGBrikOjc2zjs2s3/+adZwGS
# ht8vSNH7UGDVXP4h0wFCY/7vcLQXwI+o7tPBS18S6v39Lg6HRGDjqfTCGKPj/c4M
# hCIN86d42pPz2zjPuS8zxv8HPF6+RdMCAwEAAaOCASswggEnMA4GA1UdDwEB/wQE
# AwIBhjASBgNVHRMBAf8ECDAGAQH/AgEBMB0GA1UdJQQWMBQGCCsGAQUFBwMDBggr
# BgEFBQcDCDA7BgNVHSAENDAyMDAGBFUdIAAwKDAmBggrBgEFBQcCARYaaHR0cDov
# L3d3dy5lbnRydXN0Lm5ldC9ycGEwMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAwBgNVHR8EKTAnMCWgI6Ahhh9odHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2cyY2EuY3JsMB0GA1UdDgQWBBSCutY9l86fz3Ho
# kjev/bO1aTVXzzAfBgNVHSMEGDAWgBRqciZ60B7vfec7aVHUbI2fkBJmqzANBgkq
# hkiG9w0BAQsFAAOCAQEAH15BBLaDcCRTLFVzHWU6wOy0ewSYXlk4EwmkWZRCXlC/
# T2xuJSCQk1hADfUZtGLuJF7CAVgVAh0QCW+o1PuSfjc4Pi8UfY8dQzZks2YTXxTM
# pXH3WyFLxpe+3JX8cH0RHNMh3dAkOSnF/goapc97ee46b97cv+kR3RaDCNMsjX9N
# qBR5LwVhUjjrYPMUaH3LsoqtwJRc5CYOLIrdRsPO5FZRxVbjhbhNm0VyiwfxivtJ
# uF/R8paBXWlSJPEII9LWIw/ri9d+i8GTa/rxYntY6VCbl24XiA3hxkOY14FhtoWd
# R+yxnq4/IDtDndiiHODUfAjCr3YG+GJmerb3+sivNTCCBfUwggPdoAMCAQICEHNp
# VltQNjt30ba68TisLKAwDQYJKoZIhvcNAQENBQAwTzELMAkGA1UEBhMCVVMxFjAU
# BgNVBAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWdu
# aW5nIENBIC0gT1ZDUzIwHhcNMjMxMTIzMTI0MzU0WhcNMjQxMTIzMTI0MzUzWjBy
# MQswCQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdh
# MR8wHQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFy
# ZWQgU2VydmljZXMgQ2FuYWRhMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKC
# AYEA0pQYq1J1OvO0uaG9IRG33VI1WvKKXQ7LzDMrQ6haotf7HPdREEjLmLtIfPsg
# GtMvD4aKUR1oFBn98k++EEdPDerrzbW7RGPSwqULjhG002jpbyX08G+bV1JV3pDQ
# dJFWcyrTUQAszs99JyLRdDsowqctB/FZtkDsCMT7CggIEcthzBJrpDHDBP8J8Oht
# IZKex7o8mQeOboTU7BubYmoQwDT5oaIkYcAr0W2fNi8emp+cDxLhnJT3dgAtm6xz
# h75pZSpuXjJkumm67NFjTIlHe/wCPrK/khwcD+elf6gs8of//wh6xbk02RN0bf/A
# sigGKmC3IRZXOg5LDnHKLcuVq45NWnUFjFilGzEzuohbAhvt1NPQ51+clWbdZddc
# IhUswdz+FD1Z8O0sCS5xRhI8imno7gyxFQmnsla1UggHegz9gboZdjnUUteHKAef
# mg49SyOVKNyw4XdVeS4mw2N2pne5cxu9U6ctTqDZOjQmTu7koWuYGCrHO9MYfTjZ
# PAehAgMBAAGjggEoMIIBJDAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBQ7yhB8yjTb
# A9pM1Js6PpMr/DshcTAfBgNVHSMEGDAWgBTvn7p5sHPyJR54nANSnBtThN6N7TBn
# BggrBgEFBQcBAQRbMFkwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3Qu
# bmV0MDIGCCsGAQUFBzAChiZodHRwOi8vYWlhLmVudHJ1c3QubmV0L292Y3MyLWNo
# YWluLnA3YzAxBgNVHR8EKjAoMCagJKAihiBodHRwOi8vY3JsLmVudHJ1c3QubmV0
# L292Y3MyLmNybDAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# EwYDVR0gBAwwCjAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBADokUaZVnmsM
# 98TXNnbdEAIgGe0a5P++ieaocVUAj0oolLye3xbxVlKjP20p4F+bfNHUre3l9gyZ
# ugVIKVCudWRyxHeGD3CPk2UbWIKaYnPh5PX3bGgwFOWy6VuzVjDU5+8rXEfRz4tB
# o32G8D6PVUTmnoWP/rPO5SJoLCSbeajqW7OVO1D72ZFjtlCHu2jrxspIbYOZr4ZW
# 8fX1d11B2r5Wsm7TL66D+ENZaeastuwPC1vbSAnVfb+xJqCaJhFu/yiYdQXgc1dA
# VWjB4z7F4ZsQoOfk2Gf4mAxoc6gTeNdooCUeP8CP31gwASuU1By6FTSAvxSHHOKB
# 3NjMPEPm0EZLbc7qL4zKISoPoDFrc/c6aRqIynE5KOV4hJGIgZ+H+wxCCVhTHuMX
# vKHuogWSGRnAqnY+HH/et54TsW+LFn+UaSAiG+2ZY9VhMiS9XmPJBlqqw2MiX2+e
# hGGuEXzsS89aSze/I+sFE6d91IjlF6/Q3W9Ul5mvdHvw5gkYWjfHLXQ3ssebJbE3
# eFWzw0XaaIKQzXNQi9sQnaGAJcROL6WumvAMsi7UNVDRTdsA4ZIxaSO8wrYA7OCe
# x4YuEpi+mJzo/R138UbNXP7VWHc1yoTSaiEPePDECrBp9G0s9of/Hm94NmIWZGc4
# O/Wv+Dbtn/iOM9pXjM/VxcH+KqSQOvjnMIIGcDCCBFigAwIBAgIQce9VdK81VMNa
# LGn2b0trzTANBgkqhkiG9w0BAQ0FADBpMQswCQYDVQQGEwJVUzEWMBQGA1UECgwN
# RW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50cnVzdCBDb2RlIFNpZ25pbmcgUm9v
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIENTQlIxMB4XDTIxMDUwNzE5MjA0
# NVoXDTQwMTIyOTIzNTkwMFowTzELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1
# c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZD
# UzIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCemXYXGp5WFwhjLJNN
# g2GEMzQCttlioN7CDrkgTMhXnQ/dVFsNDNYB3S9I4ZEJ4dvIFQSCtnvw2NYwOxlx
# cPuoppf2KV2kDKn0Uz5X2wxObvx2218k6apfQ+OT5w7PyiW8xEwwC1oP5gb05W4M
# mWZYT4NhwnN8XCJvAUXFD/dAT2RL0BcKqQ4eAi+hj0zyZ1DbPuSfwk8/dOsxpNCU
# 0Jm8MJIJasskzaLYdlLQTnWYT2Ra0l6D9FjAXWp1xNg/ZDqLFA3YduHquWvnEXBJ
# EThjE27xxvq9EEU1B+Z2FdB1FqrCQ1f+q/5jc0YioLjz5MdwRgn5qTdBmrNLbB9w
# cqMH9jWSdBFkbvkC1cCSlfGXWX4N7qIl8nFVuJuNv83urt37DOeuMk5QjaHf0XO/
# wc5/ddqrv9CtgjjF54jtom06hhG317DhqIs7DEEXml/kW5jInQCf93PSw+mfBYd5
# IYPWC+3RzAif4PHFyVi6U1/Uh7GLWajSXs1p0D76xDkJr7S17ec8+iKH1nP5F5Vq
# wxz1VXhf1PoLwFs/jHgVDlpMOm7lJpjQJ8wg38CGO3qNZUZ+2WFeqfSuPtT8r0XH
# OrOFBEqLyAlds3sCKFnjhn2AolhAZmLgOFWDq58pQSa6u+nYZPi2uyhzzRVK155z
# 42ZMsVGdgSOLyIZ3srYsNyJwIQIDAQABo4IBLDCCASgwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQU75+6ebBz8iUeeJwDUpwbU4Teje0wHwYDVR0jBBgwFoAU
# grrWPZfOn89x6JI3r/2ztWk1V88wMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAxBgNVHR8EKjAoMCagJKAihiBodHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2NzYnIxLmNybDAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwMwRQYDVR0gBD4wPDAwBgRVHSAAMCgwJgYIKwYBBQUH
# AgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMAgGBmeBDAEEATANBgkqhkiG
# 9w0BAQ0FAAOCAgEAXvOGmTXBee7wEK/XkkPShdBb4Jig4HFRyRTLUJpgDrAEJkmx
# z+m6mwih2kNd1G8jorn4QMdH/k0BC0iQP8jcarQ+UzUovkBKR4VqHndAzIB/YbQ8
# T3mo5qOmoH5EhnG/EhuVgXL3DaXQ3mefxqK48Wr5/P50ZsZk5nk9agNhTksfzCBi
# ywIY7GPtfnE/lroLXmgiZ+wfwNIFFmaxsqTq/MWVo40SpfWN7xsgzZn35zLzWXEf
# 3ZTmeeVSIxBWKvxZOL+/eSWSasf9q2d3cbEEfTWtFME+qPwjF1YIGHzXeiJrkWrM
# NUVtTzudQ50FuJ3z/DQhXAQYMlc4NMHKgyNGpogjIcZ+FICrse+7C6wJP+5TkTGz
# 4lREqrV9MDwsI5zoP6NY6kAIF6MgX3rADNuq/wMWAw10ZCKalF4wNXYT9dPh4+AH
# ytnqRYhGnFTVEOLzMglAtudcFzL+zK/rbc9gPHXz7lxgQFUbtVmvciNoTZx0BAwQ
# ya9QW6cNZg+W5ZqV4CCiGtCw7jhJnipnnpGWbJjbxBBtYHwebkjntn6vMwcSce+9
# lTu+qYPUQn23pzTXX4aRta9WWNpVfRe927zNZEEVjTFRBk+0LrKLPZzzTeNYA1TM
# rIj4UjxOS0YJJRn/FeenmEYufbrq4+N8//m5GZW+drkNebICURpKyJ+IwkMxghXn
# MIIV4wIBATBjME8xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMu
# MSgwJgYDVQQDEx9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyAhBzaVZb
# UDY7d9G2uvE4rCygMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIK3dDm0rxORpKCUaCGgz
# wDzUdXHTVuCCKxyddWVMNmsKMA0GCSqGSIb3DQEBAQUABIIBgBhznOiU/3d1vmKo
# hpSPQRsZ+h1js5rfobjG0m03cliWXi/ZzZ9wcEGgtFPf21r0vfftEzxqGo9zzIpc
# t+7W8lmqxq4zhUOS84IyNQ4dc8jw7R84p17issleqx3TlyF5xju/YadEb4PFS7Zt
# p7uhPJc0QqTWGXQcO4FoBS74Si97v8Uiy2pQvo3r/NbJvSJvuBN9+JZ/lF7F2DBd
# w4I25SdUhrXLYVUL+lFfGARsM2xUT59CXswaAAMgLM2BbmbdpizuYj8CsOTJ5sov
# AX2DdTkbAL5eDyg9JlR0Sdbn5/Dp4ZZrSp4b1ZL0LTlsI9IanHGjEpFKaT0DoMk8
# 9KYa90vQp1r2dwXG0lyieU9GSV7ehU/On2C9eBCXOtep8b6Lhe0eLFrM4qjl2kC4
# hQTIe5JrR3yi6iHendMa2dg8k4kiP9g6z6OSoWmCB08ImO1VyefmKzbswqsdLnyj
# 4JJ7CtjfLORrPIgfANs6mIU5i5RZXY/3rv7cU0CQjl1S9f02Z6GCE04wghNKBgor
# BgEEAYI3AwMBMYITOjCCEzYGCSqGSIb3DQEHAqCCEycwghMjAgEDMQ8wDQYJYIZI
# AWUDBAICBQAwge8GCyqGSIb3DQEJEAEEoIHfBIHcMIHZAgEBBgorBgEEAbIxAgEB
# MDEwDQYJYIZIAWUDBAIBBQAEIFOtE9gFifTeDUV2fAoiDhwbD5o/uRO6na5lQqyr
# /PvUAhREnSC0GKKHrseun3I1/U7xFCKiuxgPMjAyNDA0MjIxOTMxMTNaoG6kbDBq
# MQswCQYDVQQGEwJHQjETMBEGA1UECBMKTWFuY2hlc3RlcjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDDCNTZWN0aWdvIFJTQSBUaW1lIFN0YW1waW5n
# IFNpZ25lciAjNKCCDekwggb1MIIE3aADAgECAhA5TCXhfKBtJ6hl4jvZHSLUMA0G
# CSqGSIb3DQEBDAUAMH0xCzAJBgNVBAYTAkdCMRswGQYDVQQIExJHcmVhdGVyIE1h
# bmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGDAWBgNVBAoTD1NlY3RpZ28gTGlt
# aXRlZDElMCMGA1UEAxMcU2VjdGlnbyBSU0EgVGltZSBTdGFtcGluZyBDQTAeFw0y
# MzA1MDMwMDAwMDBaFw0zNDA4MDIyMzU5NTlaMGoxCzAJBgNVBAYTAkdCMRMwEQYD
# VQQIEwpNYW5jaGVzdGVyMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLDAqBgNV
# BAMMI1NlY3RpZ28gUlNBIFRpbWUgU3RhbXBpbmcgU2lnbmVyICM0MIICIjANBgkq
# hkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApJMoUkvPJ4d2pCkcmTjA5w7U0RzsaMsB
# ZOSKzXewcWWCvJ/8i7u7lZj7JRGOWogJZhEUWLK6Ilvm9jLxXS3AeqIO4OBWZO2h
# 5YEgciBkQWzHwwj6831d7yGawn7XLMO6EZge/NMgCEKzX79/iFgyqzCz2Ix6lkoZ
# E1ys/Oer6RwWLrCwOJVKz4VQq2cDJaG7OOkPb6lampEoEzW5H/M94STIa7GZ6A3v
# u03lPYxUA5HQ/C3PVTM4egkcB9Ei4GOGp7790oNzEhSbmkwJRr00vOFLUHty4Fv9
# GbsfPGoZe267LUQqvjxMzKyKBJPGV4agczYrgZf6G5t+iIfYUnmJ/m53N9e7UJ/6
# GCVPE/JefKmxIFopq6NCh3fg9EwCSN1YpVOmo6DtGZZlFSnF7TMwJeaWg4Ga9mBm
# kFgHgM1Cdaz7tJHQxd0BQGq2qBDu9o16t551r9OlSxihDJ9XsF4lR5F0zXUS0Zxv
# 5F4Nm+x1Ju7+0/WSL1KF6NpEUSqizADKh2ZDoxsA76K1lp1irScL8htKycOUQjeI
# IISoh67DuiNye/hU7/hrJ7CF9adDhdgrOXTbWncC0aT69c2cPcwfrlHQe2zYHS0R
# QlNxdMLlNaotUhLZJc/w09CRQxLXMn2YbON3Qcj/HyRU726txj5Ve/Fchzpk8WBL
# BU/vuS/sCRMCAwEAAaOCAYIwggF+MB8GA1UdIwQYMBaAFBqh+GEZIA/DQXdFKI7R
# NV8GEgRVMB0GA1UdDgQWBBQDDzHIkSqTvWPz0V1NpDQP0pUBGDAOBgNVHQ8BAf8E
# BAMCBsAwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBKBgNV
# HSAEQzBBMDUGDCsGAQQBsjEBAgEDCDAlMCMGCCsGAQUFBwIBFhdodHRwczovL3Nl
# Y3RpZ28uY29tL0NQUzAIBgZngQwBBAIwRAYDVR0fBD0wOzA5oDegNYYzaHR0cDov
# L2NybC5zZWN0aWdvLmNvbS9TZWN0aWdvUlNBVGltZVN0YW1waW5nQ0EuY3JsMHQG
# CCsGAQUFBwEBBGgwZjA/BggrBgEFBQcwAoYzaHR0cDovL2NydC5zZWN0aWdvLmNv
# bS9TZWN0aWdvUlNBVGltZVN0YW1waW5nQ0EuY3J0MCMGCCsGAQUFBzABhhdodHRw
# Oi8vb2NzcC5zZWN0aWdvLmNvbTANBgkqhkiG9w0BAQwFAAOCAgEATJtlWPrgec/v
# FcMybd4zket3WOLrvctKPHXefpRtwyLHBJXfZWlhEwz2DJ71iSBewYfHAyTKx6Xw
# Jt/4+DFlDeDrbVFXpoyEUghGHCrC3vLaikXzvvf2LsR+7fjtaL96VkjpYeWaOXe8
# vrqRZIh1/12FFjQn0inL/+0t2v++kwzsbaINzMPxbr0hkRojAFKtl9RieCqEeajX
# Pawhj3DDJHk6l/ENo6NbU9irALpY+zWAT18ocWwZXsKDcpCu4MbY8pn76rSSZXwH
# fDVEHa1YGGti+95sxAqpbNMhRnDcL411TCPCQdB6ljvDS93NkiZ0dlw3oJoknk5f
# TtOPD+UTT1lEZUtDZM9I+GdnuU2/zA2xOjDQoT1IrXpl5Ozf4AHwsypKOazBpPmp
# fTXQMkCgsRkqGCGyyH0FcRpLJzaq4Jgcg3Xnx35LhEPNQ/uQl3YqEqxAwXBbmQpA
# +oBtlGF7yG65yGdnJFxQjQEg3gf3AdT4LhHNnYPl+MolHEQ9J+WwhkcqCxuEdn17
# aE+Nt/cTtO2gLe5zD9kQup2ZLHzXdR+PEMSU5n4k5ZVKiIwn1oVmHfmuZHaR6Ej+
# yFUK7SnDH944psAU+zI9+KmDYjbIw74Ahxyr+kpCHIkD3PVcfHDZXXhO7p9eIOYJ
# anwrCKNI9RX8BE/fzSEceuX1jhrUuUAwggbsMIIE1KADAgECAhAwD2+s3WaYdHyp
# RjaneC25MA0GCSqGSIb3DQEBDAUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# TmV3IEplcnNleTEUMBIGA1UEBxMLSmVyc2V5IENpdHkxHjAcBgNVBAoTFVRoZSBV
# U0VSVFJVU1QgTmV0d29yazEuMCwGA1UEAxMlVVNFUlRydXN0IFJTQSBDZXJ0aWZp
# Y2F0aW9uIEF1dGhvcml0eTAeFw0xOTA1MDIwMDAwMDBaFw0zODAxMTgyMzU5NTla
# MH0xCzAJBgNVBAYTAkdCMRswGQYDVQQIExJHcmVhdGVyIE1hbmNoZXN0ZXIxEDAO
# BgNVBAcTB1NhbGZvcmQxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDElMCMGA1UE
# AxMcU2VjdGlnbyBSU0EgVGltZSBTdGFtcGluZyBDQTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAMgbAa/ZLH6ImX0BmD8gkL2cgCFUk7nPoD5T77NawHbW
# GgSlzkeDtevEzEk0y/NFZbn5p2QWJgn71TJSeS7JY8ITm7aGPwEFkmZvIavVcRB5
# h/RGKs3EWsnb111JTXJWD9zJ41OYOioe/M5YSdO/8zm7uaQjQqzQFcN/nqJc1zjx
# FrJw06PE37PFcqwuCnf8DZRSt/wflXMkPQEovA8NT7ORAY5unSd1VdEXOzQhe5cB
# lK9/gM/REQpXhMl/VuC9RpyCvpSdv7QgsGB+uE31DT/b0OqFjIpWcdEtlEzIjDzT
# FKKcvSb/01Mgx2Bpm1gKVPQF5/0xrPnIhRfHuCkZpCkvRuPd25Ffnz82Pg4wZytG
# tzWvlr7aTGDMqLufDRTUGMQwmHSCIc9iVrUhcxIe/arKCFiHd6QV6xlV/9A5VC0m
# 7kUaOm/N14Tw1/AoxU9kgwLU++Le8bwCKPRt2ieKBtKWh97oaw7wW33pdmmTIBxK
# lyx3GSuTlZicl57rjsF4VsZEJd8GEpoGLZ8DXv2DolNnyrH6jaFkyYiSWcuoRsDJ
# 8qb/fVfbEnb6ikEk1Bv8cqUUotStQxykSYtBORQDHin6G6UirqXDTYLQjdprt9v3
# GEBXc/Bxo/tKfUU2wfeNgvq5yQ1TgH36tjlYMu9vGFCJ10+dM70atZ2h3pVBeqeD
# AgMBAAGjggFaMIIBVjAfBgNVHSMEGDAWgBRTeb9aqitKz1SA4dibwJ3ysgNmyzAd
# BgNVHQ4EFgQUGqH4YRkgD8NBd0UojtE1XwYSBFUwDgYDVR0PAQH/BAQDAgGGMBIG
# A1UdEwEB/wQIMAYBAf8CAQAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwEQYDVR0gBAow
# CDAGBgRVHSAAMFAGA1UdHwRJMEcwRaBDoEGGP2h0dHA6Ly9jcmwudXNlcnRydXN0
# LmNvbS9VU0VSVHJ1c3RSU0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDB2Bggr
# BgEFBQcBAQRqMGgwPwYIKwYBBQUHMAKGM2h0dHA6Ly9jcnQudXNlcnRydXN0LmNv
# bS9VU0VSVHJ1c3RSU0FBZGRUcnVzdENBLmNydDAlBggrBgEFBQcwAYYZaHR0cDov
# L29jc3AudXNlcnRydXN0LmNvbTANBgkqhkiG9w0BAQwFAAOCAgEAbVSBpTNdFuG1
# U4GRdd8DejILLSWEEbKw2yp9KgX1vDsn9FqguUlZkClsYcu1UNviffmfAO9Aw63T
# 4uRW+VhBz/FC5RB9/7B0H4/GXAn5M17qoBwmWFzztBEP1dXD4rzVWHi/SHbhRGdt
# j7BDEA+N5Pk4Yr8TAcWFo0zFzLJTMJWk1vSWVgi4zVx/AZa+clJqO0I3fBZ4OZOT
# lJux3LJtQW1nzclvkD1/RXLBGyPWwlWEZuSzxWYG9vPWS16toytCiiGS/qhvWiVw
# YoFzY16gu9jc10rTPa+DBjgSHSSHLeT8AtY+dwS8BDa153fLnC6NIxi5o8JHHfBd
# 1qFzVwVomqfJN2Udvuq82EKDQwWli6YJ/9GhlKZOqj0J9QVst9JkWtgqIsJLnfE5
# XkzeSD2bNJaaCV+O/fexUpHOP4n2HKG1qXUfcb9bQ11lPVCBbqvw0NP8srMftpmW
# JvQ8eYtcZMzN7iea5aDADHKHwW5NWtMe6vBE5jJvHOsXTpTDeGUgOw9Bqh/poUGd
# /rG4oGUqNODeqPk85sEwu8CgYyz8XBYAqNDEf+oRnR4GxqZtMl20OAkrSQeq/eww
# 2vGnL8+3/frQo4TZJ577AWZ3uVYQ4SBuxq6x+ba6yDVdM3aO8XwgDCp3rrWiAoa6
# Ke60WgCxjKvj+QrJVF3UuWp0nr1IrpgxggQsMIIEKAIBATCBkTB9MQswCQYDVQQG
# EwJHQjEbMBkGA1UECBMSR3JlYXRlciBNYW5jaGVzdGVyMRAwDgYDVQQHEwdTYWxm
# b3JkMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxJTAjBgNVBAMTHFNlY3RpZ28g
# UlNBIFRpbWUgU3RhbXBpbmcgQ0ECEDlMJeF8oG0nqGXiO9kdItQwDQYJYIZIAWUD
# BAICBQCgggFrMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0B
# CQUxDxcNMjQwNDIyMTkzMTEzWjA/BgkqhkiG9w0BCQQxMgQwrEqAHqfd3492iQA/
# ftDpxAd3Vv5hwkEpG341uG2jtIgJp6WnXN94i/seoe5BbeBKMIHtBgsqhkiG9w0B
# CRACDDGB3TCB2jCB1zAWBBSuYq91Cgy9R9ZGH3Vo4ryM58pPlDCBvAQUAtZbleKD
# cMFXAJX6iPkj3ZN/rY8wgaMwgY6kgYswgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhl
# IFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRp
# ZmljYXRpb24gQXV0aG9yaXR5AhAwD2+s3WaYdHypRjaneC25MA0GCSqGSIb3DQEB
# AQUABIICAJsH0do6BQdxwgBpaMcEPn7a6ADHlRyumPGG69V60cwcIXtGqLkK0mOa
# 88vRcbb08mWoXha5rNiPg4UtFgPmGLNN9AVirIoskFmPcaxTCYa+H/48tLx8GusW
# nngXJtSlseHKaZ1vn8kwSX97QqqiSc5kg/H3ble4Xx05L0oW4OqTz/h7nK4Ixcyh
# MfrVtrYgUs2gB3Qwc3KeZ/nF9s2YutsevxU4pDQybu0n7kl+H0m9s+wyD2TPfZSy
# 3DEe+x8dTYkSXzIxzpYC7HM3AOWSE+EPNkw45ZfwhmnG75DIyn09b7l3wIQu+Dod
# ydiVDZ8o4+kmJi8an5tstVLUXsBgh/x9ZnXEqLtCA+uuNMdv5BZUi6LKyEoRCauv
# SS2dwEfxWIKxDNGH8iIpRGjabumTTwosSDBxWWSb6HzLS3Biqw1V/nVdR+eMrpFq
# ialguScnLdEu4UI80IzhM+7n0hnB2rRPZ6VidrgokhoYcYeefS/nwcXrY9mysEA7
# NXjtxThyJDlAFFAdNM84MuiR2FgYJgPQiPcgCPw7WV1Kyx85QqJf0FSCeKGcLc+l
# LDXaNRK4ynrVhJNKhze94YtwbCXzkI1utuSi4AHJIQzdek4+EHhgiKVeuZQFbsRC
# C/6ntMAxOhX7e6OSTooNe85DVvPDlhvLIoDQyyHEdvYMMOgjetQi
# SIG # End signature block

function get-tagValue {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $tagKey,
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    $tagString = get-tagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}
function get-tagstring {
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    if ($object.Tag.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = [System.Text.StringBuilder]::new()
        $tKeys = $object.tag | Select-Object -ExpandProperty keys
        $tValues = $object.Tag | Select-Object -ExpandProperty values
        $index = 0

        if ($object.Tag.Count -eq 1) {
            $tagstring = "$tKeys=$tValues"
        }
        else {
            foreach ($tkey in $tKeys) {
                [void]$tagstring.Append("$tkey=$($tValues[$index]);")
                $index++
            }
        }
        $tagstring = $tagstring.ToString().TrimEnd(';')
    }
    return $tagstring
}
function get-rgtagstring {
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    if ($object.Tags.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = [System.Text.StringBuilder]::new()
        $tKeys = $object.tags | Select-Object -ExpandProperty keys
        $tValues = $object.Tags | Select-Object -ExpandProperty values
        $index = 0
        foreach ($tkey in $tKeys) {
            [void]$tagstring.Append("$tkey=$($tValues[$index]);")
            $index++
        }
        $tagstring = $tagstring.ToString().TrimEnd(';')
    }
    return $tagstring
}
function get-rgtagValue {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $tagKey,
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    $tagString = get-rgtagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}

# Returns true when the GCCloudGuardrails custom security attribute marks the user as excluded from MFA.
function Test-GuardrailsMfaExclusion {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject] $User,
        [string] $AttributeNamespace = 'GCCloudGuardrails',
        [string] $AttributeName = 'ExcludeFromMFA'
    )

    if ($null -eq $User) { return $false }

    $customAttributes = $User.customSecurityAttributes
    if ($null -eq $customAttributes) { return $false }

    $namespaceProperty = $customAttributes.PSObject.Properties[$AttributeNamespace]
    if ($null -eq $namespaceProperty) { return $false }

    $namespaceValue = $namespaceProperty.Value
    if ($null -eq $namespaceValue) { return $false }

    $attributeProperty = $namespaceValue.PSObject.Properties[$AttributeName]
    if ($null -eq $attributeProperty) { return $false }

    return ($attributeProperty.Value -eq $true)
}

function Get-GuardrailsAgentUserIds {
    <#
    .SYNOPSIS
        Returns the object IDs of Microsoft Entra Agent ID user accounts in the tenant.
    .DESCRIPTION
        Agents created by Microsoft services (Security Copilot and other agentic features) get an
        agentUser account. These are a subtype of user, so they appear in /users alongside people,
        are enabled, and never register MFA because no one can sign in to them interactively. They
        are created dynamically, so a custom security attribute cannot be applied at creation time
        and GCCloudGuardrails.ExcludeFromMFA cannot cover them.

        The agentUser subtype cast returns only these accounts, so the tenant-wide user collection
        query is left untouched. A tenant without the feature, or without permission to read the
        cast, reports Succeeded = false and the caller evaluates every account exactly as before.
    #>
    [CmdletBinding()]
    [OutputType([psobject])]
    param ()

    $agentUserIds = @{}

    # A tenant without the Agent ID feature, or without the permission to read the cast,
    # fails the same way on every attempt. Two short attempts absorb a transient blip
    # without adding the default 15 seconds of retry delay to every collection run.
    try {
        $response = Invoke-GraphQueryEX -urlPath '/users/microsoft.graph.AgentUser?$select=id,userPrincipalName' -MaxRetries 2 -RetryDelaySeconds 2 -ErrorAction Stop
    }
    catch {
        return [PSCustomObject]@{
            Ids          = $agentUserIds
            Count        = 0
            Succeeded    = $false
            ErrorMessage = $_.Exception.Message
        }
    }

    if ($null -eq $response -or $null -eq $response.Content) {
        $responseError = if ($response -and $response.Error) { [string]$response.Error } else { 'Microsoft Graph returned no content for the agentUser query.' }
        return [PSCustomObject]@{
            Ids          = $agentUserIds
            Count        = 0
            Succeeded    = $false
            ErrorMessage = $responseError
        }
    }

    foreach ($agentUser in @($response.Content.value)) {
        $agentUserId = [string]$agentUser.id
        if (-not [string]::IsNullOrWhiteSpace($agentUserId)) {
            $agentUserIds[$agentUserId] = $true
        }
    }

    return [PSCustomObject]@{
        Ids          = $agentUserIds
        Count        = $agentUserIds.Count
        Succeeded    = $true
        ErrorMessage = $null
    }
}

function New-ConnectedStorageContext {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName
    )
    try {
        # Build a blob context that uses the identity already connected to Az PowerShell instead of a storage key.
        return (New-AzStorageContext -StorageAccountName $storageaccountName -UseConnectedAccount -ErrorAction Stop)
    }
    catch {
        $errorMessage = "Failed to create an Entra-authenticated storage context for storage account '$storageaccountName'. Error: $($_.Exception.Message)"
        throw $errorMessage
    }
}

function copy-toBlobUsingConnectedAccount {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName,
        [Parameter(Mandatory = $false)]
        [switch]
        $force
    )
    try {
        # Reuse the shared Entra-authenticated context so upload works with RBAC and no Shared Key access.
        $context = New-ConnectedStorageContext -storageaccountName $storageaccountName
        $bcParams = @{
            File      = $FilePath
            Blob      = ($FilePath | Split-Path -Leaf)
            Container = $containerName
            Context   = $context
        }

        # Add -Force only when the caller asked for it so the upload call stays a single code path.
        if ($force) {
            $bcParams['Force'] = $true
        }
        Set-AzStorageBlobContent @bcParams | Out-Null
    }
    catch {
        $errorMessage = "Failed to upload blob '$($FilePath | Split-Path -Leaf)' to storage account '$storageaccountName' container '$containerName' with Entra auth. Error: $($_.Exception.Message)"
        throw $errorMessage
    }
}

function Test-GSARetryableBlobError {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]
        $ErrorRecord
    )

    # Retry only when the error still looks like RBAC/auth propagation instead of a real missing-resource problem.
    $retryableMarkers = @(
        'AuthorizationFailure',
        'AuthorizationPermissionMismatch',
        'AuthorizationPermissionDenied',
        'AuthenticationFailed',
        'Forbidden',
        'Unauthorized',
        'not authorized'
    )

    $statusCode = $null
    if ($null -ne $ErrorRecord.Exception.Response -and $null -ne $ErrorRecord.Exception.Response.StatusCode) {
        $statusCode = [int]$ErrorRecord.Exception.Response.StatusCode
    }

    if ($statusCode -in @(401, 403)) {
        return $true
    }

    $errorText = $ErrorRecord.ToString()
    foreach ($marker in $retryableMarkers) {
        if ($errorText -match $marker) {
            return $true
        }
    }

    return $false
}

function read-blob {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName
    )
    # Wait up to 10 minutes for the Automation Account's Blob Reader role to become usable.
    $maxBlobAttempts = 30
    $blobRetryDelaySeconds = 20
    $Context = New-ConnectedStorageContext -storageaccountName $storageaccountName

    for ($attempt = 1; $attempt -le $maxBlobAttempts; $attempt++) {
        try {
            $blobParams = @{
                Blob        = 'modules.json'
                Container   = $containerName
                Destination = $FilePath
                Context     = $Context
                Force       = $true
                ErrorAction = 'Stop'
            }

            Get-AzStorageBlobContent @blobParams
            return
        }
        catch {
            # Keep retrying while the new blob role settles, but fail loudly once the final attempt is exhausted.
            if ($attempt -eq $maxBlobAttempts -or -not (Test-GSARetryableBlobError -ErrorRecord $_)) {
                throw
            }

            Write-Verbose "Attempt $attempt of $maxBlobAttempts could not read modules.json yet. Waiting $blobRetryDelaySeconds seconds before retrying. Error: $($_.Exception.Message)"
            Start-Sleep -Seconds $blobRetryDelaySeconds
        }
    }
}

Function Add-LogEntry {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [ValidateSet("Critical", "Error", "Warning", "Information", "Debug")]
        [string]
        $severity,

        # message details (string)
        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $message,

        # module name
        [Parameter(Mandatory = $false)]
        [string]
        $moduleName = (Split-Path -Path $MyInvocation.ScriptName -Leaf),

        # additional values in hashtable
        [Parameter(Mandatory = $false)]
        [hashtable]
        $additionalValues = @{},

        # exception log type - this is the Log Analytics table name
        [Parameter(Mandatory = $false)]
        [string]
        $exceptionLogTable = "GuardrailsComplianceException",

        # guardrails exception workspace GUID
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceGuid,

        # guardrails exception workspace shared key
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey
    )

    # build log entry object, convert to json
    $entryHash = @{
        "message"    = $message
        "moduleName" = $moduleName
        "severity"   = $severity
    } + $additionalValues
    
    $entryJson = ConvertTo-Json -inputObject $entryHash -Depth 20

    # log event to Log Analytics workspace using DCR-based Log Ingestion API
    Send-GuardrailsData -Data $entryJson -LogType $exceptionLogTable -WorkSpaceID $workspaceGuid -WorkSpaceKey $workspaceKey 

}

Function Add-TenantInfo {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_TenantInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $true)]
        [string]
        $TenantId,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentName,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentNumber,
        [Parameter(Mandatory = $true)]
        [string]
        $cloudUsageProfiles,
        [Parameter(Mandatory = $true)]
        [string]
        $tenantName,
        [Parameter(Mandatory = $true)]
        [string]
        $locale
    )
    $tenantInfo = Get-GSAAutomationVariable("tenantDomainUPN")

    $object = [PSCustomObject]@{ 
        TenantDomain       = $tenantInfo
        DepartmentTenantID = $TenantId
        DepartmentTenantName= $tenantName
        ReportTime         = $ReportTime
        DepartmentName     = $DepartmentName
        DepartmentNumber   = $DepartmentNumber
        cloudUsageProfiles = $cloudUsageProfiles
        Locale             = $locale
    }
    if ($debug) { Write-Output $tenantInfo }
    $JSON = ConvertTo-Json -inputObject $object

    Send-GuardrailsData -Data $JSON -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $workspaceKey 
}

function Add-LogAnalyticsResults {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_Results",
        [Parameter(Mandatory = $false)]
        [array]
        $Results
    )

    $JSON = ConvertTo-Json -inputObject $Results

    Send-GuardrailsData -Data $JSON -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $workspaceKey 
}

function Get-GuardrailIdentityPermissions {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$TenantRootManagementGroupId
    )

    if ([string]::IsNullOrWhiteSpace($TenantRootManagementGroupId)) {
        throw "TenantRootManagementGroupId is required."
    }

    $context = Get-AzContext
    if (-not $context -or -not $context.Account -or [string]::IsNullOrWhiteSpace($context.Account.Id)) {
        throw "Azure context is not initialized; unable to resolve automation account identity."
    }

    $principal = $null
    $principalLookupErrors = [System.Collections.Generic.List[string]]::new()

    $automationAccountObjectId = $env:AUTOMATION_ACCOUNT_ID
    if (-not [string]::IsNullOrWhiteSpace($automationAccountObjectId)) {
        $objectGuid = [Guid]::Empty
        if ([Guid]::TryParse($automationAccountObjectId, [ref]$objectGuid)) {
            try {
                $principal = Get-AzADServicePrincipal -ObjectId $objectGuid -ErrorAction Stop
            }
            catch {
                $principalLookupErrors.Add("AUTOMATION_ACCOUNT_ID lookup failed: $($_.Exception.Message)") | Out-Null
            }
        }
        else {
            $principalLookupErrors.Add("AUTOMATION_ACCOUNT_ID value '$automationAccountObjectId' is not a GUID.") | Out-Null
        }
    }
    else {
        $principalLookupErrors.Add('AUTOMATION_ACCOUNT_ID environment variable not set.') | Out-Null
    }

    if (-not $principal) {
        $applicationGuid = [Guid]::Empty
        if ([Guid]::TryParse($context.Account.Id, [ref]$applicationGuid)) {
            try {
                $principal = Get-AzADServicePrincipal -ApplicationId $applicationGuid -ErrorAction Stop
            }
            catch {
                $principalLookupErrors.Add("ApplicationId lookup failed: $($_.Exception.Message)") | Out-Null
            }
        }
        else {
            $principalLookupErrors.Add("Context.Account.Id '$($context.Account.Id)' is not a GUID.") | Out-Null
        }
    }

    if (-not $principal) {
        $details = if ($principalLookupErrors.Count -gt 0) { ' Details: ' + ($principalLookupErrors -join ' | ') } else { '' }
        throw "Failed to resolve automation account service principal.$details"
    }

    $principalDisplayName = $principal.DisplayName
    if ([string]::IsNullOrWhiteSpace($principalDisplayName)) {
        $principalDisplayName = $principal.AppId
    }

    $assignments = [System.Collections.Generic.List[psobject]]::new()
    $errors = [System.Collections.Generic.List[string]]::new()

    try {
        $rbacAssignments = Get-AzRoleAssignment -ObjectId $principal.Id -ExpandPrincipalGroups:$false -ErrorAction Stop
    }
    catch {
        $errors.Add("RBAC enumeration failed: $($_.Exception.Message)") | Out-Null
        $rbacAssignments = @()
    }

    foreach ($assignment in $rbacAssignments) {
        $assignments.Add([pscustomobject]@{
                PrincipalType        = 'AutomationAccountMSI'
                PermissionType       = 'RBAC'
                PrincipalName        = $principalDisplayName
                PrincipalId          = $principal.Id
                Role                 = $assignment.RoleDefinitionName
                RoleDefinitionId     = $assignment.RoleDefinitionId
                Scope                = $assignment.Scope
                # Some Az versions expose the GUID as RoleAssignmentId instead of Id (PS5.1 compatible)
                AssignmentId         = if ($assignment.RoleAssignmentId) { $assignment.RoleAssignmentId } else { $assignment.Id }
                TenantRootManagementGroupId        = $TenantRootManagementGroupId
                TenantRootManagementGroupResourceId = "/providers/Microsoft.Management/managementGroups/$TenantRootManagementGroupId"
            }) | Out-Null
    }

    # AAD app-role assignments (GUIDs only)
    $resourceAppRoleAssignments = @()
    $graphPath = "/servicePrincipals/$($principal.Id)/appRoleAssignments?`$select=appRoleId,createdDateTime,principalDisplayName,principalId,resourceDisplayName,resourceId"
    $graphResponse = $null
    try {
        $graphResponse = Invoke-GraphQueryEX -urlPath $graphPath -ErrorAction Stop
    }
    catch {
        $errors.Add("AAD app-role enumeration failed: $($_.Exception.Message)") | Out-Null
    }

    if ($graphResponse -and $graphResponse.Content -and $graphResponse.Content.value) {
        $resourceAppRoleAssignments = $graphResponse.Content.value
    }
    elseif ($null -eq $graphResponse) {
        # distinguish API failure from truly empty assignments
        $errors.Add('AAD app-role enumeration did not return a response.') | Out-Null
    }

    # cache appRoles per resourceId to keep calls to 1 per resource
    $appRoleMetadataCache = @{}
    $uniqueResourceIds = @($resourceAppRoleAssignments | Select-Object -ExpandProperty resourceId -Unique | Where-Object { $_ })

    foreach ($resourceId in $uniqueResourceIds) {
        if ($appRoleMetadataCache.ContainsKey($resourceId)) { continue }

        # Use direct Graph call (not Invoke-GraphQueryEX) so appRoles aren't hidden under Content.value and AppRoleValue stays populated.
        $resourceUri = "https://graph.microsoft.com/v1.0/servicePrincipals/$resourceId"
        try {
            # The PowerShell 7.6 migration also upgrades the Runtime Environment's Az modules.
            # Use their secure token path instead of depending on the older plain-text token response.
            # This changes token handling only; the identity permission check is unchanged.
            # ErrorAction Stop sends authentication failures to the catch block below.
            $graphToken = (Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com' -AsSecureString -ErrorAction Stop).Token

            $appRoles = $null

            # Pass the secure token directly to PowerShell instead of rebuilding the old plain-text authorization header.
            # The Graph response is JSON.
            $resourcePayload = Invoke-RestMethod -Method Get -Uri $resourceUri -Authentication Bearer -Token $graphToken -ContentType 'application/json' -ErrorAction Stop
            $appRoles = if ($resourcePayload.appRoles) { $resourcePayload.appRoles }
                       elseif ($resourcePayload.value) {
                           $valueObj = $resourcePayload.value
                           if ($valueObj -is [System.Array] -and $valueObj.Count -gt 0 -and $valueObj[0].appRoles) { $valueObj[0].appRoles }
                           elseif ($valueObj.appRoles) { $valueObj.appRoles }
                       }

            if ($null -eq $appRoles) {
                $errors.Add("AAD app-role metadata lookup for resource $($resourceId): appRoles property not found or empty.") | Out-Null
            }

            $appRoleMetadataCache[$resourceId] = $appRoles
        }
        catch {
            $statusCode = if ($_.Exception.Response -and $_.Exception.Response.StatusCode) { [int]$_.Exception.Response.StatusCode.value__ } else { 500 }
            $errors.Add("AAD app-role metadata lookup for resource $($resourceId) returned status $statusCode : $($_.Exception.Message)") | Out-Null
            $appRoleMetadataCache[$resourceId] = $null
            continue
        }
    }

    foreach ($assignment in $resourceAppRoleAssignments) {
        $appRoleValue = $null

        if ($assignment.resourceId -and $assignment.appRoleId -and $appRoleMetadataCache.ContainsKey($assignment.resourceId) -and $appRoleMetadataCache[$assignment.resourceId]) {
            $matchingRole = $appRoleMetadataCache[$assignment.resourceId] | Where-Object { [string]$_.id -eq [string]$assignment.appRoleId } | Select-Object -First 1
            if ($matchingRole) {
                $appRoleValue = $matchingRole.value
            }
        }

        $assignments.Add([pscustomobject]@{
                PrincipalType        = 'AutomationAccountMSI'
                PermissionType       = 'AADAppRole'
                PrincipalName        = $principalDisplayName
                PrincipalId          = $principal.Id
                ResourceDisplayName  = $assignment.resourceDisplayName
                ResourceId           = $assignment.resourceId
                AppRoleId            = $assignment.appRoleId
                CreatedDateTime      = $assignment.createdDateTime
                AppRoleValue         = $appRoleValue
                TenantRootManagementGroupId        = $TenantRootManagementGroupId
                TenantRootManagementGroupResourceId = "/providers/Microsoft.Management/managementGroups/$TenantRootManagementGroupId"
            }) | Out-Null
    }

    return [pscustomobject]@{
        PrincipalType                     = 'AutomationAccountMSI'
        PrincipalId                       = $principal.Id
        PrincipalAppId                    = $principal.AppId
        PrincipalName                     = $principalDisplayName
        TenantRootManagementGroupId       = $TenantRootManagementGroupId
        TenantRootManagementGroupResourceId = "/providers/Microsoft.Management/managementGroups/$TenantRootManagementGroupId"
        Assignments                       = $assignments
        Errors                            = $errors
    }
}

function Check-DocumentExistsInStorage {
    [Alias('Check-DocumentsExistInStorage')]
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName, 
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID, 
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName, 
        [Parameter(Mandatory = $true)]
        [string] $ControlName, 
        [Parameter(Mandatory = $true)]
        [string]$ItemName,
        [Parameter(Mandatory = $true)]
        [hashtable] $msgTable, 
        [Parameter(Mandatory = $true)]
        [string]$itsgcode,
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $false)]
        [string] 
        $CloudUsageProfiles = "3",  # Passed as a string
        [Parameter(Mandatory = $false)]
        [string] $ModuleProfiles,  # Passed as a string
        [Parameter(Mandatory = $false)]
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false    
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null

    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        #Add-LogEntry 'Error' 
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    $docMissing = $false
    $commentsArray = @()
    $blobFound = $false
    $baseFileNameFound = $false
    $blobAccessFailed = $false

    try {
        # Use Entra/RBAC blob access here because the Guardrails storage account no longer allows Shared Key auth.
        $StorageContext = New-ConnectedStorageContext -storageaccountName $StorageAccountName
    }
    catch {
        $storageErrorMessage = "Could not connect to storage account '$storageAccountName' in resource group '$resourceGroupName' of subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_"
        $ErrorList.Add($storageErrorMessage) | Out-Null

        return [PSCustomObject]@{
            ComplianceResults = $null
            Errors            = $ErrorList
            AdditionalResults = $AdditionalResults
        }
    }
   
    if ($null -ne $StorageContext) {
        try {
            # Fail fast on blob RBAC issues so they are not misreported as a missing document.
            $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -ErrorAction Stop
            $fileNamesList = @()
            $blobs | ForEach-Object {
                $fileNamesList += $_.Name
            }
            $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
            if ( $matchingFiles.count -lt 1 ){
                # check if any fileName matches without the extension
                $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
                
                $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
                if ($BaseFileNamesMatch.Count -gt 0){
                    $baseFileNameFound = $true
                }
            }
            else {
                # also covers the use case if more than 1 appropriate files are uploaded
                $blobFound = $true
            }
        }
        catch {
            $storageErrorMessage = "Could not read from storage account '$storageAccountName' container '$ContainerName' in resource group '$resourceGroupName' of subscription '$subscriptionId'; verify that blob data access is available. Error: $_"
            $ErrorList.Add($storageErrorMessage) | Out-Null

            return [PSCustomObject]@{
                ComplianceResults = $null
                Errors            = $ErrorList
                AdditionalResults = $AdditionalResults
            }
        }

        # Use case: uploaded fileName is correct but has wrong extension
        if ($baseFileNameFound){
            # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
            $docMissing = $true
            $commentsArray += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
        }
        else {
            if ($blobFound){
                # Use case: a blob with the name $documentName was located in the specified storage account
                $commentsArray += $msgTable.procedureFileFound -f  $DocumentName
            }
            else {
                # Use case: no blob with the name $documentName was found in the specified storage account
                $docMissing = $true
                $commentsArray += $msgTable.procedureFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
            }
        }
    }

    $Comments = $commentsArray -join ";"

    If ($docMissing) {
        $IsCompliant = $false
    }
    Else {
        $IsCompliant = $true
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        DocumentName     = $DocumentName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    if ($EnableMultiCloudProfiles) {        
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID
        if (!$evalResult.ShouldEvaluate) {
            if ($evalResult.Profile -gt 0) {
                $PsObject.ComplianceStatus = "Not Applicable"
                $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $PsObject.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
                
                $moduleOutput = [PSCustomObject]@{ 
                    ComplianceResults = $PsObject
                    Errors            = $ErrorList
                    AdditionalResults = $AdditionalResults
                }
                return $moduleOutput
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        } else {
            
            $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
        }
    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput

}

function Check-UpdateAvailable {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_VersionInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $false)]
        [string]
        $ResourceGroupName
    )
    # /releases/latest skips pre-releases, so if the newest published release is a beta
    # it won't show up there. Grab the full list and pick the highest version ourselves.
    # created_at breaks ties (e.g. v4.0.0 stable wins over v4.0.0beta).
    $allReleases = Invoke-RestMethod 'https://api.github.com/repos/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases' -Verbose:$false
    $latestRelease = $allReleases |
        Sort-Object @(
            @{ Expression = {
                try   { [version]::Parse(($_.tag_name -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$', '$1')) }
                catch { [version]'0.0.0' }
            }; Descending = $true },
            @{ Expression = { $_.created_at }; Descending = $true }
        ) |
        Select-Object -First 1

    # .name is the release title, not the git tag — use .tag_name for the raw file URL.
    $tagsFileURI = "https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/raw/{0}/setup/tags.json" -f $latestRelease.tag_name
    $tags = Invoke-RestMethod $tagsFileURI -Verbose:$false

    if ([string]::IsNullOrEmpty($ResourceGroupName)) {
        $ResourceGroupName = Get-AutomationVariable -Name "ResourceGroupName"
    }
    $rg=Get-AzResourceGroup -Name $ResourceGroupName 

    $deployedVersion=$rg.Tags["ReleaseVersion"]
    $currentVersion = $tags.ReleaseVersion

    try {
        # script version numbers of surrounding characters and then converted to a version object
        $deployedVersionVersion = [version]::Parse(($deployedVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
        $currentVersionVersion = [version]::Parse(($currentVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
    }
    catch {
        Write-Error "Error: Failed to convert version numbers to version objects. Error: $_"
    }

    if ($debug) { Write-Output "Resource Group Tag (deployed version): $deployedVersion; $deployedVersionVersion"}
    if ($debug) { Write-Output "Latest available version from GitHub: $currentVersion; $currentVersionVersion"}
    
    if ($deployedVersionVersion -lt $currentVersionVersion) {
        $updateNeeded = $true
    }
    elseif ($deployedVersionVersion -eq $currentVersionVersion) {
        # Same numeric version — check whether the available release is further along
        # in the pre-release progression: alpha < beta < rc < stable.
        $preReleaseRank = @{ alpha = 0; beta = 1; rc = 2 }

        $deployedLabel = if    ($deployedVersion -match 'alpha') { 'alpha' }
                         elseif ($deployedVersion -match 'beta')  { 'beta'  }
                         elseif ($deployedVersion -match 'rc')    { 'rc'    }
                         else                                      { 'stable'}

        $currentLabel  = if    ($currentVersion -match 'alpha') { 'alpha' }
                         elseif ($currentVersion -match 'beta')  { 'beta'  }
                         elseif ($currentVersion -match 'rc')    { 'rc'    }
                         else                                     { 'stable'}

        $deployedRank = if ($preReleaseRank.ContainsKey($deployedLabel)) { $preReleaseRank[$deployedLabel] } else { 3 }
        $currentRank  = if ($preReleaseRank.ContainsKey($currentLabel))  { $preReleaseRank[$currentLabel]  } else { 3 }

        if ($currentRank -gt $deployedRank) {
            # e.g. alpha → beta, beta → stable
            $updateNeeded = $true
        }
        elseif ($currentRank -eq $deployedRank -and $deployedRank -lt 3) {
            # Same pre-release type — compare the sequence number.
            # A label with no trailing number (e.g. 'beta') is treated as 1.
            $deployedNum = if ($deployedVersion -match "$deployedLabel(\d+)") { [int]$Matches[1] } else { 1 }
            $currentNum  = if ($currentVersion  -match "$currentLabel(\d+)")  { [int]$Matches[1] } else { 1 }
            $updateNeeded = $currentNum -gt $deployedNum
        }
        else {
            $updateNeeded = $false
        }
    }
    else {
        $updateNeeded = $false
    }
    $object = [PSCustomObject]@{ 
        DeployedVersion = $deployedVersion
        AvailableVersion = $currentVersion
        UpdateNeeded= $updateNeeded
        ReportTime = $ReportTime
    }
    $JSON = ConvertTo-Json -inputObject $object

    Send-GuardrailsData -Data $JSON -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $workspaceKey 
}

function get-itsgdata {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $URL,
        [Parameter(Mandatory = $true)]
        [string] $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string] $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string] $LogType = "GRITSGControls",
        [Parameter(Mandatory = $false)]
        [switch] $DebugCode
    )
    (Invoke-WebRequest -UseBasicParsing $URL).Content | out-file tempitsg.csv
    $Header = "Family", "Control ID", "Enhancement", "Name", "Class", "Definition", "Supplemental Guidance,References"
    $itsgtempinfo = Import-Csv ./tempitsg.csv -Header $Header
    $itsginfo = $itsgtempinfo | Select-Object Name, Definition, @{Name = "itsgcode"; Expression = { ($_.Family + $_."Control ID" + $_.Enhancement).replace("`t", "") } }
    $JSONcontrols = ConvertTo-Json -inputObject $itsginfo
    
    if ($DebugCode) {
        $JSONcontrols
    }

    Send-GuardrailsData -Data $JSONcontrols -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $workspaceKey
}

function Get-GuardrailsAutomationVariableValue {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Name
    )

    if (Get-Command -Name Get-GSAAutomationVariable -ErrorAction SilentlyContinue) {
        try {
            $value = Get-GSAAutomationVariable -Name $Name -ErrorAction SilentlyContinue
            if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
                return $value
            }
        }
        catch {
            Write-Warning "Unable to read Automation variable '$Name'. Falling back to process environment variables where available. Error: $($_.Exception.Message)"
        }
    }

    return [System.Environment]::GetEnvironmentVariable($Name)
}

function Get-GuardrailsResourceGroupName {
    [CmdletBinding()]
    param ()

    foreach ($name in @('ResourceGroupName', 'ResourceGroup', 'resourceGroup')) {
        $envValue = [System.Environment]::GetEnvironmentVariable($name)
        if (-not [string]::IsNullOrWhiteSpace([string]$envValue)) {
            return $envValue
        }
    }

    foreach ($name in @('ResourceGroupName', 'ResourceGroup', 'resourceGroup')) {
        $value = Get-GuardrailsAutomationVariableValue -Name $name
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            return $value
        }
    }

    throw "DCR runtime resolution failed: Guardrails resource group could not be determined from ResourceGroupName, ResourceGroup, or resourceGroup. Verify the Automation variable or process environment is set."
}

function Get-GuardrailsSubscriptionId {
    [CmdletBinding()]
    param ()

    foreach ($name in @('subscriptionId', 'SubscriptionId')) {
        $envValue = [System.Environment]::GetEnvironmentVariable($name)
        if (-not [string]::IsNullOrWhiteSpace([string]$envValue)) {
            return $envValue
        }
    }

    foreach ($name in @('subscriptionId', 'SubscriptionId')) {
        $value = Get-GuardrailsAutomationVariableValue -Name $name
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            return $value
        }
    }

    $context = Get-AzContext
    if ($context -and $context.Subscription -and -not [string]::IsNullOrWhiteSpace($context.Subscription.Id)) {
        return $context.Subscription.Id
    }

    throw "DCR runtime resolution failed: no Guardrails subscription ID or Azure context is available. Verify the runbook loaded gsaConfigExportLatest and connected with managed identity before ingestion."
}

function Invoke-GuardrailsArmGet {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Path,
        [Parameter(Mandatory = $true)]
        [string] $ResourceName,
        [Parameter(Mandatory = $true)]
        [string] $ResourceType,
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName
    )

    $retryDelaysInSeconds = @(15, 30, 60, 120)
    for ($attempt = 1; $attempt -le ($retryDelaysInSeconds.Count + 1); $attempt++) {
        $statusCode = $null
        $responseText = $null
        try {
            $response = Invoke-AzRestMethod -Method GET -Path $Path -ErrorAction Stop
            $statusCode = ConvertTo-GuardrailsHttpStatusCode -StatusCode $response.StatusCode
            $responseText = $response.Content
        }
        catch {
            $message = $_.Exception.Message
            if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
                $message = $_.ErrorDetails.Message
            }

            $exceptionStatusCode = $_.Exception.PSObject.Properties['StatusCode']
            if ($exceptionStatusCode -and $null -ne $exceptionStatusCode.Value) {
                $statusCode = ConvertTo-GuardrailsHttpStatusCode -StatusCode $exceptionStatusCode.Value
            }
            elseif ($_.Exception.Response -and $null -ne $_.Exception.Response.StatusCode) {
                $statusCode = ConvertTo-GuardrailsHttpStatusCode -StatusCode $_.Exception.Response.StatusCode
            }
            elseif ($_.Exception.InnerException -and $_.Exception.InnerException.Response -and $null -ne $_.Exception.InnerException.Response.StatusCode) {
                $statusCode = ConvertTo-GuardrailsHttpStatusCode -StatusCode $_.Exception.InnerException.Response.StatusCode
            }

            $responseText = $message

            if ($statusCode -ne 401 -and $statusCode -ne 403) {
                throw "DCR runtime resolution failed while calling Azure Resource Manager for $ResourceType '$ResourceName' in resource group '$ResourceGroupName'. Original error: $message"
            }
        }

        if ($statusCode -ge 200 -and $statusCode -lt 300) {
            try {
                return $responseText | ConvertFrom-Json -Depth 20
            }
            catch {
                throw "DCR runtime resolution failed: Azure Resource Manager returned invalid JSON for $ResourceType '$ResourceName' in resource group '$ResourceGroupName'. Original error: $($_.Exception.Message)"
            }
        }

        if ($statusCode -eq 401 -or $statusCode -eq 403) {
            $isLastAttempt = $attempt -gt $retryDelaysInSeconds.Count
            if ($isLastAttempt) {
                throw "DCR runtime resolution failed: the runbook identity cannot read $ResourceType '$ResourceName' in resource group '$ResourceGroupName'. Required permissions include Microsoft.Insights/dataCollectionRules/read on the Guardrails resource group or a parent scope. StatusCode=$statusCode. Response: $responseText"
            }

            $retryDelayInSeconds = $retryDelaysInSeconds[$attempt - 1]
            Write-Warning "DCR runtime resolution: ARM read for $ResourceType '$ResourceName' returned StatusCode=$statusCode on attempt $attempt of $($retryDelaysInSeconds.Count + 1). This can happen while RBAC assignments propagate after deployment. Waiting $retryDelayInSeconds seconds before retrying."
            Start-Sleep -Seconds $retryDelayInSeconds
            continue
        }

        if ($statusCode -eq 404) {
            throw "DCR runtime resolution failed: $ResourceType '$ResourceName' was not found in resource group '$ResourceGroupName'. Rerun core deployment or verify the Guardrails resource group and DCR resources. StatusCode=$statusCode. Response: $responseText"
        }

        throw "DCR runtime resolution failed while reading $ResourceType '$ResourceName' in resource group '$ResourceGroupName'. StatusCode=$statusCode. Response: $responseText"
    }
}

function Get-GuardrailsDcrIngestionSettings {
    [CmdletBinding()]
    param ()

    if ($script:GuardrailsDcrIngestionSettings) {
        return $script:GuardrailsDcrIngestionSettings
    }

    $resourceGroupName = Get-GuardrailsResourceGroupName
    $subscriptionId = Get-GuardrailsSubscriptionId
    $basePath = "/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.Insights"

    Write-Host "DCR runtime resolution: resolving DCR resources from Azure Resource Manager. ResourceGroup='$resourceGroupName', SubscriptionId='$subscriptionId'."

    $dcr = Invoke-GuardrailsArmGet -Path "$basePath/dataCollectionRules/guardrails-dcr?api-version=2024-03-11" -ResourceName 'guardrails-dcr' -ResourceType 'DCR' -ResourceGroupName $resourceGroupName
    $dcr2 = Invoke-GuardrailsArmGet -Path "$basePath/dataCollectionRules/guardrails-dcr-2?api-version=2024-03-11" -ResourceName 'guardrails-dcr-2' -ResourceType 'DCR' -ResourceGroupName $resourceGroupName

    $dcrEndpoint = $dcr.properties.endpoints.logsIngestion
    $dcr2Endpoint = $dcr2.properties.endpoints.logsIngestion
    $dcrImmutableId = $dcr.properties.immutableId
    $dcrImmutableId2 = $dcr2.properties.immutableId

    if ([string]::IsNullOrWhiteSpace([string]$dcrEndpoint)) {
        throw "DCR runtime resolution failed: DCR 'guardrails-dcr' did not return properties.endpoints.logsIngestion. Verify core deployment completed successfully."
    }
    if ([string]::IsNullOrWhiteSpace([string]$dcr2Endpoint)) {
        throw "DCR runtime resolution failed: DCR 'guardrails-dcr-2' did not return properties.endpoints.logsIngestion. Verify core deployment completed successfully."
    }
    if ([string]::IsNullOrWhiteSpace([string]$dcrImmutableId)) {
        throw "DCR runtime resolution failed: DCR 'guardrails-dcr' did not return properties.immutableId. Verify core deployment completed successfully."
    }
    if ([string]::IsNullOrWhiteSpace([string]$dcrImmutableId2)) {
        throw "DCR runtime resolution failed: DCR 'guardrails-dcr-2' did not return properties.immutableId. Verify core deployment completed successfully."
    }

    $dcrEndpointHost = $dcrEndpoint
    $dcr2EndpointHost = $dcr2Endpoint
    try { $dcrEndpointHost = ([System.Uri]$dcrEndpoint).Host } catch { }
    try { $dcr2EndpointHost = ([System.Uri]$dcr2Endpoint).Host } catch { }

    Write-Host "DCR runtime resolution succeeded: DCR1='guardrails-dcr', DCR1 endpoint host='$dcrEndpointHost', DCR1 immutable ID='$dcrImmutableId', DCR2='guardrails-dcr-2', DCR2 endpoint host='$dcr2EndpointHost', DCR2 immutable ID='$dcrImmutableId2'."

    # Cache only after every ARM read and validation succeeds; failed resolution should retry cleanly.
    $script:GuardrailsDcrIngestionSettings = [PSCustomObject]@{
        DcrImmutableId       = $dcrImmutableId
        DcrImmutableId2      = $dcrImmutableId2
        DcrLogsEndpoint      = ([string]$dcrEndpoint).TrimEnd('/')
        Dcr2LogsEndpoint     = ([string]$dcr2Endpoint).TrimEnd('/')
        ResourceGroupName    = $resourceGroupName
        SubscriptionId       = $subscriptionId
    }

    return $script:GuardrailsDcrIngestionSettings
}

function Get-GuardrailsDcrStreamName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $LogType
    )

    switch ($LogType) {
        'GuardrailsCompliance' { 'Custom-GuardrailsCompliance' }
        'GuardrailsComplianceException' { 'Custom-GuardrailsComplianceException' }
        'GR_TenantInfo' { 'Custom-GR_TenantInfo' }
        'GR_Results' { 'Custom-GR_Results' }
        'GR_VersionInfo' { 'Custom-GR_VersionInfo' }
        'GRITSGControls' { 'Custom-GRITSGControls' }
        'GuardrailsTenantsCompliance' { 'Custom-GuardrailsTenantsCompliance' }
        'CaCDebugMetrics' { 'Custom-CaCDebugMetrics' }
        'GuardrailsUserRaw' { 'Custom-GuardrailsUserRaw' }
        'GuardrailsCrossTenantAccess' { 'Custom-GuardrailsCrossTenantAccess' }
        'GR2UsersWithoutGroups' { 'Custom-GR2UsersWithoutGroups' }
        'GR2ExternalUsers' { 'Custom-GR2ExternalUsers' }
        default { "Custom-$LogType" }
    }
}

function Resolve-GuardrailsDcrTarget {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $LogType
    )

    $settings = Get-GuardrailsDcrIngestionSettings
    $streamName = Get-GuardrailsDcrStreamName -LogType $LogType
    $usesDcr2 = $LogType -in @('GR2UsersWithoutGroups', 'GR2ExternalUsers')
    $dcrId = if ($usesDcr2) { $settings.DcrImmutableId2 } else { $settings.DcrImmutableId }
    $logsIngestionEndpoint = if ($usesDcr2) { $settings.Dcr2LogsEndpoint } else { $settings.DcrLogsEndpoint }

    [PSCustomObject]@{
        LogsIngestionEndpoint = $logsIngestionEndpoint
        DcrId                 = $dcrId
        StreamName            = $streamName
        UsesDcr2              = $usesDcr2
    }
}

function Get-GuardrailsDcrResponseText {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord
    )

    if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
        return $ErrorRecord.ErrorDetails.Message
    }

    $response = $ErrorRecord.Exception.Response
    if (-not $response) {
        return $ErrorRecord.Exception.Message
    }

    try {
        $stream = $response.GetResponseStream()
        if ($stream) {
            $reader = [System.IO.StreamReader]::new($stream)
            $body = $reader.ReadToEnd()
            if (-not [string]::IsNullOrWhiteSpace($body)) {
                return $body
            }
        }
    }
    catch { }

    return $ErrorRecord.Exception.Message
}

function ConvertTo-GuardrailsHttpStatusCode {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [object] $StatusCode
    )

    if ($StatusCode -is [int]) {
        return $StatusCode
    }

    try {
        return [int]$StatusCode
    }
    catch {
        switch ([string]$StatusCode) {
            'OK' { return 200 }
            'Created' { return 201 }
            'Accepted' { return 202 }
            'NoContent' { return 204 }
            'BadRequest' { return 400 }
            'Unauthorized' { return 401 }
            'Forbidden' { return 403 }
            'NotFound' { return 404 }
            default { return $null }
        }
    }
}

function Get-GuardrailsDcrStatusCode {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord
    )

    $response = $ErrorRecord.Exception.Response
    if ($response -and $null -ne $response.StatusCode) {
        return ConvertTo-GuardrailsHttpStatusCode -StatusCode $response.StatusCode
    }

    $exceptionStatusCode = $ErrorRecord.Exception.PSObject.Properties['StatusCode']
    if ($exceptionStatusCode -and $null -ne $exceptionStatusCode.Value) {
        return ConvertTo-GuardrailsHttpStatusCode -StatusCode $exceptionStatusCode.Value
    }

    return $null
}

function New-GuardrailsDcrUploadErrorMessage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord,
        [Parameter(Mandatory = $true)]
        [object] $Target,
        [Parameter(Mandatory = $true)]
        [string] $LogType
    )

    $statusCode = Get-GuardrailsDcrStatusCode -ErrorRecord $ErrorRecord
    $responseText = Get-GuardrailsDcrResponseText -ErrorRecord $ErrorRecord
    $endpointHost = $Target.LogsIngestionEndpoint
    try { $endpointHost = ([System.Uri]$Target.LogsIngestionEndpoint).Host } catch { }

    $message = "Data Collection API failed for LogType '$LogType' using stream '$($Target.StreamName)', DCR immutable ID '$($Target.DcrId)', and DCR logs ingestion endpoint '$endpointHost'."

    if ($statusCode -eq 404 -or $responseText -match 'Data collection rule with immutable Id .* not found') {
        $message += " Azure Monitor could not find the resolved DCR immutable ID. Verify guardrails-dcr and guardrails-dcr-2 exist in the Guardrails resource group and were not recreated during this run."
    }
    elseif ($statusCode -eq 401 -or $statusCode -eq 403) {
        $message += " Verify the runbook identity can request a monitor.azure.com token and has Monitoring Metrics Publisher on the target DCR."
    }
    elseif ($statusCode -eq 400) {
        $message += " Verify the DCR stream declaration, transform, payload shape, and Log Analytics table schema for this LogType."
    }

    if (-not [string]::IsNullOrWhiteSpace($responseText)) {
        $message += " Original error: $responseText"
    }

    return $message
}

function Test-GuardrailsDcrImmutableIdNotFoundError {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord
    )

    $responseText = Get-GuardrailsDcrResponseText -ErrorRecord $ErrorRecord
    $statusCode = Get-GuardrailsDcrStatusCode -ErrorRecord $ErrorRecord
    return $statusCode -eq 404 -and ($responseText -match 'Data collection rule with immutable Id .* not found')
}

function Test-GuardrailsDcrUploadAuthorizationError {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord] $ErrorRecord
    )

    $statusCode = Get-GuardrailsDcrStatusCode -ErrorRecord $ErrorRecord
    return $statusCode -eq 401 -or $statusCode -eq 403
}

function Clear-GuardrailsDcrIngestionSettingsCache {
    [CmdletBinding()]
    param ()

    $script:GuardrailsDcrIngestionSettings = $null
}

function Get-GuardrailsCachedDcrUploadFailure {
    [CmdletBinding()]
    param ()

    if ([string]::IsNullOrWhiteSpace($script:GuardrailsDcrUploadFailureMessage)) {
        return $null
    }

    return $script:GuardrailsDcrUploadFailureMessage
}

function Set-GuardrailsCachedDcrUploadFailure {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Message
    )

    $script:GuardrailsDcrUploadFailureMessage = $Message
}

function Send-GuardrailsData {
    <#
    .SYNOPSIS
    Sends data to Azure Monitor Log Analytics using DCR-based Log Ingestion API.
    
    .DESCRIPTION
    This function replaces the deprecated Data Collector API with the modern DCR-based Log Ingestion API.
    It resolves the current Guardrails DCR resources from Azure Resource Manager once per runbook job and caches the result in-process.
    
    .PARAMETER Data
    JSON string containing the data to send to Log Analytics.
    
    .PARAMETER LogType
    The log type (table name) to send data to. This will be mapped to a DCR stream name.
    
    .PARAMETER WorkSpaceID
    Optional workspace ID for backward compatibility (not used by DCR API but kept for compatibility).
    
    .PARAMETER WorkSpaceKey
    Optional workspace key for backward compatibility (not used by DCR API but kept for compatibility).
    
    .EXAMPLE
    Send-GuardrailsData -Data $jsonData -LogType "GuardrailsCompliance"
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $Data,
        
        [Parameter(Mandatory = $true)]
        [string]
        $LogType,
        
        [Parameter(Mandatory = $false)]
        [string]
        $WorkSpaceID,
        
        [Parameter(Mandatory = $false)]
        [string]
        $WorkSpaceKey
    )

    # DCR Log Ingestion API requires a JSON array body. Wrap single objects automatically
    # so callers that send a single PSCustomObject via ConvertTo-Json still work correctly.
    if ($Data.Trim().StartsWith('{')) {
        $Data = "[$Data]"
    }

    if ([string]::IsNullOrWhiteSpace($Data) -or $Data.Trim() -eq '[]') {
        Write-Warning "Send-GuardrailsData: empty payload for '$LogType', skipping."
        return
    }

    $cachedDcrUploadFailure = Get-GuardrailsCachedDcrUploadFailure
    if ($cachedDcrUploadFailure) {
        throw "Data Collection API skipped for LogType '$LogType' because a previous DCR upload exhausted its retry budget in this runbook job. Previous failure: $cachedDcrUploadFailure"
    }

    # Per API docs, encode the body explicitly as UTF-8 to prevent data transmission issues.
    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($Data)

    # The DCR ingestion endpoint rejects payloads over 1 MB. Large tenants (e.g. 18K+ users)
    # can easily blow past this with a single page of results, so we split proactively at 900 KB
    # to leave a bit of room.
    $maxBytesPerRequest = 900 * 1024

    if ($bodyBytes.Length -gt $maxBytesPerRequest) {
        Write-Warning "Send-GuardrailsData: payload for '$LogType' is $($bodyBytes.Length) bytes, which exceeds the DCR ingestion limit of 1 MB. Splitting into sub-1 MB chunks."

        $records = $Data | ConvertFrom-Json -Depth 20
        if ($records -isnot [array]) { $records = @($records) }

        # Compact-serialize each record once up front. Using the same strings for both the
        # size check and the final payload means what we measure is exactly what we send.
        $serializedRecords = @($records | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 20 -Compress })

        $chunks  = [System.Collections.Generic.List[string[]]]::new()
        $current = [System.Collections.Generic.List[string]]::new()
        $currentBytes = 2  # opening '[' + closing ']'

        foreach ($recordJson in $serializedRecords) {
            $recordBytes = [System.Text.Encoding]::UTF8.GetByteCount($recordJson)
            $commaBytes  = if ($current.Count -gt 0) { 1 } else { 0 }

            if (($currentBytes + $recordBytes + $commaBytes) -gt $maxBytesPerRequest -and $current.Count -gt 0) {
                $chunks.Add($current.ToArray())
                $current = [System.Collections.Generic.List[string]]::new()
                $currentBytes = 2
                $commaBytes = 0
            }

            $current.Add($recordJson)
            $currentBytes += $recordBytes + $commaBytes
        }

        if ($current.Count -gt 0) { $chunks.Add($current.ToArray()) }

        Write-Verbose "Send-GuardrailsData: split '$LogType' payload into $($chunks.Count) chunk(s) for DCR ingestion."

        foreach ($chunk in $chunks) {
            $chunkJson = '[' + ($chunk -join ',') + ']'
            Send-GuardrailsData -Data $chunkJson -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $WorkSpaceKey
        }
        return
    }

    $retryDelaysInSeconds = @(30, 60, 120)

    for ($attempt = 1; $attempt -le ($retryDelaysInSeconds.Count + 1); $attempt++) {
        $target = $null
        try {
            $target = Resolve-GuardrailsDcrTarget -LogType $LogType
            $uri = "$($target.LogsIngestionEndpoint)/dataCollectionRules/$($target.DcrId)/streams/$($target.StreamName)" + "?api-version=2023-01-01"

            # Invoke-AzRestMethod cannot determine the authentication audience for DCR ingestion endpoints
            # (*.ingest.monitor.azure.com is not an ARM endpoint). Explicitly request a token for
            # the Azure Monitor audience (no trailing slash per API docs) using Invoke-RestMethod.
            # The PowerShell 7.6 migration also upgrades the Runtime Environment's Az modules.
            # Use their secure token path instead of converting the token back to plain text for this request.
            # This changes token handling only; the Log Analytics upload and retry behavior are unchanged.
            # ErrorAction Stop sends token failures into this operation's retry handling.
            $monitorToken = (Get-AzAccessToken -ResourceUrl 'https://monitor.azure.com' -AsSecureString -ErrorAction Stop).Token

            $headers = @{
                'x-ms-client-request-id' = [System.Guid]::NewGuid().ToString()
            }

            # Pass the secure token directly to PowerShell; ContentType identifies the JSON body.
            # Invoke-RestMethod throws on 4xx/5xx so the existing retry handling can decide whether to try again.
            Invoke-RestMethod -Uri $uri -Method POST -Authentication Bearer -Token $monitorToken -ContentType 'application/json' -Headers $headers -Body $bodyBytes -ErrorAction Stop | Out-Null

            Write-Verbose "Successfully sent data to Log Analytics table '$LogType' via DCR stream '$($target.StreamName)' ($($bodyBytes.Length) bytes)"
            return
        }
        catch {
            $isDcrPropagationError = $target -and (Test-GuardrailsDcrImmutableIdNotFoundError -ErrorRecord $_)
            $isDcrAuthorizationError = $target -and (Test-GuardrailsDcrUploadAuthorizationError -ErrorRecord $_)
            $hasRetryBudget = $attempt -le $retryDelaysInSeconds.Count

            if ($isDcrPropagationError -and $hasRetryBudget) {
                $delayInSeconds = $retryDelaysInSeconds[$attempt - 1]
                $maxAttempts = $retryDelaysInSeconds.Count + 1
                Write-Warning "DCR ingestion endpoint does not know resolved DCR immutable ID '$($target.DcrId)' yet for LogType '$LogType' and stream '$($target.StreamName)' on attempt $attempt of $maxAttempts. Clearing DCR cache, waiting $delayInSeconds seconds, and re-resolving current DCR resources."
                Clear-GuardrailsDcrIngestionSettingsCache
                Start-Sleep -Seconds $delayInSeconds
                continue
            }

            if ($isDcrAuthorizationError -and $hasRetryBudget) {
                $delayInSeconds = $retryDelaysInSeconds[$attempt - 1]
                $maxAttempts = $retryDelaysInSeconds.Count + 1
                $statusCode = Get-GuardrailsDcrStatusCode -ErrorRecord $_
                Write-Warning "DCR ingestion authorization failed with StatusCode=$statusCode for LogType '$LogType' and stream '$($target.StreamName)' on attempt $attempt of $maxAttempts. This can happen while Monitoring Metrics Publisher propagates after deployment. Waiting $delayInSeconds seconds before retrying."
                Start-Sleep -Seconds $delayInSeconds
                continue
            }

            if ($target) {
                $uploadErrorMessage = New-GuardrailsDcrUploadErrorMessage -ErrorRecord $_ -Target $target -LogType $LogType
                if ($isDcrPropagationError -or $isDcrAuthorizationError) {
                    Set-GuardrailsCachedDcrUploadFailure -Message $uploadErrorMessage
                }
                throw $uploadErrorMessage
            }

            throw "Data Collection API failed before upload target was resolved for LogType '$LogType': $($_.Exception.Message)"
        }
    }
}

function New-LogAnalyticsData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [array] 
        $Data,
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceKey,
        [Parameter(Mandatory = $true)]
        [string]
        $LogType
    )
    $JsonObject = convertTo-Json -inputObject $Data -Depth 3

    Send-GuardrailsData -Data $JsonObject -LogType $LogType -WorkSpaceID $WorkSpaceID -WorkSpaceKey $WorkSpaceKey
}

function Hide-Email {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$email
    )

    $parts = $email -split '@'
    if ($parts.Length -eq 2) {
        $username = $parts[0]
        $domain = $parts[1]

        $hiddenUsername = $username[0] + ($username.Substring(1, $username.Length - 2) -replace '.', '#') + $username[-1]
        $hiddenDomain = $domain[0] + ($domain.Substring(1, $domain.Length - 5) -replace '.', '#') + $domain[-4] + $domain[-3] + $domain[-2] + $domain[-1]

        $hiddenEmail = "$hiddenUsername@$hiddenDomain"
        return $hiddenEmail
    } else {
        return "Invalid email format"
    }
}

#region Guardrail Telemetry Helpers

function Initialize-GuardrailTelemetry {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$GuardrailId,
        [Parameter(Mandatory = $true)]
        [string]$RunbookName,
        [Parameter(Mandatory = $true)]
        [string]$WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]$WorkspaceKey,
        [Parameter(Mandatory = $false)]
        [string]$SubscriptionId,
        [Parameter(Mandatory = $false)]
        [string]$TenantId,
        [Parameter(Mandatory = $false)]
        [string]$JobId,
        [Parameter(Mandatory = $false)]
        [string]$CorrelationId
    )

    $telemetryEnabled = $false
    if ($env:ENABLE_DEBUG_METRICS) {
        $telemetryEnabled = [string]::Equals($env:ENABLE_DEBUG_METRICS, 'true', [System.StringComparison]::InvariantCultureIgnoreCase)
    }

    if (-not $telemetryEnabled) {
        return [pscustomobject]@{ Enabled = $false }
    }

    if ([string]::IsNullOrWhiteSpace($WorkSpaceID) -or [string]::IsNullOrWhiteSpace($WorkspaceKey)) {
        Write-Verbose "Guardrail telemetry disabled due to missing workspace configuration."
        return [pscustomobject]@{ Enabled = $false }
    }

    if (-not $CorrelationId) {
        $CorrelationId = [guid]::NewGuid().ToString()
    }

    return [pscustomobject]@{
        Enabled        = $true
        GuardrailId    = $GuardrailId
        RunbookName    = $RunbookName
        WorkspaceId    = $WorkSpaceID
        WorkspaceKey   = $WorkspaceKey
        SubscriptionId = $SubscriptionId
        TenantId       = $TenantId
        JobId          = $JobId
        CorrelationId  = $CorrelationId
        DurationColumnInitialized = $false
    }
}

# Returns the current PowerShell worker memory usage in MB (rounded to two decimals).
function Get-GuardrailProcessMemory {
    [CmdletBinding()]
    param ()

    $process = [System.Diagnostics.Process]::GetCurrentProcess()
    try {
        $workingSetMb = [Math]::Round(($process.WorkingSet64 / 1MB), 2)
        $peakWorkingSetMb = [Math]::Round(($process.PeakWorkingSet64 / 1MB), 2)

        return [pscustomobject]@{
            WorkingSetMb     = $workingSetMb
            PeakWorkingSetMb = $peakWorkingSetMb
        }
    }
    finally {
        $process.Dispose()
    }
}

function Update-RunStateMemoryStats {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$RunState,
        [Parameter(Mandatory = $true)]
        [psobject]$CurrentSnapshot
    )

    $RunState.Stats.MemoryEndMb = $CurrentSnapshot.WorkingSetMb
    if ($CurrentSnapshot.PeakWorkingSetMb -gt $RunState.Stats.MemoryPeakMb) {
        $RunState.Stats.MemoryPeakMb = $CurrentSnapshot.PeakWorkingSetMb
    }
    $RunState.Stats.MemoryDeltaMb = [Math]::Round(($RunState.Stats.MemoryEndMb - $RunState.Stats.MemoryStartMb), 2)
}

function Write-GuardrailTelemetry {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$Context,
        [Parameter(Mandatory = $true)]
        [string]$ExecutionScope,
        [Parameter(Mandatory = $true)]
        [string]$EventType,
        [Parameter(Mandatory = $false)]
        [string]$ModuleName,
        [Parameter(Mandatory = $false)]
        [Nullable[double]]$DurationMs,
        [Parameter(Mandatory = $false)]
        [double]$ErrorCount,
        [Parameter(Mandatory = $false)]
        [double]$ItemCount,
        [Parameter(Mandatory = $false)]
        [double]$CompliantCount,
        [Parameter(Mandatory = $false)]
        [double]$NonCompliantCount,
        [Parameter(Mandatory = $false)]
        [string]$Message,
        [Parameter(Mandatory = $false)]
        [string]$ReportTime,
        [Parameter(Mandatory = $false)]
        [string]$GuardrailIdOverride,
        [Parameter(Mandatory = $false)]
        [Nullable[double]]$MemoryStartMb,
        [Parameter(Mandatory = $false)]
        [Nullable[double]]$MemoryEndMb,
        [Parameter(Mandatory = $false)]
        [Nullable[double]]$MemoryPeakMb,
        [Parameter(Mandatory = $false)]
        [Nullable[double]]$MemoryDeltaMb
    )

    if (-not $Context -or -not $Context.Enabled) {
        return
    }

    try {
        $record = [ordered]@{
            GuardrailId        = if (-not [string]::IsNullOrWhiteSpace($GuardrailIdOverride)) { $GuardrailIdOverride } else { $Context.GuardrailId }
            RunbookName        = $Context.RunbookName
            ModuleName         = $ModuleName
            ExecutionScope     = $ExecutionScope
            EventType          = $EventType
            CorrelationId      = [string]$Context.CorrelationId
            JobId              = [string]$Context.JobId
            RunSubscriptionId  = [string]$Context.SubscriptionId
            RunTenantId        = [string]$Context.TenantId
            ErrorCount         = if ($null -ne $ErrorCount) { [double]$ErrorCount } else { 0d }
            ItemCount          = if ($null -ne $ItemCount) { [double]$ItemCount } else { 0d }
            CompliantCount     = if ($null -ne $CompliantCount) { [double]$CompliantCount } else { 0d }
            NonCompliantCount  = if ($null -ne $NonCompliantCount) { [double]$NonCompliantCount } else { 0d }
            ReportTime         = if ($ReportTime) { $ReportTime } else { $null }
            Message            = if (-not [string]::IsNullOrWhiteSpace($Message)) { $Message } else { $null }
        }

        $hasDurationValue = $PSBoundParameters.ContainsKey('DurationMs') -and $null -ne $DurationMs

        if ($hasDurationValue) {
            $durationRounded = [double][Math]::Round($DurationMs, 2)
            $record['DurationMsReal'] = $durationRounded
            $Context.DurationColumnInitialized = $true
        }
        elseif (-not $Context.DurationColumnInitialized) {
            # LAW infers DurationMsReal as string when the first ingested
            # record omits duration. Seed with a tiny double to force the column type once.
            $record['DurationMsReal'] = [double]0.01
            $Context.DurationColumnInitialized = $true
        }

        if ($PSBoundParameters.ContainsKey('MemoryStartMb') -and $null -ne $MemoryStartMb) {
            $record['MemoryStartMb'] = [double][Math]::Round($MemoryStartMb, 2)
        }
        if ($PSBoundParameters.ContainsKey('MemoryEndMb') -and $null -ne $MemoryEndMb) {
            $record['MemoryEndMb'] = [double][Math]::Round($MemoryEndMb, 2)
        }
        if ($PSBoundParameters.ContainsKey('MemoryPeakMb') -and $null -ne $MemoryPeakMb) {
            $record['MemoryPeakMb'] = [double][Math]::Round($MemoryPeakMb, 2)
        }
        if ($PSBoundParameters.ContainsKey('MemoryDeltaMb') -and $null -ne $MemoryDeltaMb) {
            $record['MemoryDeltaMb'] = [double][Math]::Round($MemoryDeltaMb, 2)
        }

        $data = @([pscustomobject]$record)
        New-LogAnalyticsData -Data $data -WorkSpaceID $Context.WorkspaceId -WorkSpaceKey $Context.WorkspaceKey -LogType 'CaCDebugMetrics' | Out-Null
    }
    catch {
        Write-Verbose "Failed to write guardrail telemetry: $_"
    }
}

function New-GuardrailRunState {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$GuardrailId,
        [Parameter(Mandatory = $true)]
        [string]$RunbookName,
        [Parameter(Mandatory = $true)]
        [string]$WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]$WorkspaceKey,
        [Parameter(Mandatory = $false)]
        [string]$SubscriptionId,
        [Parameter(Mandatory = $false)]
        [string]$TenantId,
        [Parameter(Mandatory = $false)]
        [string]$JobId,
        [Parameter(Mandatory = $false)]
        [string]$ReportTime
    )

    $telemetryContext = Initialize-GuardrailTelemetry -GuardrailId $GuardrailId -RunbookName $RunbookName -WorkSpaceID $WorkSpaceID -WorkspaceKey $WorkspaceKey -SubscriptionId $SubscriptionId -TenantId $TenantId -JobId $JobId -CorrelationId $null

    $runState = [pscustomobject]@{
        TelemetryContext = $telemetryContext
        ReportTime       = $ReportTime
        RunStopwatch     = [System.Diagnostics.Stopwatch]::StartNew()
        Stats            = [ordered]@{
            ModulesEnabled    = 0
            ModulesDisabled   = 0
            TotalItems        = 0
            CompliantItems    = 0
            NonCompliantItems = 0
            Errors            = 0
            MemoryStartMb     = 0
            MemoryEndMb       = 0
            MemoryPeakMb      = 0
            MemoryDeltaMb     = 0
        }
        Summaries        = [System.Collections.Generic.List[psobject]]::new()
    }

    $initialMemory = Get-GuardrailProcessMemory
    $runState.Stats.MemoryStartMb = $initialMemory.WorkingSetMb
    Update-RunStateMemoryStats -RunState $runState -CurrentSnapshot $initialMemory

    Write-GuardrailTelemetry -Context $telemetryContext -ExecutionScope 'Runbook' -ModuleName 'RUNBOOK' -EventType 'Start' -ReportTime $ReportTime -MemoryStartMb $initialMemory.WorkingSetMb -MemoryPeakMb $initialMemory.PeakWorkingSetMb

    return $runState
}

function Start-GuardrailModuleState {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$RunState,
        [Parameter(Mandatory = $true)]
        [string]$ModuleName,
        [Parameter(Mandatory = $false)]
        [string]$GuardrailId
    )

    $RunState.Stats.ModulesEnabled++

    $memorySnapshot = Get-GuardrailProcessMemory
    Update-RunStateMemoryStats -RunState $RunState -CurrentSnapshot $memorySnapshot

    $moduleState = [pscustomobject]@{
        ModuleName        = $ModuleName
        Stopwatch         = [System.Diagnostics.Stopwatch]::StartNew()
        GuardrailId       = $GuardrailId
        MemoryStartMb     = $memorySnapshot.WorkingSetMb
        MemoryStartPeakMb = $memorySnapshot.PeakWorkingSetMb
    }

    Write-GuardrailTelemetry -Context $RunState.TelemetryContext -ExecutionScope 'Module' -ModuleName $ModuleName -EventType 'Start' -ReportTime $RunState.ReportTime -GuardrailIdOverride $GuardrailId -MemoryStartMb $memorySnapshot.WorkingSetMb -MemoryPeakMb $memorySnapshot.PeakWorkingSetMb

    return $moduleState
}

function Complete-GuardrailModuleState {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$RunState,
        [Parameter(Mandatory = $true)]
        [psobject]$ModuleState,
        [Parameter(Mandatory = $false)]
        [int]$ErrorCount = 0,
        [Parameter(Mandatory = $false)]
        [int]$ItemCount = 0,
        [Parameter(Mandatory = $false)]
        [int]$CompliantCount = 0,
        [Parameter(Mandatory = $false)]
        [int]$NonCompliantCount = 0,
        [Parameter(Mandatory = $false)]
        [string]$Message
    )

    if ($ModuleState.Stopwatch -and $ModuleState.Stopwatch.IsRunning) {
        $ModuleState.Stopwatch.Stop()
    }

    $durationMs = $null
    if ($ModuleState.Stopwatch) {
        $durationMs = $ModuleState.Stopwatch.Elapsed.TotalMilliseconds
    }

    $RunState.Stats.Errors += $ErrorCount
    $RunState.Stats.TotalItems += $ItemCount
    $RunState.Stats.CompliantItems += $CompliantCount
    $RunState.Stats.NonCompliantItems += $NonCompliantCount

    if (-not $Message) {
        $parts = @("Items=$ItemCount")
        if ($ErrorCount -gt 0) { $parts += "Errors=$ErrorCount" }
        $Message = $parts -join '; '
    }

    $memoryEnd = Get-GuardrailProcessMemory
    $memoryStartMb = if ($ModuleState.PSObject.Properties.Match('MemoryStartMb').Count -gt 0) { $ModuleState.MemoryStartMb } else { $memoryEnd.WorkingSetMb }
    $memoryStartPeakMb = if ($ModuleState.PSObject.Properties.Match('MemoryStartPeakMb').Count -gt 0) { $ModuleState.MemoryStartPeakMb } else { $memoryEnd.PeakWorkingSetMb }
    $modulePeakMb = [Math]::Round(([Math]::Max($memoryEnd.PeakWorkingSetMb, $memoryStartPeakMb)), 2)
    $memoryDeltaMb = [Math]::Round(($memoryEnd.WorkingSetMb - $memoryStartMb), 2)

    Update-RunStateMemoryStats -RunState $RunState -CurrentSnapshot $memoryEnd

    Write-GuardrailTelemetry -Context $RunState.TelemetryContext -ExecutionScope 'Module' -ModuleName $ModuleState.ModuleName -EventType 'End' -DurationMs $durationMs -ErrorCount $ErrorCount -ItemCount $ItemCount -CompliantCount $CompliantCount -NonCompliantCount $NonCompliantCount -ReportTime $RunState.ReportTime -Message $Message -GuardrailIdOverride $ModuleState.GuardrailId -MemoryStartMb $memoryStartMb -MemoryEndMb $memoryEnd.WorkingSetMb -MemoryPeakMb $modulePeakMb -MemoryDeltaMb $memoryDeltaMb

    $summary = [pscustomobject]@{
        ModuleName      = $ModuleState.ModuleName
        IsSkipped       = $false
        DurationSeconds = if ($null -ne $durationMs) { [Math]::Round($durationMs / 1000, 2) } else { 0 }
        Items           = $ItemCount
        Errors          = $ErrorCount
        GuardrailId     = $ModuleState.GuardrailId
        MemoryStartMb   = $memoryStartMb
        MemoryEndMb     = $memoryEnd.WorkingSetMb
        MemoryDeltaMb   = $memoryDeltaMb
        MemoryPeakMb    = $modulePeakMb
    }
    $null = $RunState.Summaries.Add($summary)

    return $summary
}

function Skip-GuardrailModuleState {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$RunState,
        [Parameter(Mandatory = $true)]
        [string]$ModuleName,
        [Parameter(Mandatory = $false)]
        [string]$GuardrailId
    )

    $RunState.Stats.ModulesDisabled++

    $memorySnapshot = Get-GuardrailProcessMemory
    Update-RunStateMemoryStats -RunState $RunState -CurrentSnapshot $memorySnapshot

    Write-GuardrailTelemetry -Context $RunState.TelemetryContext -ExecutionScope 'Module' -ModuleName $ModuleName -EventType 'Skipped' -ReportTime $RunState.ReportTime -GuardrailIdOverride $GuardrailId -MemoryStartMb $memorySnapshot.WorkingSetMb -MemoryEndMb $memorySnapshot.WorkingSetMb -MemoryPeakMb $memorySnapshot.PeakWorkingSetMb -MemoryDeltaMb 0

    $summary = [pscustomobject]@{
        ModuleName      = $ModuleName
        IsSkipped       = $true
        DurationSeconds = 0
        Items           = 0
        Errors          = 0
        GuardrailId     = $GuardrailId
        MemoryStartMb   = $memorySnapshot.WorkingSetMb
        MemoryEndMb     = $memorySnapshot.WorkingSetMb
        MemoryDeltaMb   = 0
        MemoryPeakMb    = $memorySnapshot.PeakWorkingSetMb
    }
    $null = $RunState.Summaries.Add($summary)

    return $summary
}

function Complete-GuardrailRunState {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$RunState
    )

    if ($RunState.RunStopwatch -and $RunState.RunStopwatch.IsRunning) {
        $RunState.RunStopwatch.Stop()
    }

    $duration = if ($RunState.RunStopwatch) { $RunState.RunStopwatch.Elapsed } else { [TimeSpan]::Zero }

    $messageParts = @(
        "ModulesEnabled=$($RunState.Stats.ModulesEnabled)",
        "ModulesDisabled=$($RunState.Stats.ModulesDisabled)",
        "TotalItems=$($RunState.Stats.TotalItems)"
    )
    $runMessage = $messageParts -join '; '

    Update-RunStateMemoryStats -RunState $RunState -CurrentSnapshot ([pscustomobject]@{
            WorkingSetMb     = $RunState.Stats.MemoryEndMb
            PeakWorkingSetMb = $RunState.Stats.MemoryPeakMb
        })

    Write-GuardrailTelemetry -Context $RunState.TelemetryContext -ExecutionScope 'Runbook' -ModuleName 'RUNBOOK' -EventType 'End' -DurationMs $duration.TotalMilliseconds -ErrorCount $RunState.Stats.Errors -ItemCount $RunState.Stats.TotalItems -CompliantCount $RunState.Stats.CompliantItems -NonCompliantCount $RunState.Stats.NonCompliantItems -ReportTime $RunState.ReportTime -Message $runMessage -MemoryStartMb $RunState.Stats.MemoryStartMb -MemoryEndMb $RunState.Stats.MemoryEndMb -MemoryPeakMb $RunState.Stats.MemoryPeakMb -MemoryDeltaMb $RunState.Stats.MemoryDeltaMb

    return [pscustomobject]@{
        Duration  = $duration
        Stats     = $RunState.Stats
        Summaries = $RunState.Summaries
    }
}

#endregion Guardrail Telemetry Helpers

function Get-EvaluationProfile {
    [OutputType([PSCustomObject])]
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $CloudUsageProfiles,
        [Parameter(Mandatory = $true)]
        [string] $ModuleProfiles,
        [Parameter(Mandatory = $false)]
        [string] $SubscriptionId
    )
    Write-Host "Config CloudUsageProfiles $CloudUsageProfiles"
    Write-Host "MCP GR ModuleProfiles $ModuleProfiles"
    Write-Host "SubscriptionId $SubscriptionId"

    $returnProfile = ""
    $returnShouldEvaluate = $false
    $returnShouldAvailable = $false

    try {
        # Convert input strings to integer arrays  
        $cloudUsageProfileArray = ConvertTo-IntArray $CloudUsageProfiles
        $moduleProfileArray = ConvertTo-IntArray $ModuleProfiles

        if (-not $SubscriptionId) {
            $matchedProfile = Get-HighestMatchingProfile $cloudUsageProfileArray $moduleProfileArray
            return [PSCustomObject]@{
                Profile = $matchedProfile
                ShouldEvaluate = ($matchedProfile -in $cloudUsageProfileArray)
            }
        }

        $subscriptionTags = Get-AzTag -ResourceId "subscriptions/$SubscriptionId" -ErrorAction Stop
        $profileTagValues = if ($subscriptionTags.Properties -and 
                              $subscriptionTags.Properties.TagsProperty -and 
                              $subscriptionTags.Properties.TagsProperty['profile']) {
            $subscriptionTags.Properties.TagsProperty['profile']
        } else {
            $null
        }

        if ($null -eq $profileTagValues) {
            $matchedProfile = Get-HighestMatchingProfile $cloudUsageProfileArray $moduleProfileArray
            return [PSCustomObject]@{
                Profile = $matchedProfile
                ShouldEvaluate = ($matchedProfile -in $cloudUsageProfileArray)
                ShouldAvailable = ($matchedProfile -in $moduleProfileArray)
            }
        }

        $profileTagValuesArray = ConvertTo-IntArray $profileTagValues

        # Get the highest profile from all sources
        #cloudUsageProfile from config json
        $highestCloudUsageProfile = ($cloudUsageProfileArray | Measure-Object -Maximum).Maximum
        #module profiles for the guardrail
        $highestModuleProfile = ($moduleProfileArray | Measure-Object -Maximum).Maximum
        #subscription tag
        $highestTagProfile = ($profileTagValuesArray | Measure-Object -Maximum).Maximum


        $returnProfile = $highestTagProfile
        $returnShouldAvailable = ($highestTagProfile -in $moduleProfileArray)
        # Use the highest profile if it's present in the module profiles
        if ($highestTagProfile -in $moduleProfileArray) {
            # CONDITION: hightest sub tag is in module profile
            $returnShouldEvaluate = ($highestTagProfile -in $cloudUsageProfileArray)   
        }
        else{
            # CONDITION: hightest sub tag is not in module profile
            $returnShouldEvaluate = ($highestTagProfile -in $moduleProfileArray)
        }
        
        return [PSCustomObject]@{
            Profile =  $returnProfile
            ShouldEvaluate = $returnShouldEvaluate
            ShouldAvailable = $returnShouldAvailable
        }
    }
    catch {
        Write-Error "Error in Get-EvaluationProfile: $_"
        return [PSCustomObject]@{
            Profile = 0
            ShouldEvaluate = $false
            ShouldAvailable = $false
        }
    }
}

# Helper function to get the highest matching profile
function Get-HighestMatchingProfile {
    [OutputType([int])]
    param (
        [Parameter(Mandatory = $true)]
        [int[]]$profile1,
        [Parameter(Mandatory = $true)]
        [int[]]$profile2
    )
    $matchingProfiles = $profile1 | Where-Object { $profile2 -contains $_ }
    if ($matchingProfiles.Count -eq 0) {
        return 0
    }
    return ($matchingProfiles | Measure-Object -Maximum).Maximum
}

function ConvertTo-IntArray {
    [OutputType([int[]])]
    param (
        [Parameter(Mandatory = $true)]
        [string]$inputString
    )
    # Remove any brackets and split on comma, then convert each element to int
    return $inputString.Trim('[]').Split(',') | ForEach-Object { [int]$_.Trim() }
}

function Parse-BlobContent {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$blobContent
    )

    # Check if blob content is retrieved
    if (-not $blobContent) {
        throw "Failed to retrieve blob content or blob is empty."
    }

    # Split content into lines
    $lines = $blobContent -split "`r`n|`n|,|;|,\s|;\s"

    $filteredLines = $lines | Where-Object { $_ -match '\S' -and $_ -like "*@*" } | ForEach-Object { $_ -replace '\s' }

    # Initialize an empty array
    $globalAdminUPNs = @()

    # Check each line, remove the hyphen (if any), and add to array
    foreach ($line in $filteredLines) {
        if ($line.StartsWith("-")) {
            # Remove the leading hyphen and any potential whitespace after it
            $trimmedLine = $line.Substring(1)
        } 
        else{
            $trimmedLine = $line
        }
        $trimmedLine = $trimmedLine.Trim()
        $globalAdminUPNs += $trimmedLine
    }

    $result = New-Object PSObject -Property @{
        GlobalAdminUPNs = $globalAdminUPNs
    }

    return $result
}
# New improves version of Invoke-GraphQuery function that handles paging and retries
# This function is designed to be used with the Microsoft Graph API and will automatically handle pagination

function Invoke-GraphQueryEX {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string]
        $urlPath,
        [int]$MaxRetries = 3,
        [int]$RetryDelaySeconds = 5
    )

    [string]$baseUri = "https://graph.microsoft.com/v1.0"
    $fullUri = "$baseUri$urlPath" 
    # Use a generic List to avoid the O(n²) memory cost of PowerShell array '+=' on every page
    $allResults = [System.Collections.Generic.List[object]]::new()
    $singleObjectResult = $null
    $statusCode = $null
    $pageCount = 0
    do {
        $retryCount = 0
        $success = $false
        $pageCount++
        Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Retrieving page $pageCount..."
        
        do {
            try {
                $uri = $fullUri -as [uri]
                $response = Invoke-AZRestMethod  -Uri $uri  -Method GET -ErrorAction Stop
                $statusCode = $response.StatusCode
                # Treat any non-2xx as an error so bad requests (e.g. unsupported $filter)
                # are retried/surfaced rather than silently returned as content
                if ($statusCode -lt 200 -or $statusCode -ge 300) {
                    throw [System.Exception]::new(
                        "Graph API returned HTTP $statusCode at page $pageCount. Response: $($response.Content)")
                }
                $data = $response.Content | ConvertFrom-Json
                $success = $true
            }
            catch {
                $retryCount++
                if ($retryCount -ge $MaxRetries) {
                    Write-Error "Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $($_.Exception.Message) at page $pageCount"
                    Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Failed" -Completed
                    return @{
                        Content    = $null
                        StatusCode = $statusCode
                        Error      = $_.Exception.Message
                    }
                } else {
                    Write-Warning "Transient error calling Graph API: $($_.Exception.Message). Retrying in $RetryDelaySeconds seconds... (Attempt $retryCount of $MaxRetries)"
                    Start-Sleep -Seconds $RetryDelaySeconds
                }
            }
        } while (-not $success -and $retryCount -lt $MaxRetries)

        if ($null -ne $data.value) {
            # AddRange avoids per-item overhead; cast ensures compatibility with all page types
            $allResults.AddRange([object[]]$data.value)
        } else {
            # Endpoint returns a single object rather than a .value collection;
            # preserve original return shape @{ value = singleObject } for caller compatibility
            $singleObjectResult = $data
            break
        }
        # Handle paging
        if ($data.'@odata.nextLink') {
            $fullUri = $data.'@odata.nextLink'
        } else {
            $fullUri = $null
        }
    } while ($fullUri)
    
    Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Completed" -Completed

    # Return arrays for paged results so existing callers keep the same shape they had before.
    $valueOut = if ($null -ne $singleObjectResult) { $singleObjectResult } else { [object[]]$allResults.ToArray() }
    return @{
        Content    = @{ value = $valueOut }
        StatusCode = $statusCode
    }
}
# end of Invoke-GraphQueryEX function

# Function for true streaming Graph API queries with callback processing
function Invoke-GraphQueryStreamWithCallback {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string] $urlPath,
        
        [Parameter(Mandatory = $true)]
        [scriptblock] $ProcessPageCallback,
        
        [Parameter(Mandatory = $false)]
        [hashtable] $CallbackContext = @{},
        
        [Parameter(Mandatory = $false)]
        [int] $PageSize = 999,
        
        [Parameter(Mandatory = $false)]
        [int] $MaxRetries = 3,
        
        [Parameter(Mandatory = $false)]
        [int] $RetryDelaySeconds = 5,

        # High-volume callers can tune fixed page waits; default keeps existing behavior.
        [Parameter(Mandatory = $false)]
        [int] $InterPageDelaySeconds = 2,
        
        [Parameter(Mandatory = $false)]
        [hashtable] $PerformanceMetrics = $null
    )

    [string] $baseUri = "https://graph.microsoft.com/v1.0"
    
    # Add $top parameter if not already present
    if ($urlPath -notmatch '\$top=') {
        $separator = if ($urlPath -match '\?') { '&' } else { '?' }
        $urlPath = "$urlPath$separator`$top=$PageSize"
    }

    # Graph can tell us how long to wait after throttling. Reading that value keeps
    # normal paging fast while still backing off for the tenant that needs it.
    function Get-GraphRetryAfterSeconds {
        param(
            $Headers,
            [int] $DefaultDelaySeconds
        )

        $retryAfter = $null
        if ($null -ne $Headers) {
            try {
                if ($Headers -is [System.Collections.IDictionary]) {
                    foreach ($key in $Headers.Keys) {
                        if ([string]$key -ieq 'Retry-After') {
                            $retryAfter = @($Headers[$key]) | Select-Object -First 1
                            break
                        }
                    }
                }
                elseif ($Headers.PSObject.Methods.Name -contains 'TryGetValues') {
                    $retryAfterValues = $null
                    if ($Headers.TryGetValues('Retry-After', [ref]$retryAfterValues)) {
                        $retryAfter = @($retryAfterValues) | Select-Object -First 1
                    }
                }
                else {
                    $retryAfterProperty = $Headers.PSObject.Properties |
                        Where-Object { $_.Name -ieq 'Retry-After' } |
                        Select-Object -First 1
                    if ($retryAfterProperty) {
                        $retryAfter = @($retryAfterProperty.Value) | Select-Object -First 1
                    }
                }
            }
            catch {
                # A malformed or unfamiliar header shape must not prevent the retry.
                $retryAfter = $null
            }
        }

        $retryAfterSeconds = 0
        if ($null -ne $retryAfter -and
            [int]::TryParse([string]$retryAfter, [ref]$retryAfterSeconds) -and
            $retryAfterSeconds -gt 0) {
            return $retryAfterSeconds
        }

        return $DefaultDelaySeconds
    }

    $fullUri = "$baseUri$urlPath"
    $pageCount = 0
    $totalProcessed = 0
    $totalUploaded = 0
        
    do {
        $pageCount++
        $retryCount = 0
        $success = $false
        
        Write-Verbose "  -> Fetching page $pageCount from Graph API..."        
        do {
            try {
                # Default to retryable until we know the exact HTTP status from Graph.
                $isRetryable = $true
                $retryDelayForAttempt = $RetryDelaySeconds
                $statusCode = $null
                $uri = $fullUri -as [uri]
                $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop
                $statusCode = $response.StatusCode
                                
                # Check for successful status codes (200-299)
                if ($statusCode -ge 200 -and $statusCode -lt 300) {
                    $data = $response.Content | ConvertFrom-Json
                    $success = $true
                                        
                    # Update performance metrics if provided
                    if ($PerformanceMetrics) {
                        $PerformanceMetrics.GraphApiCalls++
                    }
                } else {
                    # Handle non-success status codes
                    $errorContent = $response.Content
                    if ($statusCode -eq 429) {
                        $retryDelayForAttempt = Get-GraphRetryAfterSeconds -Headers $response.Headers -DefaultDelaySeconds $RetryDelaySeconds
                    }

                    # Determine if this is a retryable error
                    $isRetryable = switch ($statusCode) {
                        429 { $true }   # Too Many Requests - always retry
                        500 { $true }   # Internal Server Error - retry
                        502 { $true }   # Bad Gateway - retry  
                        503 { $true }   # Service Unavailable - retry
                        504 { $true }   # Gateway Timeout - retry
                        400 { $false }  # Bad Request - don't retry (client error)
                        401 { $false }  # Unauthorized - don't retry (auth error)
                        403 { $false }  # Forbidden - don't retry (permission error)
                        404 { $false }  # Not Found - don't retry (resource error)
                        default { $statusCode -ge 500 }  # Retry on 5xx errors, not 4xx
                    }
                    
                    if (-not $isRetryable) {
                        throw [System.Exception]::new("Graph API returned non-retryable error $statusCode at page $pageCount. Content: $errorContent")
                    } else {
                        throw [System.Exception]::new("Graph API returned retryable error $statusCode at page $pageCount. Content: $errorContent")
                    }
                }
                
            }
            catch {
                $retryCount++
                $errorMessage = $_.Exception.Message
                if ($_.Exception.Response -and $_.Exception.Response.Headers) {
                    if ($null -ne $_.Exception.Response.StatusCode) {
                        $statusCode = [int]$_.Exception.Response.StatusCode
                    }
                    $retryDelayForAttempt = Get-GraphRetryAfterSeconds -Headers $_.Exception.Response.Headers -DefaultDelaySeconds $retryDelayForAttempt
                }

                if ($PerformanceMetrics -and $statusCode -eq 429) {
                    $PerformanceMetrics.GraphThrottles429++
                }
                                
                if ($retryCount -ge $MaxRetries) {
                    Write-Error "Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $errorMessage at page $pageCount"
                    throw [System.Exception]::new("Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $errorMessage at page $pageCount")
                } elseif ($isRetryable) {
                    if ($PerformanceMetrics) {
                        $PerformanceMetrics.GraphApiRetries++
                        $PerformanceMetrics.GraphRetryDelaySeconds += $retryDelayForAttempt
                    }
                    Write-Warning "Retryable error calling Graph API (attempt $retryCount/$MaxRetries): $errorMessage. Retrying in $retryDelayForAttempt seconds..."
                    Start-Sleep -Seconds $retryDelayForAttempt
                } else {
                    Write-Error "Non-retryable error calling Graph API: $errorMessage"
                    throw [System.Exception]::new("Non-retryable error calling Graph API: $errorMessage")
                }
            }
        } while (-not $success -and $retryCount -lt $MaxRetries)

        # Process current page immediately via callback
        $pageData = @{
            Data = if ($null -ne $data.value) { $data.value } else { $data }
            PageNumber = $pageCount
            HasMore = $null -ne $data.'@odata.nextLink'
            StatusCode = $statusCode
        }
        
        # Execute callback to process this page immediately with error handling
        try {
            $callbackResult = & $ProcessPageCallback $pageData $CallbackContext
            if ($callbackResult) {
                $totalProcessed += $callbackResult.ProcessedCount
                $totalUploaded += $callbackResult.UploadedCount
            }
        }
        catch {
            Write-Error "Failed to process page $pageCount via callback: $($_.Exception.Message)"
            throw $_  # Re-throw to stop processing if callback fails
        }
        
        # Update URI for next page
        if ($data.'@odata.nextLink') {
            $fullUri = $data.'@odata.nextLink'
        } else {
            $fullUri = $null
        }
        
        # Optional rate limiting between pages. Retry handling still covers throttling/transient failures.
        if ($fullUri -and $InterPageDelaySeconds -gt 0) {
            Write-Verbose "  -> Waiting $InterPageDelaySeconds seconds before fetching next page..."
            Start-Sleep -Seconds $InterPageDelaySeconds
        }
        
    } while ($fullUri)
    
    return @{
        TotalPages = $pageCount
        TotalProcessed = $totalProcessed
        TotalUploaded = $totalUploaded
    }
}

function Invoke-GraphQuery {
    [CmdletBinding()]
    param(
        # URL path (ex: /users)
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string]
        $urlPath
    )

    try {
        $uri = "https://graph.microsoft.com/v1.0$urlPath" -as [uri]
        
        $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop

    }
    catch {
        Write-Error "An error occured constructing the URI or while calling Graph query for URI GET '$uri': $($_.Exception.Message)"
    }
    
    @{
        Content    = $response.Content | ConvertFrom-Json
        StatusCode = $response.StatusCode
    }
}

# Utility function for centralized error handling
function Add-FunctionError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Message,
        
        [Parameter(Mandatory = $false)]
        [System.Exception] $Exception = $null,
        
        [Parameter(Mandatory = $false)]
        [string] $Category = "General",
        
        [Parameter(Mandatory = $false)]
        [System.Collections.Generic.List[string]] $ErrorList = $null
    )
    
    if ($Exception) {
        $errorMsg = "$Category - $Message : $($Exception.Message)"
    } else {
        $errorMsg = "$Category - $Message"
    }
    
    Write-Warning $errorMsg
    
    # PowerShell treats an empty list like false. Check whether the list exists so
    # the first error is added even when the list does not contain anything yet.
    if ($null -ne $ErrorList) {
        [void]$ErrorList.Add($errorMsg)
    }
}

# Utility function for exponential backoff delay calculation
function Get-BackoffDelay {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int] $Attempt,
        
        [Parameter(Mandatory = $true)]
        [hashtable] $Config
    )
    
    $delay = [Math]::Min(
        $Config.BaseDelay * [Math]::Pow($Config.BackoffMultiplier, $Attempt - 1),
        $Config.MaxDelay
    )
    return [int]$delay
}

# Utility function for Graph API calls with metrics and error handling
function Invoke-GraphQueryWithMetrics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $UrlPath,
        
        [Parameter(Mandatory = $false)]
        [string] $Operation = "Graph API Call",
        
        [Parameter(Mandatory = $false)]
        [hashtable] $PerformanceMetrics = $null,
        
        [Parameter(Mandatory = $false)]
        [int] $MaxRetries = 5,
        
        [Parameter(Mandatory = $false)]
        [int] $RetryDelaySeconds = 10
    )
    
    Write-Verbose "  -> $Operation : $UrlPath"
    
    try {
        # Use the existing retry logic in Invoke-GraphQueryEX
        $response = Invoke-GraphQueryEX -urlPath $UrlPath -MaxRetries $MaxRetries -RetryDelaySeconds $RetryDelaySeconds -ErrorAction Stop
        
        # Update performance metrics if provided
        if ($PerformanceMetrics) {
            $PerformanceMetrics.GraphApiCalls++
        }
        
        # Handle array responses consistently
        if ($response -is [System.Array]) {
            $response = $response | Where-Object { 
                $null -ne $_.Content -or $null -ne $_.StatusCode 
            } | Select-Object -Last 1
        }
        
        # Check for successful response
        if ($response.Error) {
            throw [System.Exception]::new("Graph API error: $($response.Error)")
        }
        
        if (-not $response.StatusCode -or $response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
            throw [System.Exception]::new("Graph API returned status code: $($response.StatusCode)")
        }
        
        Write-Verbose "  Success: $Operation completed"
        return $response
    }
    catch {
        Write-Error "$Operation failed: $($_.Exception.Message)"
        throw $_
    }
}



# Function to add other possible file extension(s) to the module file names
function add-documentFileExtensions {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName,
        [Parameter(Mandatory = $true)]
        [string]$ItemName

    )

    if ($ItemName.ToLower() -eq 'network architecture diagram' -or 
        $ItemName.ToLower() -eq 'high level design documentation' -or
        $ItemName.ToLower() -eq "diagramme d'architecture réseau" -or 
        $ItemName.ToLower() -eq 'documentation de Conception de haut niveau'){

            $fileExtensions = @(".pdf", ".png", ".jpeg", ".vsdx",".txt",".docx", ".doc")
    }
    elseif ($ItemName.ToLower() -eq 'dedicated user accounts for administration' -or 
            $ItemName.ToLower() -eq "Comptes d'utilisateurs dédiés pour l'administration") {
                
            $fileExtensions = @(".csv")
    }
    elseif ($ItemName.ToLower() -eq 'application gateway certificate validity' -or 
            $ItemName.ToLower() -eq "validité du certificat : passerelle d'application") {
        
            $fileExtensions = @(".txt")
    }
    else {
        $fileExtensions = @(".txt",".docx", ".doc", ".pdf")
    }
    
    $DocumentName_new = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($fileExt in $fileExtensions) {
        $DocumentName_new.Add($DocumentName[0] + $fileExt)
    }

    return $DocumentName_new
}

function Get-UserSignInPreferences {
    [CmdletBinding()]
    param (      
        [Parameter(Mandatory = $true)]
        [string]$UserUPN
    )
    
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $signInPreferences = $null
    
    # Handle guest accounts (external users)
    $pattern = "*#EXT#*"
    if($UserUPN -like $pattern){
        # for guest accounts
        $userEmail = $UserUPN
        if(!$null -eq $userEmail){
            # Use WebUtility for PS5/PS7 compatibility
            $encodedUserEmail = [System.Net.WebUtility]::UrlEncode($userEmail)
            $urlPath = '/users/' + $encodedUserEmail + '/authentication/signInPreferences'            
        }else{
            Write-Warning "userEmail is null for $UserUPN"
            $extractedEmail = (($UserUPN -split '#')[0]) -replace '_', '@'
            $urlPath = '/users/' + $extractedEmail + '/authentication/signInPreferences'
        }
    }else{
        # for member accounts
        $urlPath = '/users/' + $UserUPN + '/authentication/signInPreferences'
    }
    
    try {
        # Use beta endpoint for signInPreferences
        $uri = "https://graph.microsoft.com/beta$urlPath" -as [uri]
        
        $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop
        
        if ($response.StatusCode -eq 200) {
            $signInPreferences = $response.Content | ConvertFrom-Json
            Write-Host "Successfully retrieved sign-in preferences for $UserUPN"
        } else {
            $errorMsg = "Failed to retrieve sign-in preferences for $UserUPN. Status code: $($response.StatusCode)"
            $ErrorList.Add($errorMsg)
            Write-Error $errorMsg
        }
    }
    catch {
        $errorMsg = "Failed to call Microsoft Graph Beta API at URL '$urlPath'; returned error message: $_"
        $ErrorList.Add($errorMsg)
        Write-Error "Error: $errorMsg"
    }
    
    $PsObject = [PSCustomObject]@{
        SignInPreferences = $signInPreferences
        ErrorList = $ErrorList
    }
    
    return $PsObject
}



function Get-AllUserAuthInformation {
    [CmdletBinding()]
    param (      
        [Parameter(Mandatory = $true)]
        [array]$allUserList
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $userValidMFACounter = 0
    $userUPNsValidMFA = @()
    $userUPNsBadMFA = @()
    $pattern = "*#EXT#*"

    ForEach ($user in $allUserList) {
        $userAccount = $user.userPrincipalName
        $authFound = $false

        # First, check if user has FIDO2 or HardwareOTP as system preferred authentication method
        try {
            $signInPrefsResult = Get-UserSignInPreferences -UserUPN $userAccount
            if ($signInPrefsResult.ErrorList.Count -eq 0 -and $null -ne $signInPrefsResult.SignInPreferences) {
                $preferences = $signInPrefsResult.SignInPreferences
                $isSystemPreferredEnabled = $preferences.isSystemPreferredAuthenticationMethodEnabled
                $systemPreferredMethod = $preferences.systemPreferredAuthenticationMethod
                
                # Check if system preferred is enabled and set to FIDO2 or HardwareOTP
                if ($isSystemPreferredEnabled -eq $true -and 
                    ($systemPreferredMethod -eq "Fido2" -or $systemPreferredMethod -eq "HardwareOTP")) {
                    $authFound = $true
                    Write-Host "$userAccount - System preferred authentication method is $systemPreferredMethod"
                }
            }
        }
        catch {
            $errorMsg = "Failed to check sign-in preferences for $userAccount : $_"
            $ErrorList.Add($errorMsg)
            Write-Error "Warning: $errorMsg"
        }
        
        # If system preferred authentication is not FIDO2 or HardwareOTP, check authentication methods
        if (-not $authFound) {
            if($userAccount -like $pattern){
                # for guest accounts
                $userEmail = $user.mail
                if(!$null -eq  $userEmail){
                    $urlPath = '/users/' + $userEmail + '/authentication/methods'
                }else{
                    Write-Host "userEmail is null for $userAccount"
                    $extractedEmail = (($userAccount -split '#')[0]) -replace '_', '@'
                    $urlPath = '/users/' + $extractedEmail + '/authentication/methods'
                }
                
            }else{
                # for member accounts
                $urlPath = '/users/' + $userAccount + '/authentication/methods'
            }
            
            try {
                $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop

            }
            catch {
                $errorMsg = "Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"
            }

            # # To check if MFA is setup for a user, we're checking various authentication methods:
            # # 1. #microsoft.graph.microsoftAuthenticatorAuthenticationMethod
            # # 2. #microsoft.graph.phoneAuthenticationMethod
            # # 3. #microsoft.graph.passwordAuthenticationMethod - not considered for MFA
            # # 4. #microsoft.graph.emailAuthenticationMethod - not considered for MFA
            # # 5. #microsoft.graph.fido2AuthenticationMethod
            # # 6. #microsoft.graph.softwareOathAuthenticationMethod
            # # 7. #microsoft.graph.temporaryAccessPassAuthenticationMethod
            # # 8. #microsoft.graph.windowsHelloForBusinessAuthenticationMethod

            if ($null -ne $response) {
                # portal
                $data = $response.Content
                # # localExecution
                # $data = $response
                if ($null -ne $data -and $null -ne $data.value) {
                    $authenticationmethods = $data.value
                    
                    foreach ($authmeth in $authenticationmethods) {    
                    
                        switch ($authmeth.'@odata.type') {
                            "#microsoft.graph.phoneAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.fido2AuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.temporaryAccessPassAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.softwareOathAuthenticationMethod" { $authFound = $true; break }
                        }
                    }
                }
                else {
                    $errorMsg = "No authentication methods data found for $userAccount"                
                    $ErrorList.Add($errorMsg)
                    # Write-Error "Error: $errorMsg"
                }
            }
            else {
                $errorMsg = "Failed to get response from Graph API for $userAccount"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"
            }
        }
        
        # Process the authentication result
        if($authFound){
            #need to keep track of user account mfa in a counter and compare it with the total user count   
            $userValidMFACounter += 1
            Write-Host "Auth method found for $userAccount"

            # Create an instance of valid MFA inner list object
            $userValidUPNtemplate = [PSCustomObject]@{
                UPN  = $userAccount
                MFAStatus   = $true
            }
            $userUPNsValidMFA +=  $userValidUPNtemplate
        }
        else{
            # This message is being used for debugging
            Write-Host "$userAccount does not have MFA enabled"

            # Create an instance of inner list object
            $userUPNtemplate = [PSCustomObject]@{
                UPN  = $userAccount
                MFAStatus   = $false
            }
            # Add the list to user accounts MFA list
            $userUPNsBadMFA += $userUPNtemplate

        }    
    }

    $PsObject = [PSCustomObject]@{
        userUPNsBadMFA = $userUPNsBadMFA
        ErrorList      = $ErrorList
        userValidMFACounter = $userValidMFACounter
        userUPNsValidMFA = $userUPNsValidMFA
    }

    return $PsObject

}
function Get-AllUserAuthInformationEX {
    <#
    .SYNOPSIS
    Optimized version of Get-AllUserAuthInformation using Microsoft Graph Batch API for improved performance.
    Compatible with PowerShell 5.1. Signature and output format are unchanged.

    .PARAMETER allUserList
    Array of user objects to check for MFA status.

    .OUTPUTS
    PSCustomObject with userUPNsBadMFA, ErrorList, userValidMFACounter, userUPNsValidMFA.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [array]$allUserList
    )

    # Initialize output containers
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $userValidMFACounter = 0
    $userUPNsValidMFA = @()
    $userUPNsBadMFA = @()
    $batchSize = 20
    $pattern = "*#EXT#*"

    # Process users in batches of 20 (Graph Batch API limit)
    for ($i = 0; $i -lt $allUserList.Count; $i += $batchSize) {
        $batchUsers = $allUserList[$i..([Math]::Min($i+$batchSize-1, $allUserList.Count-1))]
        $batchRequests = @()
        $userMap = @{}

        # Build batch request payload for each user in the batch
        $reqId = 1
        foreach ($user in $batchUsers) {
            $userAccount = $user.userPrincipalName
            if ($userAccount -like $pattern) {
                # Guest accounts
                $userEmail = $user.mail
                if ($null -ne $userEmail) {
                    $urlPath = "/users/$userEmail/authentication/methods"
                } else {
                    $extractedEmail = (($userAccount -split '#')[0]) -replace '_', '@'
                    $urlPath = "/users/$extractedEmail/authentication/methods"
                }
            } else {
                # Member accounts
                $urlPath = "/users/$userAccount/authentication/methods"
            }
            $batchRequests += @{
                id     = "$reqId"
                method = "GET"
                url    = $urlPath
            }
            $userMap["$reqId"] = $userAccount
            $reqId++
        }

        # Convert batch request to JSON
        $batchPayload = @{ requests = $batchRequests } | ConvertTo-Json -Depth 4

        # Send batch request to Graph API
        try {
            $response = Invoke-AzRestMethod -Uri "https://graph.microsoft.com/v1.0/\$batch" -Method POST -Body $batchPayload -ErrorAction Stop
            $batchResults = ($response.Content | ConvertFrom-Json).responses
        }
        catch {
            $ErrorList.Add("Batch request failed: $_")
            continue
        }

        # Process each response in the batch
        foreach ($result in $batchResults) {
            $userAccount = $userMap[$result.id]
            if ($result.status -eq 200 -and $null -ne $result.body.value) {
                $authFound = $false
                foreach ($authmeth in $result.body.value) {
                    switch ($authmeth.'@odata.type') {
                        "#microsoft.graph.phoneAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.fido2AuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.temporaryAccessPassAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.softwareOathAuthenticationMethod" { $authFound = $true; break }
                    }
                }
                if ($authFound) {
                    $userValidMFACounter += 1
                    $userValidUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $true }
                    $userUPNsValidMFA += $userValidUPNtemplate
                } else {
                    $userUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $false }
                    $userUPNsBadMFA += $userUPNtemplate
                }
            } else {
                $ErrorList.Add("No authentication methods data for $userAccount or error status: $($result.status)")
                $userUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $false }
                $userUPNsBadMFA += $userUPNtemplate
            }
        }
    }

    # Return results in the same format as the original function
    $PsObject = [PSCustomObject]@{
        userUPNsBadMFA      = $userUPNsBadMFA
        ErrorList           = $ErrorList
        userValidMFACounter = $userValidMFACounter
        userUPNsValidMFA    = $userUPNsValidMFA
    }
}
function CompareKQLQueries{
    param (
        [string] $query,
        [string] $targetQuery
        )

    #Fix the formatting of KQL query
    $normalizedTargetQuery = $targetQuery -replace '\s+', ' ' -replace '\|', ' | ' 
    $removeSpacesQuery = $query -replace '\s', ''
    $removeSpacesTargetQuery = $normalizedTargetQuery -replace '\s', ''

    return $removeSpacesQuery -eq $removeSpacesTargetQuery
}

# Function used for V2.0 GR2V7(M) andV1.0  GR3(R) cloud console access
function Get-allowedLocationCAPCompliance {
    param (
        [AllowEmptyCollection()]
        # Callers pass an ArrayList so this function can append errors in-place
        # and return the same mutable collection in the output envelope.
        [System.Collections.ArrayList] $ErrorList,
        [bool] $IsCompliant,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID,
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable
    )

    # Find named locations
    $locationsBaseAPIUrl = '/identity/conditionalAccess/namedLocations'
    try {
        $response = Invoke-GraphQueryEX -urlPath $locationsBaseAPIUrl -ErrorAction Stop
        $data = $response.Content
        $locationData = if ($data -and $data.value) { $data.value } else { @() }
        # Filter for country NamedLocation only
        $locations = $locationData | Where-Object { $_.'@odata.type' -and $_.'@odata.type' -eq '#microsoft.graph.countryNamedLocation'}
        # Filter for IP-based named locations only
        $ipLocations = $locationData | Where-Object {$_.'@odata.type' -and $_.'@odata.type' -eq '#microsoft.graph.ipNamedLocation'}
    }
    catch {
        # Suppress Add() return index so the function output remains a compliance object, not an array.
        [void]$Errorlist.Add("Failed to call Microsoft Graph REST API at URL '$locationsBaseAPIUrl'; returned error message: $_") 
        Write-Warning "Error: Failed to call Microsoft Graph REST API at URL '$locationsBaseAPIUrl'; returned error message: $_"
        $locations = @()
        $ipLocations = @()
    }

    # Find conditional access policies
    $CABaseAPIUrl = '/identity/conditionalAccess/policies'
    try {
        $response = Invoke-GraphQueryEX -urlPath $CABaseAPIUrl -ErrorAction Stop

        $caps = if ($response.Content -and $response.Content.value) { $response.Content.value } else { @() }
    }
    catch {
        [void]$Errorlist.Add("Failed to call Microsoft Graph REST API at URL '$CABaseAPIUrl'; returned error message: $_")
        Write-Warning "Error: Failed to call Microsoft Graph REST API at URL '$CABaseAPIUrl'; returned error message: $_"
        $caps = @()
    }

    # # --------------------Named Location check to filter out cases -------------------- #
    # Case 1: Named locations not found at all
    # Case 2: Multiple named locations exist, but no Canada-only named location and no 'all-countries' except Canada named location or no valid IP-based named location found
    # Case 3: One Named location exists and it's Canada-only
    # Case 4: One named location exists and it's 'all-countries' except Canada'
    # Case 5: One named location exists and it's includes Canada + other countries
    # Case 6: Multiple named locations exist, at least one Canada-only named location found
    
    # ---------------------------------------------------------------
    # Case 1: No named locations of any type (country/ip based) found
    # ---------------------------------------------------------------
    if ($locations.Count -eq 0 -and $ipLocations.Count -eq 0) {
        Write-Warning "Warning: No named locations found. Cannot evaluate Conditional Access Policies for compliance."
        $ErrorList.Add("No named locations found. Cannot evaluate Conditional Access Policies for compliance.") | Out-Null
        $IsCompliant = $false
        $Comments = $msgTable.noNamedLocationFound 

        $PsObject = [PSCustomObject]@{
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
            Errors           = $ErrorList
        }
        
        return $PsObject
    }
    
    # -------------------------------------------------------------
    # Find for Case 2: checking country-based allowed location - Conditional Access Policy
    # -------------------------------------------------------------

    # Group country-based named locations and find location Ids
    $validLocations = @()               # Canada-only named locations
    $validLocationIds = @()             
    $nonCAnamedLocations = @()          # named locations that represent 'all countries except Canada-only
    $nonCAnamedLocationsIds = @()
    $someNonCAnamedLocations = @()      # named locations that represent 'some countries except Canada-only'
    $someNonCAnamedLocationsIds = @()       
    $notValidCAnamedLocations = @()     # named locations that includes Canada + other countries
    $notValidCAnamedLocationsIds = @()  

    foreach ($location in $locations) {
        try {
            $countries = @()
            if ($null -ne $location.countriesAndRegions) { 
                $countries = @($location.countriesAndRegions) 
            }
            # Find all valid locations: Canada-Only; a valid location requirement i.e. Canada
            if ($countries.Count -eq 1 -and $countries[0] -eq 'CA') {
                Write-Host "Named Location Found: $($location.displayName) with Country/Region: $($location.countriesAndRegions -join ', ')"
                $validLocations += $location
                if ($location.PSObject.Properties.Match('id').Count -gt 0) { 
                    $validLocationIds += $location.id.ToString().ToLower()
                }
                continue
            }
            # Find named location contains ALL countries except Canada; a valid location requirement i.e. 'RestOfTheWorld'
            if ($countries.Count -eq 249 -and -not ($countries -contains 'CA')) {
                Write-Host "Named Location Found: $($location.displayName) with Country/Region: $($location.countriesAndRegions -join ', ')"
                $nonCAnamedLocations += $location
                if ($location.PSObject.Properties.Match('id').Count -gt 0){
                    $nonCAnamedLocationsIds += $location.id.ToString().ToLower()
                }
                continue
            }
            # Find named location contains multiple countries; includes Canada; not a valid location requirement i.e. 'TestLocation'
            if ($countries.Count -ge 1 -and ($countries -contains 'CA')) {
                Write-Host "Named Location Found: $($location.displayName) with Country/Region: $($location.countriesAndRegions -join ', ')"
                $notValidCAnamedLocations += $location
                if ($location.PSObject.Properties.Match('id').Count -gt 0){
                    $notValidCAnamedLocationsIds += $location.id.ToString().ToLower()
                }
                continue
            }
            # Find named location contains countries (may or may not multiple but not 'ALL') except Canada; not a valid location requirement i.e. 'SelectedCountriesExclCanada'
            if ($countries.Count -lt 249 -and -not ($countries -contains 'CA')) {
                Write-Host "Named Location Found: $($location.displayName) with Country/Region: $($location.countriesAndRegions -join ', ')"
                $someNonCAnamedLocations += $location
                if ($location.PSObject.Properties.Match('id').Count -gt 0){
                    $someNonCAnamedLocationsIds += $location.id.ToString().ToLower()
                }
                continue
            }
        }
        catch {
            $ErrorList.Add("Error processing named location object: $_") | Out-Null
            continue
        }
    }

    # Required IP-ranges for compliant patterns
    $requiredIPRanges = @()
    # Read UPN files from storage with .csv extensions, add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName

    # If IP address based named location exists, then read allowed IP ranges from document in blob storage 
    if($ipLocations.Count -gt 0){
        # --------------------------------
        # Check if document exists in blob
        # --------------------------------

        $subName = ""

        try {
            Select-AzSubscription -Subscription $SubscriptionID | out-null
            $subName  = (Get-AzContext).Subscription.Name
        }
        catch {
            $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
            throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
        }
        
        try {
            # Use Entra/RBAC blob access because the Guardrails storage account no longer allows Shared Key auth.
            $StorageContext = New-ConnectedStorageContext -storageaccountName $StorageAccountName
        }
        catch {
            $storageErrorMessage = "Could not connect to storage account '$storageAccountName' in resource group '$resourceGroupName' of subscription '$SubscriptionID'; verify that the storage account exists and that you have permissions to it. Error: $_"

            Write-Warning "Warning: $storageErrorMessage"
            Write-Host "Warning: $storageErrorMessage"
        }

        $baseFileNameFound = $false
        $blobFound = $false

        # Get a list of filenames uploaded in the blob storage
        $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -ErrorAction Stop
        if ($null -eq $blobs) {            
            # a blob with the name $DocumentName was not located in the specified storage account
            $warningMsg = "Could not get blob from storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the blob exists and that you have permissions to it."
            Write-Warning $warningMsg
                
            $blobFound = $false
            $baseFileNameFound = $false
            $Comments += "Missing required document in storage account" -f $DocumentName
            Write-Host "Missing required document '$DocumentName' in storage account"
        }
        else{
            $fileNamesList = @()
            $blobs | ForEach-Object {
                $fileNamesList += $_.Name
            }
            $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
            if ( $matchingFiles.count -lt 1 ){
                # check if any fileName matches without the extension
                $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
                
                $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
                if ($BaseFileNamesMatch.Count -gt 0){
                    $baseFileNameFound = $true
                }
            }
            else {
                # also covers the use case if more than 1 appropriate files are uploaded
                
                # check for procedure doc in blob storage account
                $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageContext -Blob $matchingFiles -ErrorAction Stop

                If ($blobs) {
                    $blobFound = $true
                    # Read the content of the blob and save IP ranges into array
                    $blobContent = Get-AzStorageBlobContent -Container $ContainerName -Blob $matchingFiles -Context $StorageContext -Force -ErrorAction Stop
                    $requiredIPRanges = Get-Content $blobContent.Name | Where-Object { $_ -match '\S' } | ForEach-Object { $_.Trim() }
                    if ($requiredIPRanges -eq 0){
                        $Comments += "The required document in storage account is empty. Add the IP ranges to the document." -f $DocumentName
                        Write-Host "The required document '$DocumentName' in storage account is empty. Add the IP ranges to the document."
                    }
                    else{
                        Write-Host "Sucessfully read IP ranges from blob storage: $($requiredIPRanges -join ', ')"
                    }
                    

                }
            }
        }

        # ----------------------
        # DOC Case 1: uploaded fileName is correct but has wrong extension
        # ----------------------
        if ($baseFileNameFound){
            # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
            $Comments += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
            $Comments += "Unable to evaluate the IP-based named location. Upload the document with correct extension."
        }
        elseif ($blobFound){
        # ----------------------
        # DOC Case 2: file exists in blob storage
        # ----------------------
            $Comments += $msgTable.approvedIPrangeFileFound -f $DocumentName[0]
            Write-Host "Continue with IP named location evaluation"
        }
        else {
            # ----------------------
            # DOC Case 3: file does not exist in blob storage
            # ----------------------
            $Comments += $msgTable.approvedIPrangeFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
            $Comments += "Unable to evaluate the IP-based named location. Upload the document in storage account."
        
        }

    }

    # ----------------------
    # DOC Case 2 extension: Regardless of correct document exists (i.e. blobfound) - 
    #                       proceed with checking IP based allowed location - Conditional Access Policy and compliance evaluation
    # ----------------------

    # -------------------------------------------------------------
    # Find for Case 2: checking IP-based allowed location - Conditional Access Policy
    # -------------------------------------------------------------
    
    # Group IP-based named locations and find location Ids 
    $validIpLocations = @()                 # Ip named locations whose ranges include all required CIDR ranges
    $validIpLocationIds = @()
    $notValidIpLocations = @()              # Ip named locations that are missing ALL required CIDR ranges
    $notValidIpLocationIds = @() 
    $someNotValidIpnamedLocations = @()     # Ip named locations that are missing one or more required CIDR ranges
    $someNotValidIpnamedLocationsIds = @()       

    if($blobFound -and ($null -ne $requiredIPRanges)){
        # Collect Ip-baeed named location IDs for use in CAP pattern matching
        foreach ($ipLoc in $ipLocations) {
            try{
                $definedCIDRs = @()
                if ($null -ne $ipLoc.ipRanges){
                    $definedCIDRs = @(
                        $ipLoc.ipRanges | ForEach-Object {
                            if($_.PSObject.Properties.Match('cidrAddress').Count -gt 0){
                                $_.cidrAddress
                            }
                        } | Where-Object {$_}
                    )
                }
                Write-Host "IP-based Named Location found: $($ipLoc.displayName) with CIDRs: $($definedCIDRs -join ', ')"

                # Find all valid Ip locations: a valid location requirement i.e. includes all IP ranges provided in blob document
                $missingCIDRs = $requiredIPRanges | Where-Object {$definedCIDRs -notcontains $_}
                if ($missingCIDRs.Count -eq 0){
                    $validIpLocations += $ipLoc
                    if($ipLoc.PSObject.Properties.Match('id').Count -gt 0){
                        $validIpLocationIds += $ipLoc.id.ToString().ToLower()
                    }
                    continue
                }
                elseif($missingCIDRs.Count -eq $requiredIPRanges.Count){
                    # Find named location that contains IP ranges but doesn't include ALL required/valid IPs provided in the blob doc; not a valid location requirement
                    Write-Host "IP-based Named Location '$($ipLoc.displayName)' is missing required CIDR ranges: $($missingCIDRs -join ', ')"
                    $notValidIpLocations += $ipLoc
                    if($ipLoc.PSObject.Properties.Match('id').Count -gt 0){
                        $notValidIpLocationIds += $ipLoc.id.ToString().ToLower()
                    }
                    continue
                }
                else{
                    # Find named location contains some IP ranges but not ALL required/valid IPs provided in the blob doc; not a valid location requirement
                    Write-Host "IP-based Named Location '$($ipLoc.displayName)' is missing required CIDR ranges: $($missingCIDRs -join ', ')"
                    $someNotValidIpnamedLocations += $ipLoc
                    if($ipLoc.PSObject.Properties.Match('id').Count -gt 0){
                        $someNotValidIpnamedLocationsIds += $ipLoc.id.ToString().ToLower()
                    }
                    continue
                    
                }
            }
            catch{
                $ErrorList.Add("Error processing IP named location object '$($ipLoc.displayName)': $_") | Out-Null
                continue
            }

        }
    }
    else{
        $Comments += $msgTable.approvedIPrangesNotFound -f $DocumentName[0]
        $Comments += "Unable to evaluate the IP-based named location. Add the IP ranges to the document."
    }
    

    # ---------------------------------------------------------------
    # Case 2: multiple named locations exist, but
    # 2a. no Canada-only named location and no 'all-countries' except Canada named location found
    # 2b. no valid IP-based named location found
    # return non-compliant
    # ---------------------------------------------------------------

    if ($locations.Count -gt 1 -and ($validLocations.Count -eq 0 -and $nonCAnamedLocations.Count -eq 0) -and $validIpLocations -eq 0){
        Write-Warning "Warning: No Canada-only named locations found or no non-Canada all-country named locations found or no IP-based valid named locations found. Cannot evaluate Conditional Access Policies for compliance."
        $ErrorList.Add("No Canada-only named locations found or no IP-based valid named locations found. Cannot evaluate Conditional Access Policies for compliance.") | Out-Null
        $IsCompliant = $false
        $Comments = $msgTable.noCanadaNamedLocationFound + " " + $msgTable.noCAallLocationsNonCompliant + " " + $msgTable.noValidIPLocationsNonCompliant

        $PsObject = [PSCustomObject]@{
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
            Errors           = $ErrorList
        }
        
        return $PsObject
    }
    
    # Case 2/3/4/5/6: next evaluation step

    # Filter enabled CAPs
    $enabledCAPs = $caps | Where-Object { $_.state -eq 'enabled' }
    # If no enabled CAPs found, return non-compliant
    if ($null -eq $enabledCAPs -or $enabledCAPs.Count -eq 0) {
        Write-Host "No enabled Conditional Access Policies found."
        $ErrorList.Add("No enabled Conditional Access Policies found. Cannot evaluate Conditional Access Policies for compliance.") | Out-Null
        $Comments = $msgTable.noEnabledPoliciesFound
        $IsCompliant = $false

        $PsObject = [PSCustomObject]@{
            ComplianceStatus = $IsCompliant
            ControlName      = $ControlName
            Comments         = $Comments
            ItemName         = $ItemName
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
            Errors           = $ErrorList
        }
        return $PsObject
    }
    
    Write-Host "Found $($enabledCAPs.Count) enabled Conditional Access Policies."

    #  ---------Evaluate CAPs for patterns that effectively restrict access to Canada ---------------#
    # COMPLIANT PATTERNS: Compliant if CAPs found that match the patterns below:
    #  A-1) Pattern A:          Policy explicitly includes a named location that represents 'all countries except Canada' (make sure all countries are included) AND action is Block
    #  A-2) IP-based Pattern A: Policy explicitly includes a all non-trusted IP ranges that represents 'all IP ranges except trusted IP ranges' (make sure all other IP ranges are included) AND action is Block
    #  B-1) Pattern B:          Policy includes 'all' locations and explicitely excludes the Canada-only named-location id AND action is Block (i.e. block all except Canada)
    #  B-2) IP-based Pattern B: Policy includes 'all' (or equivalent) locations but explicitly excludes a 'valid IP only' named locaition id (if no country-based Locations included)
    #  C-1) Pattern C:          Policy has no includeLocations but EXCLUDES the Canada-only named-location id (conservative treat as location-based)
    #  C-2) IP-based Pattern C: Policy has no includeLocations but explicitely EXCLUDES the valid IP-based named locations(conservative detection)
    
    # NON-COMPLIANT PATTERNS: Non-Compliant if CAPs found that match the patterns below:
    #  D-1) Pattern D:          Policy explicitly includes the Canada-only named-location id AND action is Grant, but none in exclusion (i.e. allow only Canada)
    #  D-2) IP-based Pattern D: Policy explicitly includes all the valid IP-ranges based named location AND action is Grant, but none in exclusion -> can represent "allow only valid IPs but other IPs  not excluded
    #  E-1) Pattern E:          Policy explicitly includes a named location that represents some countries except Canada AND action is Block
    #  E-2) IP-based Pattern E: Policy explicitly includes a named location that represents some of the required IPs (not ALL) AND action is Block
    #  ----------------------------------------------------------------------------------------------#

    # Common synonyms for "all" locations in various CAP outputs
    $allLocationsSym = @('all','any','alltrusted','alltrustedlocations','alllocations')

    # $locationBasedPolicies =  $enabledCAPs | Where-Object {($null -ne $_.conditions.locations) -and ($validLocations.id -in $_.conditions.locations.includeLocations) -or ($validLocations.id -in $_.conditions.locations.excludeLocations ) }
    
    # Find CAPs with Location conditions
    $locationBasedPolicies =  $enabledCAPs | Where-Object {($null -ne $_.conditions) -and ($null -ne $_.conditions.locations) }

    # validlocationBasedPolicies includes both country-based and IP-based location policy
    $validlocationBasedPolicies = @()
    foreach ($cap in $locationBasedPolicies) {
        try {
            $locationCondition = $cap.conditions.locations
            # include/exclude lists
            $includes = @()
            $excludes = @()
            if ($locationCondition.includeLocations -and $locationCondition.PSObject.Properties.Match('includeLocations').Count -gt 0 ) {
                $includeVals = @( $locationCondition.includeLocations )
                $includes = $includeVals | ForEach-Object { $_.ToString().ToLower() }
            }
            if ($locationCondition.excludeLocations -and $locationCondition.PSObject.Properties.Match('excludeLocations').Count -gt 0) {
                $excludeVals = @( $locationCondition.excludeLocations )
                $excludes = $excludeVals | ForEach-Object { $_.ToString().ToLower() }
            }
            # Determine the CAP's grant controls
            $grantControls = @()
            $grantBuiltIns = @()    
            if ($cap.grantControls -and $cap.PSObject.Properties.Match('grantControls').Count -gt 0) {
                $grantControls = @($cap.grantControls.buildInControls )
                try {
                    if ($cap.grantControls.PSObject.Properties.Match('builtInControls').Count -gt 0 -and $cap.grantControls.builtInControls) {
                        $grantBuiltIns = @($cap.grantControls.builtInControls) | ForEach-Object { $_.ToString().ToLower() }
                    }
                } catch { 
                    Write-Warning "Warning: Unable to process grantControls builtInControls for CAP '$($cap.id)': $_"
                }
            }
            # Check for Grant/Block action in grant controls
            $isBlockAction = $false
            $isGrantAction = $false
            if ($grantControls -contains 'block' -or $grantBuiltIns -contains 'block') {
                $isBlockAction = $true
            }
            else{
                $isGrantAction = $true
            }
            # Evaluate patterns
            $matched = $false

            # Pattern A: explicitly includes a named location of 'All' countries but does not have Canada in it  -> can represent "block all except Canada"
            # PASS
            if ($includes | Where-Object { $nonCAnamedLocationsIds -contains $_ }) {
                if ($isBlockAction) {
                    $matched = $true
                }
            }

            # IP-based Pattern A: explicitly includes a all non-trusted IP ranges that represents 'all IP ranges except trusted IP ranges' (make sure all other IP ranges are included) AND action is Block
            # PASS
            if ($includes | Where-Object { $notValidIpLocationIds -contains $_ }) {
                if ($isBlockAction) {
                    $matched = $true
                }
            }

            # Pattern B: includes 'all' (or equivalent) but explicitly excludes Canada-only named location -> can represent "block all except Canada"
            # PASS
            if (($includes | Where-Object { $allLocationsSym -contains $_ }) -and ($excludes | Where-Object { $validLocationIds -contains $_ })) {
                if ($isBlockAction) {
                    $matched = $true
                }
            }

            # IP-based Pattern B: includes 'all' (or equivalent) locations but explicitly excludes a 'valid IP only' named locaition id (if no country-based Locations included)
            # Semantics: block everyone except the allowed IP ranges (which is equivalent of country in Pattern B)
            # PASS
            # if( $isIpLocationBasedCap -and ($includes | Where-object {$allLocationsSym -contains $_}) -and ($excludes | Where-Object { $validIpLocationIds -contains $_ })){
            if(($includes | Where-object {$allLocationsSym -contains $_}) -and ($excludes | Where-Object { $validIpLocationIds -contains $_ })){
                if ($isBlockAction) {
                    $matched = $true
                }
            }
            # Pattern C: no includes but explicitely exclude Canada-only named locations(conservative detection)
            # PASS
            if ($includes.Count -eq 0 -and ($excludes | Where-Object { $validLocationIds -contains $_ })) {
                if ($isBlockAction) {
                    $matched = $true
                }
            }
            # IP-based Pattern C: no includes but explicitely exclude IP-based named locations(conservative detection)
            # PASS
            if (($includes.Count -eq 0 -and ($excludes | Where-Object { $validIpLocationIds -contains $_ }))) {
                if ($isBlockAction) {
                    $matched = $true
                }
            }
            # Pattern D: explicit inclusion of Canada-only named location, no exclusion -> can represent "allow only Canada but other countries not excluded
            # FAIL
            if ($includes | Where-Object { $validLocationIds -contains $_ }) {
                if ($isGrantAction) {
                    $matched = $false
                }
            }
            # IP-based Pattern D: explicit inclusion of ALL valid IPs in named location, no exclusion -> can represent "allow only valid IPs but other countries not excluded
            # FAIL
            if ($includes | Where-Object { $validIpLocationIds -contains $_ }) {
                if ($isGrantAction) {
                    $matched = $false
                }
            }
            # Pattern E: explicit inclusion of some countries except Canada -> can represent "block some countries except Canada"
            # FAIL
            if ($someNonCAnamedLocationsIds | Where-Object { $includes -contains $_ }) {
                if ($isBlockAction) {
                    $matched = $false
                }
            }
            # IP-based Pattern E: explicit inclusion of some (not ALL) of the required IPs in named location -> can represent "block some countries except Canada"
            # FAIL
            if ($someNotValidIpnamedLocationsIds | Where-Object { $includes -contains $_ }) {
                if ($isBlockAction) {
                    $matched = $false
                }
            }
            

            Write-Host "CAP Found $($cap.displayName) with include and/or exclude location condition that has a match '$($matched)' with '$($grantBuiltIns)' access control"
            if ($matched) {
                $validlocationBasedPolicies += $cap
                Write-Host "Valid Canada-only location CAP Found: $($cap.displayName)"
            }

        }
        catch {
            $ErrorList.Add("Error evaluating CAP '$($cap.id)' : $_") | Out-Null
            continue
        }
        
        # Determine compliance based on presence of named-location and matching policies
        if ($null -eq $validlocationBasedPolicies -or ($validlocationBasedPolicies.Count -eq 0) ){
            # Non-complient; No policies have valid locations
            $Comments = $msgTable.noCompliantPoliciesfound
            $IsCompliant = $false
        }
        elseif ($validlocationBasedPolicies.count -ne 0) {
            # Compliant; valid policies found
            $validCAPnames = ($validlocationBasedPolicies | Select-Object -ExpandProperty displayName) -join ', '
            $IsCompliant = $true
            # display all names of compliant CAPs in Comments
            $Comments = $msgTable.allPoliciesAreCompliant -f $validCAPnames
        }
        else{
            # Do nothing; all use cases are covered
        }
    }
    
    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        Comments         = $Comments
        ItemName         = $ItemName
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
        Errors           = $ErrorList
    }
    return  $PsObject

}


function Test-PolicyExemptionExists {
    param (
        [string] $ScopeId,
        [array]  $requiredPolicyExemptionIds
    )
    [PSCustomObject] $policyExemptionList = New-Object System.Collections.ArrayList     
    # Az 15 returns this list through the singular generated-model property name.
    $exemptionsIds = (Get-AzPolicyExemption -Scope $ScopeId).PolicyDefinitionReferenceId
    $isExempt =  $false

    if ($null -ne $exemptionsIds)
    {
        foreach ($exemptionId in $exemptionsIds)
        {
            if ($exemptionId -in $requiredPolicyExemptionIds){
                $isExempt = $true

                # if exempted, add to the list
                $result = [PSCustomObject] @{
                    isExempt = $isExempt 
                    exemptionId = $exemptionId
                }
                $policyExemptionList.add($result)
            }

        }
    }
    return $policyExemptionList
    
}

function Test-ComplianceForSubscription {
    param (
        [System.Object] $obj,
        [System.Object] $subscription,
        [string] $PolicyID,
        [array]  $requiredPolicyExemptionIds,
        [string] $objType
    )
    $strPattern = "/providers/microsoft.authorization/policysetdefinitions/(.*)"
    if ($PolicyID -match $strPattern){
        $PolicyID = $matches[1]
    }
    Write-Host "Get compliance details for Subscription : $($subscription.DisplayName)"
    $complianceDetails = @()
    $policySetDefinitionName = $PolicyID
    $policyFilters = @()
    $subscriptionFilter = "SubscriptionId eq '$($subscription.SubscriptionID)'"
    foreach ($policyRef in $requiredPolicyExemptionIds) {
        if (-not [string]::IsNullOrWhiteSpace($policyRef)) {
            $policyFilters += "PolicyDefinitionReferenceId eq '$policyRef'"
        }
    }
    if ($policyFilters.Count -gt 0) {
        $filterExpression = "$subscriptionFilter and PolicySetDefinitionName eq '$policySetDefinitionName' and (" + ($policyFilters -join " or ") + ")"
    }
    else {
        $filterExpression = "$subscriptionFilter and PolicySetDefinitionName eq '$policySetDefinitionName'"
    }

    $filteredQueryFailed = $true
    if ($filterExpression) {
        $filteredQueryFailed = $false
        try {
            Write-Verbose "Querying policy state with filter: $filterExpression"
            $complianceDetails = @(Get-AzPolicyState -Filter $filterExpression | Where-Object{ $_.SubscriptionId -eq $($subscription.SubscriptionID) })
        }
        catch {
            Write-Verbose "Filtered Get-AzPolicyState call failed, falling back to unfiltered query. Error: $_"
            $filteredQueryFailed = $true
        }
    }

    if ($filteredQueryFailed) {
        $complianceDetails = @(Get-AzPolicyState | Where-Object{ $_.SubscriptionId -eq $($subscription.SubscriptionID) } | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID})
    }

    if ($complianceDetails.Count -eq 0) {
        $complianceDetails = $null
    }
    
    If ($null -eq $complianceDetails) {
        Write-Host "No compliance details found for Management Group : $($obj.DisplayName) and subscription: $($subscription.DisplayName)"
    }
    else{   
        $complianceDetails = $complianceDetails | Where-Object{$_.PolicyAssignmentScope -like "*$($obj.TenantId)*" }
        $requiredPolicyExemptionIds_smallCaps = @()
        foreach ($str in $requiredPolicyExemptionIds) {
            $requiredPolicyExemptionIds_smallCaps += $str.ToLower()
        }
        # Filter for required policies
        $complianceDetails = $complianceDetails | Where-Object{ $_.PolicyDefinitionReferenceId -in $requiredPolicyExemptionIds_smallCaps}
        if ($objType -eq "subscription"){
            Write-Host "$($complianceDetails.count) Compliance details found for subscription: $($subscription.DisplayName)"
        }
        else {
            Write-Host "$($complianceDetails.count) Compliance details found for Management Group : $($obj.DisplayName) and subscription: $($subscription.DisplayName)"                            
        }
        
    }

    return $complianceDetails
}


function Check-PBMMPolicies {
    param (
        [System.Object] $objList,
        [string] $objType, #subscription or management Group
        [array]  $requiredPolicyExemptionIds,
        [string] $PolicyID,
        [string] $ControlName,
        [string] $ItemName,
        [string] $LogType,
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [string] $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] $EnableMultiCloudProfiles,
        [System.Object] $skippedObjList

    )   
    [System.Collections.ArrayList] $tempObjectList = New-Object System.Collections.ArrayList
    $policyAssignmentCache = @{}
    $policySetDefinitionCache = @{}

    foreach ($skippedObj in $skippedObjList){
        $notEvaluatedResult = [PSCustomObject]@{
            Type                = [string]$objType
            Id                  = [string]$skippedObj.Id
            # Only populate SubscriptionName for subscription-scoped rows; other row types (tenant/resource) would be misleading.
            SubscriptionName = $(if ($objType -eq "subscription") { [string]$skippedObj.Name } else { "" })
            ComplianceStatus = [boolean]$false
            Comments = ''
            ItemName = [string]$ItemName
            itsgcode = [string]$itsgcode
            ControlName = [string]$ControlName
            ReportTime = [string]$ReportTime
        }
        $notEvaluatedResult = Set-SubscriptionNotEvaluatedStatus -Result $notEvaluatedResult -SubscriptionName $skippedObj.Name -msgTable $msgTable
        $tempObjectList.Add($notEvaluatedResult) | Out-Null
    }

    foreach ($obj in $objList)
    {
        Write-Verbose "Checking $objType : $($obj.Name)"
        Write-Verbose "PBMM policy PolicyID is $PolicyID"

        if ([string]::IsNullOrWhiteSpace($PolicyID)) {
            Write-Error "PolicyID is null or empty. Skipping PBMM evaluation for scope '$($obj.Id)'."
            continue
        }

        # Find scope
        if ($objType -eq "subscription"){
            $tempId="/subscriptions/$($obj.Id)"
        }
        else {
            $tempId=$obj.Id                              
        }
        Write-Host "Scope is $tempId"

        # Find assigned policy list from PBMM policy for the scope
        # Accept tenant, management group, or subscription scoped IDs that end with /policySetDefinitions/{id}
        if ($PolicyID.StartsWith("/") -and $PolicyID -match "/policySetDefinitions/[^/]+$") {
            $policyDefinitionIdFilter = $PolicyID
        }
        else {
            $policyDefinitionIdFilter = "/providers/Microsoft.Authorization/policySetDefinitions/$PolicyID"
        }

        $assignmentCacheKey = "$tempId|$policyDefinitionIdFilter"
        if ($policyAssignmentCache.ContainsKey($assignmentCacheKey)) {
            $AssignedPolicyList = $policyAssignmentCache[$assignmentCacheKey]
        }
        else {
            # The PowerShell 7.6 runtime uses Az 15, where assignment fields are returned directly.
            $AssignedPolicyList = Get-AzPolicyAssignment -Scope $tempId -PolicyDefinitionId $policyDefinitionIdFilter
            $policyAssignmentCache[$assignmentCacheKey] = $AssignedPolicyList
        }

        # Az 15 calls this list `NotScope` in its generated model. A missing list is null, which
        # PowerShell would otherwise count as one item, so remove null values before counting.
        $hasExcludedScopes = @($AssignedPolicyList.NotScope | Where-Object { $null -ne $_ }).Count -gt 0
        If ($null -eq $AssignedPolicyList -or $hasExcludedScopes)
        {
            # PBMM initiative not applied
            $ComplianceStatus=$false
            $Comment = $msgTable.isNotCompliant + ' ' + $msgTable.pbmmNotApplied 
        }
        else {
            # PBMM initiative applied
            $Comment = $msgTable.pbmmApplied

            # List the policies within the PBMM initiative (policy set definition)
            if ($PolicyID.StartsWith("/") -and $PolicyID -match "/policySetDefinitions/[^/]+$") {
                $policySetCacheKey = $PolicyID
            }
            else {
                $policySetCacheKey = "/providers/Microsoft.Authorization/policySetDefinitions/$PolicyID"
            }

            if ($policySetDefinitionCache.ContainsKey($policySetCacheKey)) {
                $policySetDefinition = $policySetDefinitionCache[$policySetCacheKey]
            }
            else {
                try {
                    $policySetDefinition = Get-AzPolicySetDefinition -Id $policySetCacheKey
                    $policySetDefinitionCache[$policySetCacheKey] = $policySetDefinition
                }
                catch {
                    Write-Verbose "Direct lookup for policy set '$policySetCacheKey' failed. Falling back to tenant scan. Error: $_"
                    $policySetDefinition = Get-AzPolicySetDefinition | `
                        Where-Object { $_.Id -like "*$PolicyID*" }
                }
            }

            $listPolicies = $policySetDefinition.PolicyDefinition
            # Check all 3 policies are applied for this scope
            $appliedPolicies = $listPolicies.policyDefinitionReferenceId | Where-Object { $requiredPolicyExemptionIds -contains $_ }
            if($appliedPolicies.Count -ne  $requiredPolicyExemptionIds.Count){
                # some required policies are not applied
                $ComplianceStatus=$false
                $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' ' + $msgTable.reqPolicyNotApplied
            }
            else{
                # All 3 required policies are applied
                $Comment += ' ' + $msgTable.reqPolicyApplied

                # PBMM is applied and not excluded. Testing if specific policies haven't been exempted.
                $policyExemptionList = Test-PolicyExemptionExists -ScopeId $tempId -requiredPolicyExemptionIds $requiredPolicyExemptionIds

                $exemptList = $policyExemptionList.exemptionId
                # $nonExemptList = $policyExemptionList | Where-Object { $_.isExempt -eq $false }
                if ($ExemptList.Count -gt 0){   
                    
                    # join all exempt policies to a string
                    if(-not($null -eq $exemptList)){
                        $exemptListAllPolicies = $exemptList -join ", "
                    }
                    # boolean, exemption for GR, required policies exists.
                    $ComplianceStatus=$false
                    $Comment += ' '+ $msgTable.grExemptionFound -f $exemptListAllPolicies

                }
                else {
                     # Required Policy Definitions are not exempt. Find compliance details for the assigned PBMM policy
                    $Comment += ' ' + $msgTable.grExemptionNotFound

                    # Check the number of resources and compliance for the required policies in applied PBMM initiative
                    # ----------------#
                    # Subscription
                    # ----------------#
                    if ($objType -eq "subscription"){
                        Write-Host "Find compliance details for Subscription : $($obj.Name)"
                        $subscription = @()
                        $subscription += New-Object -TypeName psobject -Property ([ordered]@{'DisplayName'=$obj.Name;'SubscriptionID'=$obj.Id})
                        
                        $currentSubscription = Get-AzContext
                        if($currentSubscription.Subscription.Id -ne $subscription.SubscriptionId){
                            # Set Az context to this subscription
                            Set-AzContext -SubscriptionId $subscription.SubscriptionID | Out-Null
                            Write-Host "AzContext set to $($subscription.DisplayName)"
                        }
    
                        $complianceDetailsSubscription = Test-ComplianceForSubscription -obj $obj -subscription $subscription -PolicyID $PolicyID -requiredPolicyExemptionIds $requiredPolicyExemptionIds -objType $objType

                        if ($null -eq $complianceDetailsSubscription) {
                            Write-Host "Compliance details for $($subscription.DisplayName) outputs as NULL"
                            $complianceDetailsList = $null
                        }
                        else{
                            if($complianceDetailsSubscription.Count -lt 2){
                                $complianceDetailsList = $complianceDetailsSubscription[0] | Select-Object `
                                    Timestamp, ResourceId, ResourceLocation, ResourceType, SubscriptionId, `
                                    ResourceGroup, PolicyDefinitionName, ManagementGroupIds, PolicyAssignmentScope, IsCompliant, `
                                    ComplianceState, PolicyDefinitionAction, PolicyDefinitionReferenceId, ResourceTags, ResourceName
                            }
                            else{
                                $complianceDetailsList = $complianceDetailsSubscription | Select-Object `
                                    Timestamp, ResourceId, ResourceLocation, ResourceType, SubscriptionId, `
                                    ResourceGroup, PolicyDefinitionName, ManagementGroupIds, PolicyAssignmentScope, IsCompliant, `
                                    ComplianceState, PolicyDefinitionAction, PolicyDefinitionReferenceId, ResourceTags, ResourceName
                            }
                            
                            if (-not ($complianceDetailsList -is [System.Array])) {
                                $complianceDetailsList = @($complianceDetailsList)
                            }
                        }

                    }

                    if ($null -eq $complianceDetailsList) {
                        # PBMM applied but complianceDetailsList is null i.e. no resources in this subcription to apply the required policies
                        Write-Host "Check for compliance details; outputs as NULL"
                        $resourceCompliant = 0 
                        $resourceNonCompliant = 0
                        $totalResource = 0
                        $countResourceCompliant = 0 
                        $countResourceNonCompliant = 0          
                    }
                    else{
                        # # check the compliant & non-compliant resources only for $requiredPolicyExemptionIds policies
                        $totalResource = $complianceDetailsList.Count

                        # #-------------# #
                        # # Compliant
                        # #-------------# #
                        # List compliant resource
                        if ( $complianceDetailsList.Count -eq 1){
                            $resourceCompliant = $complianceDetailsList[0] | Where-Object {$_.ComplianceState -eq "Compliant"}
                        }
                        else{
                            $resourceCompliant = $complianceDetailsList | Where-Object {$_.ComplianceState -eq "Compliant"}
                        }
                        if (-not ($resourceCompliant -is [System.Array])) {
                            $resourceCompliant = @($resourceCompliant)
                        }
                        if ($null -eq $resourceCompliant){
                            Write-Host "resourceCompliant is null"
                            $countResourceCompliant = 0
                        }
                        else{
                            Write-Host "resourceCompliant is not null"
                            $countResourceCompliant = $resourceCompliant.Count
                        }
                        
                        # #-------------##
                        # # Non-compliant
                        # #-------------##
                        # List non-compliant resources
                        $resourceNonCompliant = $complianceDetailsList | Where-Object {$_.ComplianceState -eq "NonCompliant"}
                        if (-not ($resourceNonCompliant -is [System.Array])) {
                            $resourceNonCompliant = @($resourceNonCompliant)
                        }
                        $countResourceNonCompliant = $resourceNonCompliant.Count
                    }
                    
                    # # ---------------------------------------------------------------------------------
                    # At this point PBMM initiative is applied. All 3 policies are applied. No exemption.
                    # # ---------------------------------------------------------------------------------

                    # Count Compliant & non-compliant resources and Total resources
                    if($totalResource -eq 0){
                        # complianceDetailsList is null i.e no resources to apply the required policies in this subscription
                        $ComplianceStatus=$true
                        $Comment = $msgTable.isCompliant + ' ' + $Comment + ' '+ $msgTable.noResource
                    }
                    elseif($totalResource -gt 0 -and ($countResourceCompliant -eq $totalResource)){
                        # All resources are compliant
                        $ComplianceStatus=$true
                        $Comment = $msgTable.isCompliant + ' ' + $Comment + ' '+ $msgTable.allCompliantResources
                    }
                    elseif($totalResource -gt 0 -and ($countResourceNonCompliant -eq $totalResource)){
                        # All resources are non-compliant
                        $ComplianceStatus=$false
                        $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' '+ $msgTable.allNonCompliantResources
                    }
                    elseif($totalResource -gt 0 -and $countResourceNonCompliant -gt 0 -and ($countResourceNonCompliant -lt $totalResource)){
                        # There are some resources that are non-compliant
                        $ComplianceStatus=$false
                        $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' '+ $msgTable.hasNonComplianceResource -f $countResourceNonCompliant, $totalResource
                    }
                    else{
                        Write-host "All use cases are addressed."
                        # Do nothing 
                    }                   
                }

            }
        }

        # Add to the Object List 
        $props = @{
            Type = [string]$objType
            Id = [string]$obj.Id
            # Only populate SubscriptionName for subscription-scoped rows; other row types (tenant/resource) would be misleading.
            SubscriptionName = $(if ($objType -eq "subscription") { [string]$obj.Name } else { "" })
            ComplianceStatus = [boolean]$ComplianceStatus
            Comments = [string]$Comment
            ItemName = [string]$ItemName
            itsgcode = [string]$itsgcode
            ControlName = [string]$ControlName
            ReportTime = [string]$ReportTime
        }
        if ($objType -ne "subscription") {
            # For non-subscription rows, keep Name/DisplayName as entity labels; subscription rows rely on SubscriptionName to avoid duplicate labels.
            $name = [string]$obj.Name
            $props.Name = $name
            $props.DisplayName = if ([string]::IsNullOrWhiteSpace([string]$obj.DisplayName)) { $name } else { [string]$obj.DisplayName }
        }
        $c = New-Object -TypeName PSCustomObject -Property $props

        if ($EnableMultiCloudProfiles) {
            if ($objType -eq "subscription") {
                $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $obj.Id
            } else {
                $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
            }
            
            if (!$evalResult.ShouldEvaluate) {
                if(!$evalResult.ShouldAvailable ){
                    if ($evalResult.Profile -gt 0) {
                        $c.ComplianceStatus = "Not Applicable"
                        $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                        $c.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
                    } else {
                        $ErrorList.Add("Error occurred while evaluating profile configuration availability")
                    }
                } else {
                    if ($evalResult.Profile -gt 0) {
                        $c.ComplianceStatus = "Not Applicable"
                        $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                        $c.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
                    } else {
                        $ErrorList.Add("Error occurred while evaluating profile configuration")
                    }
                }
            } else {
                
                $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
            }
        }        
        
        $tempObjectList.add($c)| Out-Null
    }
    return $tempObjectList
}

# Used in AlersMonitor and UserAccountGCEventLogging
function get-AADDiagnosticSettings {
    $apiUrl = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings?api-version=2017-04-01-preview"
    $response = Invoke-AzRestMethod -Uri $apiUrl -Method Get -ErrorAction Stop
    if ($response.StatusCode -eq 200) {
        return ($response.Content | ConvertFrom-Json).value
    }
    throw "Failed to retrieve diagnostic settings. Status code: $($response.StatusCode)"
}


# USE OF THIS FUNCITON: GR2 V10 and V3 automated role reviews
function Expand-ListColumns {
    param (
        [Parameter(Mandatory = $true)]
        [Array]$accessReviewList  # The input list of access review objects
    )

    $expandedList = @()

    # Iterate through each item in the $accessReviewList
    foreach ($reviewInfo in $accessReviewList) {
        # Determine the maximum number of elements in the lists you want to expand
        $maxCount = @(
            $reviewInfo.AccessReviewScopeList.Count,
            $reviewInfo.AccessReviewResourceScopeList.Count,
            $reviewInfo.AccessReviewReviewerList.Count
        ) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

        # Expand the lists by iterating through each element
        for ($i = 0; $i -lt $maxCount; $i++) {
            $expandedReviewInfo = [PSCustomObject]@{
                AccessReviewName                            = $reviewInfo.AccessReviewName
                AccessReviewInstanceId                      = $reviewInfo.AccessReviewInstanceId
                DescriptionForAdmins                        = $reviewInfo.DescriptionForAdmins
                DescriptionForReviewers                     = $reviewInfo.DescriptionForReviewers
                AccessReviewCreatedBy                       = $reviewInfo.AccessReviewCreatedBy
                AccessReviewStartDate                       = $reviewInfo.AccessReviewStartDate
                AccessReviewEndDate                         = $reviewInfo.AccessReviewEndDate
                AccessReviewStatus                          = $reviewInfo.AccessReviewStatus
                AccesReviewRecurrenceType                   = $reviewInfo.AccesReviewRecurrenceType
                AccesReviewRecurrencePattern                = $reviewInfo.AccesReviewRecurrencePattern
                AccessReviewScope                           = if ($reviewInfo.AccessReviewScopeList.Count -eq 1) { $reviewInfo.AccessReviewScopeList} else { if ($reviewInfo.AccessReviewScopeList.Count -gt $i) { $reviewInfo.AccessReviewScopeList[$i] } else {$null}}
                AccessReviewReviewer                        = if ($reviewInfo.AccessReviewReviewerList.Count -eq 1) { $reviewInfo.AccessReviewReviewerList} else { if ($reviewInfo.AccessReviewReviewerList.Count -gt $i) { $reviewInfo.AccessReviewReviewerList[$i] } else { $null }}
                AccessReviewResourceScope                   = if ($reviewInfo.AccessReviewResourceScopeList.Count -eq 1) { $reviewInfo.AccessReviewResourceScopeList} else { if ($reviewInfo.AccessReviewResourceScopeList.Count -gt $i) { $reviewInfo.AccessReviewResourceScopeList[$i] } else { $null }}
            }

            # Add the expanded row to the new list
            $expandedList += $expandedReviewInfo
        }
    }

    # Return the expanded list
    return $expandedList
}

function Add-ProfileInformation {
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$Result,
        [string]$CloudUsageProfiles,
        [string]$ModuleProfiles,
        [string]$SubscriptionId,
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )
    
    if($null -eq $SubscriptionId){
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
    }else{
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID
    }

    if (!$evalResult.ShouldEvaluate) {
        if(!$evalResult.ShouldAvailable ){
            if ($evalResult.Profile -gt 0) {
                $Result.ComplianceStatus = "Not Applicable"
                $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $Result.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration availability")
            }
        } else {
            if ($evalResult.Profile -gt 0) {
                $Result.ComplianceStatus = "Not Applicable"
                $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $Result.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        }
    } else {
        $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
    }
    return $Result
}

function Check-BuiltInPoliciesPerSubscription {
    param (
        [Parameter(Mandatory = $true)]
        [array]$requiredPolicyIds,
        [Parameter(Mandatory = $true)]
        [string]$ReportTime,
        [Parameter(Mandatory = $true)]
        [string]$ItemName,
        [Parameter(Mandatory = $true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory = $true)]
        [string]$ControlName,
        [string]$itsgcode,
        [string]$CloudUsageProfiles = "3",
        [string]$ModuleProfiles,
        [switch]$EnableMultiCloudProfiles,
        [System.Collections.ArrayList]$ErrorList
    )


    # $subscriptions = Get-AzSubscription
    # $results = New-Object System.Collections.ArrayList
    $allSubscriptions = Get-AzSubscription
    $subscriptions = $allSubscriptions | Where-Object { $_.State -eq 'Enabled' }
    $skippedSubscriptions = $allSubscriptions | Where-Object { $_.State -ne 'Enabled' }
    
    
    $results = New-Object System.Collections.ArrayList
    foreach ($skippedSubscription in $skippedSubscriptions) {
        $notEvaluatedResult = [PSCustomObject]@{
            Type                = "subscription"
            Id                  = $skippedSubscription.Id
            SubscriptionName    = $skippedSubscription.Name
            ComplianceStatus    = false
            Comments            = ""
            ItemName            = "$ItemName"
            ControlName         = $ControlName
            ReportTime          = $ReportTime
            itsgcode            = $itsgcode
        }
        $notEvaluatedResult = Set-SubscriptionNotEvaluatedStatus -Result $notEvaluatedResult -SubscriptionName $skippedSubscription.Name -msgTable $msgTable
        $results.Add($notEvaluatedResult) | Out-Null
    }

    foreach ($subscription in $subscriptions) {
        try {
            Set-AzContext -SubscriptionId $subscription.Id -ErrorAction Stop
            $scope = "/subscriptions/$($subscription.Id)"
            Write-Host "Checking policies for subscription: $($subscription.Name) [$($subscription.Id)]"
        } catch {
            $ErrorList.Add("Error setting context for subscription $($subscription.Id): $_")
            continue
        }
        $result = Check-BuiltInPolicies -requiredPolicyIds $requiredPolicyIds -ReportTime $ReportTime -ItemName $ItemName -msgTable $msgTable -ControlName $ControlName -subScope $scope -subscription $subscription -itsgcode $itsgcode -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -EnableMultiCloudProfiles -ErrorList $ErrorList
        $results.Add($result)
    }
    Write-Host "Completed policy compliance check. Found $($results.Count) results ($skippedSubscriptions.Count) subscription(s) not enabled)."
    return $results
}


function Check-BuiltInPolicies {
    param (
        [Parameter(Mandatory=$true)]
        [array]$requiredPolicyIds,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [string]$subScope, #optional param to check a specific subscription
        $subscription,
        [string]$itsgcode,
        [string]$CloudUsageProfiles = "3",
        [string]$ModuleProfiles,
        [switch]$EnableMultiCloudProfiles,
        [System.Collections.ArrayList]$ErrorList
    )
    
    $results = New-Object System.Collections.ArrayList
    
    if($subScope){$rootScope = $subScope}
    else{
        # Get tenant root management group
        try {
            $tenantId = (Get-AzContext).Tenant.Id
            $rootScope = "/providers/Microsoft.Management/managementGroups/$tenantId"
        } catch {
            $ErrorList.Add("Error getting tenant context: $_")
            return $results
        }
    }

    Write-Host "Starting policy compliance check for tenant: $tenantId"
    
    foreach ($policyId in $requiredPolicyIds) {
        Write-Host "Checking policy assignment for policy ID: $policyId"
        
        # Get policy definition details
        try {
            $policyDefinition = Get-AzPolicyDefinition -Id $policyId -ErrorAction Stop
            $policyDisplayName = $policyDefinition.DisplayName
        } catch {
            $ErrorList.Add("Error getting policy definition: $_")
            $policyDisplayName = "Unknown Policy"
            return $results
        }
        
        # Check for policy assignments at tenant level
        try {
            $assignments = Get-AzPolicyAssignment -Scope $rootScope -PolicyDefinitionId $policyId -ErrorAction Stop
            $tenantPolicyAssignments = @()
            if ($assignments -is [array]) {
                $tenantPolicyAssignments = $assignments | Where-Object { $null -ne $_ }
            } else {
                if ($null -ne $assignments) {
                    $tenantPolicyAssignments += $assignments
                }
            }            
        } catch {
            $ErrorList.Add("Error getting policy assignments for policy $policyId : $_")
            $tenantPolicyAssignments = @()
        }
        
        # Check if we have any policy assignments (not null and not empty)
        if ($null -ne $tenantPolicyAssignments -and $tenantPolicyAssignments.Count -gt 0) {
            Write-Host "Found $($tenantPolicyAssignments.Count) assignments matching this policy ID"
            
            $hasExemptions = $false
            
            # Check for policy exemptions
            foreach ($assignment in $tenantPolicyAssignments) {
                try {
                    if ($null -ne $assignment -and -not [string]::IsNullOrWhiteSpace($assignment.Id)) {
                        Write-Host "Checking exemptions for assignment: $($assignment.Id)"
                        $policyExemptions = Get-AzPolicyExemption -Scope $rootScope -PolicyAssignmentIdFilter $assignment.Id -ErrorAction Stop
                        if ($policyExemptions) {
                            $hasExemptions = $true
                            break
                        }
                    } else {
                        Write-Host "Skipping exemption check for invalid assignment"
                        continue
                    }
                } catch {
                    $ErrorList.Add("Error checking policy exemptions: $_")
                }
                continue
            }
            
            if ($hasExemptions) {
                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        SubscriptionName = $subscription.Name
                        ComplianceStatus = $false
                        Comments = $msgTable.policyHasExemptions
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "Tenant ($tenantId)"
                        DisplayName = "Tenant ($tenantId)"
                        ComplianceStatus = $false
                        Comments = $msgTable.policyHasExemptions
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                $results.Add($result) | Out-Null
                continue
            }

            Write-Host "Policy is assigned at tenant level. Checking compliance states..."
            
            # Get all policy states for this policy
            $policyStates = Get-AzPolicyState | Where-Object { $_.PolicyDefinitionId -eq $policyId }

            # If no resources are found that the policy applies to
            if ($null -eq $policyStates -or $policyStates.Count -eq 0) {

                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        SubscriptionName = $subscription.Name
                        ComplianceStatus = $true
                        Comments = $msgTable.policyNoApplicableResourcesSub
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "Tenant ($tenantId)"
                        DisplayName = "Tenant ($tenantId)"
                        ComplianceStatus = $true
                        Comments = $msgTable.policyNoApplicableResources
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                
                $results.Add($result) | Out-Null
                continue
            }

            # Check if any resources are non-compliant
            $nonCompliantResources = $policyStates | 
                Where-Object { $_.ComplianceState -eq "NonCompliant" -or $_.IsCompliant -eq $false }
            
            if ($nonCompliantResources) {
                Write-Host "Found $($nonCompliantResources.Count) non-compliant resources"
                foreach ($resource in $nonCompliantResources) {
                    $result = [PSCustomObject]@{
                        Type = $resource.ResourceType
                        Id = $resource.ResourceId
                        Name = $resource.ResourceGroup + "/" + ($resource.ResourceId -split '/')[-1]
                        DisplayName = $resource.ResourceGroup + "/" + ($resource.ResourceId -split '/')[-1]
                        ComplianceStatus = $false
                        Comments = $msgTable.policyNotCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                    
                    if ($EnableMultiCloudProfiles) {
                        $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                    }
                    
                    $results.Add($result) | Out-Null
                }
            } else {
                Write-Host "All resources are compliant with the policy"

                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        SubscriptionName = $subscription.Name
                        Name = "All Resources"
                        ComplianceStatus = $true
                        Comments = $msgTable.policyCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "All Resources"
                        DisplayName = "All Resources"
                        ComplianceStatus = $true
                        Comments = $msgTable.policyCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                $results.Add($result) | Out-Null
            }
        } else {
            
            if($subScope){
                $result = [PSCustomObject]@{
                    Type = "subscription"
                    Id = $subscription.Id
                    SubscriptionName = $subscription.Name
                    ComplianceStatus = $false
                    Comments = $msgTable.policyNotConfiguredSub -f $subScope
                    ItemName = "$ItemName - $policyDisplayName"
                    ControlName = $ControlName
                    ReportTime = $ReportTime
                    itsgcode = $itsgcode
                }
            }
            else{
                $result = [PSCustomObject]@{
                    Type = "tenant"
                    Id = $tenantId
                    Name = "Tenant ($tenantId)"
                    DisplayName = "Tenant ($tenantId)"
                    ComplianceStatus = $false
                    Comments = $msgTable.policyNotConfigured
                    ItemName = "$ItemName - $policyDisplayName"
                    ControlName = $ControlName
                    ReportTime = $ReportTime
                    itsgcode = $itsgcode
                }
            }
            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
            }
            $results.Add($result) | Out-Null
        }
    }

    Write-Host "Completed policy compliance check. Found $($results.Count) results"
    return $results
}

function Check-BuiltInPoliciesWithResourceGraph {
    <#
    .SYNOPSIS
        Checks that required built-in policies are assigned to every subscription in the tenant.

    .DESCRIPTION
        For each required policy ID this function determines, per subscription, whether the policy
        is assigned at a scope that covers that subscription — either directly at subscription scope
        or via a parent management group.

        Two batched Azure Resource Graph queries replace the old approach of iterating subscriptions
        with Get-AzSubscription / Set-AzContext and calling Get-AzPolicyState (which caused timeouts
        in large tenants):

          1. All subscriptions with their management-group ancestor chain.
          2. All policy assignments for the required policy IDs (any scope).

        These are joined in memory so the guardrail result is one row per subscription per policy:
          - ComplianceStatus = $true  when an assignment covers the subscription.
          - ComplianceStatus = $false when no assignment covers the subscription.

    .PARAMETER requiredPolicyIds
        Array of built-in policy definition resource IDs to evaluate.
    .PARAMETER ReportTime
        ISO-8601 timestamp injected into every result object.
    .PARAMETER ItemName
        Human-readable check name prepended to the policy display name in results.
    .PARAMETER msgTable
        Hashtable of localised message strings.  Keys used: policyAssignedSub,
        policyNotConfiguredSub.
    .PARAMETER ControlName
        Guardrail control identifier included in every result.
    .PARAMETER itsgcode
        ITSG security control code included in every result.
    .PARAMETER CloudUsageProfiles / ModuleProfiles / EnableMultiCloudProfiles
        Multi-cloud profile parameters forwarded to Add-ProfileInformation when needed.
    .PARAMETER ErrorList
        ArrayList that receives non-terminating error strings.

    .OUTPUTS
        System.Collections.ArrayList of PSCustomObject result rows — one per subscription per
        required policy.
    #>
    param (
        [Parameter(Mandatory=$true)]
        [array]$requiredPolicyIds,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [string]$itsgcode,
        [string]$CloudUsageProfiles = "3",
        [string]$ModuleProfiles,
        [switch]$EnableMultiCloudProfiles,
        [System.Collections.ArrayList]$ErrorList
    )

    $results = New-Object System.Collections.ArrayList

    if ($requiredPolicyIds.Count -eq 0) {
        Write-Warning "Verify-TLSConfiguration: No required policies found for ItemName '$ItemName'. Skipping."
        $ErrorList.Add("Verify-TLSConfiguration: No required policies found for ItemName '$ItemName'. Skipping.")
        return [PSCustomObject]@{ ComplianceResults = @(); Errors = $ErrorList }
    }

    # ── Helper: paginate an ARG query and return all rows ─────────────────────
    function Invoke-ARGQueryAllPages {
        param([string]$Query)
        $allRows = [System.Collections.Generic.List[object]]::new()
        $skipToken = $null
        $page = 0
        do {
            $page++
            $invokeParams = @{
                UseTenantScope = $true
                Query          = $Query
                First          = 1000
                ErrorAction    = 'Stop'
            }
            if ($skipToken) { $invokeParams['SkipToken'] = $skipToken }
            $pageResult = Search-AzGraph @invokeParams
            foreach ($row in $pageResult) { $allRows.Add($row) | Out-Null }
            $skipToken = $pageResult.SkipToken
            Write-Verbose "ARG page $page returned $($pageResult.Count) rows. HasMore: $($null -ne $skipToken)"
        } while ($skipToken)
        return $allRows
    }

    # ── Normalise IDs to lower-case for case-insensitive KQL matching ─────────
    $normalizedIds = $requiredPolicyIds | ForEach-Object { $_.ToLower() }
    $kqlIdList     = ($normalizedIds | ForEach-Object { "'$_'" }) -join ', '

    # ── Query 1: Policy definition display names ──────────────────────────────
    $defQuery = @"
policyresources
| where type =~ 'microsoft.authorization/policydefinitions'
| where tolower(id) in~ ($kqlIdList)
| project id = tolower(id), displayName = tostring(properties.displayName)
"@

    $policyDisplayNames = @{}
    try {
        Write-Host "ARG: fetching policy definition display names..."
        $defRows = Invoke-ARGQueryAllPages -Query $defQuery
        foreach ($row in $defRows) {
            $policyDisplayNames[$row.id] = $row.displayName
        }
    } catch {
        $ErrorList.Add("ARG policy definition query failed: $_") | Out-Null
    }

    # ── Query 2: All (subscription, coveringScope) pairs ─────────────────────
    # The query expands every subscription to one row per scope that can hold a
    # policy assignment covering it: the subscription scope itself (direct
    # assignment) plus every parent management group scope.
    # Using mv-expand + union inside a single resourcecontainers query avoids
    # returning nested dynamic arrays that are fragile to deserialize in
    # PowerShell, and also avoids cross-table let statements unsupported in ARG.

    # ── Query 2a: ─────────────────────
    # Only 'Enabled' subscriptions are considered; disabled subscriptions are skipped and reported as non-evaluated 
    $subScopeQuery = @"
resourcecontainers
| where type =~ 'microsoft.resources/subscriptions'
| where properties.state =~ 'Enabled'
| extend subId   = tolower(subscriptionId)
| extend subName = name
| mv-expand ancestor = properties.managementGroupAncestorsChain
| project subId, subName,
          coveringScope = tolower(strcat('/providers/microsoft.management/managementgroups/', tostring(ancestor.name)))
| union (
    resourcecontainers
    | where type =~ 'microsoft.resources/subscriptions'
    | where properties.state =~ 'Enabled'
    | project subId        = tolower(subscriptionId),
              subName      = name,
              coveringScope = tolower(strcat('/subscriptions/', subscriptionId))
)
"@

    $allSubscriptions  = @{}   # subId → subName
    $subCoveringScopes = @{}   # subId → HashSet<coveringScope>

    try {
        Write-Host "ARG: fetching subscriptions and management group hierarchy..."
        $scopeRows = Invoke-ARGQueryAllPages -Query $subScopeQuery
        foreach ($row in $scopeRows) {
            if (-not $allSubscriptions.ContainsKey($row.subId)) {
                $allSubscriptions[$row.subId] = $row.subName
                $subCoveringScopes[$row.subId] = [System.Collections.Generic.HashSet[string]]::new()
            }
            [void]$subCoveringScopes[$row.subId].Add($row.coveringScope)
        }
        Write-Host "ARG: found $($allSubscriptions.Count) subscriptions"
    } catch {
        $ErrorList.Add("ARG subscription covering-scopes query failed: $_") | Out-Null
    }
    # ── Query 2b: Subscriptions NOT in 'enabled' state ─────────────────────
    # These subscriptions are excluded from query 2a and will be reported as non-evaluated/not applicable in the final results.
    # These are skipped subs from evaluation and accounted for in the final results with a message indicating they are not evaluated.
    $skippedSubQuery = @"
    resourcecontainers
    | where type =~ 'microsoft.resources/subscriptions'
    | where properties.state !~ 'Enabled'
    | project subId        = tolower(subscriptionId),
              subName      = name,
              coveringScope = tolower(strcat('/subscriptions/', subscriptionId))
"@
    $skippedSubscriptions = @{}   # subId → subName
    try{
        Write-Host "ARG: fetching non-enabled or skipped subscriptions..."
        $skippedRows = Invoke-ARGQueryAllPages -Query $skippedSubQuery
        foreach ($row in $skippedRows) {
            $skippedSubscriptions[$row.subId] = $row.subName
            
        }
        Write-Host "ARG: found $($skippedSubscriptions.Count) non-enabled or skipped subscriptions"
    } catch {
        $ErrorList.Add("ARG skipped subscription query failed: $_") | Out-Null
    }



    # ── Query 3: Policy assignments (scope + ID) for the required policy IDs ─────────────────────
    # The assignment ID is required to match against exemptions in Query 4.
    $assignQuery = @"
policyresources
| where type =~ 'microsoft.authorization/policyassignments'
| where tolower(tostring(properties.policyDefinitionId)) in~ ($kqlIdList)
| project policyDefId    = tolower(tostring(properties.policyDefinitionId)),
          assignmentScope = tolower(tostring(properties.scope)),
          assignmentId    = tolower(id)
"@

    # assignmentsByPolicy[policyDefId] = List of objects with Scope and Id
    $assignmentsByPolicy = @{}
    try {
        Write-Host "ARG: fetching policy assignments..."
        $assignRows = Invoke-ARGQueryAllPages -Query $assignQuery
        foreach ($row in $assignRows) {
            $polId = $row.policyDefId
            if (-not $assignmentsByPolicy.ContainsKey($polId)) {
                $assignmentsByPolicy[$polId] = [System.Collections.Generic.List[object]]::new()
            }
            $assignmentsByPolicy[$polId].Add([PSCustomObject]@{
                Scope = $row.assignmentScope
                Id    = $row.assignmentId
            }) | Out-Null
        }
        Write-Host "ARG: found assignments for $($assignmentsByPolicy.Count) distinct policy IDs"
    } catch {
        $ErrorList.Add("ARG policy assignment query failed: $_") | Out-Null
    }

    # ── Query 4: Exemptions for the collected assignments ─────────────────────
    # Mirrors Check-BuiltInPolicies: any exemption on a covering assignment means
    # the subscription reports policyHasExemptions (non-compliant).
    $exemptedAssignmentIds = [System.Collections.Generic.HashSet[string]]::new()

    $allAssignmentIds = [System.Collections.Generic.List[string]]::new()
    foreach ($assignments in $assignmentsByPolicy.Values) {
        foreach ($a in $assignments) { $allAssignmentIds.Add($a.Id) | Out-Null }
    }

    if ($allAssignmentIds.Count -gt 0) {
        $kqlAssignmentList = ($allAssignmentIds | Select-Object -Unique | ForEach-Object { "'$_'" }) -join ', '

        $exemptQuery = @"
policyresources
| where type =~ 'microsoft.authorization/policyexemptions'
| where tolower(tostring(properties.policyAssignmentId)) in~ ($kqlAssignmentList)
| project assignmentId = tolower(tostring(properties.policyAssignmentId))
"@
        try {
            Write-Host "ARG: fetching policy exemptions..."
            $exemptRows = Invoke-ARGQueryAllPages -Query $exemptQuery
            foreach ($row in $exemptRows) {
                [void]$exemptedAssignmentIds.Add($row.assignmentId)
            }
            Write-Host "ARG: found exemptions on $($exemptedAssignmentIds.Count) assignment(s)"
        } catch {
            $ErrorList.Add("ARG policy exemption query failed: $_") | Out-Null
        }
    }

    # ── Build per-subscription × per-policy results ───────────────────────────
    # Decision tree per subscription per policy:
    #   1. No assignment covers this subscription → policyNotConfiguredSub  
    #   2. Covering assignment has an exemption   → policyHasExemptions     
    #   3. Covered and no exemptions              → policyAssignedSub       
    foreach ($policyId in $requiredPolicyIds) {
        $polIdLower        = $policyId.ToLower()
        $policyDisplayName = if ($policyDisplayNames.ContainsKey($polIdLower)) {
            $policyDisplayNames[$polIdLower]
        } else {
            'Unknown Policy'
        }

        $policyAssignments = $assignmentsByPolicy[$polIdLower]   # may be $null

        foreach ($subId in $allSubscriptions.Keys) {
            $subName        = $allSubscriptions[$subId]
            $subScope       = "/subscriptions/$subId"
            $coveringScopes = $subCoveringScopes[$subId]

            # Assignments whose scope is in the subscription's covering-scope set
            $coveringAssignments = if ($null -ne $policyAssignments) {
                @($policyAssignments | Where-Object { $coveringScopes.Contains($_.Scope) })
            } else {
                @()
            }

            if ($coveringAssignments.Count -eq 0) {
                # No assignment covers this subscription
                $complianceStatus = $false
                $comments         = $msgTable.policyNotConfiguredSub -f $subScope
            } else {
                # Check whether any covering assignment carries an exemption
                $hasExemption = $false
                foreach ($assignment in $coveringAssignments) {
                    if ($exemptedAssignmentIds.Contains($assignment.Id)) {
                        $hasExemption = $true
                        break
                    }
                }

                if ($hasExemption) {
                    $complianceStatus = $false
                    $comments         = $msgTable.policyHasExemptions
                } else {
                    $complianceStatus = $true
                    $comments         = $msgTable.policyAssignedSub -f $subScope
                }
            }

            $r = [PSCustomObject]@{
                Type             = 'subscription'
                Id               = $subId
                SubscriptionName = $subName
                ComplianceStatus = $complianceStatus
                Comments         = $comments
                ItemName         = "$ItemName - $policyDisplayName"
                ControlName      = $ControlName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }

            if ($EnableMultiCloudProfiles) {
                $r = Add-ProfileInformation -Result $r -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
            }

            $results.Add($r) | Out-Null
        }

        # Add 'not evaluated comment and compliance status for non-enabled subscriptions
        foreach ($skippedSubId in $skippedSubscriptions.Keys) {
            $skippedSub = $skippedSubscriptions[$skippedSubId]
            $notEvalResult = [PSCustomObject]@{
                Type             = 'subscription'
                Id               = $skippedSubId
                SubscriptionName = $skippedSub
                ComplianceStatus = $false
                Comments         = ""
                ItemName         = "$ItemName - $policyDisplayName"
                ControlName      = $ControlName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }

            $notEvalResult = Set-SubscriptionNotEvaluatedStatus -Result $notEvalResult -SubscriptionName $skippedSub -msgTable $msgTable
            if ($EnableMultiCloudProfiles) {
                $notEvalResult = Add-ProfileInformation -Result $notEvalResult -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
            }
            $results.Add($notEvalResult) | Out-Null
        }
    }

    Write-Host "ARG policy assignment coverage check completed. $($results.Count) results ($($allSubscriptions.Count) evaluated + $($skippedSubscriptions.Count) skipped not-evaluated subscriptions x $($requiredPolicyIds.Count) policies)"
    return $results
}

function FetchAllUserRawData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ReportTime,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $FirstBreakGlassUPN,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $SecondBreakGlassUPN,
        
        [Parameter(Mandatory=$true)]
        [ValidateScript({
            try { [System.Guid]::Parse($_); $true }
            catch { throw "WorkSpaceID must be a valid GUID" }
        })]
        [string] $WorkSpaceID,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceKey,
        
        [Parameter()]
        [int] $BatchSize = 999,
        
        [Parameter()]
        [hashtable] $RetryConfig = @{
            MaxRetries = 12
            BaseDelay = 5
            MaxDelay = 60
            BackoffMultiplier = 2
        }
    )
    ###
    $currentTenantId = [string](Get-AzContext).Tenant.Id

    # Initialize error tracking and performance monitoring
    $ErrorList = [System.Collections.Generic.List[string]]::new()
    # The MFA control reads this state later in the same main runbook. Start with
    # incomplete and change it only after every temporary bucket is processed and
    # uploaded, so missing user data can never become a false compliance pass.
    $Global:GuardrailsUserRawDataCollectionComplete = $false
    $Global:GuardrailsUserRawDataExpectedRecordCount = 0
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $performanceMetrics = @{
        StartTime = Get-Date
        GraphApiCalls = 0
        GraphApiRetries = 0
        GraphThrottles429 = 0
        GraphRetryDelaySeconds = 0
        UsersProcessed = 0
        DataIngestionAttempts = 0
    }
    # Report each major phase separately so an interrupted large-tenant run shows
    # where it stopped and whether Graph, temporary files, or upload took the time.
    $writePhaseTiming = {
        param(
            [string] $PhaseName,
            [System.Diagnostics.Stopwatch] $PhaseStopwatch
        )
        $phaseDurationSeconds = [Math]::Round($PhaseStopwatch.Elapsed.TotalSeconds, 2)
        $phaseDurationMinutes = [Math]::Round($PhaseStopwatch.Elapsed.TotalMinutes, 2)
        # Warning is preserved in the Automation job export used by operations;
        # host output from this callback was absent in the client evidence.
        Write-Warning "FetchAllUserRawData timing | Phase=$PhaseName | Seconds=$phaseDurationSeconds | Minutes=$phaseDurationMinutes"
    }

    # Emit live progress while Graph pages are being written to temporary files.
    # These messages survive the Automation log export, so a timeout or OOM still
    # leaves the last completed page, record count, memory, and disk use in the log.
    $writeCollectionProgress = {
        param(
            [string] $PhaseName,
            [string] $EventName,
            [int] $PageNumber,
            [long] $RecordCount,
            [string] $Directory,
            [System.Diagnostics.Stopwatch] $PhaseStopwatch
        )

        try {
            $temporaryBytes = [long](Get-ChildItem -LiteralPath $Directory -File | Measure-Object -Property Length -Sum).Sum
            $temporaryStorageMb = [Math]::Round($temporaryBytes / 1MB, 2)
            $memoryMb = [Math]::Round([System.Diagnostics.Process]::GetCurrentProcess().PrivateMemorySize64 / 1MB, 0)
            $elapsedMinutes = [Math]::Round($PhaseStopwatch.Elapsed.TotalMinutes, 2)
            Write-Warning "FetchAllUserRawData collection progress | Phase=$PhaseName | Event=$EventName | Pages=$PageNumber | Records=$RecordCount | TemporaryStorageMb=$temporaryStorageMb | MemoryMb=$memoryMb | Minutes=$elapsedMinutes"
        }
        catch {
            # Diagnostics must never turn an otherwise healthy collection into a failure.
            Write-Warning "FetchAllUserRawData collection progress unavailable | Phase=$PhaseName | Event=$EventName | Pages=$PageNumber | Records=$RecordCount | Error=$($_.Exception.Message)"
        }
    }

    # A partition below means one numbered bucket stored in this Automation job's
    # local temporary directory, not in an Azure Storage Account. Each of the 64
    # buckets has one compressed registration file and one compressed user file,
    # for up to 128 temporary files. Processing one pair at a time keeps only about
    # 1/64 of the registration lookup in memory. The same Entra user ID always goes
    # to the same bucket in both files so the records can be matched safely.
    $partitionCount = 64
    # Fifty pages is frequent enough to leave useful evidence before a hard stop,
    # but sparse enough to avoid slowing large tenants or flooding their job logs.
    $collectionProgressIntervalPages = 50
    # Graph can return 999 users per page, but the richer Log Analytics rows are
    # larger. Uploading 650 at a time keeps typical payloads below the existing
    # 900 KB safety limit and avoids parsing and splitting the same payload twice.
    # The byte-based ingestion splitter remains the fallback for unusually large rows.
    $userRawUploadBatchSize = 650
    $partitionDirectory = $null
    $registrationStore = $null
    $userStore = $null

    # Create one compressed temporary file and writer for each numbered bucket.
    # Compression limits temporary-disk use, and small writers let all 64 buckets
    # stay open without recreating the memory problem this design is fixing.
    $newPartitionStore = {
        param(
            [string] $Directory,
            [string] $Prefix,
            [int] $Count
        )

        $paths = [string[]]::new($Count)
        $writers = [System.IO.StreamWriter[]]::new($Count)
        $utf8WithoutBom = [System.Text.UTF8Encoding]::new($false)
        # Each open file uses a small 8 KB write buffer. This keeps the combined
        # writer memory low while still writing the compressed files efficiently.
        $partitionBufferSize = 8192

        try {
            for ($index = 0; $index -lt $Count; $index++) {
                $path = Join-Path $Directory ("{0}-{1:D3}.jsonl.gz" -f $Prefix, $index)
                $fileStream = [System.IO.FileStream]::new(
                    $path,
                    [System.IO.FileMode]::Create,
                    [System.IO.FileAccess]::Write,
                    [System.IO.FileShare]::None,
                    $partitionBufferSize,
                    [System.IO.FileOptions]::SequentialScan
                )
                $gzipStream = [System.IO.Compression.GZipStream]::new(
                    $fileStream,
                    [System.IO.Compression.CompressionLevel]::Fastest,
                    $false
                )
                $writers[$index] = [System.IO.StreamWriter]::new($gzipStream, $utf8WithoutBom, $partitionBufferSize, $false)
                $paths[$index] = $path
            }
        }
        catch {
            foreach ($writer in $writers) {
                if ($null -ne $writer) {
                    $writer.Dispose()
                }
            }
            throw
        }

        return [PSCustomObject]@{
            Paths = $paths
            Writers = $writers
            Count = $Count
        }
    }

    # Close every writer so all compressed data is fully saved before it is read.
    # If a file cannot be closed cleanly, fail the collection rather than letting
    # incomplete temporary data produce an incorrect compliance result.
    $closePartitionStore = {
        param($Store)

        if ($null -eq $Store -or $null -eq $Store.Writers) {
            return
        }

        $firstCloseError = $null
        foreach ($writer in $Store.Writers) {
            if ($null -ne $writer) {
                try {
                    $writer.Dispose()
                }
                catch {
                    if ($null -eq $firstCloseError) {
                        $firstCloseError = $_
                    }
                }
            }
        }
        $Store.Writers = $null

        # Report the first close failure after attempting to close every file.
        if ($null -ne $firstCloseError) {
            throw $firstCloseError
        }
    }

    # Split one Graph page across the numbered buckets and write it immediately.
    # This lets the original Graph page leave memory while preserving the user ID
    # needed to match registration and user data later.
    $writePartitionedPage = {
        param(
            [object[]] $Records,
            $Store
        )

        $partitionBuckets = [System.Collections.Generic.List[object][]]::new($Store.Count)
        foreach ($record in $Records) {
            $recordId = [string]$record.id
            if ($recordId.Length -lt 2) {
                throw "Graph returned a record without a valid user ID."
            }

            # Use the first part of the Entra ID to choose a stable bucket. GUIDs
            # normally spread records across the buckets, and matching IDs always
            # choose the same bucket in both Graph passes.
            try {
                $partitionIndex = [Convert]::ToInt32($recordId.Substring(0, 2), 16) % $Store.Count
            }
            catch {
                throw "Graph returned an invalid user ID '$recordId'."
            }

            if ($null -eq $partitionBuckets[$partitionIndex]) {
                $partitionBuckets[$partitionIndex] = [System.Collections.Generic.List[object]]::new()
            }
            $partitionBuckets[$partitionIndex].Add($record)
        }

        for ($index = 0; $index -lt $Store.Count; $index++) {
            $bucket = $partitionBuckets[$index]
            if ($null -eq $bucket -or $bucket.Count -eq 0) {
                continue
            }

            # Store this page's records for one bucket as a compressed line. The
            # line can later be read by itself instead of loading the full tenant.
            $bucketRecords = $bucket.ToArray()
            $json = ConvertTo-Json -InputObject $bucketRecords -Depth 12 -Compress
            $Store.Writers[$index].WriteLine($json)
        }
    }

    # Open one compressed bucket for sequential reading. Data is decompressed as
    # it is read, so neither the whole file nor the whole tenant enters memory.
    $openPartitionReader = {
        param([string] $Path)

        $fileStream = [System.IO.FileStream]::new(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::Read,
            65536,
            [System.IO.FileOptions]::SequentialScan
        )
        $gzipStream = [System.IO.Compression.GZipStream]::new(
            $fileStream,
            [System.IO.Compression.CompressionMode]::Decompress,
            $false
        )
        return [System.IO.StreamReader]::new($gzipStream, [System.Text.Encoding]::UTF8, $true, 65536, $false)
    }

    # Log which bucket is about to enter memory, along with both compressed file
    # sizes. If processing stops inside one bucket, the last start line identifies
    # the bucket and whether unusually large input contributed to the failure.
    $writeBucketStart = {
        param(
            [int] $BucketIndex,
            [int] $BucketCount,
            [string] $RegistrationPath,
            [string] $UserPath,
            [System.Diagnostics.Stopwatch] $PhaseStopwatch
        )

        try {
            $registrationFileMb = [Math]::Round(([System.IO.FileInfo]::new($RegistrationPath).Length / 1MB), 2)
            $userFileMb = [Math]::Round(([System.IO.FileInfo]::new($UserPath).Length / 1MB), 2)
            $memoryMb = [Math]::Round([System.Diagnostics.Process]::GetCurrentProcess().PrivateMemorySize64 / 1MB, 0)
            $elapsedMinutes = [Math]::Round($PhaseStopwatch.Elapsed.TotalMinutes, 2)
            Write-Warning "FetchAllUserRawData bucket start | Bucket=$($BucketIndex + 1)/$BucketCount | RegistrationFileMb=$registrationFileMb | UserFileMb=$userFileMb | MemoryMb=$memoryMb | Minutes=$elapsedMinutes"
        }
        catch {
            # Continue into the real read so a diagnostic problem cannot hide or cause a data failure.
            Write-Warning "FetchAllUserRawData bucket diagnostic unavailable | Bucket=$($BucketIndex + 1)/$BucketCount | Error=$($_.Exception.Message)"
        }
    }
    
    $startTimeFormatted = $performanceMetrics.StartTime.ToString("yyyy-MM-dd HH:mm:ss")
    Write-Verbose "=== Starting FetchAllUserRawData with ReportTime: $ReportTime  at $startTimeFormatted ==="
    Write-Verbose "Step 1: Spooling authentication registration details into bounded partitions..."

    # Prepare a small lookup of break-glass accounts. Filtering them during the
    # final match keeps the two Graph collection passes simple and memory-safe.
    $bgUpns = @($FirstBreakGlassUPN, $SecondBreakGlassUPN) |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        ForEach-Object { $_.ToLowerInvariant() }
    $bgUpnLookup = @{}
    $bgUpns | ForEach-Object { $bgUpnLookup[$_] = $true }

    # Agent ID user accounts cannot register MFA and cannot be tagged with the exclusion
    # attribute because Microsoft services create them on demand. Read them once here and
    # flag the matching rows during the join. A failure leaves the lookup empty, which
    # evaluates every account as before rather than silently passing the control.
    $agentUserResult = Get-GuardrailsAgentUserIds
    $agentUserIdLookup = $agentUserResult.Ids
    if ($agentUserResult.Succeeded) {
        Write-Verbose "Identified $($agentUserResult.Count) Agent ID user account(s) to exclude from MFA evaluation."
    }
    else {
        Add-FunctionError -Message "Failed to enumerate Agent ID user accounts; agent accounts will be evaluated as regular users" -Exception ([System.Exception]::new([string]$agentUserResult.ErrorMessage)) -Category "GraphAPI" -ErrorList $ErrorList
    }

    $registrationResult = $null
    $userSpoolResult = $null
    $pageNumber = 0
    $processedUsers = 0
    $totalUploadedRecords = 0
    $totalReadUserRecords = 0
    $domainTenantCache = @{}

    try {
        # Use a unique folder in this Automation job's temporary storage. Nothing
        # is shared with another run or retained as compliance evidence afterward.
        $partitionDirectory = Join-Path ([System.IO.Path]::GetTempPath()) ("guardrails-userraw-{0}" -f [guid]::NewGuid().ToString('N'))
        [void][System.IO.Directory]::CreateDirectory($partitionDirectory)

        # Keep only registration fields used in the final GuardrailsUserRaw row.
        # Smaller temporary records reduce disk use and memory during matching.
        $registrationStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $registrationStore = & $newPartitionStore $partitionDirectory 'registration' $partitionCount
        $registrationContext = @{
            Store = $registrationStore
            WritePartitionedPage = $writePartitionedPage
            WriteCollectionProgress = $writeCollectionProgress
            Directory = $partitionDirectory
            PhaseStopwatch = $registrationStopwatch
            ProgressIntervalPages = $collectionProgressIntervalPages
            TotalRecords = [long]0
        }
        # Convert each Graph registration page to smaller records and write them
        # to temporary buckets immediately. This replaces the tenant-wide lookup
        # that ran out of memory in the reported large tenant.
        $processRegistrationPageCallback = {
            param($pageData, $context)

            $pageRecords = @($pageData.Data)
            $projectedRecords = [System.Collections.Generic.List[object]]::new($pageRecords.Count)
            foreach ($record in $pageRecords) {
                if (-not $record.id) {
                    continue
                }

                $projectedRecords.Add([PSCustomObject]@{
                    id = $record.id
                    isMfaRegistered = $record.isMfaRegistered
                    isMfaCapable = $record.isMfaCapable
                    isSsprEnabled = $record.isSsprEnabled
                    isSsprRegistered = $record.isSsprRegistered
                    isSsprCapable = $record.isSsprCapable
                    isPasswordlessCapable = $record.isPasswordlessCapable
                    defaultMethod = $record.defaultMethod
                    methodsRegistered = $record.methodsRegistered
                    isSystemPreferredAuthenticationMethodEnabled = $record.isSystemPreferredAuthenticationMethodEnabled
                    systemPreferredAuthenticationMethods = $record.systemPreferredAuthenticationMethods
                    userPreferredMethodForSecondaryAuthentication = $record.userPreferredMethodForSecondaryAuthentication
                })
            }

            & $context.WritePartitionedPage $projectedRecords.ToArray() $context.Store
            $context.TotalRecords += $projectedRecords.Count
            if (($pageData.PageNumber % $context.ProgressIntervalPages) -eq 0 -or -not $pageData.HasMore) {
                & $context.WriteCollectionProgress 'registration-write' 'Progress' $pageData.PageNumber $context.TotalRecords $context.Directory $context.PhaseStopwatch
            }
            return @{ ProcessedCount = $pageRecords.Count; UploadedCount = 0 }
        }

        # Read registration pages without a fixed delay because hundreds of pages
        # would turn that delay into minutes. The shared Graph reader still retries
        # throttling and temporary failures.
        & $writeCollectionProgress 'registration-write' 'Start' 0 0 $partitionDirectory $registrationStopwatch
        try {
            $registrationResult = Invoke-GraphQueryStreamWithCallback -UrlPath '/reports/authenticationMethods/userRegistrationDetails' -PageSize $BatchSize -ProcessPageCallback $processRegistrationPageCallback -CallbackContext $registrationContext -InterPageDelaySeconds 0 -PerformanceMetrics $performanceMetrics
        }
        catch {
            Add-FunctionError -Message "Failed to fetch registration details from Microsoft Graph" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
            throw
        }
        finally {
            & $closePartitionStore $registrationStore
        }
        Write-Verbose "  Success: Spooled $($registrationResult.TotalProcessed) registration records"
        & $writePhaseTiming 'registration-spool' $registrationStopwatch

        # Write users with the same 64-bucket ID rule used for registrations. This
        # places matching records together without keeping either full list in memory.
        Write-Verbose "Step 2: Spooling enabled users into bounded partitions..."
        $selectFields = 'displayName,id,userPrincipalName,mail,createdDateTime,userType,accountEnabled,signInActivity,customSecurityAttributes,identities'
        $usersPath = "/users?`$select=$selectFields&`$filter=accountEnabled eq true"
        $userSpoolStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $userStore = & $newPartitionStore $partitionDirectory 'user' $partitionCount
        $userSpoolContext = @{
            Store = $userStore
            WritePartitionedPage = $writePartitionedPage
            WriteCollectionProgress = $writeCollectionProgress
            Directory = $partitionDirectory
            PhaseStopwatch = $userSpoolStopwatch
            ProgressIntervalPages = $collectionProgressIntervalPages
            TotalRecords = [long]0
        }
        # Write each Graph user page to temporary buckets immediately so the page
        # can leave memory before the next page is requested.
        $processUserSpoolPageCallback = {
            param($pageData, $context)

            $pageUsers = @($pageData.Data)
            & $context.WritePartitionedPage $pageUsers $context.Store
            $context.TotalRecords += $pageUsers.Count
            if (($pageData.PageNumber % $context.ProgressIntervalPages) -eq 0 -or -not $pageData.HasMore) {
                & $context.WriteCollectionProgress 'user-write' 'Progress' $pageData.PageNumber $context.TotalRecords $context.Directory $context.PhaseStopwatch
            }
            return @{ ProcessedCount = $pageUsers.Count; UploadedCount = 0 }
        }

        # Request the next /users page immediately. If Graph needs a slower rate,
        # the shared reader honours Retry-After and pauses only for that response.
        & $writeCollectionProgress 'user-write' 'Start' 0 0 $partitionDirectory $userSpoolStopwatch
        try {
            $userSpoolResult = Invoke-GraphQueryStreamWithCallback -UrlPath $usersPath -PageSize $BatchSize -ProcessPageCallback $processUserSpoolPageCallback -CallbackContext $userSpoolContext -InterPageDelaySeconds 0 -PerformanceMetrics $performanceMetrics
        }
        catch {
            Add-FunctionError -Message "Failed to fetch users from Microsoft Graph" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
            throw
        }
        finally {
            & $closePartitionStore $userStore
        }
        $pageNumber = $userSpoolResult.TotalPages
        $processedUsers = $userSpoolResult.TotalProcessed
        $performanceMetrics.UsersProcessed = $processedUsers
        Write-Verbose "  Success: Spooled $processedUsers enabled users from $pageNumber pages"
        & $writePhaseTiming 'user-spool' $userSpoolStopwatch

        $spoolBytes = [long](Get-ChildItem -LiteralPath $partitionDirectory -File | Measure-Object -Property Length -Sum).Sum
        $spoolSizeMb = [Math]::Round($spoolBytes / 1MB, 2)
        # Include retry totals in a captured Automation stream so scale tests can
        # confirm that faster paging did not simply trade elapsed time for throttling.
        Write-Warning "FetchAllUserRawData bounded join | Partitions=$partitionCount | UploadBatchSize=$userRawUploadBatchSize | TemporaryStorageMb=$spoolSizeMb | GraphCalls=$($performanceMetrics.GraphApiCalls) | GraphRetries=$($performanceMetrics.GraphApiRetries) | Graph429=$($performanceMetrics.GraphThrottles429) | GraphRetryWaitSeconds=$($performanceMetrics.GraphRetryDelaySeconds)"

        # Both Graph reads and all temporary-file writers are finished. Ask .NET
        # once to release their unused buffers before matching begins. Doing this
        # once avoids the large slowdown that collection inside the user loop causes.
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()
        [System.GC]::Collect()

        # Process one matching bucket pair at a time. Load only that bucket's
        # registration lookup, read its users, combine the records, and upload them.
        # Keeping roughly 1/64 of the lookup in memory is the main OOM protection.
        Write-Verbose "Step 3: Joining and uploading one bounded partition at a time..."
        $joinStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        # Upload one existing-size Log Analytics batch. Retry a temporary failure
        # up to three times; if all attempts fail, stop the collection so the MFA
        # control cannot treat partially uploaded data as complete.
        $sendUploadBatch = {
            param(
                [object[]] $BatchData,
                [int] $PartitionIndex,
                [string] $TargetWorkSpaceID,
                [string] $TargetWorkspaceKey,
                [hashtable] $TargetRetryConfig,
                [System.Collections.Generic.List[string]] $TargetErrorList
            )

            for ($attempt = 1; $attempt -le 3; $attempt++) {
                try {
                    New-LogAnalyticsData -Data $BatchData -WorkSpaceID $TargetWorkSpaceID -WorkspaceKey $TargetWorkspaceKey -LogType 'GuardrailsUserRaw' | Out-Null
                    return $BatchData.Count
                }
                catch {
                    if ($attempt -eq 3) {
                        $errorMsg = "Failed to upload partition $PartitionIndex after 3 attempts: $($_.Exception.Message)"
                        Add-FunctionError -Message $errorMsg -Exception $_.Exception -Category 'LogAnalytics' -ErrorList $TargetErrorList
                        throw [System.Exception]::new($errorMsg)
                    }
                    Start-Sleep -Seconds (Get-BackoffDelay -Attempt $attempt -Config $TargetRetryConfig)
                }
            }
        }

        # Complete one bucket before opening the next. The registration side is a
        # small ID lookup, while the matching user file is read gradually.
        for ($partitionIndex = 0; $partitionIndex -lt $partitionCount; $partitionIndex++) {
            & $writeBucketStart $partitionIndex $partitionCount $registrationStore.Paths[$partitionIndex] $userStore.Paths[$partitionIndex] $joinStopwatch
            $registrationLookup = @{}
            $registrationReader = & $openPartitionReader $registrationStore.Paths[$partitionIndex]
            try {
                while (-not $registrationReader.EndOfStream) {
                    $line = $registrationReader.ReadLine()
                    if ([string]::IsNullOrWhiteSpace($line)) {
                        continue
                    }
                    foreach ($registration in @($line | ConvertFrom-Json)) {
                        if ($registration.id -and -not $registrationLookup.ContainsKey($registration.id)) {
                            $registrationLookup[$registration.id] = $registration
                        }
                    }
                }
            }
            finally {
                $registrationReader.Dispose()
            }

            $uploadBatch = [System.Collections.Generic.List[object]]::new($userRawUploadBatchSize)
            $userReader = & $openPartitionReader $userStore.Paths[$partitionIndex]
            try {
                while (-not $userReader.EndOfStream) {
                    $line = $userReader.ReadLine()
                    if ([string]::IsNullOrWhiteSpace($line)) {
                        continue
                    }

                    foreach ($user in @($line | ConvertFrom-Json)) {
                        $totalReadUserRecords++
                        $upn = [string]$user.userPrincipalName
                        if ([string]::IsNullOrWhiteSpace($upn) -or $bgUpnLookup.ContainsKey($upn.ToLowerInvariant())) {
                            continue
                        }

                        $registration = $registrationLookup[$user.id]
                        $methods = if ($registration -and $registration.methodsRegistered) { @($registration.methodsRegistered) } else { @() }
                        $guardrailsExcluded = Test-GuardrailsMfaExclusion -User $user
                        $isAgentUser = $agentUserIdLookup.ContainsKey([string]$user.id)

                        # Reuse guest-tenant results across all buckets so the memory
                        # redesign does not repeat the same external-domain lookup.
                        $homeTenantId = $null
                        $homeTenantResolved = $false
                        # Resolve the home tenant for external B2B users regardless of whether
                        # Entra represents the account as Guest or Member.
                        $domain = Get-ExternalUserHomeDomain -User $user

                        if ($domain) {
                            $resolutionResult = Get-TenantIdWithCache `
                                -Domain $domain `
                                -Cache $domainTenantCache
                            if ($resolutionResult.ResolutionSucceeded) {
                                $resolvedTenantId = [string]$resolutionResult.TenantId
                                if ($resolvedTenantId -ne $currentTenantId) {
                                    $homeTenantId = $resolvedTenantId
                                    $homeTenantResolved = $true
                                }
                            }
                        }

                        $uploadBatch.Add([PSCustomObject]@{
                            id = $user.id
                            userPrincipalName = $user.userPrincipalName
                            displayName = $user.displayName
                            mail = $user.mail
                            createdDateTime = $user.createdDateTime
                            userType = $user.userType
                            homeTenantId = $homeTenantId
                            homeTenantResolved = $homeTenantResolved
                            accountEnabled = $user.accountEnabled
                            signInActivity = $user.signInActivity
                            customSecurityAttributes = $user.customSecurityAttributes
                            guardrailsExcludedMfa = $guardrailsExcluded
                            guardrailsExcludedAgentUser = $isAgentUser
                            isMfaRegistered = if ($registration) { $registration.isMfaRegistered } else { $null }
                            isMfaCapable = if ($registration) { $registration.isMfaCapable } else { $null }
                            isSsprEnabled = if ($registration) { $registration.isSsprEnabled } else { $null }
                            isSsprRegistered = if ($registration) { $registration.isSsprRegistered } else { $null }
                            isSsprCapable = if ($registration) { $registration.isSsprCapable } else { $null }
                            isPasswordlessCapable = if ($registration) { $registration.isPasswordlessCapable } else { $null }
                            defaultMethod = if ($registration) { $registration.defaultMethod } else { $null }
                            methodsRegistered = $methods
                            isSystemPreferredAuthenticationMethodEnabled = if ($registration) { $registration.isSystemPreferredAuthenticationMethodEnabled } else { $null }
                            systemPreferredAuthenticationMethods = if ($registration) { $registration.systemPreferredAuthenticationMethods } else { $null }
                            userPreferredMethodForSecondaryAuthentication = if ($registration) { $registration.userPreferredMethodForSecondaryAuthentication } else { $null }
                            ReportTime = $ReportTime
                        })

                        if ($uploadBatch.Count -ge $userRawUploadBatchSize) {
                            $batchData = $uploadBatch.ToArray()
                            $totalUploadedRecords += (& $sendUploadBatch $batchData $partitionIndex $WorkSpaceID $WorkspaceKey $RetryConfig $ErrorList)
                            $uploadBatch.Clear()
                        }
                    }
                }

                # Upload the remaining records even when they do not fill a complete batch.
                if ($uploadBatch.Count -gt 0) {
                    $batchData = $uploadBatch.ToArray()
                    $totalUploadedRecords += (& $sendUploadBatch $batchData $partitionIndex $WorkSpaceID $WorkspaceKey $RetryConfig $ErrorList)
                    $uploadBatch.Clear()
                }
            }
            finally {
                $userReader.Dispose()
                $registrationLookup.Clear()
            }

            # Delete this completed file pair immediately. Temporary disk use then
            # falls throughout the run instead of remaining at its peak until the end.
            [System.IO.File]::Delete($registrationStore.Paths[$partitionIndex])
            [System.IO.File]::Delete($userStore.Paths[$partitionIndex])

            # Report every eight buckets so operations can locate a timeout or OOM
            # without producing a warning line for every bucket.
            if ((($partitionIndex + 1) % 8) -eq 0 -or $partitionIndex -eq ($partitionCount - 1)) {
                $memoryMb = [Math]::Round([System.Diagnostics.Process]::GetCurrentProcess().PrivateMemorySize64 / 1MB, 0)
                $elapsedMinutes = [Math]::Round($joinStopwatch.Elapsed.TotalMinutes, 2)
                Write-Warning "FetchAllUserRawData bucket progress | BucketsCompleted=$($partitionIndex + 1)/$partitionCount | UsersRead=$totalReadUserRecords/$processedUsers | Uploaded=$totalUploadedRecords | MemoryMb=$memoryMb | Minutes=$elapsedMinutes"
            }
        }

        # Confirm that every user written to temporary storage was read again. A
        # mismatch means data was lost or incomplete, so do not approve MFA input.
        if ($totalReadUserRecords -ne $processedUsers) {
            throw "Temporary partition validation failed. Spooled $processedUsers users but read $totalReadUserRecords users during the join."
        }

        # Only a complete Graph read, partition join, and upload can mark this run
        # safe for the downstream MFA compliance query.
        $Global:GuardrailsUserRawDataExpectedRecordCount = $totalUploadedRecords
        $Global:GuardrailsUserRawDataCollectionComplete = $true
        Write-Verbose "  Success: Joined and uploaded $totalUploadedRecords records"
        & $writePhaseTiming 'partition-join-upload' $joinStopwatch
    }
    catch {
        # Detailed Graph and upload failures are normally recorded where they occur.
        # Add a fallback only when none exists, preventing Errors=0 without duplicates.
        if ($ErrorList.Count -eq 0) {
            Add-FunctionError -Message "Failed during bounded user-data processing" -Exception $_.Exception -Category 'UserData' -ErrorList $ErrorList
        }
        $stopwatch.Stop()
        & $writePhaseTiming 'total' $stopwatch
        return $ErrorList
    }
    finally {
        # Remove temporary files after normal completion and handled errors. If the
        # process is forcibly stopped, the Automation sandbox owns its job-local cleanup.
        try { & $closePartitionStore $registrationStore } catch { Write-Warning "Could not close registration partition files: $($_.Exception.Message)" }
        try { & $closePartitionStore $userStore } catch { Write-Warning "Could not close user partition files: $($_.Exception.Message)" }
        if ($partitionDirectory -and [System.IO.Directory]::Exists($partitionDirectory)) {
            try {
                [System.IO.Directory]::Delete($partitionDirectory, $true)
            }
            catch {
                Write-Warning "Could not remove temporary user-data directory '$partitionDirectory': $($_.Exception.Message)"
            }
        }
    }
    
    # Step 4: Wait before verification to allow data ingestion and table creation
    Write-Verbose "Step 4: Checking Log Analytics table readiness before verification..."
    $verificationStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    # Existing tables usually need only a short ingestion buffer before the verification query.
    $existingTableVerificationDelaySeconds = 20
    try {
        # Existing tables only need a short ingestion wait; first-time table creation keeps the longer wait below.
        $tableCheckQuery = "GuardrailsUserRaw_CL | take 1 | count"
        Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkSpaceID -Query $tableCheckQuery -ErrorAction Stop | Out-Null
        Write-Verbose "  -> GuardrailsUserRaw_CL table exists. Waiting $existingTableVerificationDelaySeconds seconds for ingestion before verification..."
        Start-Sleep -Seconds $existingTableVerificationDelaySeconds
    }
    catch {
        $tableCheckError = $_.Exception.Message
        if ($tableCheckError -like "*Failed to resolve table*GuardrailsUserRaw_CL*" -or $tableCheckError -like "*BadRequest*" -or $tableCheckError -like "*400*") {
            Write-Verbose "  -> GuardrailsUserRaw_CL table is not queryable yet. Waiting 60 seconds for first-time table creation..."
            Write-Verbose "  -> Note: First-time table creation can take several minutes in Log Analytics"
            Start-Sleep -Seconds 60
        }
        else {
            Write-Verbose "  -> Table readiness check failed: $tableCheckError"
            Write-Verbose "  -> Continuing to verification loop without an extra fixed wait"
        }
    }
    
    # Step 5: Verify data ingestion with robust error handling
    Write-Verbose "Step 5: Verifying data ingestion..."
    
    $dataIngested = $false
    $recordCount = 0
    $permissionError = $false
    $verificationSkipped = $false
    
    # First, check if we can access Log Analytics at all
    Write-Verbose "  -> Testing Log Analytics connectivity..."
    try {
        # Simple test query to check permissions and connectivity
        $testQuery = "Heartbeat | limit 1"
        $testResult = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkSpaceID -Query $testQuery -ErrorAction Stop
        Write-Verbose "  -> Log Analytics connectivity test successful"
    }
    catch {
        $errorMessage = $_.Exception.Message
        if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*" -or $errorMessage -like "*unauthorized*") {
            Write-Verbose "  -> Automation Account may need 'Log Analytics Reader' role on workspace $WorkSpaceID"
            $permissionError = $true
            $verificationSkipped = $true
        }
        elseif ($errorMessage -like "*BadRequest*" -or $errorMessage -like "*400*" -or $errorMessage -like "*Failed to resolve table*") {
            Write-Verbose "  -> The GuardrailsUserRaw_CL table may still be initializing after first data upload"
            Write-Verbose "  -> This typically resolves within 5-15 minutes of first deployment"
            $verificationSkipped = $true
        }
        else {
            Write-Verbose "  -> Will attempt data verification with reduced retry count"
        }
    }
    
    # Only attempt verification if connectivity test passed
    if (-not $verificationSkipped) {
        $maxVerificationAttempts = [Math]::Min($RetryConfig.MaxRetries, 6)  # Limit to 6 attempts max
        
        for ($attempt = 1; $attempt -le $maxVerificationAttempts; $attempt++) {
        $performanceMetrics.DataIngestionAttempts = $attempt
            
            # Use more robust query with error handling
            $query = @"
GuardrailsUserRaw_CL 
| where ReportTime_s == '$ReportTime'
| count
"@
            
            try {
                Write-Verbose "  -> Verification attempt $attempt/$maxVerificationAttempts : Querying Log Analytics..."
                
                # Use shorter timeout and explicit error handling
                $result = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkSpaceID -Query $query -ErrorAction Stop
                $recordCount = 0
            
                if ($result -and $result.Results) {
                    try {
                        # Direct access - if Count property exists, this will work
                        $recordCount = [int]$result.Results[0].Count
                    } catch {
                        # If direct access fails, the Count property doesn't exist as expected
                        $recordCount = 0
                    }
                }
            
                if ($recordCount -gt 0) {
                    Write-Verbose "  Success: Data ingestion verified - $recordCount records found for ReportTime '$ReportTime'"
                    $dataIngested = $true
                    break
                } else {
                    $delay = Get-BackoffDelay -Attempt $attempt -Config $RetryConfig
                        Write-Verbose "  -> Data not yet available (attempt $attempt/$maxVerificationAttempts). Waiting $delay seconds..."
                    
                        if ($attempt -lt $maxVerificationAttempts) {
                        Start-Sleep -Seconds $delay
                    }
                }
            
            } catch {
                $errorMessage = $_.Exception.Message
                $delay = Get-BackoffDelay -Attempt $attempt -Config $RetryConfig
                
                if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*" -or $errorMessage -like "*unauthorized*") {
                    Write-Warning "  Warning: Permission error on attempt $attempt : $errorMessage"
                    $permissionError = $true
                    break  # Don't retry permission errors
                } 
                elseif ($errorMessage -like "*BadRequest*" -or $errorMessage -like "*400*" -or $errorMessage -like "*Failed to resolve table*") {
                    if ($errorMessage -like "*Failed to resolve table*GuardrailsUserRaw_CL*") {
                        Write-Warning "  Warning: Table GuardrailsUserRaw_CL not yet available in Log Analytics."
                        Write-Verbose "  -> This is normal for first-time deployments - table creation can take 5-15 minutes"
                        Write-Verbose "  -> Data was uploaded successfully and will be available once indexing completes"
                        $verificationSkipped = $true
                    } else {
                        Write-Warning "  Warning: Query error on attempt $attempt : $errorMessage"
                        if ($attempt -eq $maxVerificationAttempts) {
                            Write-Verbose "  -> Query verification not available in this environment"
                            $verificationSkipped = $true
                        }
                    }
                    break  # Don't retry bad request errors
                }
                else {
                    Write-Warning "  Warning: Query attempt $attempt failed: $errorMessage"                    
                    if ($attempt -eq $maxVerificationAttempts) {
                        Write-Verbose "  -> Maximum verification attempts reached"
                    } elseif ($attempt -lt $maxVerificationAttempts) {
                        Write-Verbose "  -> Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }
            }
        }
    }
    
    # Step 6: Final validation and reporting with graceful error handling
    Write-Verbose "Step 6: Final validation and reporting..."
    
    if ($verificationSkipped) {
        if ($permissionError) {
                Write-Warning "  Warning: Data verification skipped due to insufficient Log Analytics permissions."
                Write-Verbose "  -> Data upload completed successfully: $totalUploadedRecords records uploaded"
                Write-Verbose "  -> Consider granting 'Log Analytics Reader' role to the Automation Account for verification"
            } else {
                Write-Warning "  Warning: Data verification skipped - GuardrailsUserRaw_CL table not yet available."
                Write-Verbose "  -> Data upload completed successfully: $totalUploadedRecords records uploaded"
                Write-Verbose "  -> This is normal for first-time deployments - table creation can take 5-15 minutes"
                Write-Verbose "  -> Subsequent runs will be able to verify data once the table is established"
            }
            
        # Don't treat verification skip as a failure - data was uploaded successfully
        Write-Verbose "  Success: Data upload completed - $totalUploadedRecords records uploaded to Log Analytics"        
    } elseif ($permissionError) {
        # Permission error occurred during verification attempts
        Write-Warning "  Warning: Cannot verify data ingestion due to permission error."
        Write-Verbose "  -> Data upload completed: $totalUploadedRecords records uploaded"
        Write-Verbose "  -> Verification failed, but upload was successful"
            
        # Add a non-fatal warning rather than an error
        Add-FunctionError -Message "Data verification unavailable due to permissions. Upload completed successfully with $totalUploadedRecords records." -Category "Permissions" -ErrorList $ErrorList
        
    } elseif (-not $dataIngested) {
        # Log Analytics indexing can take longer than this immediate check even
        # after every upload succeeds. Keep the delay visible without reporting a
        # false collection error; the MFA control verifies these rows again before
        # it evaluates compliance and returns Not Applicable if they never appear.
        Write-Warning "FetchAllUserRawData verification pending | Uploaded=$totalUploadedRecords | ReportTime=$ReportTime | Log Analytics has not indexed these rows yet; the MFA control will verify them before compliance is evaluated."
    } elseif ($recordCount -ne $totalUploadedRecords) {
        # Data found but Log Analytics may still be indexing large uploads; upload failures are caught earlier per page.
        # Treat this as indexing lag instead of a module failure because each page upload already had retry/error handling.
        $expectedCount = $totalUploadedRecords
        Write-Warning "  Warning: Data count mismatch detected."
        Write-Verbose "  -> Expected: $expectedCount records, Found: $recordCount records"
        Write-Verbose "  -> Partial data ingestion detected - some records may still be processing"
    } else {
        # Perfect success case
        Write-Verbose "  Success: Data ingestion verification successful - $recordCount records ingested and verified"
        Write-Verbose "  -> Upload and verification both completed successfully"
    }
    
    # Performance summary
    $stopwatch.Stop()
    $performanceMetrics.EndTime = Get-Date
    $performanceMetrics.TotalDurationMs = $stopwatch.ElapsedMilliseconds
    $performanceMetrics.TotalDurationMin = [Math]::Round($stopwatch.ElapsedMilliseconds / 60000, 2)
    
    Write-Verbose "=== Performance Summary ==="
    $durationMin = $performanceMetrics.TotalDurationMin
    $durationMs = $performanceMetrics.TotalDurationMs
    Write-Verbose "  Total Duration: $durationMin minutes ($durationMs ms)"
    Write-Verbose "  Users Processed: $($performanceMetrics.UsersProcessed)"
    Write-Verbose "  Records Uploaded: $totalUploadedRecords"
    Write-Verbose "  Page Size: $BatchSize"
    Write-Verbose "  Upload Batch Size: $userRawUploadBatchSize"
    Write-Verbose "  Total Pages: $pageNumber"
    Write-Verbose "  Graph API Calls: $($performanceMetrics.GraphApiCalls)"
    Write-Verbose "  Graph API Retries: $($performanceMetrics.GraphApiRetries)"
    Write-Verbose "  Graph 429 Responses: $($performanceMetrics.GraphThrottles429)"
    Write-Verbose "  Graph Retry Wait: $($performanceMetrics.GraphRetryDelaySeconds) seconds"
    Write-Verbose "  Data Ingestion Attempts: $($performanceMetrics.DataIngestionAttempts)"
    # Include verification and total timings in normal completion logs.
    if ($verificationStopwatch) {
        & $writePhaseTiming "verification" $verificationStopwatch
    }
    & $writePhaseTiming "total" $stopwatch
    Write-Verbose "  Errors: $($ErrorList.Count)"
    
    if ($ErrorList.Count -eq 0) {
        Write-Verbose "  Success: Function completed successfully with no errors!"
    } else {
        $errorCount = $ErrorList.Count
        Write-Verbose "  Warning: Function completed with $errorCount errors/warnings"
    }
    
    Write-Verbose "=== FetchAllUserRawData Complete ==="
    
    return $ErrorList
}

# ============================================================================
# Guest User Cross-Tenant MFA Trust Functions
# ============================================================================

# Function to extract domain from guest user UPN or email
function Get-GuestUserHomeDomain {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string] $UserPrincipalName,
        
        [Parameter(Mandatory=$false)]
        [string] $Mail
    )
    
    # Extract domain from UPN (format: user_domain.com#EXT#@hosttenant.com)
    # Use greedy match (.*_) to capture from the LAST underscore before #EXT#
    if ($UserPrincipalName -match '.*_([^_#]+)#EXT#') {
        return $Matches[1]
    }
    # Or extract from mail
    elseif ($Mail -and $Mail -match '@(.+)$') {
        return $Matches[1]
    }
    
    return $null
}

function Get-ExternalUserHomeDomain {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [psobject] $User
    )

    # Preferred source:
    # Microsoft Graph identities[].issuer
    if ($User.identities) {
        foreach ($identity in @($User.identities)) {

            $issuer = [string]$identity.issuer

            if (-not [string]::IsNullOrWhiteSpace($issuer) -and
                $issuer -ne 'MicrosoftAccount' -and
                $issuer -ne 'ExternalAzureAD') {

                return $issuer
            }
        }
    }

    # B2B guest/member UPN in #EXT# format.
    $upn = [string]$User.userPrincipalName

    if ($upn -match '.*_([^_#]+)#EXT#') {
        return $Matches[1]
    }

    # Final fallback: mail domain.
    if ($User.mail -and $User.mail -match '@(.+)$') {
        return $Matches[1]
    }

    return $null
}
# Function to resolve tenant ID from domain (single domain)
# Returns a PSCustomObject with TenantId and ResolutionSucceeded properties
# Includes retry logic for transient failures (DNS timeout, throttling, 5xx errors)
function Resolve-TenantIdFromDomain {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string] $Domain,
        
        [Parameter(Mandatory=$false)]
        [int] $MaxRetries = 3,
        
        [Parameter(Mandatory=$false)]
        [int] $InitialDelayMs = 500
    )
    
    $attempt = 0
    $delay = $InitialDelayMs
    
    while ($attempt -lt $MaxRetries) {
        $attempt++
        
        try {
            # Use OpenID Connect discovery endpoint (public, no auth required)
            $tenantUrl = "https://login.microsoftonline.com/$Domain/.well-known/openid-configuration"
            
            if ($attempt -eq 1) {
                Write-Verbose "  Resolving tenant ID for domain: $Domain"
            } else {
                Write-Verbose "  Retry attempt $attempt/$MaxRetries for domain: $Domain"
            }
            
            $response = Invoke-RestMethod -Uri $tenantUrl -Method Get -ErrorAction Stop -TimeoutSec 10
            
            if ($response.token_endpoint -match 'https://login\.microsoftonline\.com/([a-f0-9-]+)/') {
                $tenantId = $Matches[1]
                Write-Verbose "Resolved $Domain → $tenantId (attempt $attempt)"
                return [PSCustomObject]@{
                    TenantId = $tenantId
                    ResolutionSucceeded = $true
                }
            }
            
            # Regex didn't match - this is a permanent failure (bad response format)
            Write-Verbose "Invalid response format for domain: $Domain"
            return [PSCustomObject]@{
                TenantId = $null
                ResolutionSucceeded = $false
            }
            
        }
        catch {
            # NOTE: Invoke-RestMethod throws exceptions for HTTP error codes (4xx, 5xx) by default
            # This catch block handles: 404, 429, 500, 503, timeouts, network errors, etc.
            
            $errorMessage = $_.Exception.Message
            $statusCode = $null
            $isTransient = $false
            
            # Extract HTTP status code if available (works for both PS 5.1 and PS 7+)
            if ($_.Exception.Response) {
                # Try direct property first (PS 7+)
                if ($_.Exception.Response.StatusCode.Value__) {
                    $statusCode = [int]$_.Exception.Response.StatusCode.Value__
                }
                # Fallback to casting (PS 5.1)
                else {
                    $statusCode = [int]$_.Exception.Response.StatusCode
                }
            }
            elseif ($_.Exception.InnerException.Response) {
                # Check inner exception (some network stacks wrap the exception)
                if ($_.Exception.InnerException.Response.StatusCode.Value__) {
                    $statusCode = [int]$_.Exception.InnerException.Response.StatusCode.Value__
                }
                else {
                    $statusCode = [int]$_.Exception.InnerException.Response.StatusCode
                }
            }
            
            # Classify error based on status code (most reliable)
            if ($statusCode) {
                Write-Verbose "HTTP $statusCode for domain: $Domain (attempt $attempt/$MaxRetries)"
                
                switch ($statusCode) {
                    # 2xx - Success (shouldn't reach here, but handle gracefully)
                    { $_ -ge 200 -and $_ -lt 300 } {
                        Write-Verbose "Unexpected: Got HTTP $statusCode but entered catch block"
                        $isTransient = $false
                    }
                    # 4xx - Client errors (permanent, except 429)
                    429 {
                        # Too Many Requests - transient, should retry
                        $isTransient = $true
                        Write-Verbose "Rate limited (429) for domain: $Domain"
                    }
                    404 {
                        # Not Found - domain/tenant doesn't exist (permanent)
                        Write-Verbose "Domain not found (404): $Domain"
                        return [PSCustomObject]@{
                            TenantId = $null
                            ResolutionSucceeded = $false
                        }
                    }
                    { $_ -ge 400 -and $_ -lt 500 } {
                        # Other 4xx - permanent errors (bad request, unauthorized, forbidden, etc.)
                        Write-Verbose "Client error ($statusCode) for domain: $Domain"
                        return [PSCustomObject]@{
                            TenantId = $null
                            ResolutionSucceeded = $false
                        }
                    }
                    # 5xx - Server errors (transient, should retry)
                    { $_ -ge 500 -and $_ -lt 600 } {
                        $isTransient = $true
                        Write-Verbose "Server error ($statusCode) for domain: $Domain"
                    }
                    # Unexpected status code
                    default {
                        $isTransient = $true
                        Write-Verbose "Unexpected status code ($statusCode) for domain: $Domain"
                    }
                }
            }
            # No status code - likely network/DNS/timeout issue (transient)
            else {
                $isTransient = $true
                Write-Verbose "Network/timeout error for domain $Domain (attempt $attempt/$MaxRetries): $errorMessage"
            }
            
            # If this is the last attempt, fail
            if (!$isTransient -or $attempt -ge $MaxRetries) {
                Write-Verbose "Failed to resolve tenant ID for domain: $Domain after $attempt attempt(s)"
                return [PSCustomObject]@{
                    TenantId = $null
                    ResolutionSucceeded = $false
                }
            }
            
            # Wait before retry with exponential backoff
            Write-Verbose "Waiting ${delay}ms before retry..."
            Start-Sleep -Milliseconds $delay
            $delay = $delay * 2  # Exponential backoff
        }
    }
    
    # Shouldn't reach here, but handle edge case
    Write-Verbose "Failed to resolve tenant ID for domain: $Domain (max retries exceeded)"
    return [PSCustomObject]@{
        TenantId = $null
        ResolutionSucceeded = $false
    }
}

# Function to get or resolve tenant ID with lazy caching
# Returns a PSCustomObject with TenantId and ResolutionSucceeded properties
function Get-TenantIdWithCache {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string] $Domain,
        
        [Parameter(Mandatory=$true)]
        [hashtable] $Cache
    )
    
    # Check cache first
    if ($Cache.ContainsKey($Domain)) {
        return $Cache[$Domain]
    }
    
    # Not in cache, resolve it
    Write-Verbose "  Cache miss for domain: $Domain, resolving..."
    $result = Resolve-TenantIdFromDomain -Domain $Domain
    
    # Store in cache (even if resolution failed, to avoid retrying failed lookups)
    $Cache[$Domain] = $result
    
    return $result
}

# Function to get cross-tenant access settings for B2B collaboration
function Get-CrossTenantAccessSettings {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$false)]
        [hashtable] $PerformanceMetrics = $null
    )
    
    $ErrorList = [System.Collections.Generic.List[string]]::new()
    $crossTenantSettings = @()
    
    try {
        Write-Verbose "Fetching cross-tenant access settings..."
        
        # Get default cross-tenant access settings
        $defaultSettingsPath = "/policies/crossTenantAccessPolicy/default"
        try {
            $defaultResponse = Invoke-GraphQueryWithMetrics -UrlPath $defaultSettingsPath -Operation "Fetch Default Cross-Tenant Access Settings" -PerformanceMetrics $PerformanceMetrics
            $defaultSettings = $defaultResponse.Content
            
            if ($defaultSettings) {
                Write-Verbose "  Retrieved default cross-tenant access settings"
                $crossTenantSettings += [PSCustomObject]@{
                    PartnerTenantId = "default"
                    InboundTrustMfa = $defaultSettings.inboundTrust.isMfaAccepted
                    InboundTrustCompliantDevice = $defaultSettings.inboundTrust.isCompliantDeviceAccepted
                    InboundTrustHybridAzureADJoined = $defaultSettings.inboundTrust.isHybridAzureADJoinedDeviceAccepted
                    IsDefault = $true
                }
            }
        } catch {
            Add-FunctionError -Message "Failed to fetch default cross-tenant access settings: $($_.Exception.Message)" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
        }
        
        # Get partner-specific cross-tenant access settings
        $partnerSettingsPath = "/policies/crossTenantAccessPolicy/partners"
        try {
            $partnerResponse = Invoke-GraphQueryWithMetrics -UrlPath $partnerSettingsPath -Operation "Fetch Partner Cross-Tenant Access Settings" -PerformanceMetrics $PerformanceMetrics
            $partnerSettings = @($partnerResponse.Content.value)
            
            Write-Verbose "  Retrieved $($partnerSettings.Count) partner-specific cross-tenant access settings"
            
            foreach ($partner in $partnerSettings) {
                $crossTenantSettings += [PSCustomObject]@{
                    PartnerTenantId = $partner.tenantId
                    InboundTrustMfa = $partner.inboundTrust.isMfaAccepted
                    InboundTrustCompliantDevice = $partner.inboundTrust.isCompliantDeviceAccepted
                    InboundTrustHybridAzureADJoined = $partner.inboundTrust.isHybridAzureADJoinedDeviceAccepted
                    IsDefault = $false
                }
            }
        } catch {
            Add-FunctionError -Message "Failed to fetch partner cross-tenant access settings: $($_.Exception.Message)" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
        }
        
    } catch {
        Add-FunctionError -Message "Unexpected error fetching cross-tenant access settings: $($_.Exception.Message)" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
    }
    
    return [PSCustomObject]@{
        Settings = $crossTenantSettings
        ErrorList = $ErrorList
    }
}

# Function to check if conditional access policies require MFA for guest users
function Test-GuestMfaConditionalAccessPolicy {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$false)]
        [hashtable] $PerformanceMetrics = $null
    )
    
    $ErrorList = [System.Collections.Generic.List[string]]::new()
    $hasGuestMfaPolicy = $false
    $matchingPolicies = @()
    
    try {
        Write-Verbose "Checking conditional access policies for guest MFA requirements..."
        
        $capPath = "/identity/conditionalAccess/policies"
        $capResponse = Invoke-GraphQueryWithMetrics -UrlPath $capPath -Operation "Fetch Conditional Access Policies" -PerformanceMetrics $PerformanceMetrics
        $policies = @($capResponse.Content.value)
        
        Write-Verbose "  Analyzing $($policies.Count) conditional access policies..."
        
        # Check for policies that meet these criteria:
        # 1. State = 'enabled'
        # 2. Includes guest/external users OR includes all users
        # 3. Does NOT explicitly exclude guest/external users
        # 4. Requires MFA
        $matchingPolicies = $policies | Where-Object {
            $_.state -eq 'enabled' -and
            $_.grantControls.builtInControls -contains 'mfa' -and
            (
                # Either targets all users (which includes guests)
                ($_.conditions.users.includeUsers -contains 'All') -or
                # Or specifically targets guest/external users
                ($null -ne $_.conditions.users.includeGuestsOrExternalUsers -and
                 $_.conditions.users.includeGuestsOrExternalUsers.guestOrExternalUserTypes -match 'b2bCollaborationGuest|b2bCollaborationMember|internalGuest')
            ) -and
            # Ensure guests are NOT explicitly excluded
            ($null -eq $_.conditions.users.excludeGuestsOrExternalUsers -or
             $_.conditions.users.excludeGuestsOrExternalUsers.guestOrExternalUserTypes -notmatch 'b2bCollaborationGuest|b2bCollaborationMember|internalGuest')
        }
        
        if ($matchingPolicies.Count -gt 0) {
            $hasGuestMfaPolicy = $true
            Write-Verbose "  Found $($matchingPolicies.Count) conditional access policies requiring MFA for guest users"
            foreach ($policy in $matchingPolicies) {
                Write-Verbose "    - Policy: $($policy.displayName)"
            }
        } else {
            Write-Verbose "  No conditional access policies found requiring MFA for guest users"
        }
        
    } catch {
        Add-FunctionError -Message "Failed to check conditional access policies for guest MFA: $($_.Exception.Message)" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
    }
    
    return [PSCustomObject]@{
        HasGuestMfaPolicy = $hasGuestMfaPolicy
        MatchingPolicies = $matchingPolicies
        ErrorList = $ErrorList
    }
}

# Function to collect and upload cross-tenant access and guest MFA policy data to Log Analytics
function Upload-CrossTenantAccessData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        
        [Parameter(Mandatory=$true)]
        [string] $WorkSpaceID,
        
        [Parameter(Mandatory=$true)]
        [string] $WorkspaceKey,
        
        [Parameter(Mandatory=$false)]
        [hashtable] $PerformanceMetrics = $null
    )
    
    $ErrorList = [System.Collections.Generic.List[string]]::new()
    
    try {
        Write-Verbose "=== Starting Cross-Tenant Access Data Collection ==="
        
        # Get cross-tenant access settings
        $crossTenantResult = Get-CrossTenantAccessSettings -PerformanceMetrics $PerformanceMetrics
        if ($crossTenantResult.ErrorList.Count -gt 0) {
            $crossTenantResult.ErrorList | ForEach-Object { $ErrorList.Add($_) }
        }
        
        # Check guest MFA conditional access policies
        $guestMfaPolicyResult = Test-GuestMfaConditionalAccessPolicy -PerformanceMetrics $PerformanceMetrics
        if ($guestMfaPolicyResult.ErrorList.Count -gt 0) {
            $guestMfaPolicyResult.ErrorList | ForEach-Object { $ErrorList.Add($_) }
        }
        
        # Prepare data for upload
        $crossTenantData = @()
        
        # Upload cross-tenant access settings
        foreach ($setting in $crossTenantResult.Settings) {
            $crossTenantData += [PSCustomObject]@{
                ReportTime = $ReportTime
                PartnerTenantId = $setting.PartnerTenantId
                InboundTrustMfa = $setting.InboundTrustMfa
                InboundTrustCompliantDevice = $setting.InboundTrustCompliantDevice
                InboundTrustHybridAzureADJoined = $setting.InboundTrustHybridAzureADJoined
                IsDefault = $setting.IsDefault
                HasGuestMfaPolicy = $guestMfaPolicyResult.HasGuestMfaPolicy
            }
        }
        
        # If no settings found, upload a single record indicating the state
        if ($crossTenantData.Count -eq 0) {
            $crossTenantData += [PSCustomObject]@{
                ReportTime = $ReportTime
                PartnerTenantId = "none"
                InboundTrustMfa = $false
                InboundTrustCompliantDevice = $false
                InboundTrustHybridAzureADJoined = $false
                IsDefault = $true
                HasGuestMfaPolicy = $guestMfaPolicyResult.HasGuestMfaPolicy
            }
        }
        
        # Upload to Log Analytics
        Write-Verbose "Uploading cross-tenant access data to Log Analytics..."
        try {
            New-LogAnalyticsData -Data $crossTenantData -WorkSpaceID $WorkSpaceID -WorkSpaceKey $WorkspaceKey -LogType "GuardrailsCrossTenantAccess" | Out-Null
            Write-Verbose "  Success: Cross-tenant access data uploaded successfully"
        } catch {
            Add-FunctionError -Message "Failed to upload cross-tenant access data: $($_.Exception.Message)" -Exception $_.Exception -Category "LogAnalytics" -ErrorList $ErrorList
        }
        
        Write-Verbose "=== Cross-Tenant Access Data Collection Complete ==="
        
    } catch {
        Add-FunctionError -Message "Unexpected error during cross-tenant access data collection: $($_.Exception.Message)" -Exception $_.Exception -Category "General" -ErrorList $ErrorList
    }
    
    return $ErrorList
}


function Set-SubscriptionNotEvaluatedStatus{
    <#
    .SYNOPSIS
    Sets the subscription status to "Not applicable".

    .DESCRIPTION
    Mirrors the compliance status as 'Not applicable' convention used by Add-ProfileInformation for profile skipped rows. 
    It takes an existing result object and overwrites its compliance status and comments to reflect that it is not evaluated.
    This is used when a subscription is not evaluated due to being excluded by the user or by the system.
    #>
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject] $Result,
        [Parameter(Mandatory=$true)]
        $SubscriptionName,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable
        
    )

    $Result.ComplianceStatus = "Not applicable"
    $Result.Comments = $msgTable.subEvaluationNotApplicable -f $SubscriptionName
    return $Result


}
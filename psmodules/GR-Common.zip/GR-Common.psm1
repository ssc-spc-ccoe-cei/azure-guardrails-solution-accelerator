function get-tagValue {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $tagKey,
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    $tagString = get-tagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}
function get-tagstring {
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    if ($object.Tag.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = [System.Text.StringBuilder]::new()
        $tKeys = $object.tag | Select-Object -ExpandProperty keys
        $tValues = $object.Tag | Select-Object -ExpandProperty values
        $index = 0

        if ($object.Tag.Count -eq 1) {
            $tagstring = "$tKeys=$tValues"
        }
        else {
            foreach ($tkey in $tKeys) {
                [void]$tagstring.Append("$tkey=$($tValues[$index]);")
                $index++
            }
        }
        $tagstring = $tagstring.ToString().TrimEnd(';')
    }
    return $tagstring
}
function get-rgtagstring {
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    if ($object.Tags.Count -eq 0) {
        $tagstring = "None"
    }
    else {
        $tagstring = [System.Text.StringBuilder]::new()
        $tKeys = $object.tags | Select-Object -ExpandProperty keys
        $tValues = $object.Tags | Select-Object -ExpandProperty values
        $index = 0
        foreach ($tkey in $tKeys) {
            [void]$tagstring.Append("$tkey=$($tValues[$index]);")
            $index++
        }
        $tagstring = $tagstring.ToString().TrimEnd(';')
    }
    return $tagstring
}
function get-rgtagValue {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $tagKey,
        [Parameter(Mandatory = $true)]
        [System.Object] $object
    )
    $tagString = get-rgtagstring($object)
    $tagslist = $tagString.split(";")
    foreach ($tag in $tagslist) {
        if ($tag.split("=")[0] -eq $tagKey) {
            return $tag.split("=")[1]
        }
    }
    return ""
}
function copy-toBlob {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName,
        [Parameter(Mandatory = $false)]
        [switch]
        $force
    )
    try {
        $saParams = @{
            ResourceGroupName = $resourcegroup
            Name              = $storageaccountName
        }
        $scParams = @{
            Container = $containerName
        }
        $bcParams = @{
            File = $FilePath
            Blob = ($FilePath | Split-Path -Leaf)
        }
        if ($force)
        { Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Set-AzStorageBlobContent @bcParams -Force | Out-Null }
        else { Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Set-AzStorageBlobContent @bcParams | Out-Null }
    }
    catch {
        Write-Error $_.Exception.Message
    }
}
function get-blobs {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup
    )
    $psModulesContainerName = "psmodules"
    try {
        $saParams = @{
            ResourceGroupName = $resourcegroup
            Name              = $storageaccountName
        }
        $scParams = @{
            Container = $psModulesContainerName
        }
        return (Get-AzStorageAccount @saParams | Get-AzStorageContainer @scParams | Get-AzStorageBlob)
    }
    catch {
        Write-Error $_.Exception.Message
    }
}

function read-blob {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $FilePath,
        [Parameter(Mandatory = $true)]
        [string]
        $storageaccountName,
        [Parameter(Mandatory = $true)]
        [string]
        $resourcegroup,
        [Parameter(Mandatory = $true)]
        [string]
        $containerName,
        [Parameter(Mandatory = $false)]
        [switch]
        $force
    )
    $Context = (Get-AzStorageAccount -ResourceGroupName $resourcegroup -Name $storageaccountName).Context
    $blobParams = @{
        Blob        = 'modules.json'
        Container   = $containerName
        Destination = $FilePath
        Context     = $Context
        Force       = $true
    }
    Get-AzStorageBlobContent @blobParams
}

Function Add-LogEntry {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [ValidateSet("Critical", "Error", "Warning", "Information", "Debug")]
        [string]
        $severity,

        # message details (string)
        [Parameter(Mandatory = $true, Position = 1)]
        [string]
        $message,

        # module name
        [Parameter(Mandatory = $false)]
        [string]
        $moduleName = (Split-Path -Path $MyInvocation.ScriptName -Leaf),

        # additional values in hashtable
        [Parameter(Mandatory = $false)]
        [hashtable]
        $additionalValues = @{},

        # exception log type - this is the Log Analytics table name
        [Parameter(Mandatory = $false)]
        [string]
        $exceptionLogTable = "GuardrailsComplianceException",

        # guardrails exception workspace GUID
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceGuid,

        # guardrails exception workspace shared key
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey
    )

    # build log entry object, convert to json
    $entryHash = @{
        "message"    = $message
        "moduleName" = $moduleName
        "severity"   = $severity
    } + $additionalValues
    
    $entryJson = ConvertTo-Json -inputObject $entryHash -Depth 20

    # log event to Log Analytics workspace by REST API via the OMSIngestionAPI community PS module
    Send-OMSAPIIngestionFile  -customerId $workspaceGuid `
        -sharedkey $workspaceKey `
        -body $entryJson `
        -logType $exceptionLogTable `
        -TimeStampField Get-Date 

}

Function Add-TenantInfo {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_TenantInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $true)]
        [string]
        $TenantId,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentName,
        [Parameter(Mandatory = $true)]
        [string]
        $DepartmentNumber,
        [Parameter(Mandatory = $true)]
        [string]
        $cloudUsageProfiles,
        [Parameter(Mandatory = $true)]
        [string]
        $tenantName,
        [Parameter(Mandatory = $true)]
        [string]
        $locale
    )
    $tenantInfo = Get-GSAAutomationVariable("tenantDomainUPN")

    $object = [PSCustomObject]@{ 
        TenantDomain       = $tenantInfo
        DepartmentTenantID = $TenantId
        DepartmentTenantName= $tenantName
        ReportTime         = $ReportTime
        DepartmentName     = $DepartmentName
        DepartmentNumber   = $DepartmentNumber
        cloudUsageProfiles = $cloudUsageProfiles
        Locale             = $locale
    }
    if ($debug) { Write-Output $tenantInfo }
    $JSON = ConvertTo-Json -inputObject $object

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}

function Add-LogAnalyticsResults {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_Results",
        [Parameter(Mandatory = $false)]
        [array]
        $Results
    )

    $JSON = ConvertTo-Json -inputObject $Results

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}

function Check-DocumentExistsInStorage {
    [Alias('Check-DocumentsExistInStorage')]
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $StorageAccountName,
        [Parameter(Mandatory = $true)]
        [string] $ContainerName, 
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID, 
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName, 
        [Parameter(Mandatory = $true)]
        [string] $ControlName, 
        [Parameter(Mandatory = $true)]
        [string]$ItemName,
        [Parameter(Mandatory = $true)]
        [hashtable] $msgTable, 
        [Parameter(Mandatory = $true)]
        [string]$itsgcode,
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $false)]
        [string] 
        $CloudUsageProfiles = "3",  # Passed as a string
        [Parameter(Mandatory = $false)]
        [string] $ModuleProfiles,  # Passed as a string
        [Parameter(Mandatory = $false)]
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false    
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null

    # Add possible file extensions
    $DocumentName_new = add-documentFileExtensions -DocumentName $DocumentName -ItemName $ItemName

    try {
        Select-AzSubscription -Subscription $SubscriptionID | out-null
    }
    catch {
        $ErrorList.Add("Failed to run 'Select-Azsubscription' with error: $_")
        #Add-LogEntry 'Error' 
        throw "Error: Failed to run 'Select-Azsubscription' with error: $_"
    }
    try {
        $StorageAccount = Get-Azstorageaccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -ErrorAction Stop
    }
    catch {
        $ErrorList.Add("Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_")
        #Add-LogEntry 'Error' "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
        #    subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_" `
        #    -workspaceKey $workspaceKey -workspaceGuid $WorkSpaceID
        Write-Error "Could not find storage account '$storageAccountName' in resoruce group '$resourceGroupName' of `
            subscription '$subscriptionId'; verify that the storage account exists and that you have permissions to it. Error: $_"
    }

    $docMissing = $false
    $commentsArray = @()
    $blobFound = $false
    $baseFileNameFound = $false
   
    # Get a list of filenames uploaded in the blob storage
    $blobs = Get-AzStorageBlob -Container $ContainerName -Context $StorageAccount.Context
    $fileNamesList = @()
    $blobs | ForEach-Object {
        $fileNamesList += $_.Name
    }
    $matchingFiles = $fileNamesList | Where-Object { $_ -in $DocumentName_new }
    if ( $matchingFiles.count -lt 1 ){
        # check if any fileName matches without the extension
        $baseFileNames = $fileNamesList | ForEach-Object { ($_.Split('.')[0]) }
        
        $BaseFileNamesMatch = $baseFileNames | Where-Object { $_ -in $DocumentName  }
        if ($BaseFileNamesMatch.Count -gt 0){
            $baseFileNameFound = $true
        }
    }
    else {
        # also covers the use case if more than 1 appropriate files are uploaded
        $blobFound = $true
    }

    # Use case: uploaded fileName is correct but has wrong extension
    if ($baseFileNameFound){
        # a blob with the name $documentName was located in the specified storage account; however, the ext is not correct
        $docMissing = $true
        $commentsArray += $msgTable.procedureFileNotFoundWithCorrectExtension -f $DocumentName[0], $ContainerName, $StorageAccountName
    }
    else{
        if ($blobFound){
            # Use case: a blob with the name $documentName was located in the specified storage account
            $commentsArray += $msgTable.procedureFileFound -f  $DocumentName
        }
        else {
            # Use case: no blob with the name $documentName was found in the specified storage account
            $docMissing = $true
            $commentsArray += $msgTable.procedureFileNotFound -f $DocumentName[0], $ContainerName, $StorageAccountName
        }
    }

    $Comments = $commentsArray -join ";"

    If ($docMissing) {
        $IsCompliant = $false
    }
    Else {
        $IsCompliant = $true
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        DocumentName     = $DocumentName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    if ($EnableMultiCloudProfiles) {        
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID
        if (!$evalResult.ShouldEvaluate) {
            if ($evalResult.Profile -gt 0) {
                $PsObject.ComplianceStatus = "Not Applicable"
                $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $PsObject.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
                
                $moduleOutput = [PSCustomObject]@{ 
                    ComplianceResults = $PsObject
                    Errors            = $ErrorList
                    AdditionalResults = $AdditionalResults
                }
                return $moduleOutput
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        } else {
            
            $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
        }
    }

    $moduleOutput = [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput

}

function Check-UpdateAvailable {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string]
        $LogType = "GR_VersionInfo",
        [Parameter(Mandatory = $true)]
        [string]
        $ReportTime,
        [Parameter(Mandatory = $false)]
        [string]
        $ResourceGroupName
    )
    #fetches current public version (from repo...maybe should download the zip...)
    $latestRelease = Invoke-RestMethod 'https://api.github.com/repos/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases/latest' -Verbose:$false
    $tagsFileURI = "https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/raw/{0}/setup/tags.json" -f $latestRelease.name
    $tags = Invoke-RestMethod $tagsFileURI -Verbose:$false

    if ([string]::IsNullOrEmpty($ResourceGroupName)) {
        $ResourceGroupName = Get-AutomationVariable -Name "ResourceGroupName"
    }
    $rg=Get-AzResourceGroup -Name $ResourceGroupName 

    $deployedVersion=$rg.Tags["ReleaseVersion"]
    $currentVersion = $tags.ReleaseVersion

    try {
        # script version numbers of surrounding characters and then converted to a version object
        $deployedVersionVersion = [version]::Parse(($deployedVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
        $currentVersionVersion = [version]::Parse(($currentVersion -replace '[\w-]+?(\d+?\.\d+?\.\d+?(\.\d+?)?)[\w-]*$','$1'))
    }
    catch {
        Write-Error "Error: Failed to convert version numbers to version objects. Error: $_"
    }

    if ($debug) { Write-Output "Resource Group Tag (deployed version): $deployedVersion; $deployedVersionVersion"}
    if ($debug) { Write-Output "Latest available version from GitHub: $currentVersion; $currentVersionVersion"}
    
    if ($deployedVersionVersion -lt $currentVersionVersion)
    {
        $updateNeeded=$true
    }
    elseif(($deployedVersionVersion -eq $currentVersionVersion) -and 
        ($deployedVersion -match 'beta') -and 
        ($currentVersion -notmatch 'beta')) {
        $updateNeeded = $true
    }
    else {
        $updateNeeded = $false
    }
    $object = [PSCustomObject]@{ 
        DeployedVersion = $deployedVersion
        AvailableVersion = $currentVersion
        UpdateNeeded= $updateNeeded
        ReportTime = $ReportTime
    }
    $JSON = ConvertTo-Json -inputObject $object

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSON `
        -logType $LogType `
        -TimeStampField Get-Date 
}

function get-itsgdata {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]
        $URL,
        [Parameter(Mandatory = $true)]
        [string] $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string] $workspaceKey,
        [Parameter(Mandatory = $false)]
        [string] $LogType = "GRITSGControls",
        [Parameter(Mandatory = $false)]
        [switch] $DebugCode
    )
    (Invoke-WebRequest -UseBasicParsing $URL).Content | out-file tempitsg.csv
    $Header = "Family", "Control ID", "Enhancement", "Name", "Class", "Definition", "Supplemental Guidance,References"
    $itsgtempinfo = Import-Csv ./tempitsg.csv -Header $Header
    $itsginfo = $itsgtempinfo | Select-Object Name, Definition, @{Name = "itsgcode"; Expression = { ($_.Family + $_."Control ID" + $_.Enhancement).replace("`t", "") } }
    $JSONcontrols = ConvertTo-Json -inputObject $itsginfo
    
    if ($DebugCode) {
        $JSONcontrols
    }

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JSONcontrols `
        -logType $LogType `
        -TimeStampField Get-Date
}

function New-LogAnalyticsData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [array] 
        $Data,
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceID,
        [Parameter(Mandatory = $true)]
        [string]
        $WorkSpaceKey,
        [Parameter(Mandatory = $true)]
        [string]
        $LogType
    )
    $JsonObject = convertTo-Json -inputObject $Data -Depth 3

    Send-OMSAPIIngestionFile  -customerId $WorkSpaceID `
        -sharedkey $workspaceKey `
        -body $JsonObject `
        -logType $LogType `
        -TimeStampField Get-Date  
}

function Hide-Email {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$email
    )

    $parts = $email -split '@'
    if ($parts.Length -eq 2) {
        $username = $parts[0]
        $domain = $parts[1]

        $hiddenUsername = $username[0] + ($username.Substring(1, $username.Length - 2) -replace '.', '#') + $username[-1]
        $hiddenDomain = $domain[0] + ($domain.Substring(1, $domain.Length - 5) -replace '.', '#') + $domain[-4] + $domain[-3] + $domain[-2] + $domain[-1]

        $hiddenEmail = "$hiddenUsername@$hiddenDomain"
        return $hiddenEmail
    } else {
        return "Invalid email format"
    }
}

function Get-EvaluationProfile {
    [OutputType([PSCustomObject])]
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $CloudUsageProfiles,
        [Parameter(Mandatory = $true)]
        [string] $ModuleProfiles,
        [Parameter(Mandatory = $false)]
        [string] $SubscriptionId
    )
    Write-Host "Config CloudUsageProfiles $CloudUsageProfiles"
    Write-Host "MCP GR ModuleProfiles $ModuleProfiles"
    Write-Host "SubscriptionId $SubscriptionId"

    $returnProfile = ""
    $returnShouldEvaluate = $false
    $returnShouldAvailable = $false

    try {
        # Convert input strings to integer arrays  
        $cloudUsageProfileArray = ConvertTo-IntArray $CloudUsageProfiles
        $moduleProfileArray = ConvertTo-IntArray $ModuleProfiles

        if (-not $SubscriptionId) {
            $matchedProfile = Get-HighestMatchingProfile $cloudUsageProfileArray $moduleProfileArray
            return [PSCustomObject]@{
                Profile = $matchedProfile
                ShouldEvaluate = ($matchedProfile -in $cloudUsageProfileArray)
            }
        }

        $subscriptionTags = Get-AzTag -ResourceId "subscriptions/$SubscriptionId" -ErrorAction Stop
        $profileTagValues = if ($subscriptionTags.Properties -and 
                              $subscriptionTags.Properties.TagsProperty -and 
                              $subscriptionTags.Properties.TagsProperty['profile']) {
            $subscriptionTags.Properties.TagsProperty['profile']
        } else {
            $null
        }

        if ($null -eq $profileTagValues) {
            $matchedProfile = Get-HighestMatchingProfile $cloudUsageProfileArray $moduleProfileArray
            return [PSCustomObject]@{
                Profile = $matchedProfile
                ShouldEvaluate = ($matchedProfile -in $cloudUsageProfileArray)
                ShouldAvailable = ($matchedProfile -in $moduleProfileArray)
            }
        }

        $profileTagValuesArray = ConvertTo-IntArray $profileTagValues

        # Get the highest profile from all sources
        #cloudUsageProfile from config json
        $highestCloudUsageProfile = ($cloudUsageProfileArray | Measure-Object -Maximum).Maximum
        #module profiles for the guardrail
        $highestModuleProfile = ($moduleProfileArray | Measure-Object -Maximum).Maximum
        #subscription tag
        $highestTagProfile = ($profileTagValuesArray | Measure-Object -Maximum).Maximum


        $returnProfile = $highestTagProfile
        $returnShouldAvailable = ($highestTagProfile -in $moduleProfileArray)
        # Use the highest profile if it's present in the module profiles
        if ($highestTagProfile -in $moduleProfileArray) {
            # CONDITION: hightest sub tag is in module profile
            $returnShouldEvaluate = ($highestTagProfile -in $cloudUsageProfileArray)   
        }
        else{
            # CONDITION: hightest sub tag is not in module profile
            $returnShouldEvaluate = ($highestTagProfile -in $moduleProfileArray)
        }
        
        return [PSCustomObject]@{
            Profile =  $returnProfile
            ShouldEvaluate = $returnShouldEvaluate
            ShouldAvailable = $returnShouldAvailable
        }
    }
    catch {
        Write-Error "Error in Get-EvaluationProfile: $_"
        return [PSCustomObject]@{
            Profile = 0
            ShouldEvaluate = $false
            ShouldAvailable = $false
        }
    }
}

# Helper function to get the highest matching profile
function Get-HighestMatchingProfile {
    [OutputType([int])]
    param (
        [Parameter(Mandatory = $true)]
        [int[]]$profile1,
        [Parameter(Mandatory = $true)]
        [int[]]$profile2
    )
    $matchingProfiles = $profile1 | Where-Object { $profile2 -contains $_ }
    if ($matchingProfiles.Count -eq 0) {
        return 0
    }
    return ($matchingProfiles | Measure-Object -Maximum).Maximum
}

function ConvertTo-IntArray {
    [OutputType([int[]])]
    param (
        [Parameter(Mandatory = $true)]
        [string]$inputString
    )
    # Remove any brackets and split on comma, then convert each element to int
    return $inputString.Trim('[]').Split(',') | ForEach-Object { [int]$_.Trim() }
}

function Parse-BlobContent {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$blobContent
    )

    # Check if blob content is retrieved
    if (-not $blobContent) {
        throw "Failed to retrieve blob content or blob is empty."
    }

    # Split content into lines
    $lines = $blobContent -split "`r`n|`n|,|;|,\s|;\s"

    $filteredLines = $lines | Where-Object { $_ -match '\S' -and $_ -like "*@*" } | ForEach-Object { $_ -replace '\s' }

    # Initialize an empty array
    $globalAdminUPNs = @()

    # Check each line, remove the hyphen (if any), and add to array
    foreach ($line in $filteredLines) {
        if ($line.StartsWith("-")) {
            # Remove the leading hyphen and any potential whitespace after it
            $trimmedLine = $line.Substring(1)
        } 
        else{
            $trimmedLine = $line
        }
        $trimmedLine = $trimmedLine.Trim()
        $globalAdminUPNs += $trimmedLine
    }

    $result = New-Object PSObject -Property @{
        GlobalAdminUPNs = $globalAdminUPNs
    }

    return $result
}
# New improves version of Invoke-GraphQuery function that handles paging and retries
# This function is designed to be used with the Microsoft Graph API and will automatically handle pagination

function Invoke-GraphQueryEX {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string]
        $urlPath,
        [int]$MaxRetries = 3,
        [int]$RetryDelaySeconds = 5
    )

    [string]$baseUri = "https://graph.microsoft.com/v1.0"
    $fullUri = "$baseUri$urlPath" 
    $allResults = @()
    $statusCode = $null
    $pageCount = 0
   # Write-Host $fullUri
    do {
        $retryCount = 0
        $success = $false
        $pageCount++
        Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Retrieving page $pageCount..."
        
        do {
            try {
                $uri = $fullUri -as [uri]
                $response = Invoke-AZRestMethod  -Uri $uri  -Method GET -ErrorAction Stop 
                $data = $response.Content | ConvertFrom-Json
                $parsedcontent = $data.value
                $statusCode = $response.StatusCode
                $success = $true
            }
            catch {
                $retryCount++
                if ($retryCount -ge $MaxRetries) {
                    Write-Error "Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $($_.Exception.Message) at page $pageCount"
                    Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Failed" -Completed
                    return @{
                        Content    = $null
                        StatusCode = $null
                        Error      = $_.Exception.Message
                    }
                } else {
                    Write-Warning "Transient error calling Graph API: $($_.Exception.Message). Retrying in $RetryDelaySeconds seconds... (Attempt $retryCount of $MaxRetries)"
                    Start-Sleep -Seconds $RetryDelaySeconds
                }
            }
        } while (-not $success -and $retryCount -lt $MaxRetries)

        if ($null -ne $data.value) {
            $allResults += $data.value
        } else {
            # For endpoints that don't return .value (single object)
            $allResults = $data
            break
        }
        # Handle paging
        if ($data.'@odata.nextLink') {
            $fullUri = $data.'@odata.nextLink'
        } else {
            $fullUri = $null
        }
    } while ($fullUri)
    
    Write-Progress -Activity "Invoke-GraphQueryEX" -Status "Completed" -Completed

    return @{
        Content    = @{ value = $allResults }
        StatusCode = $statusCode
    }
}
# end of Invoke-GraphQueryEX function

# Function for true streaming Graph API queries with callback processing
function Invoke-GraphQueryStreamWithCallback {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string] $urlPath,
        
        [Parameter(Mandatory = $true)]
        [scriptblock] $ProcessPageCallback,
        
        [Parameter(Mandatory = $false)]
        [hashtable] $CallbackContext = @{},
        
        [Parameter(Mandatory = $false)]
        [int] $PageSize = 999,
        
        [Parameter(Mandatory = $false)]
        [int] $MaxRetries = 3,
        
        [Parameter(Mandatory = $false)]
        [int] $RetryDelaySeconds = 5,
        
        [Parameter(Mandatory = $false)]
        [hashtable] $PerformanceMetrics = $null
    )

    [string] $baseUri = "https://graph.microsoft.com/v1.0"
    
    # Add $top parameter if not already present
    if ($urlPath -notmatch '\$top=') {
        $separator = if ($urlPath -match '\?') { '&' } else { '?' }
        $urlPath = "$urlPath$separator`$top=$PageSize"
    }

    
    $fullUri = "$baseUri$urlPath"
    $pageCount = 0
    $totalProcessed = 0
    $totalUploaded = 0
        
    do {
        $pageCount++
        $retryCount = 0
        $success = $false
        
        Write-Verbose "  -> Fetching page $pageCount from Graph API..."        
        do {
            try {
                $uri = $fullUri -as [uri]
                $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop
                $statusCode = $response.StatusCode
                                
                # Check for successful status codes (200-299)
                if ($statusCode -ge 200 -and $statusCode -lt 300) {
                    $data = $response.Content | ConvertFrom-Json
                    $success = $true
                                        
                    # Update performance metrics if provided
                    if ($PerformanceMetrics) {
                        $PerformanceMetrics.GraphApiCalls++
                    }
                } else {
                    # Handle non-success status codes
                    $errorContent = $response.Content

                    # Determine if this is a retryable error
                    $isRetryable = switch ($statusCode) {
                        429 { $true }   # Too Many Requests - always retry
                        500 { $true }   # Internal Server Error - retry
                        502 { $true }   # Bad Gateway - retry  
                        503 { $true }   # Service Unavailable - retry
                        504 { $true }   # Gateway Timeout - retry
                        400 { $false }  # Bad Request - don't retry (client error)
                        401 { $false }  # Unauthorized - don't retry (auth error)
                        403 { $false }  # Forbidden - don't retry (permission error)
                        404 { $false }  # Not Found - don't retry (resource error)
                        default { $statusCode -ge 500 }  # Retry on 5xx errors, not 4xx
                    }
                    
                    if (-not $isRetryable) {
                        throw [System.Exception]::new("Graph API returned non-retryable error $statusCode at page $pageCount. Content: $errorContent")
                    } else {
                        throw [System.Exception]::new("Graph API returned retryable error $statusCode at page $pageCount. Content: $errorContent")
                    }
                }
                
            }
            catch {
                $retryCount++
                $errorMessage = $_.Exception.Message
                                
                if ($retryCount -ge $MaxRetries) {
                    Write-Error "Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $errorMessage at page $pageCount"
                    throw [System.Exception]::new("Failed to call Microsoft Graph REST API at URL '$fullUri' after $MaxRetries attempts; error: $errorMessage at page $pageCount")
                } elseif ($isRetryable) {
                    Write-Warning "Retryable error calling Graph API (attempt $retryCount/$MaxRetries): $errorMessage. Retrying in $RetryDelaySeconds seconds..."
                    Start-Sleep -Seconds $RetryDelaySeconds
                } else {
                    Write-Error "Non-retryable error calling Graph API: $errorMessage"
                    throw [System.Exception]::new("Non-retryable error calling Graph API: $errorMessage")
                }
            }
        } while (-not $success -and $retryCount -lt $MaxRetries)

        # Process current page immediately via callback
        $pageData = @{
            Data = if ($null -ne $data.value) { $data.value } else { $data }
            PageNumber = $pageCount
            HasMore = $null -ne $data.'@odata.nextLink'
            StatusCode = $statusCode
        }
        
        # Execute callback to process this page immediately with error handling
        try {
            $callbackResult = & $ProcessPageCallback $pageData $CallbackContext
            if ($callbackResult) {
                $totalProcessed += $callbackResult.ProcessedCount
                $totalUploaded += $callbackResult.UploadedCount
            }
        }
        catch {
            Write-Error "Failed to process page $pageCount via callback: $($_.Exception.Message)"
            throw $_  # Re-throw to stop processing if callback fails
        }
        
        # Update URI for next page
        if ($data.'@odata.nextLink') {
            $fullUri = $data.'@odata.nextLink'
        } else {
            $fullUri = $null
        }
        
        # Rate limiting between pages
        if ($fullUri) {
            Write-Verbose "  -> Waiting 2 seconds before fetching next page..."
            Start-Sleep -Seconds 2
        }
        
    } while ($fullUri)
    
    return @{
        TotalPages = $pageCount
        TotalProcessed = $totalProcessed
        TotalUploaded = $totalUploaded
    }
}

function Invoke-GraphQuery {
    [CmdletBinding()]
    param(
        # URL path (ex: /users)
        [Parameter(Mandatory = $true)]
        [ValidatePattern('^(?!https://graph.microsoft.com/(v1|beta)/)')]
        [string]
        $urlPath
    )

    try {
        $uri = "https://graph.microsoft.com/v1.0$urlPath" -as [uri]
        
        $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop

    }
    catch {
        Write-Error "An error occured constructing the URI or while calling Graph query for URI GET '$uri': $($_.Exception.Message)"
    }
    
    @{
        Content    = $response.Content | ConvertFrom-Json
        StatusCode = $response.StatusCode
    }
}

# Utility function for centralized error handling
function Add-FunctionError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $Message,
        
        [Parameter(Mandatory = $false)]
        [System.Exception] $Exception = $null,
        
        [Parameter(Mandatory = $false)]
        [string] $Category = "General",
        
        [Parameter(Mandatory = $false)]
        [System.Collections.Generic.List[string]] $ErrorList = $null
    )
    
    if ($Exception) {
        $errorMsg = "$Category - $Message : $($Exception.Message)"
    } else {
        $errorMsg = "$Category - $Message"
    }
    
    Write-Warning $errorMsg
    
    if ($ErrorList) {
        $ErrorList.Add($errorMsg)
    }
}

# Utility function for exponential backoff delay calculation
function Get-BackoffDelay {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int] $Attempt,
        
        [Parameter(Mandatory = $true)]
        [hashtable] $Config
    )
    
    $delay = [Math]::Min(
        $Config.BaseDelay * [Math]::Pow($Config.BackoffMultiplier, $Attempt - 1),
        $Config.MaxDelay
    )
    return [int]$delay
}

# Utility function for Graph API calls with metrics and error handling
function Invoke-GraphQueryWithMetrics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string] $UrlPath,
        
        [Parameter(Mandatory = $false)]
        [string] $Operation = "Graph API Call",
        
        [Parameter(Mandatory = $false)]
        [hashtable] $PerformanceMetrics = $null,
        
        [Parameter(Mandatory = $false)]
        [int] $MaxRetries = 5,
        
        [Parameter(Mandatory = $false)]
        [int] $RetryDelaySeconds = 10
    )
    
    Write-Verbose "  -> $Operation : $UrlPath"
    
    try {
        # Use the existing retry logic in Invoke-GraphQueryEX
        $response = Invoke-GraphQueryEX -urlPath $UrlPath -MaxRetries $MaxRetries -RetryDelaySeconds $RetryDelaySeconds -ErrorAction Stop
        
        # Update performance metrics if provided
        if ($PerformanceMetrics) {
            $PerformanceMetrics.GraphApiCalls++
        }
        
        # Handle array responses consistently
        if ($response -is [System.Array]) {
            $response = $response | Where-Object { 
                $null -ne $_.Content -or $null -ne $_.StatusCode 
            } | Select-Object -Last 1
        }
        
        # Check for successful response
        if ($response.Error) {
            throw [System.Exception]::new("Graph API error: $($response.Error)")
        }
        
        if (-not $response.StatusCode -or $response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
            throw [System.Exception]::new("Graph API returned status code: $($response.StatusCode)")
        }
        
        Write-Verbose "  Success: $Operation completed"
        return $response
    }
    catch {
        Write-Error "$Operation failed: $($_.Exception.Message)"
        throw $_
    }
}



# Function to add other possible file extension(s) to the module file names
function add-documentFileExtensions {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string[]] $DocumentName,
        [Parameter(Mandatory = $true)]
        [string]$ItemName

    )

    if ($ItemName.ToLower() -eq 'network architecture diagram' -or 
        $ItemName.ToLower() -eq 'high level design documentation' -or
        $ItemName.ToLower() -eq "diagramme d'architecture réseau" -or 
        $ItemName.ToLower() -eq 'documentation de Conception de haut niveau'){

            $fileExtensions = @(".pdf", ".png", ".jpeg", ".vsdx",".txt",".docx", ".doc")
    }
    elseif ($ItemName.ToLower() -eq 'dedicated user accounts for administration' -or 
            $ItemName.ToLower() -eq "Comptes d'utilisateurs dédiés pour l'administration") {
                
            $fileExtensions = @(".csv")
    }
    elseif ($ItemName.ToLower() -eq 'application gateway certificate validity' -or 
            $ItemName.ToLower() -eq "validité du certificat : passerelle d'application") {
        
            $fileExtensions = @(".txt")
    }
    else {
        $fileExtensions = @(".txt",".docx", ".doc", ".pdf")
    }
    
    $DocumentName_new = New-Object System.Collections.Generic.List[System.Object]
    ForEach ($fileExt in $fileExtensions) {
        $DocumentName_new.Add($DocumentName[0] + $fileExt)
    }

    return $DocumentName_new
}

function Get-UserSignInPreferences {
    [CmdletBinding()]
    param (      
        [Parameter(Mandatory = $true)]
        [string]$UserUPN
    )
    
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $signInPreferences = $null
    
    # Handle guest accounts (external users)
    $pattern = "*#EXT#*"
    if($UserUPN -like $pattern){
        # for guest accounts
        $userEmail = $UserUPN
        if(!$null -eq $userEmail){
            $encodedUserEmail = [System.Web.HttpUtility]::UrlEncode($userEmail)
            $urlPath = '/users/' + $encodedUserEmail + '/authentication/signInPreferences'            
        }else{
            Write-Warning "userEmail is null for $UserUPN"
            $extractedEmail = (($UserUPN -split '#')[0]) -replace '_', '@'
            $urlPath = '/users/' + $extractedEmail + '/authentication/signInPreferences'
        }
    }else{
        # for member accounts
        $urlPath = '/users/' + $UserUPN + '/authentication/signInPreferences'
    }
    
    try {
        # Use beta endpoint for signInPreferences
        $uri = "https://graph.microsoft.com/beta$urlPath" -as [uri]
        
        $response = Invoke-AzRestMethod -Uri $uri -Method GET -ErrorAction Stop
        
        if ($response.StatusCode -eq 200) {
            $signInPreferences = $response.Content | ConvertFrom-Json
            Write-Host "Successfully retrieved sign-in preferences for $UserUPN"
        } else {
            $errorMsg = "Failed to retrieve sign-in preferences for $UserUPN. Status code: $($response.StatusCode)"
            $ErrorList.Add($errorMsg)
            Write-Error $errorMsg
        }
    }
    catch {
        $errorMsg = "Failed to call Microsoft Graph Beta API at URL '$urlPath'; returned error message: $_"
        $ErrorList.Add($errorMsg)
        Write-Error "Error: $errorMsg"
    }
    
    $PsObject = [PSCustomObject]@{
        SignInPreferences = $signInPreferences
        ErrorList = $ErrorList
    }
    
    return $PsObject
}



function Get-AllUserAuthInformation {
    [CmdletBinding()]
    param (      
        [Parameter(Mandatory = $true)]
        [array]$allUserList
    )
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $userValidMFACounter = 0
    $userUPNsValidMFA = @()
    $userUPNsBadMFA = @()
    $pattern = "*#EXT#*"

    ForEach ($user in $allUserList) {
        $userAccount = $user.userPrincipalName
        $authFound = $false

        # First, check if user has FIDO2 or HardwareOTP as system preferred authentication method
        try {
            $signInPrefsResult = Get-UserSignInPreferences -UserUPN $userAccount
            if ($signInPrefsResult.ErrorList.Count -eq 0 -and $null -ne $signInPrefsResult.SignInPreferences) {
                $preferences = $signInPrefsResult.SignInPreferences
                $isSystemPreferredEnabled = $preferences.isSystemPreferredAuthenticationMethodEnabled
                $systemPreferredMethod = $preferences.systemPreferredAuthenticationMethod
                
                # Check if system preferred is enabled and set to FIDO2 or HardwareOTP
                if ($isSystemPreferredEnabled -eq $true -and 
                    ($systemPreferredMethod -eq "Fido2" -or $systemPreferredMethod -eq "HardwareOTP")) {
                    $authFound = $true
                    Write-Host "✅ $userAccount - System preferred authentication method is $systemPreferredMethod"
                }
            }
        }
        catch {
            $errorMsg = "Failed to check sign-in preferences for $userAccount : $_"
            $ErrorList.Add($errorMsg)
            Write-Error "Warning: $errorMsg"
        }
        
        # If system preferred authentication is not FIDO2 or HardwareOTP, check authentication methods
        if (-not $authFound) {
            if($userAccount -like $pattern){
                # for guest accounts
                $userEmail = $user.mail
                if(!$null -eq  $userEmail){
                    $urlPath = '/users/' + $userEmail + '/authentication/methods'
                }else{
                    Write-Host "userEmail is null for $userAccount"
                    $extractedEmail = (($userAccount -split '#')[0]) -replace '_', '@'
                    $urlPath = '/users/' + $extractedEmail + '/authentication/methods'
                }
                
            }else{
                # for member accounts
                $urlPath = '/users/' + $userAccount + '/authentication/methods'
            }
            
            try {
                $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop

            }
            catch {
                $errorMsg = "Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"
            }

            # # To check if MFA is setup for a user, we're checking various authentication methods:
            # # 1. #microsoft.graph.microsoftAuthenticatorAuthenticationMethod
            # # 2. #microsoft.graph.phoneAuthenticationMethod
            # # 3. #microsoft.graph.passwordAuthenticationMethod - not considered for MFA
            # # 4. #microsoft.graph.emailAuthenticationMethod - not considered for MFA
            # # 5. #microsoft.graph.fido2AuthenticationMethod
            # # 6. #microsoft.graph.softwareOathAuthenticationMethod
            # # 7. #microsoft.graph.temporaryAccessPassAuthenticationMethod
            # # 8. #microsoft.graph.windowsHelloForBusinessAuthenticationMethod

            if ($null -ne $response) {
                # portal
                $data = $response.Content
                # # localExecution
                # $data = $response
                if ($null -ne $data -and $null -ne $data.value) {
                    $authenticationmethods = $data.value
                    
                    foreach ($authmeth in $authenticationmethods) {    
                    
                        switch ($authmeth.'@odata.type') {
                            "#microsoft.graph.phoneAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.fido2AuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.temporaryAccessPassAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" { $authFound = $true; break }
                            "#microsoft.graph.softwareOathAuthenticationMethod" { $authFound = $true; break }
                        }
                    }
                }
                else {
                    $errorMsg = "No authentication methods data found for $userAccount"                
                    $ErrorList.Add($errorMsg)
                    # Write-Error "Error: $errorMsg"
                }
            }
            else {
                $errorMsg = "Failed to get response from Graph API for $userAccount"                
                $ErrorList.Add($errorMsg)
                Write-Error "Error: $errorMsg"
            }
        }
        
        # Process the authentication result
        if($authFound){
            #need to keep track of user account mfa in a counter and compare it with the total user count   
            $userValidMFACounter += 1
            Write-Host "Auth method found for $userAccount"

            # Create an instance of valid MFA inner list object
            $userValidUPNtemplate = [PSCustomObject]@{
                UPN  = $userAccount
                MFAStatus   = $true
            }
            $userUPNsValidMFA +=  $userValidUPNtemplate
        }
        else{
            # This message is being used for debugging
            Write-Host "$userAccount does not have MFA enabled"

            # Create an instance of inner list object
            $userUPNtemplate = [PSCustomObject]@{
                UPN  = $userAccount
                MFAStatus   = $false
            }
            # Add the list to user accounts MFA list
            $userUPNsBadMFA += $userUPNtemplate

        }    
    }

    $PsObject = [PSCustomObject]@{
        userUPNsBadMFA = $userUPNsBadMFA
        ErrorList      = $ErrorList
        userValidMFACounter = $userValidMFACounter
        userUPNsValidMFA = $userUPNsValidMFA
    }

    return $PsObject

}
function Get-AllUserAuthInformationEX {
    <#
    .SYNOPSIS
    Optimized version of Get-AllUserAuthInformation using Microsoft Graph Batch API for improved performance.
    Compatible with PowerShell 5.1. Signature and output format are unchanged.

    .PARAMETER allUserList
    Array of user objects to check for MFA status.

    .OUTPUTS
    PSCustomObject with userUPNsBadMFA, ErrorList, userValidMFACounter, userUPNsValidMFA.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [array]$allUserList
    )

    # Initialize output containers
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $userValidMFACounter = 0
    $userUPNsValidMFA = @()
    $userUPNsBadMFA = @()
    $batchSize = 20
    $pattern = "*#EXT#*"

    # Process users in batches of 20 (Graph Batch API limit)
    for ($i = 0; $i -lt $allUserList.Count; $i += $batchSize) {
        $batchUsers = $allUserList[$i..([Math]::Min($i+$batchSize-1, $allUserList.Count-1))]
        $batchRequests = @()
        $userMap = @{}

        # Build batch request payload for each user in the batch
        $reqId = 1
        foreach ($user in $batchUsers) {
            $userAccount = $user.userPrincipalName
            if ($userAccount -like $pattern) {
                # Guest accounts
                $userEmail = $user.mail
                if ($null -ne $userEmail) {
                    $urlPath = "/users/$userEmail/authentication/methods"
                } else {
                    $extractedEmail = (($userAccount -split '#')[0]) -replace '_', '@'
                    $urlPath = "/users/$extractedEmail/authentication/methods"
                }
            } else {
                # Member accounts
                $urlPath = "/users/$userAccount/authentication/methods"
            }
            $batchRequests += @{
                id     = "$reqId"
                method = "GET"
                url    = $urlPath
            }
            $userMap["$reqId"] = $userAccount
            $reqId++
        }

        # Convert batch request to JSON
        $batchPayload = @{ requests = $batchRequests } | ConvertTo-Json -Depth 4

        # Send batch request to Graph API
        try {
            $response = Invoke-AzRestMethod -Uri "https://graph.microsoft.com/v1.0/\$batch" -Method POST -Body $batchPayload -ErrorAction Stop
            $batchResults = ($response.Content | ConvertFrom-Json).responses
        }
        catch {
            $ErrorList.Add("Batch request failed: $_")
            continue
        }

        # Process each response in the batch
        foreach ($result in $batchResults) {
            $userAccount = $userMap[$result.id]
            if ($result.status -eq 200 -and $null -ne $result.body.value) {
                $authFound = $false
                foreach ($authmeth in $result.body.value) {
                    switch ($authmeth.'@odata.type') {
                        "#microsoft.graph.phoneAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.fido2AuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.temporaryAccessPassAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" { $authFound = $true; break }
                        "#microsoft.graph.softwareOathAuthenticationMethod" { $authFound = $true; break }
                    }
                }
                if ($authFound) {
                    $userValidMFACounter += 1
                    $userValidUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $true }
                    $userUPNsValidMFA += $userValidUPNtemplate
                } else {
                    $userUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $false }
                    $userUPNsBadMFA += $userUPNtemplate
                }
            } else {
                $ErrorList.Add("No authentication methods data for $userAccount or error status: $($result.status)")
                $userUPNtemplate = [PSCustomObject]@{ UPN = $userAccount; MFAStatus = $false }
                $userUPNsBadMFA += $userUPNtemplate
            }
        }
    }

    # Return results in the same format as the original function
    $PsObject = [PSCustomObject]@{
        userUPNsBadMFA      = $userUPNsBadMFA
        ErrorList           = $ErrorList
        userValidMFACounter = $userValidMFACounter
        userUPNsValidMFA    = $userUPNsValidMFA
    }
}
function CompareKQLQueries{
    param (
        [string] $query,
        [string] $targetQuery
        )

    #Fix the formatting of KQL query
    $normalizedTargetQuery = $targetQuery -replace '\s+', ' ' -replace '\|', ' | ' 
    $removeSpacesQuery = $query -replace '\s', ''
    $removeSpacesTargetQuery = $normalizedTargetQuery -replace '\s', ''

    return $removeSpacesQuery -eq $removeSpacesTargetQuery
}

# Function used for V2.0 GR2V7(M) andV1.0  GR3(R) cloud console access
function Get-allowedLocationCAPCompliance {
    param (
        [array]$ErrorList,
        [string] $IsCompliant
    )

    # get named locations
    $locationsBaseAPIUrl = '/identity/conditionalAccess/namedLocations'
    try {
        $response = Invoke-GraphQuery -urlPath $locationsBaseAPIUrl -ErrorAction Stop
        $data = $response.Content
        $locations = $data.value
    }
    catch {
        $Errorlist.Add("Failed to call Microsoft Graph REST API at URL '$locationsBaseAPIUrl'; returned error message: $_") 
        Write-Warning "Error: Failed to call Microsoft Graph REST API at URL '$locationsBaseAPIUrl'; returned error message: $_"
    }

    # get conditional access policies
    $CABaseAPIUrl = '/identity/conditionalAccess/policies'
    try {
        $response = Invoke-GraphQuery -urlPath $CABaseAPIUrl -ErrorAction Stop

        $caps = $response.Content.value
    }
    catch {
        $Errorlist.Add("Failed to call Microsoft Graph REST API at URL '$CABaseAPIUrl'; returned error message: $_")
        Write-Warning "Error: Failed to call Microsoft Graph REST API at URL '$CABaseAPIUrl'; returned error message: $_"
    }
    
    # check that a named location for Canada exists and that a policy exists that uses it
    $validLocations = @()

    foreach ($location in $locations) {
        #Determine location conditions
        #get all valid locations: needs to have Canada Only
        if ($location.countriesAndRegions.Count -eq 1 -and $location.countriesAndRegions[0] -eq "CA") {
            $validLocations += $location
        }
    }

    $locationBasedPolicies = $caps | Where-Object { $_.conditions.locations.includeLocations -in $validLocations.ID -and $_.state -eq 'enabled' }

    if ($validLocations.count -ne 0) {
        #if there is at least one location with Canada only, we are good. If no Canada Only policy, not compliant.
        # Conditional access Policies
        # Need a location based policy, for admins (owners, contributors) that uses one of the valid locations above.
        # If there is no policy or the policy doesn't use one of the locations above, not compliant.

        if (!$locationBasedPolicies) {
            #failed. No policies have valid locations.
            $Comments = $msgTable.noCompliantPoliciesfound
            $IsCompliant = $false
        }
        else {
            #"Compliant Policies."
            $IsCompliant = $true
            $Comments = $msgTable.allPoliciesAreCompliant
        }      
    }
    else {
        # Failed. Reason: No locations have only Canada.
        $Comments = $msgTable.noLocationsCompliant
        $IsCompliant = $false
    }
    
    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        Comments         = $Comments
        ItemName         = $ItemName
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
        Errors           = $ErrorList
    }
    return  $PsObject

}


function Test-PolicyExemptionExists {
    param (
        [string] $ScopeId,
        [array]  $requiredPolicyExemptionIds
    )
    [PSCustomObject] $policyExemptionList = New-Object System.Collections.ArrayList     
    # $exemptionsIds = Get-AzPolicyExemption -Scope $ScopeId | Select-Object -ExpandProperty Properties| Select-Object PolicyDefinitionReferenceIds
    $exemptionsIds=(Get-AzPolicyExemption -Scope $ScopeId).Properties.PolicyDefinitionReferenceIds
    $isExempt =  $false

    if ($null -ne $exemptionsIds)
    {
        foreach ($exemptionId in $exemptionsIds)
        {
            if ($exemptionId -in $requiredPolicyExemptionIds){
                $isExempt = $true

                # if exempted, add to the list
                $result = [PSCustomObject] @{
                    isExempt = $isExempt 
                    exemptionId = $exemptionId
                }
                $policyExemptionList.add($result)
            }

        }
    }
    return $policyExemptionList
    
}

function Test-ComplianceForSubscription {
    param (
        [System.Object] $obj,
        [System.Object] $subscription,
        [string] $PolicyID,
        [array]  $requiredPolicyExemptionIds,
        [string] $objType
    )
    $strPattern = "/providers/microsoft.authorization/policysetdefinitions/(.*)"
    if ($PolicyID -match $strPattern){
        $PolicyID = $matches[1]
    }
    Write-Host "Get compliance details for Subscription : $($subscription.DisplayName)"
    $complianceDetails = Get-AzPolicyState | Where-Object{ $_.SubscriptionId -eq $($subscription.SubscriptionID) } | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID}  
    
    If ($null -eq $complianceDetails) {
        Write-Host "No compliance details found for Management Group : $($obj.DisplayName) and subscription: $($subscription.DisplayName)"
    }
    else{   
        $complianceDetails = $complianceDetails | Where-Object{$_.PolicyAssignmentScope -like "*$($obj.TenantId)*" }
        $requiredPolicyExemptionIds_smallCaps = @()
        foreach ($str in $requiredPolicyExemptionIds) {
            $requiredPolicyExemptionIds_smallCaps += $str.ToLower()
        }
        # Filter for required policies
        $complianceDetails = $complianceDetails | Where-Object{ $_.PolicyDefinitionReferenceId -in $requiredPolicyExemptionIds_smallCaps}
        if ($objType -eq "subscription"){
            Write-Host "$($complianceDetails.count) Compliance details found for subscription: $($subscription.DisplayName)"
        }
        else {
            Write-Host "$($complianceDetails.count) Compliance details found for Management Group : $($obj.DisplayName) and subscription: $($subscription.DisplayName)"                            
        }
        
    }

    return $complianceDetails
}


function Check-PBMMPolicies {
    param (
        [System.Object] $objList,
        [string] $objType, #subscription or management Group
        [array]  $requiredPolicyExemptionIds,
        [string] $PolicyID,
        [string] $ControlName,
        [string] $ItemName,
        [string] $LogType,
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [string] $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false    
    )   
    [PSCustomObject] $tempObjectList = New-Object System.Collections.ArrayList

    foreach ($obj in $objList)
    {
        Write-Verbose "Checking $objType : $($obj.Name)"
        Write-Verbose "PBMM policy PolicyID is $PolicyID"

        # Find scope
        if ($objType -eq "subscription"){
            $tempId="/subscriptions/$($obj.Id)"
        }
        else {
            $tempId=$obj.Id                              
        }
        Write-Host "Scope is $tempId"

        # Find assigned policy list from PBMM policy for the scope
        $AssignedPolicyList = Get-AzPolicyAssignment -scope $tempId | `
            Select-Object -ExpandProperty properties | `
            Where-Object { $_.PolicyDefinitionID -like "*$PolicyID*" } 

        If ($null -eq $AssignedPolicyList -or (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))))
        {
            # PBMM initiative not applied
            $ComplianceStatus=$false
            $Comment = $msgTable.isNotCompliant + ' ' + $msgTable.pbmmNotApplied 
        }
        else {
            # PBMM initiative applied
            $Comment = $msgTable.pbmmApplied

            # List the policies within the PBMM initiative (policy set definition)
            $policySetDefinition = Get-AzPolicySetDefinition | `
                Where-Object { $_.PolicySetDefinitionId -like "*$PolicyID*" } 

            $listPolicies = $policySetDefinition.Properties.policyDefinitions
            # Check all 3 policies are applied for this scope
            $appliedPolicies = $listPolicies.policyDefinitionReferenceId | Where-Object { $requiredPolicyExemptionIds -contains $_ }
            if($appliedPolicies.Count -ne  $requiredPolicyExemptionIds.Count){
                # some required policies are not applied
                $ComplianceStatus=$false
                $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' ' + $msgTable.reqPolicyNotApplied
            }
            else{
                # All 3 required policies are applied
                $Comment += ' ' + $msgTable.reqPolicyApplied

                # PBMM is applied and not excluded. Testing if specific policies haven't been exempted.
                $policyExemptionList = Test-PolicyExemptionExists -ScopeId $tempId -requiredPolicyExemptionIds $requiredPolicyExemptionIds

                $exemptList = $policyExemptionList.exemptionId
                # $nonExemptList = $policyExemptionList | Where-Object { $_.isExempt -eq $false }
                if ($ExemptList.Count -gt 0){   
                    
                    # join all exempt policies to a string
                    if(-not($null -eq $exemptList)){
                        $exemptListAllPolicies = $exemptList -join ", "
                    }
                    # boolean, exemption for GR, required policies exists.
                    $ComplianceStatus=$false
                    $Comment += ' '+ $msgTable.grExemptionFound -f $exemptListAllPolicies

                }
                else {
                     # Required Policy Definitions are not exempt. Find compliance details for the assigned PBMM policy
                    $Comment += ' ' + $msgTable.grExemptionNotFound

                    # Check the number of resources and compliance for the required policies in applied PBMM initiative
                    # ----------------#
                    # Subscription
                    # ----------------#
                    if ($objType -eq "subscription"){
                        Write-Host "Find compliance details for Subscription : $($obj.Name)"
                        $subscription = @()
                        $subscription += New-Object -TypeName psobject -Property ([ordered]@{'DisplayName'=$obj.Name;'SubscriptionID'=$obj.Id})
                        
                        $currentSubscription = Get-AzContext
                        if($currentSubscription.Subscription.Id -ne $subscription.SubscriptionId){
                            # Set Az context to the this subscription
                            Set-AzContext -SubscriptionId $subscription.SubscriptionID
                            Write-Host "AzContext set to $($subscription.DisplayName)"
                        }
    
                        $complianceDetailsSubscription = Test-ComplianceForSubscription -obj $obj -subscription $subscription -PolicyID $PolicyID -requiredPolicyExemptionIds $requiredPolicyExemptionIds -objType $objType

                        if ($null -eq $complianceDetailsSubscription) {
                            Write-Host "Compliance details for $($subscription.DisplayName) outputs as NULL"
                            $complianceDetailsList = $null
                        }
                        else{
                            if($complianceDetailsSubscription.Count -lt 2){
                                $complianceDetailsList = $complianceDetailsSubscription[0] | Select-Object `
                                    Timestamp, ResourceId, ResourceLocation, ResourceType, SubscriptionId, `
                                    ResourceGroup, PolicyDefinitionName, ManagementGroupIds, PolicyAssignmentScope, IsCompliant, `
                                    ComplianceState, PolicyDefinitionAction, PolicyDefinitionReferenceId, ResourceTags, ResourceName
                            }
                            else{
                                $complianceDetailsList = $complianceDetailsSubscription | Select-Object `
                                    Timestamp, ResourceId, ResourceLocation, ResourceType, SubscriptionId, `
                                    ResourceGroup, PolicyDefinitionName, ManagementGroupIds, PolicyAssignmentScope, IsCompliant, `
                                    ComplianceState, PolicyDefinitionAction, PolicyDefinitionReferenceId, ResourceTags, ResourceName
                            }
                            
                            if (-not ($complianceDetailsList -is [System.Array])) {
                                $complianceDetailsList = @($complianceDetailsList)
                            }
                        }

                    }

                    if ($null -eq $complianceDetailsList) {
                        # PBMM applied but complianceDetailsList is null i.e. no resources in this subcription to apply the required policies
                        Write-Host "Check for compliance details; outputs as NULL"
                        $resourceCompliant = 0 
                        $resourceNonCompliant = 0
                        $totalResource = 0
                        $countResourceCompliant = 0 
                        $countResourceNonCompliant = 0          
                    }
                    else{
                        # # check the compliant & non-compliant resources only for $requiredPolicyExemptionIds policies
                        $totalResource = $complianceDetailsList.Count

                        # #-------------# #
                        # # Compliant
                        # #-------------# #
                        # List compliant resource
                        if ( $complianceDetailsList.Count -eq 1){
                            $resourceCompliant = $complianceDetailsList[0] | Where-Object {$_.ComplianceState -eq "Compliant"}
                        }
                        else{
                            $resourceCompliant = $complianceDetailsList | Where-Object {$_.ComplianceState -eq "Compliant"}
                        }
                        if (-not ($resourceCompliant -is [System.Array])) {
                            $resourceCompliant = @($resourceCompliant)
                        }
                        if ($null -eq $resourceCompliant){
                            Write-Host "resourceCompliant is null"
                            $countResourceCompliant = 0
                        }
                        else{
                            Write-Host "resourceCompliant is not null"
                            $countResourceCompliant = $resourceCompliant.Count
                        }
                        
                        # #-------------##
                        # # Non-compliant
                        # #-------------##
                        # List non-compliant resources
                        $resourceNonCompliant = $complianceDetailsList | Where-Object {$_.ComplianceState -eq "NonCompliant"}
                        if (-not ($resourceNonCompliant -is [System.Array])) {
                            $resourceNonCompliant = @($resourceNonCompliant)
                        }
                        $countResourceNonCompliant = $resourceNonCompliant.Count
                    }
                    
                    # # ---------------------------------------------------------------------------------
                    # At this point PBMM initiative is applied. All 3 policies are applied. No exemption.
                    # # ---------------------------------------------------------------------------------

                    # Count Compliant & non-compliant resources and Total resources
                    if($totalResource -eq 0){
                        # complianceDetailsList is null i.e no resources to apply the required policies in this subscription
                        $ComplianceStatus=$true
                        $Comment = $msgTable.isCompliant + ' ' + $Comment + ' '+ $msgTable.noResource
                    }
                    elseif($totalResource -gt 0 -and ($countResourceCompliant -eq $totalResource)){
                        # All resources are compliant
                        $ComplianceStatus=$true
                        $Comment = $msgTable.isCompliant + ' ' + $Comment + ' '+ $msgTable.allCompliantResources
                    }
                    elseif($totalResource -gt 0 -and ($countResourceNonCompliant -eq $totalResource)){
                        # All resources are non-compliant
                        $ComplianceStatus=$false
                        $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' '+ $msgTable.allNonCompliantResources
                    }
                    elseif($totalResource -gt 0 -and $countResourceNonCompliant -gt 0 -and ($countResourceNonCompliant -lt $totalResource)){
                        # There are some resources that are non-compliant
                        $ComplianceStatus=$false
                        $Comment = $msgTable.isNotCompliant + ' ' + $Comment + ' '+ $msgTable.hasNonComplianceResource -f $countResourceNonCompliant, $totalResource
                    }
                    else{
                        Write-host "All use cases are addressed."
                        # Do nothing 
                    }                   
                }

            }
        }

        # Add to the Object List 
        if ($null -eq $obj.DisplayName){
            $DisplayName=$obj.Name
        }
        else {
            $DisplayName=$obj.DisplayName
        }

        $c = New-Object -TypeName PSCustomObject -Property @{ 
            Type = [string]$objType
            Id = [string]$obj.Id
            Name = [string]$obj.Name
            DisplayName = [string]$DisplayName
            ComplianceStatus = [boolean]$ComplianceStatus
            Comments = [string]$Comment
            ItemName = [string]$ItemName
            itsgcode = [string]$itsgcode
            ControlName = [string]$ControlName
            ReportTime = [string]$ReportTime
        }

        if ($EnableMultiCloudProfiles) {
            if ($objType -eq "subscription") {
                $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $obj.Id
            } else {
                $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
            }
            
            if (!$evalResult.ShouldEvaluate) {
                if(!$evalResult.ShouldAvailable ){
                    if ($evalResult.Profile -gt 0) {
                        $c.ComplianceStatus = "Not Applicable"
                        $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                        $c.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
                    } else {
                        $ErrorList.Add("Error occurred while evaluating profile configuration availability")
                    }
                } else {
                    if ($evalResult.Profile -gt 0) {
                        $c.ComplianceStatus = "Not Applicable"
                        $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                        $c.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
                    } else {
                        $ErrorList.Add("Error occurred while evaluating profile configuration")
                    }
                }
            } else {
                
                $c | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
            }
        }        

        $tempObjectList.add($c)| Out-Null
    }
    return $tempObjectList
}

# Used in AlersMonitor and UserAccountGCEventLogging
function get-AADDiagnosticSettings {
    $apiUrl = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings?api-version=2017-04-01-preview"
    $response = Invoke-AzRestMethod -Uri $apiUrl -Method Get -ErrorAction Stop
    if ($response.StatusCode -eq 200) {
        return ($response.Content | ConvertFrom-Json).value
    }
    throw "Failed to retrieve diagnostic settings. Status code: $($response.StatusCode)"
}


# USE OF THIS FUNCITON: GR2 V10 and V3 automated role reviews
function Expand-ListColumns {
    param (
        [Parameter(Mandatory = $true)]
        [Array]$accessReviewList  # The input list of access review objects
    )

    $expandedList = @()

    # Iterate through each item in the $accessReviewList
    foreach ($reviewInfo in $accessReviewList) {
        # Determine the maximum number of elements in the lists you want to expand
        $maxCount = @(
            $reviewInfo.AccessReviewScopeList.Count,
            $reviewInfo.AccessReviewResourceScopeList.Count,
            $reviewInfo.AccessReviewReviewerList.Count
        ) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

        # Expand the lists by iterating through each element
        for ($i = 0; $i -lt $maxCount; $i++) {
            $expandedReviewInfo = [PSCustomObject]@{
                AccessReviewName                            = $reviewInfo.AccessReviewName
                AccessReviewInstanceId                      = $reviewInfo.AccessReviewInstanceId
                DescriptionForAdmins                        = $reviewInfo.DescriptionForAdmins
                DescriptionForReviewers                     = $reviewInfo.DescriptionForReviewers
                AccessReviewCreatedBy                       = $reviewInfo.AccessReviewCreatedBy
                AccessReviewStartDate                       = $reviewInfo.AccessReviewStartDate
                AccessReviewEndDate                         = $reviewInfo.AccessReviewEndDate
                AccessReviewStatus                          = $reviewInfo.AccessReviewStatus
                AccesReviewRecurrenceType                   = $reviewInfo.AccesReviewRecurrenceType
                AccesReviewRecurrencePattern                = $reviewInfo.AccesReviewRecurrencePattern
                AccessReviewScope                           = if ($reviewInfo.AccessReviewScopeList.Count -eq 1) { $reviewInfo.AccessReviewScopeList} else { if ($reviewInfo.AccessReviewScopeList.Count -gt $i) { $reviewInfo.AccessReviewScopeList[$i] } else {$null}}
                AccessReviewReviewer                        = if ($reviewInfo.AccessReviewReviewerList.Count -eq 1) { $reviewInfo.AccessReviewReviewerList} else { if ($reviewInfo.AccessReviewReviewerList.Count -gt $i) { $reviewInfo.AccessReviewReviewerList[$i] } else { $null }}
                AccessReviewResourceScope                   = if ($reviewInfo.AccessReviewResourceScopeList.Count -eq 1) { $reviewInfo.AccessReviewResourceScopeList} else { if ($reviewInfo.AccessReviewResourceScopeList.Count -gt $i) { $reviewInfo.AccessReviewResourceScopeList[$i] } else { $null }}
            }

            # Add the expanded row to the new list
            $expandedList += $expandedReviewInfo
        }
    }

    # Return the expanded list
    return $expandedList
}

function Add-ProfileInformation {
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$Result,
        [string]$CloudUsageProfiles,
        [string]$ModuleProfiles,
        [string]$SubscriptionId,
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )
    
    if($null -eq $SubscriptionId){
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
    }else{
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $SubscriptionID
    }

    if (!$evalResult.ShouldEvaluate) {
        if(!$evalResult.ShouldAvailable ){
            if ($evalResult.Profile -gt 0) {
                $Result.ComplianceStatus = "Not Applicable"
                $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $Result.Comments = "Not available - Profile $($evalResult.Profile) not applicable for this guardrail"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration availability")
            }
        } else {
            if ($evalResult.Profile -gt 0) {
                $Result.ComplianceStatus = "Not Applicable"
                $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $Result.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        }
    } else {
        $Result | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
    }
    return $Result
}

function Check-BuiltInPoliciesPerSubscription {
    param (
        [Parameter(Mandatory = $true)]
        [array]$requiredPolicyIds,
        [Parameter(Mandatory = $true)]
        [string]$ReportTime,
        [Parameter(Mandatory = $true)]
        [string]$ItemName,
        [Parameter(Mandatory = $true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory = $true)]
        [string]$ControlName,
        [string]$itsgcode,
        [string]$CloudUsageProfiles = "3",
        [string]$ModuleProfiles,
        [switch]$EnableMultiCloudProfiles,
        [System.Collections.ArrayList]$ErrorList
    )


    $subscriptions = Get-AzSubscription
    $results = New-Object System.Collections.ArrayList

    foreach ($subscription in $subscriptions) {
        try {
            Set-AzContext -SubscriptionId $subscription.Id -ErrorAction Stop
            $scope = "/subscriptions/$($subscription.Id)"
            Write-Host "Checking policies for subscription: $($subscription.Name) [$($subscription.Id)]"
        } catch {
            $ErrorList.Add("Error setting context for subscription $($subscription.Id): $_")
            continue
        }
        $result = Check-BuiltInPolicies -requiredPolicyIds $requiredPolicyIds -ReportTime $ReportTime -ItemName $ItemName -msgTable $msgTable -ControlName $ControlName -subScope $scope -subscription $subscription -itsgcode $itsgcode -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -EnableMultiCloudProfiles -ErrorList $ErrorList
        $results.Add($result)
    }
    Write-Host "Completed policy compliance check. Found $($results.Count) results"
    return $results
}


function Check-BuiltInPolicies {
    param (
        [Parameter(Mandatory=$true)]
        [array]$requiredPolicyIds,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [string]$subScope, #optional param to check a specific subscription
        $subscription,
        [string]$itsgcode,
        [string]$CloudUsageProfiles = "3",
        [string]$ModuleProfiles,
                             [switch]$EnableMultiCloudProfiles,
        [System.Collections.ArrayList]$ErrorList
    )
    
    $results = New-Object System.Collections.ArrayList
    
    if($subScope){$rootScope = $subScope}
    else{
        # Get tenant root management group
        try {
            $tenantId = (Get-AzContext).Tenant.Id
            $rootScope = "/providers/Microsoft.Management/managementGroups/$tenantId"
        } catch {
            $ErrorList.Add("Error getting tenant context: $_")
            return $results
        }
    }

    Write-Host "Starting policy compliance check for tenant: $tenantId"
    
    foreach ($policyId in $requiredPolicyIds) {
        Write-Host "Checking policy assignment for policy ID: $policyId"
        
        # Get policy definition details
        try {
            $policyDefinition = Get-AzPolicyDefinition -Id $policyId -ErrorAction Stop
            $policyDisplayName = $policyDefinition.Properties.DisplayName
        } catch {
            $ErrorList.Add("Error getting policy definition: $_")
            $policyDisplayName = "Unknown Policy"
            return $results
        }
        
        # Check for policy assignments at tenant level
        try {
            $assignments = Get-AzPolicyAssignment -Scope $rootScope -PolicyDefinitionId $policyId -ErrorAction Stop
            $tenantPolicyAssignments = @()
            if ($assignments -is [array]) {
                $tenantPolicyAssignments = $assignments | Where-Object { $null -ne $_ }
            } else {
                if ($null -ne $assignments) {
                    $tenantPolicyAssignments += $assignments
                }
            }            
        } catch {
            $ErrorList.Add("Error getting policy assignments for policy $policyId : $_")
            $tenantPolicyAssignments = @()
        }
        
        # Check if we have any policy assignments (not null and not empty)
        if ($null -ne $tenantPolicyAssignments -and $tenantPolicyAssignments.Count -gt 0) {
            Write-Host "Found $($tenantPolicyAssignments.Count) assignments matching this policy ID"
            
            $hasExemptions = $false
            
            # Check for policy exemptions
            foreach ($assignment in $tenantPolicyAssignments) {
                try {
                    if ($null -ne $assignment -and $null -ne $assignment.PolicyAssignmentId ) {
                        Write-Host "Checking exemptions for assignment: $($assignment.PolicyAssignmentId)"
                        $policyExemptions = Get-AzPolicyExemption -Scope $rootScope -PolicyAssignmentId $assignment.PolicyAssignmentId  -ErrorAction Stop
                        if ($policyExemptions) {
                            $hasExemptions = $true
                            break
                        }
                    } else {
                        Write-Host "Skipping exemption check for invalid assignment"
                        continue
                    }
                } catch {
                    $ErrorList.Add("Error checking policy exemptions: $_")
                }
                continue
            }
            
            if ($hasExemptions) {
                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        SubscriptionName = $subscription.Name
                        DisplayName = $subscription.Name
                        ComplianceStatus = $false
                        Comments = $msgTable.policyHasExemptions
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "Tenant ($tenantId)"
                        DisplayName = "Tenant ($tenantId)"
                        ComplianceStatus = $false
                        Comments = $msgTable.policyHasExemptions
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                $results.Add($result) | Out-Null
                continue
            }

            Write-Host "Policy is assigned at tenant level. Checking compliance states..."
            
            # Get all policy states for this policy
            $policyStates = Get-AzPolicyState | Where-Object { $_.PolicyDefinitionId -eq $policyId }

            # If no resources are found that the policy applies to
            if ($null -eq $policyStates -or $policyStates.Count -eq 0) {

                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        SubscriptionName = $subscription.Name
                        DisplayName = $subscription.Name
                        ComplianceStatus = $true
                        Comments = $msgTable.policyNoApplicableResourcesSub
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "Tenant ($tenantId)"
                        DisplayName = "Tenant ($tenantId)"
                        ComplianceStatus = $true
                        Comments = $msgTable.policyNoApplicableResources
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                
                $results.Add($result) | Out-Null
                continue
            }

            # Check if any resources are non-compliant
            $nonCompliantResources = $policyStates | 
                Where-Object { $_.ComplianceState -eq "NonCompliant" -or $_.IsCompliant -eq $false }
            
            if ($nonCompliantResources) {
                Write-Host "Found $($nonCompliantResources.Count) non-compliant resources"
                foreach ($resource in $nonCompliantResources) {
                    $result = [PSCustomObject]@{
                        Type = $resource.ResourceType
                        Id = $resource.ResourceId
                        Name = $resource.ResourceGroup + "/" + ($resource.ResourceId -split '/')[-1]
                        DisplayName = $resource.ResourceGroup + "/" + ($resource.ResourceId -split '/')[-1]
                        ComplianceStatus = $false
                        Comments = $msgTable.policyNotCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                    
                    if ($EnableMultiCloudProfiles) {
                        $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                    }
                    
                    $results.Add($result) | Out-Null
                }
            } else {
                Write-Host "All resources are compliant with the policy"

                if($subScope){
                    $result = [PSCustomObject]@{
                        Type = "subscription"
                        Id = $subscription.Id
                        Name = "All Resources"
                        DisplayName = $subscription.Name
                        ComplianceStatus = $true
                        Comments = $msgTable.policyCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                else{
                    $result = [PSCustomObject]@{
                        Type = "tenant"
                        Id = $tenantId
                        Name = "All Resources"
                        DisplayName = "All Resources"
                        ComplianceStatus = $true
                        Comments = $msgTable.policyCompliant
                        ItemName = "$ItemName - $policyDisplayName"
                        ControlName = $ControlName
                        ReportTime = $ReportTime
                        itsgcode = $itsgcode
                    }
                }
                if ($EnableMultiCloudProfiles) {
                    $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
                }
                $results.Add($result) | Out-Null
            }
        } else {
            
            if($subScope){
                $result = [PSCustomObject]@{
                    Type = "subscription"
                    Id = $subscription.Id
                    SubscriptionName = $subscription.Name
                    DisplayName = $subscription.Name
                    ComplianceStatus = $false
                    Comments = $msgTable.policyNotConfiguredSub -f $subScope
                    ItemName = "$ItemName - $policyDisplayName"
                    ControlName = $ControlName
                    ReportTime = $ReportTime
                    itsgcode = $itsgcode
                }
            }
            else{
                $result = [PSCustomObject]@{
                    Type = "tenant"
                    Id = $tenantId
                    Name = "Tenant ($tenantId)"
                    DisplayName = "Tenant ($tenantId)"
                    ComplianceStatus = $false
                    Comments = $msgTable.policyNotConfigured
                    ItemName = "$ItemName - $policyDisplayName"
                    ControlName = $ControlName
                    ReportTime = $ReportTime
                    itsgcode = $itsgcode
                }
            }
            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $result -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -ErrorList $ErrorList
            }
            $results.Add($result) | Out-Null
        }
    }

    Write-Host "Completed policy compliance check. Found $($results.Count) results"
    return $results
}

function FetchAllUserRawData {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ReportTime,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $FirstBreakGlassUPN,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $SecondBreakGlassUPN,
        
        [Parameter(Mandatory=$true)]
        [ValidateScript({
            try { [System.Guid]::Parse($_); $true }
            catch { throw "WorkSpaceID must be a valid GUID" }
        })]
        [string] $WorkSpaceID,
        
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $WorkspaceKey,
        
        [Parameter()]
        [int] $BatchSize = 999,
        
        [Parameter()]
        [hashtable] $RetryConfig = @{
            MaxRetries = 12
            BaseDelay = 5
            MaxDelay = 60
            BackoffMultiplier = 2
        }
    )
    
    # Initialize error tracking and performance monitoring
    $ErrorList = [System.Collections.Generic.List[string]]::new()
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $performanceMetrics = @{
        StartTime = Get-Date
        GraphApiCalls = 0
        UsersProcessed = 0
        DataIngestionAttempts = 0
    }
    
    $startTimeFormatted = $performanceMetrics.StartTime.ToString("yyyy-MM-dd HH:mm:ss")
    Write-Verbose "=== Starting FetchAllUserRawData with ReportTime: $ReportTime  at $startTimeFormatted ==="
    Write-Verbose "Step 1: Fetching authentication method registration details..."
    $regById = @{}
    
    try {
        $regPath = "/reports/authenticationMethods/userRegistrationDetails"
        $regResponse = Invoke-GraphQueryWithMetrics -UrlPath $regPath -Operation "Fetch Registration Details" -PerformanceMetrics $performanceMetrics
        $registrationDetails = @($regResponse.Content.value)
        
        Write-Verbose "  Success: Retrieved $($registrationDetails.Count) registration records"
        
        # Build efficient lookup for registration data
        $registrationDetails | ForEach-Object {
            if ($_.id -and -not $regById.ContainsKey($_.id)) {
                $regById[$_.id] = $_
            }
        }
        Write-Verbose "  Success: Built lookup table for $($regById.Count) registration records"        
    } catch {
        Add-FunctionError -Message "Failed to fetch registration details from Microsoft Graph" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
    }
    
    # Step 2: Prepare break-glass account filtering
    Write-Verbose "Step 2: Preparing break-glass account filtering..."
        $bgUpns = @($FirstBreakGlassUPN, $SecondBreakGlassUPN) | 
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.ToLower() }
            
            # Use hashtable for O(1) lookup performance
            $bgUpnLookup = @{}
            $bgUpns | ForEach-Object { $bgUpnLookup[$_] = $true }
            
    if ($bgUpns.Count -gt 0) {
        $bgUpnList = $bgUpns -join ', '
        Write-Verbose "  -> Will filter out break-glass accounts: $bgUpnList"
    }
    
    # Step 3: Setup streaming user processing
    Write-Verbose "Step 3: Starting streaming user processing..."
    $selectFields = "displayName,id,userPrincipalName,mail,createdDateTime,userType,accountEnabled,signInActivity"
    $filterQuery = "accountEnabled eq true"
    $usersPath = "/users?$" + "select=$selectFields&$" + "filter=$filterQuery"

    # Step 4: True streaming - process and upload users page by page as they're fetched
    Write-Verbose "Step 4: True streaming user processing with page size $BatchSize..."
    
    # Create a context object with all variables needed by the callback
    $callbackContext = @{
        WorkSpaceID = $WorkSpaceID
        WorkspaceKey = $WorkspaceKey
        ReportTime = $ReportTime
        bgUpnLookup = $bgUpnLookup
        regById = $regById
        RetryConfig = $RetryConfig
        ErrorList = $ErrorList
    }
    
    # Define the callback function that processes each page immediately
    $processPageCallback = {
        param($pageData, $context)
        
        $pageNumber = $pageData.PageNumber
        $pageUsers = $pageData.Data
        $hasMore = $pageData.HasMore
        
        if (-not $pageUsers -or $pageUsers.Count -eq 0) {
            Write-Verbose "  -> Page $pageNumber : No users returned, skipping..."
            return @{ ProcessedCount = 0; UploadedCount = 0 }
        }
        
        Write-Verbose "  -> Page $pageNumber : Processing $($pageUsers.Count) users from Graph API..."
                
        # Filter out break-glass accounts from this page
        $filteredPageUsers = $pageUsers | Where-Object { 
            $upn = $_.userPrincipalName
            if ([string]::IsNullOrWhiteSpace($upn)) { 
                return $false 
            }
            
            $isNotBreakGlass = -not $context.bgUpnLookup.ContainsKey($upn.ToLower())
            if (-not $isNotBreakGlass) { 
                Write-Verbose "    Filtered out break-glass account: $upn" 
            }
            return $isNotBreakGlass
        }
        
        $filteredCount = $filteredPageUsers.Count
        $removedCount = $pageUsers.Count - $filteredCount
        if ($removedCount -gt 0) {
            Write-Verbose "  -> Page $pageNumber : Filtered $($pageUsers.Count) -> $filteredCount users (removed $removedCount break-glass accounts)"
        }
        
        if ($filteredCount -eq 0) {
            Write-Verbose "  -> Page $pageNumber : No users remaining after filtering, skipping upload..."
            return @{ ProcessedCount = $pageUsers.Count; UploadedCount = 0 }
        }
        
        # Process current page users
        $batchResults = $filteredPageUsers | ForEach-Object {
            $user = $_
            $registration = $context.regById[$user.id]
            $methods = @()
            
            if ($registration -and $registration.methodsRegistered) {
                $methods = @($registration.methodsRegistered)
            }
            
            [PSCustomObject]@{
                id                = $user.id
                userPrincipalName = $user.userPrincipalName
                displayName       = $user.displayName
                mail              = $user.mail
                createdDateTime   = $user.createdDateTime
                userType          = $user.userType
                accountEnabled    = $user.accountEnabled
                signInActivity    = $user.signInActivity
                isMfaRegistered       = if ($registration) { $registration.isMfaRegistered } else { $null }
                isMfaCapable          = if ($registration) { $registration.isMfaCapable } else { $null }
                isSsprEnabled         = if ($registration) { $registration.isSsprEnabled } else { $null }
                isSsprRegistered      = if ($registration) { $registration.isSsprRegistered } else { $null }
                isSsprCapable         = if ($registration) { $registration.isSsprCapable } else { $null }
                isPasswordlessCapable = if ($registration) { $registration.isPasswordlessCapable } else { $null }
                defaultMethod         = if ($registration) { $registration.defaultMethod } else { $null }
                methodsRegistered     = $methods
                isSystemPreferredAuthenticationMethodEnabled = if ($registration) { $registration.isSystemPreferredAuthenticationMethodEnabled } else { $null }
                systemPreferredAuthenticationMethods = if ($registration) { $registration.systemPreferredAuthenticationMethods } else { $null }
                userPreferredMethodForSecondaryAuthentication = if ($registration) { $registration.userPreferredMethodForSecondaryAuthentication } else { $null }
                ReportTime        = $context.ReportTime
            }
        }
        
        Write-Verbose "  -> Page $pageNumber : Processing complete. $filteredCount records prepared for upload"        
        # Upload current page to Log Analytics
        Write-Verbose "  -> Page $pageNumber : Uploading $($batchResults.Count) records to Log Analytics..."
        
        $pageUploadSuccessful = $false
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            try {
                New-LogAnalyticsData -Data $batchResults -WorkSpaceID $context.WorkSpaceID -WorkSpaceKey $context.WorkspaceKey -LogType "GuardrailsUserRaw" | Out-Null
                $pageUploadSuccessful = $true
                Write-Verbose "  Success: Page $pageNumber upload successful on attempt $attempt"
                break
            }
            catch {
                if ($attempt -eq 3) {
                    $errorMsg = "Failed to upload page $pageNumber after 3 attempts: $($_.Exception.Message)"
                    Add-FunctionError -Message $errorMsg -Exception $_.Exception -Category "LogAnalytics" -ErrorList $context.ErrorList
                    throw [System.Exception]::new($errorMsg)
                } else {
                    $delay = Get-BackoffDelay -Attempt $attempt -Config $context.RetryConfig
                    Start-Sleep -Seconds $delay
                }
            }
        }
        
        if (-not $pageUploadSuccessful) {
            $errorMsg = "Failed to upload page $pageNumber after 3 attempts"
            Add-FunctionError -Message $errorMsg -Category "LogAnalytics" -ErrorList $context.ErrorList
            throw [System.Exception]::new($errorMsg)
        }
        
        # Progress reporting
        $statusMsg = if ($hasMore) { "more pages remaining..." } else { "final page" }
        Write-Verbose "  -> Page $pageNumber : Upload complete ($statusMsg)"
        
        return @{ 
            ProcessedCount = $pageUsers.Count
            UploadedCount = $batchResults.Count 
        }
    }
    
    try {
        # Use true streaming approach with callback processing        
        $streamResult = Invoke-GraphQueryStreamWithCallback -urlPath $usersPath -PageSize $BatchSize -ProcessPageCallback $processPageCallback -CallbackContext $callbackContext -PerformanceMetrics $performanceMetrics        
        $pageNumber = $streamResult.TotalPages
        $processedUsers = $streamResult.TotalProcessed
        $totalUploadedRecords = $streamResult.TotalUploaded
                
        $performanceMetrics.UsersProcessed = $processedUsers
        Write-Verbose "  Success: All pages processed and uploaded - $totalUploadedRecords total records uploaded from $pageNumber pages"
        
    } catch {
        Add-FunctionError -Message "Failed during streaming user processing" -Exception $_.Exception -Category "GraphAPI" -ErrorList $ErrorList
        return $ErrorList
    }
    
    # Step 5: Wait before verification to allow data ingestion and table creation
    Write-Verbose "Step 5: Waiting for data ingestion and table creation..."
    Write-Verbose "  -> Waiting 60 seconds to allow Log Analytics to create table and index data..."
    Write-Verbose "  -> Note: First-time table creation can take several minutes in Log Analytics"
    Start-Sleep -Seconds 60
    
    # Step 6: Verify data ingestion with robust error handling
    Write-Verbose "Step 6: Verifying data ingestion..."
    
    $dataIngested = $false
    $recordCount = 0
    $permissionError = $false
    $verificationSkipped = $false
    
    # First, check if we can access Log Analytics at all
    Write-Verbose "  -> Testing Log Analytics connectivity..."
    try {
        # Simple test query to check permissions and connectivity
        $testQuery = "Heartbeat | limit 1"
        $testResult = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkSpaceID -Query $testQuery -ErrorAction Stop
        Write-Verbose "  -> Log Analytics connectivity test successful"
    }
    catch {
        $errorMessage = $_.Exception.Message
        if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*" -or $errorMessage -like "*unauthorized*") {
            Write-Verbose "  -> Automation Account may need 'Log Analytics Reader' role on workspace $WorkSpaceID"
            $permissionError = $true
            $verificationSkipped = $true
        }
        elseif ($errorMessage -like "*BadRequest*" -or $errorMessage -like "*400*" -or $errorMessage -like "*Failed to resolve table*") {
            Write-Verbose "  -> The GuardrailsUserRaw_CL table may still be initializing after first data upload"
            Write-Verbose "  -> This typically resolves within 5-15 minutes of first deployment"
            $verificationSkipped = $true
        }
        else {
            Write-Verbose "  -> Will attempt data verification with reduced retry count"
        }
    }
    
    # Only attempt verification if connectivity test passed
    if (-not $verificationSkipped) {
        $maxVerificationAttempts = [Math]::Min($RetryConfig.MaxRetries, 6)  # Limit to 6 attempts max
        
        for ($attempt = 1; $attempt -le $maxVerificationAttempts; $attempt++) {
        $performanceMetrics.DataIngestionAttempts = $attempt
            
            # Use more robust query with error handling
            $query = @"
GuardrailsUserRaw_CL 
| where ReportTime_s == '$ReportTime'
| count
"@
            
            try {
                Write-Verbose "  -> Verification attempt $attempt/$maxVerificationAttempts : Querying Log Analytics..."
                
                # Use shorter timeout and explicit error handling
                $result = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkSpaceID -Query $query -ErrorAction Stop
                $recordCount = 0
            
                if ($result -and $result.Results) {
                    try {
                        # Direct access - if Count property exists, this will work
                        $recordCount = [int]$result.Results[0].Count
                    } catch {
                        # If direct access fails, the Count property doesn't exist as expected
                        $recordCount = 0
                    }
                }
            
                if ($recordCount -gt 0) {
                    Write-Verbose "  Success: Data ingestion verified - $recordCount records found for ReportTime '$ReportTime'"
                    $dataIngested = $true
                    break
                } else {
                    $delay = Get-BackoffDelay -Attempt $attempt -Config $RetryConfig
                        Write-Verbose "  -> Data not yet available (attempt $attempt/$maxVerificationAttempts). Waiting $delay seconds..."
                    
                        if ($attempt -lt $maxVerificationAttempts) {
                        Start-Sleep -Seconds $delay
                    }
                }
            
            } catch {
                $errorMessage = $_.Exception.Message
                $delay = Get-BackoffDelay -Attempt $attempt -Config $RetryConfig
                
                if ($errorMessage -like "*Forbidden*" -or $errorMessage -like "*403*" -or $errorMessage -like "*unauthorized*") {
                    Write-Warning "  Warning: Permission error on attempt $attempt : $errorMessage"
                    $permissionError = $true
                    break  # Don't retry permission errors
                } 
                elseif ($errorMessage -like "*BadRequest*" -or $errorMessage -like "*400*" -or $errorMessage -like "*Failed to resolve table*") {
                    if ($errorMessage -like "*Failed to resolve table*GuardrailsUserRaw_CL*") {
                        Write-Warning "  Warning: Table GuardrailsUserRaw_CL not yet available in Log Analytics."
                        Write-Verbose "  -> This is normal for first-time deployments - table creation can take 5-15 minutes"
                        Write-Verbose "  -> Data was uploaded successfully and will be available once indexing completes"
                        $verificationSkipped = $true
                    } else {
                        Write-Warning "  Warning: Query error on attempt $attempt : $errorMessage"
                        if ($attempt -eq $maxVerificationAttempts) {
                            Write-Verbose "  -> Query verification not available in this environment"
                            $verificationSkipped = $true
                        }
                    }
                    break  # Don't retry bad request errors
                }
                else {
                    Write-Warning "  Warning: Query attempt $attempt failed: $errorMessage"                    
                    if ($attempt -eq $maxVerificationAttempts) {
                        Write-Verbose "  -> Maximum verification attempts reached"
                    } elseif ($attempt -lt $maxVerificationAttempts) {
                        Write-Verbose "  -> Retrying in $delay seconds..."
                        Start-Sleep -Seconds $delay
                    }
                }
            }
        }
    }
    
    # Step 7: Final validation and reporting with graceful error handling
    Write-Verbose "Step 7: Final validation and reporting..."
    
    if ($verificationSkipped) {
        if ($permissionError) {
                Write-Warning "  Warning: Data verification skipped due to insufficient Log Analytics permissions."
                Write-Verbose "  -> Data upload completed successfully: $totalUploadedRecords records uploaded"
                Write-Verbose "  -> Consider granting 'Log Analytics Reader' role to the Automation Account for verification"
            } else {
                Write-Warning "  Warning: Data verification skipped - GuardrailsUserRaw_CL table not yet available."
                Write-Verbose "  -> Data upload completed successfully: $totalUploadedRecords records uploaded"
                Write-Verbose "  -> This is normal for first-time deployments - table creation can take 5-15 minutes"
                Write-Verbose "  -> Subsequent runs will be able to verify data once the table is established"
            }
            
        # Don't treat verification skip as a failure - data was uploaded successfully
        Write-Verbose "  Success: Data upload completed - $totalUploadedRecords records uploaded to Log Analytics"        
    } elseif ($permissionError) {
        # Permission error occurred during verification attempts
        Write-Warning "  Warning: Cannot verify data ingestion due to permission error."
        Write-Verbose "  -> Data upload completed: $totalUploadedRecords records uploaded"
        Write-Verbose "  -> Verification failed, but upload was successful"
            
        # Add a non-fatal warning rather than an error
        Add-FunctionError -Message "Data verification unavailable due to permissions. Upload completed successfully with $totalUploadedRecords records." -Category "Permissions" -ErrorList $ErrorList
        
    } elseif (-not $dataIngested) {
        # Verification was attempted but no data found
        Write-Warning "  Warning: Data ingestion verification failed - no records found in Log Analytics."
        Write-Verbose "  -> Uploaded $totalUploadedRecords records but verification query returned 0 results"
        Write-Verbose "  -> This may indicate data ingestion delay or indexing issues"
            
        Add-FunctionError -Message "Data ingestion verification failed. Uploaded $totalUploadedRecords records but verification query found 0 results. Data may still be processing." -Category "DataVerification" -ErrorList $ErrorList        
    } elseif ($recordCount -ne $totalUploadedRecords) {
            # Data found but count mismatch
        $expectedCount = $totalUploadedRecords
        Write-Warning "  Warning: Data count mismatch detected."
        Write-Verbose "  -> Expected: $expectedCount records, Found: $recordCount records"
            
        if ($recordCount > 0) {
            Write-Verbose "  -> Partial data ingestion detected - some records may still be processing"
            Add-FunctionError -Message "Data count mismatch: expected $expectedCount, found $recordCount records. Some data may still be processing." -Category "DataIntegrity" -ErrorList $ErrorList
        } else {
            Add-FunctionError -Message "Data count mismatch: expected $expectedCount, found $recordCount records. Data may be missing or still processing." -Category "DataIntegrity" -ErrorList $ErrorList
        }    
    } else {
        # Perfect success case
        Write-Verbose "  Success: Data ingestion verification successful - $recordCount records ingested and verified"
        Write-Verbose "  -> Upload and verification both completed successfully"
    }
    
    # Performance summary
    $stopwatch.Stop()
    $performanceMetrics.EndTime = Get-Date
    $performanceMetrics.TotalDurationMs = $stopwatch.ElapsedMilliseconds
    $performanceMetrics.TotalDurationMin = [Math]::Round($stopwatch.ElapsedMilliseconds / 60000, 2)
    
    Write-Verbose "=== Performance Summary ==="
    $durationMin = $performanceMetrics.TotalDurationMin
    $durationMs = $performanceMetrics.TotalDurationMs
    Write-Verbose "  Total Duration: $durationMin minutes ($durationMs ms)"
    Write-Verbose "  Users Processed: $($performanceMetrics.UsersProcessed)"
    Write-Verbose "  Records Uploaded: $totalUploadedRecords"
    Write-Verbose "  Page Size: $BatchSize"
    Write-Verbose "  Total Pages: $pageNumber"
    Write-Verbose "  Graph API Calls: $($performanceMetrics.GraphApiCalls)"
    Write-Verbose "  Data Ingestion Attempts: $($performanceMetrics.DataIngestionAttempts)"
    Write-Verbose "  Errors: $($ErrorList.Count)"
    
    if ($ErrorList.Count -eq 0) {
        Write-Verbose "  Success: Function completed successfully with no errors!"
    } else {
        $errorCount = $ErrorList.Count
        Write-Verbose "  Warning: Function completed with $errorCount errors/warnings"
    }
    
    Write-Verbose "=== FetchAllUserRawData Complete ==="
    
    return $ErrorList
}
# SIG # Begin signature block
# MIIyrAYJKoZIhvcNAQcCoIIynTCCMpkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBGuBgs0Z3ZV6AY
# 1zvRIs1a1VfR2cjY/n0m7Jg8J63Br6CCFpIwggQ+MIIDJqADAgECAgRKU4woMA0G
# CSqGSIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwg
# SW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5
# MDcGA1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVk
# IHVzZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkgLSBHMjAeFw0wOTA3MDcxNzI1NTRaFw0zMDEyMDcxNzU1NTRaMIG+
# MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMf
# U2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIw
# MDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MTIwMAYD
# VQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHMjCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALqEtnLbngxr4pnpMAGnduoy
# uJVBGsnaYU5Ycs/+9oJ5v3NhBgqlJ9izX9NFThxy1k4y8nKKD/eDGdBqgIAARR6w
# x+eavxJXJxyjaC8Kh71qaw5eZfMcd9XUhY1wIbSzMueLotWGOQKxuNJHzuTJScQ7
# p977VH1XvvDobsJ5sjoLVeJQmBYyE1wveFbBwpSz8lrkJ5qfJNfG7NCbJYLjzMLE
# RcWMl3oGayoRn6kKbkg7b9vUERlC948Hv/VTX5w+9Bcs5mmsTjJMYnfqt+jluzS8
# GYuunFHnt361U7EzIuVtz3A8Gvrim2e2g/SNpa9iTE3gWKxkNBID+LaNlGMkpHEC
# AwEAAaNCMEAwDgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFGpyJnrQHu995ztpUdRsjZ+QEmarMA0GCSqGSIb3DQEBCwUAA4IBAQB5nx2W
# xrZ5PyKNh9OHAwRgamuaLlmJcxGsQ9H1E/+NOSvA8r1PcIypL+oXxAtUntQblpgz
# PKitYqIAdqtZaW4GHX7EuUSNmK8S1GHbChlGR/Pr92PBQAVApdK39LWaNr+piHaI
# BFUEK5yHfxo3PH4tpRrY1Ileyr2sPWzYba/V83YPzTuIOCKdbJOaxD2/ghtlP6YP
# Xar85bIVyrWtxrw90ITo6gZysE05Mni/PhGcC6SdmiHz8JsLMHjbwdyHQ/68Y5rK
# xcIcyceN/zsSWAjmtj3seixO+4OWzgw8aYdUc6RzwpP/URCsFVQB2PwFsYmhf3SD
# mknX3E57ikhvi0X2MIIF3zCCBMegAwIBAgIQTkDkN1Tt5owAAAAAUdOUfzANBgkq
# hkiG9w0BAQsFADCBvjELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1c3QsIElu
# Yy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVzdC5uZXQvbGVnYWwtdGVybXMxOTA3
# BgNVBAsTMChjKSAyMDA5IEVudHJ1c3QsIEluYy4gLSBmb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTEyMDAGA1UEAxMpRW50cnVzdCBSb290IENlcnRpZmljYXRpb24gQXV0
# aG9yaXR5IC0gRzIwHhcNMjEwNTA3MTU0MzQ1WhcNMzAxMTA3MTYxMzQ1WjBpMQsw
# CQYDVQQGEwJVUzEWMBQGA1UECgwNRW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50
# cnVzdCBDb2RlIFNpZ25pbmcgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAt
# IENTQlIxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAp4GP9xRFtmJD
# 8tiu0yVeSE9Rv8V9n1AcNdHWfmEqlBltJ0akphpd91RRaoAixqhmdU1Ug8leaBur
# 9ltksK2tIL1U70ZrbQLnRa519o6KuTIui7h3HFJNeYhfpToYyVAslyctv9oAfWN/
# 7zLsRodj25qfw1ohNnv5m9XKoG5yLPzh8Z5wTQhWFW+Qq/tIurnXwYJ4hWUuf7XJ
# wOIUtzcRQQbiiuCo9uV+tngFAcNg7U8HQS4KE0njkJt/3b36rL9kUdFcm7T1XOdc
# /zubpaAa130JssK3/24cvMh95ukr/HKzFOlKVRKEnEQldR32KvBPpSA9aCXrYZd8
# D+W2PfOuw8ERvBuOzOBHMF5CAIZx41isBsplH3uUpktXZwx+Xq14Z1tV417rx9js
# TG6Gy/Pc+J+HqnJYEg99pvj4Qjk7PCzkMk1JjODhAMI4oJz6hD5B3G5WrsYaW/Rn
# aAUBzRu/roe8nVP2Lui2a+SZ3sVPh1io0mUeyB/Vcm7uWRxXOwlyndfKt5DGzXtF
# kpFCA0x9P8ryqrjCDobzEJ9GLqRmhmhaaBhwKTgRgGBrikOjc2zjs2s3/+adZwGS
# ht8vSNH7UGDVXP4h0wFCY/7vcLQXwI+o7tPBS18S6v39Lg6HRGDjqfTCGKPj/c4M
# hCIN86d42pPz2zjPuS8zxv8HPF6+RdMCAwEAAaOCASswggEnMA4GA1UdDwEB/wQE
# AwIBhjASBgNVHRMBAf8ECDAGAQH/AgEBMB0GA1UdJQQWMBQGCCsGAQUFBwMDBggr
# BgEFBQcDCDA7BgNVHSAENDAyMDAGBFUdIAAwKDAmBggrBgEFBQcCARYaaHR0cDov
# L3d3dy5lbnRydXN0Lm5ldC9ycGEwMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAwBgNVHR8EKTAnMCWgI6Ahhh9odHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2cyY2EuY3JsMB0GA1UdDgQWBBSCutY9l86fz3Ho
# kjev/bO1aTVXzzAfBgNVHSMEGDAWgBRqciZ60B7vfec7aVHUbI2fkBJmqzANBgkq
# hkiG9w0BAQsFAAOCAQEAH15BBLaDcCRTLFVzHWU6wOy0ewSYXlk4EwmkWZRCXlC/
# T2xuJSCQk1hADfUZtGLuJF7CAVgVAh0QCW+o1PuSfjc4Pi8UfY8dQzZks2YTXxTM
# pXH3WyFLxpe+3JX8cH0RHNMh3dAkOSnF/goapc97ee46b97cv+kR3RaDCNMsjX9N
# qBR5LwVhUjjrYPMUaH3LsoqtwJRc5CYOLIrdRsPO5FZRxVbjhbhNm0VyiwfxivtJ
# uF/R8paBXWlSJPEII9LWIw/ri9d+i8GTa/rxYntY6VCbl24XiA3hxkOY14FhtoWd
# R+yxnq4/IDtDndiiHODUfAjCr3YG+GJmerb3+sivNTCCBfUwggPdoAMCAQICEH9t
# pc0g1hYK1SPEEVZtoXEwDQYJKoZIhvcNAQENBQAwTzELMAkGA1UEBhMCVVMxFjAU
# BgNVBAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWdu
# aW5nIENBIC0gT1ZDUzIwHhcNMjQxMDI5MTQ1NDIyWhcNMjUxMTIzMTQ1NDIwWjBy
# MQswCQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdh
# MR8wHQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFy
# ZWQgU2VydmljZXMgQ2FuYWRhMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKC
# AYEAiojKH+XPe+beyDzVUpIChDDMhep8ENwkPx7hfdmutAWP4h2EE1OaaBJcGm/z
# yRtuYJ64uSmUahu23wueRdhDxkBaJgfDO/AHkT7Q6UC3NgZrsEEe2Mb7nbUui676
# NbEQRLfh+vmW/s+9Vz4psnWK7qCHBn5ypVYjCQSnZGQjng2E0Ko5bZo7hO3itObT
# Ld7xq9Lr1L+FK5hWydu5UAndazONs0IgwqQKgZ0iu52B4dtojGJCNXoN6Z4GOV5O
# PYg0fammJRYHur+wcbGWcC/v5jPvbwfOzAL+J7ZoGnW4SAvolCnW47SAfkwDSzOl
# iMLeCb5zxolBi8kg3sy82stU7VBQxiK9Q/i7eUyhk/Cbxa1+9tTVIVak/RMLXE7h
# nAPEhv/Vds0Zxi+3xfIVM4Yo/JJelzixOHwvfjDdAnn2gjOdHmgXf3qLUd/8VVTI
# NG5ypZIlRTDLjfw5DY7AISYL7T0dMuq2FhD8DE/f/hAYhxRcXgpC5LEzHF13O3JI
# aa59AgMBAAGjggEoMIIBJDAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBSMKfPIWgMV
# dRERIVCRdhTVOQWaPDAfBgNVHSMEGDAWgBTvn7p5sHPyJR54nANSnBtThN6N7TAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwZwYIKwYBBQUHAQEE
# WzBZMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAyBggrBgEF
# BQcwAoYmaHR0cDovL2FpYS5lbnRydXN0Lm5ldC9vdmNzMi1jaGFpbi5wN2MwMQYD
# VR0fBCowKDAmoCSgIoYgaHR0cDovL2NybC5lbnRydXN0Lm5ldC9vdmNzMi5jcmww
# EwYDVR0gBAwwCjAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBABarCE8pTjYN
# zIJAvqBuEnADo9afVzezReZHOptUpdA1Q6oDBm/7ARFJIiJkQdxnt7aesBETwiV4
# 5wndiZ0rliv4aOMle7oPlMmG1M44bvCDaFwYNxMKqtLWu77lPUUa63XZ0CKRHdHg
# QvjCHnBV7K/JEMT0gvtJ8squJ/o38f507jWKaJATEtYvT8SYjxBk0tXo21Vc9C/C
# xndoIMW6lcVREVwvdL9bClEO8du7x6I1KDBfdIn7/0iokuY+yDbRDKUrr/lJ4ULZ
# AgIldVTRORdR0hYdLDNXOKMdn8p1+V0Xa/2bwX8tch5x9bamaalNlh9vGxack0d/
# tCZ4xHjwchTeBdbVxIDvMeOg+DCKk4OKlNSkl1kCC3dGKLQnl+7S3UHnONffWLFz
# niQ4RuCve3ELt9JhLXdQL/qyHc2J3ZAkvAUMT3kYinQL6JZZmeS/DakrBgI/eLfE
# uv9+Ys10WeB+HnO7tGRFXBuzb7a0HBP02BJXmCnylsM16MuPtpNVsXaNUgzLfe7/
# 5P/fYCGiM4VCLJBNz9paFjZfLaIL38QsPg7BbsE00jT8j97nqKzPZiw8J3tfrN5R
# FP74QQbBaoujXpUmIw4tb6fgw7pjbIXRjJPReDp8rtctaBc8H9rpz0o5x2McMFbL
# ScjxUB5vCttH2p7+m9qRDjuZbzqNB/+CMIIGcDCCBFigAwIBAgIQce9VdK81VMNa
# LGn2b0trzTANBgkqhkiG9w0BAQ0FADBpMQswCQYDVQQGEwJVUzEWMBQGA1UECgwN
# RW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50cnVzdCBDb2RlIFNpZ25pbmcgUm9v
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIENTQlIxMB4XDTIxMDUwNzE5MjA0
# NVoXDTQwMTIyOTIzNTkwMFowTzELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1
# c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZD
# UzIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCemXYXGp5WFwhjLJNN
# g2GEMzQCttlioN7CDrkgTMhXnQ/dVFsNDNYB3S9I4ZEJ4dvIFQSCtnvw2NYwOxlx
# cPuoppf2KV2kDKn0Uz5X2wxObvx2218k6apfQ+OT5w7PyiW8xEwwC1oP5gb05W4M
# mWZYT4NhwnN8XCJvAUXFD/dAT2RL0BcKqQ4eAi+hj0zyZ1DbPuSfwk8/dOsxpNCU
# 0Jm8MJIJasskzaLYdlLQTnWYT2Ra0l6D9FjAXWp1xNg/ZDqLFA3YduHquWvnEXBJ
# EThjE27xxvq9EEU1B+Z2FdB1FqrCQ1f+q/5jc0YioLjz5MdwRgn5qTdBmrNLbB9w
# cqMH9jWSdBFkbvkC1cCSlfGXWX4N7qIl8nFVuJuNv83urt37DOeuMk5QjaHf0XO/
# wc5/ddqrv9CtgjjF54jtom06hhG317DhqIs7DEEXml/kW5jInQCf93PSw+mfBYd5
# IYPWC+3RzAif4PHFyVi6U1/Uh7GLWajSXs1p0D76xDkJr7S17ec8+iKH1nP5F5Vq
# wxz1VXhf1PoLwFs/jHgVDlpMOm7lJpjQJ8wg38CGO3qNZUZ+2WFeqfSuPtT8r0XH
# OrOFBEqLyAlds3sCKFnjhn2AolhAZmLgOFWDq58pQSa6u+nYZPi2uyhzzRVK155z
# 42ZMsVGdgSOLyIZ3srYsNyJwIQIDAQABo4IBLDCCASgwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQU75+6ebBz8iUeeJwDUpwbU4Teje0wHwYDVR0jBBgwFoAU
# grrWPZfOn89x6JI3r/2ztWk1V88wMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAxBgNVHR8EKjAoMCagJKAihiBodHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2NzYnIxLmNybDAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwMwRQYDVR0gBD4wPDAwBgRVHSAAMCgwJgYIKwYBBQUH
# AgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMAgGBmeBDAEEATANBgkqhkiG
# 9w0BAQ0FAAOCAgEAXvOGmTXBee7wEK/XkkPShdBb4Jig4HFRyRTLUJpgDrAEJkmx
# z+m6mwih2kNd1G8jorn4QMdH/k0BC0iQP8jcarQ+UzUovkBKR4VqHndAzIB/YbQ8
# T3mo5qOmoH5EhnG/EhuVgXL3DaXQ3mefxqK48Wr5/P50ZsZk5nk9agNhTksfzCBi
# ywIY7GPtfnE/lroLXmgiZ+wfwNIFFmaxsqTq/MWVo40SpfWN7xsgzZn35zLzWXEf
# 3ZTmeeVSIxBWKvxZOL+/eSWSasf9q2d3cbEEfTWtFME+qPwjF1YIGHzXeiJrkWrM
# NUVtTzudQ50FuJ3z/DQhXAQYMlc4NMHKgyNGpogjIcZ+FICrse+7C6wJP+5TkTGz
# 4lREqrV9MDwsI5zoP6NY6kAIF6MgX3rADNuq/wMWAw10ZCKalF4wNXYT9dPh4+AH
# ytnqRYhGnFTVEOLzMglAtudcFzL+zK/rbc9gPHXz7lxgQFUbtVmvciNoTZx0BAwQ
# ya9QW6cNZg+W5ZqV4CCiGtCw7jhJnipnnpGWbJjbxBBtYHwebkjntn6vMwcSce+9
# lTu+qYPUQn23pzTXX4aRta9WWNpVfRe927zNZEEVjTFRBk+0LrKLPZzzTeNYA1TM
# rIj4UjxOS0YJJRn/FeenmEYufbrq4+N8//m5GZW+drkNebICURpKyJ+IwkMxghtw
# MIIbbAIBATBjME8xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMu
# MSgwJgYDVQQDEx9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyAhB/baXN
# INYWCtUjxBFWbaFxMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIK4UOxeU+ByI//vpaEX8
# Pogy3RjbZSIsd6pEmh5JPP0tMA0GCSqGSIb3DQEBAQUABIIBgHGDbfHc+kIwHsF6
# qwmMzPmW+HmsK6Ol6KU7Lagi6S9Uwiz8m1wFWqz8BZ3M4be+NYcX56wDsJTPcm4Q
# r36gjI8W5KnL6sOa34Qquxvgh0RdpZGexiGVS2iG3IGfWKI9Jzo3JmZ9K0oBUWmn
# og9mDbHoElE1tOQManWTaikPJbvRBsNPhQ8u/RPMRTBojg1B+PNrwJ1RNCGgbE6f
# 9vlxj5e34I+5sa+4aB+YqvAuNabusqGqmsWJbGs+QNkJteclfGHsAG9nNJ8bWdph
# 28VTVheHIMd9/93KyehoR58J51SzP6ytfBAqbEIYtH49Rrw7BFy4Oy2ueDhlXN1z
# 9kjiFSBDBaVIAyDxwdLUJjlk7UCxIBA/A/5uGizcZXMGn6NRUYKQSOtEehEuGr+K
# dOxbktsZPWbHocgNKZ7J+9a7CBq5MkjOHYbsMSl5nG37xKK9Vtsvk5iAhpv9nigN
# 6SKUCz0acH1YWOpyU219LHkYjt6+KpPZ8GP7B5Flg0Xj9Dv3PKGCGNcwghjTBgor
# BgEEAYI3AwMBMYIYwzCCGL8GCSqGSIb3DQEHAqCCGLAwghisAgEDMQ8wDQYJYIZI
# AWUDBAICBQAwgfcGCyqGSIb3DQEJEAEEoIHnBIHkMIHhAgEBBgorBgEEAbIxAgEB
# MDEwDQYJYIZIAWUDBAIBBQAEIIB2wh1712QQhQOlmhcOeUhCT3kV4e24avbRo4I2
# hZScAhRD6xsQcp74nKeynS/mOnK4O0hKdhgPMjAyNTEwMDcxODI3MThaoHakdDBy
# MQswCQYDVQQGEwJHQjEXMBUGA1UECBMOV2VzdCBZb3Jrc2hpcmUxGDAWBgNVBAoT
# D1NlY3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBT
# dGFtcGluZyBTaWduZXIgUjM2oIITBDCCBmIwggTKoAMCAQICEQCkKTtuHt3XpzQI
# h616TrckMA0GCSqGSIb3DQEBDAUAMFUxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxLDAqBgNVBAMTI1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgQ0EgUjM2MB4XDTI1MDMyNzAwMDAwMFoXDTM2MDMyMTIzNTk1OVowcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDldlc3QgWW9ya3NoaXJlMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzNjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# ANOElfRupFN48j0QS3gSBzzclIFTZ2Gsn7BjsmBF659/kpA2Ey7NXK3MP6JdrMBN
# U8wdmkf+SSIyjX++UAYWtg3Y/uDRDyg8RxHeHRJ+0U1jHEyH5uPdk1ttiPC3x/gO
# xIc9P7Gn3OgW7DQc4x07exZ4DX4XyaGDq5LoEmk/BdCM1IelVMKB3WA6YpZ/XYdJ
# 9JueOXeQObSQ/dohQCGyh0FhmwkDWKZaqQBWrBwZ++zqlt+z/QYTgEnZo6dyIo2I
# hXXANFkCHutL8765NBxvolXMFWY8/reTnFxk3MajgM5NX6wzWdWsPJxYRhLxtJLS
# UJJ5yWRNw+NBqH1ezvFs4GgJ2ZqFJ+Dwqbx9+rw+F2gBdgo4j7CVomP49sS7Cbqs
# dybbiOGpB9DJhs5QVMpYV73TVV3IwLiBHBECrTgUfZVOMF0KSEq2zk/Lsfvehswa
# vE3W4aBXJmGjgWSpcDz+6TqeTM8f1DIcgQPdz0IYgnT3yFTgiDbFGOFNt6eCidxd
# R6j9x+kpcN5RwApy4pRhE10YOV/xafBvKpRuWPjOPWRBlKdm53kS2aMh08spx7xS
# EqXn4QQldCnUWRz3Lki+TgBlpwYwJUbR77DAayNwAANE7taBrz2v+MnnogMrvvct
# 0iwvfIA1W8kp155Lo44SIfqGmrbJP6Mn+Udr3MR2oWozAgMBAAGjggGOMIIBijAf
# BgNVHSMEGDAWgBRfWO1MMXqiYUKNUoC6s2GXGaIymzAdBgNVHQ4EFgQUiGGMoSo3
# ZIEoYKGbMdCM/SwCzk8wDgYDVR0PAQH/BAQDAgbAMAwGA1UdEwEB/wQCMAAwFgYD
# VR0lAQH/BAwwCgYIKwYBBQUHAwgwSgYDVR0gBEMwQTA1BgwrBgEEAbIxAQIBAwgw
# JTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMwCAYGZ4EMAQQC
# MEoGA1UdHwRDMEEwP6A9oDuGOWh0dHA6Ly9jcmwuc2VjdGlnby5jb20vU2VjdGln
# b1B1YmxpY1RpbWVTdGFtcGluZ0NBUjM2LmNybDB6BggrBgEFBQcBAQRuMGwwRQYI
# KwYBBQUHMAKGOWh0dHA6Ly9jcnQuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1Rp
# bWVTdGFtcGluZ0NBUjM2LmNydDAjBggrBgEFBQcwAYYXaHR0cDovL29jc3Auc2Vj
# dGlnby5jb20wDQYJKoZIhvcNAQEMBQADggGBAAKBPqSGclEh+WWpLj1SiuHlm8xL
# E0SThI2yLuq+75s11y6SceBchpnKpxWaGtXc8dya1Aq3RuW//y3wMThsvT4fSba2
# AoSWlR67rA4fTYGMIhgzocsids0ct/pHaocLVJSwnTYxY2pE0hPoZAvRebctbsTq
# ENmZHyOVjOFlwN2R3DRweFeNs4uyZN5LRJ5EnVYlcTOq3bl1tI5poru9WaQRWQ4e
# ynXp7Pj0Fz4DKr86HYECRJMWiDjeV0QqAcQMFsIjJtrYTw7mU81qf4FBc4u4swph
# LeKRNyn9DDrd3HIMJ+CpdhSHEGleeZ5I79YDg3B3A/fmVY2GaMik1Vm+FajEMv4/
# EN2mmHf4zkOuhYZNzVm4NrWJeY4UAriLBOeVYODdA1GxFr1ycbcUEGlUecc4RCPg
# YySs4d00NNuicR4a9n7idJlevAJbha/arIYMEuUqTeRRbWkhJwMKmb9yEvppRudK
# yu1t6l21sIuIZqcpVH8oLWCxHS0LpDRF9Y4jijCCBhQwggP8oAMCAQICEHojrtpT
# aZYPkcg+XPTH4z8wDQYJKoZIhvcNAQEMBQAwVzELMAkGA1UEBhMCR0IxGDAWBgNV
# BAoTD1NlY3RpZ28gTGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGlt
# ZSBTdGFtcGluZyBSb290IFI0NjAeFw0yMTAzMjIwMDAwMDBaFw0zNjAzMjEyMzU5
# NTlaMFUxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLDAq
# BgNVBAMTI1NlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgQ0EgUjM2MIIBojAN
# BgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAzZjYQ0GrboIr7PYzfiY05ImM0+8i
# EoBUPu8mr4wOgYPjoiIz5vzf7d5wu8GFK1JWN5hciN9rdqOhbdxLcSVwnOTJmUGf
# AMQm4eXOls3iQwfapEFWuOsYmBKXPNSpwZAFoLGl5y1EaGGc5LByM8wjcbSF52/Z
# 42YaJRsPXY545E3QAPN2mxDh0OLozhiGgYT1xtjXVfEzYBVmfQaI5QL35cTTAjsJ
# Ap85R+KAsOfuL9Z7LFnjdcuPkZWjssMETFIueH69rxbFOUD64G+rUo7xFIdRAuDN
# vWBsv0iGDPGaR2nZlY24tz5fISYk1sPY4gir99aXAGnoo0vX3Okew4MsiyBn5ZnU
# DMKzUcQrpVavGacrIkmDYu/bcOUR1mVBIZ0X7P4bKf38JF7Mp7tY3LFF/h7hvBS2
# tgTYXlD7TnIMPrxyXCfB5yQq3FFoXRXM3/DvqQ4shoVWF/mwwz9xoRku05iphp22
# fTfjKRIVpm4gFT24JKspEpM8mFa9eTgKWWCvAgMBAAGjggFcMIIBWDAfBgNVHSME
# GDAWgBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAdBgNVHQ4EFgQUX1jtTDF6omFCjVKA
# urNhlxmiMpswDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQAwEwYD
# VR0lBAwwCgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMEwGA1UdHwRFMEMw
# QaA/oD2GO2h0dHA6Ly9jcmwuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVT
# dGFtcGluZ1Jvb3RSNDYuY3JsMHwGCCsGAQUFBwEBBHAwbjBHBggrBgEFBQcwAoY7
# aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0YW1waW5n
# Um9vdFI0Ni5wN2MwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29t
# MA0GCSqGSIb3DQEBDAUAA4ICAQAS13sgrQ41WAyegR0lWP1MLWd0r8diJiH2VVRp
# xqFGhnZbaF+IQ7JATGceTWOS+kgnMAzGYRzpm8jIcjlSQ8JtcqymKhgx1s6cFZBS
# fvfeoyigF8iCGlH+SVSo3HHr98NepjSFJTU5KSRKK+3nVSWYkSVQgJlgGh3MPcz9
# IWN4I/n1qfDGzqHCPWZ+/Mb5vVyhgaeqxLPbBIqv6cM74Nvyo1xNsllECJJrOvsr
# JQkajVz4xJwZ8blAdX5umzwFfk7K/0K3fpjgiXpqNOpXaJ+KSRW0HdE0FSDC7+ZK
# JJSJx78mn+rwEyT+A3z7Ss0gT5CpTrcmhUwIw9jbvnYuYRKxFVWjKklW3z83epDV
# zoWJttxFpujdrNmRwh1YZVIB2guAAjEQoF42H0BA7WBCueHVMDyV1e4nM9K4As7P
# VSNvQ8LI1WRaTuGSFUd9y8F8jw22BZC6mJoB40d7SlZIYfaildlgpgbgtu6SDsek
# 2L8qomG57Yp5qTqof0DwJ4Q4HsShvRl/59T4IJBovRwmqWafH0cIPEX7cEttS5+t
# XrgRtMjjTOp6A9l0D6xcKZtxnLqiTH9KPCy6xZEi0UDcMTww5Fl4VvoGbMG2oonu
# X3f1tsoHLaO/Fwkj3xVr3lDkmeUqivebQTvGkx5hGuJaSVQ+x60xJ/Y29RBr8Tm9
# XJ59AjCCBoIwggRqoAMCAQICEDbCsL18Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEM
# BQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQH
# EwtKZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4w
# LAYDVQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4X
# DTIxMDMyMjAwMDAwMFoXDTM4MDExODIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAW
# BgNVBAoTD1NlY3RpZ28gTGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMg
# VGltZSBTdGFtcGluZyBSb290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBAIid2LlFZ50d3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYs
# yAhTXiDQkiUvpVdYqZ1uYoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXV
# ydmhx7Dx4IBrAou7hNGsKioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjt
# hgF7Hjx4vvyVDQGsd5KarLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1
# gASn/hp6IuHJorEu6EopoB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35Zv
# xQw6zid61qmrlD/IbKJA6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6K
# dOpuzVDR3ZUwxDKL1wCAxgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhL
# RPb7YkzM8/6NnWH3T9ClmcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb
# 49zYHr7ALL8bAJyPDmubNqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRK
# KsxCG1t6tG9oj7liwPddXEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5
# e45NuzAHteORlsSuDt5t4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjggEW
# MIIBEjAfBgNVHSMEGDAWgBRTeb9aqitKz1SA4dibwJ3ysgNmyzAdBgNVHQ4EFgQU
# 9ndq3T/9ARP/FqFsggIv0Ao9FCUwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wEwYDVR0lBAwwCgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMFAG
# A1UdHwRJMEcwRaBDoEGGP2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9VU0VSVHJ1
# c3RSU0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDA1BggrBgEFBQcBAQQpMCcw
# JQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcN
# AQEMBQADggIBAA6+ZUHtaES45aHF1BGH5Lc7JYzrftrIF5Ht2PFDxKKFOct/awAE
# WgHQMVHol9ZLSyd/pYMbaC0IZ+XBW9xhdkkmUV/KbUOiL7g98M/yzRyqUOZ1/IY7
# Ay0YbMniIibJrPcgFp73WDnRDKtVutShPSZQZAdtFwXnuiWl8eFARK3PmLqEm9Us
# VX+55DbVIz33Mbhba0HUTEYv3yJ1fwKGxPBsP/MgTECimh7eXomvMm0/GPxX2uhw
# Ccs/YLxDnBdVVlxvDjHjO1cuwbOpkiJGHmLXXVNbsdXUC2xBrq9fLrfe8IBsA4ho
# pwsCj8hTuwKXJlSTrZcPRVSccP5i9U28gZ7OMzoJGlxZ5384OKm0r568Mo9TYrqz
# KeKZgFo0fj2/0iHbj55hc20jfxvK3mQi+H7xpbzxZOFGm/yVQkpo+ffv5gdhp+hv
# 1GDsvJOtJinJmgGbBFZIThbqI+MHvAmMmkfb3fTxmSkop2mSJL1Y2x/955S29Gu0
# gSJIkc3z30vU/iXrMpWx2tS7UVfVP+5tKuzGtgkP7d/doqDrLF1u6Ci3TpjAZdeL
# LlRQZm867eVeXED58LXd1Dk6UvaAhvmWYXoiLz4JA5gPBcz7J311uahxCweNxE+x
# xxR3kT0WKzASo5G/PyDez6NHdIUKBeE3jDPs2ACc6CkJ1Sji4PKWVT0/MYIEkjCC
# BI4CAQEwajBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVk
# MSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFIzNgIR
# AKQpO24e3denNAiHrXpOtyQwDQYJYIZIAWUDBAICBQCgggH5MBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjUxMDA3MTgyNzE4WjA/
# BgkqhkiG9w0BCQQxMgQw+XD0T8qHYAPm3yWn/U5JnvDA1wb4ojLv5+MkWjLobRi5
# u+2l8fw9Mk8wWEQqcn/xMIIBegYLKoZIhvcNAQkQAgwxggFpMIIBZTCCAWEwFgQU
# OMkUgRBEtNxmPpPUdEuBQYaptbEwgYcEFMauVOR4hvF8PVUSSIxpw0p6+cLdMG8w
# W6RZMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAs
# BgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBSNDYCEHoj
# rtpTaZYPkcg+XPTH4z8wgbwEFIU9Yy2TgoJhfNCQNcSR3pLBQtrHMIGjMIGOpIGL
# MIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxML
# SmVyc2V5IENpdHkxHjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwG
# A1UEAxMlVVNFUlRydXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eQIQNsKw
# vXwbOuejs902y8l1aDANBgkqhkiG9w0BAQEFAASCAgAiw46vkp/kPrWYhawzX/MJ
# mNmLe3ZjA6sb6VxU6g4OJzUD/Lm8jI1NR9qDlBXZB+tLVwvObdzRlIEDehTG+dFs
# ktNrRtRB/mxJOuNcZdu+qYwyUfJLX/pyQsKwPkynVc/5B5IgKJNpgWhWZSrT5QEH
# WTm5Lbb5HXXqxIN4DCfu/vs+Jg9YK3/9+Jh0NZ/+28gPztU6tkOVn/ZR0bkkhq7v
# xH80SLa3R4WtOwYMoiUOQZEWVe/fJQcijkGmL1ZUzvHH5pjg1olSKgbA/urOvy8c
# YviIOE8nSE6Pmm4qPZk35X2SaNPkqDqBX9IPLQVrrYP+nvvufSEkNfUSR71qnww8
# MfgBiPCrIB6l421sLOF60KC+lr1Aksw7ZacmhhpqpQCVwK0bOdYJyMJIhOEV0yOk
# RmMnJaeyvagWJ5FGGtAcRf1FavDBlI4hLE2ndIGyaFHRXP6/HNM6SUUrGr0cTCO1
# yc4cAwROf5BamdgMPa7tYt/lSjV5b4+GPYzN6viBXoecVcxhu4RaQ0emg6bM27bn
# 2F28J/AyOfODXIAZg7C6v4WiEqQliW1UTSBgoH6OcFVLnWFdItRwz5BL2LvHZ+2j
# aLWLOR6n//Gt2TJjajTIVTlXqUynKX8rfV3kJ+/hra6FGbiuvkBUgqmxl+OmxiBn
# qv5gs8wapPa3/+YWZGX3Og==
# SIG # End signature block

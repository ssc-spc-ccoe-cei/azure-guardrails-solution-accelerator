

function Get-ResourceCountsFromARG {
    <#
    .SYNOPSIS
        Retrieves resource counts by type across all subscriptions using Azure Resource Graph.

    .DESCRIPTION
        Queries Azure Resource Graph to count resources grouped by subscription ID and resource type.
        Returns a nested hashtable where the first key is the subscription ID and the second key is
        the resource type, with the count as the value. Supports pagination for large environments.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A nested hashtable with structure: countsBySub[subscriptionId][resourceType] = count
    #>
    param(
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable countsBySub[subscriptionId][resourceType] = count
    $countsBySub = @{}

    $query = @"
resources
| summarize c=count() by subscriptionId, type
"@

    try {
        Write-Verbose "ARG: counting resources by type across tenant..."
        $skipToken = $null
        $pageCount = 0

        do {
            $pageCount++
            if ($skipToken) {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -SkipToken $skipToken -ErrorAction Stop
            } else {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -ErrorAction Stop
            }

            foreach ($row in $results) {
                $sid = [string]$row.subscriptionId
                $rtype = [string]$row.type
                $cnt = [int]$row.c

                if (-not $countsBySub.ContainsKey($sid)) { $countsBySub[$sid] = @{} }
                $countsBySub[$sid][$rtype] = $cnt
            }

            $skipToken = $results.SkipToken
            Write-Verbose "ARG page $pageCount processed. HasSkipToken: $($null -ne $skipToken)"
        } while ($skipToken)

        return $countsBySub
    }
    catch {
        Write-Verbose "ARG resource count query failed: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARG resource count query failed: $_") }
        return @{}
    }
}

function Get-DefenderPricingBySubscription {
    <#
    .SYNOPSIS
        Retrieves Microsoft Defender for Cloud pricing tiers for a specific subscription.

    .DESCRIPTION
        Calls the Azure Management REST API to retrieve the Defender for Cloud pricing configuration
        for the specified subscription. Returns a hashtable mapping each Defender plan name to its
        pricing tier (e.g., 'Free' or 'Standard').

    .PARAMETER SubscriptionId
        The Azure subscription ID to query for Defender pricing information.

    .PARAMETER AccessToken
        A secure access token for Azure REST API calls.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A hashtable with structure: pricingByPlan[planName] = pricingTier
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [securestring]$AccessToken,
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable pricingByPlan[planName] = pricingTier
    $pricingByPlan = @{}

    # Use stable API version
    $uri = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Security/pricings?api-version=2023-01-01"

    try {
        # The 7.6 migration uses the secure token path provided by the upgraded Az modules.
        # Pass that token directly to PowerShell instead of rebuilding the old plain-text authorization header.
        # This API returns JSON; ErrorAction Stop sends HTTP failures to the catch block below.
        $resp = Invoke-RestMethod -Uri $uri -Method Get -Authentication Bearer -Token $AccessToken -ContentType 'application/json' -ErrorAction Stop
        if ($resp -and $resp.value) {
            foreach ($p in $resp.value) {
                $name = [string]$p.name
                $tier = $null
                if ($p.properties -and $p.properties.pricingTier) { $tier = [string]$p.properties.pricingTier }
                if ($name) { $pricingByPlan[$name] = $tier }
            }
        }
    }
    catch {
        Write-Verbose "Failed to get Defender pricings for subscription ${SubscriptionId}: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARM Defender pricings failed for ${SubscriptionId}: $_") }
    }

    return $pricingByPlan
}



function Get-CwpCoverageForSubscription {
    <#
    .SYNOPSIS
        Evaluates Cloud Workload Protection (CWP) coverage for a subscription based on deployed resources.

    .DESCRIPTION
        Determines which Defender for Cloud plans are required based on the types of resources deployed
        in the subscription, then verifies that those plans are enabled at the 'Standard' tier.
        Returns a coverage assessment including required plans, missing plans, and compliance status.

    .PARAMETER SubscriptionId
        The Azure subscription ID to evaluate for CWP coverage.

    .PARAMETER CountsBySub
        A hashtable from Get-ResourceCountsFromARG containing resource counts by subscription and type.

    .PARAMETER TypeToPlanMap
        A hashtable mapping Azure resource types to their corresponding Defender for Cloud plan names.

    .PARAMETER PricingByPlan
        A hashtable from Get-DefenderPricingBySubscription containing plan names and their pricing tiers.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .OUTPUTS
        PSCustomObject - An object with properties: coverageOk, requiredPlans, missingPlans, and comment.
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [hashtable]$CountsBySub,      # output of Get-ResourceCountsFromARG
        [Parameter(Mandatory)]
        [hashtable]$TypeToPlanMap,    
        [Parameter(Mandatory)]
        [hashtable]$PricingByPlan,    # output of Get-DefenderPricingBySubscription
        [Parameter(Mandatory)]
        [hashtable]$msgTable
    )

    $requiredPlans = New-Object System.Collections.Generic.HashSet[string]
    $subCounts = $null
    if ($CountsBySub.ContainsKey($SubscriptionId)) { $subCounts = $CountsBySub[$SubscriptionId] }

    # Determine which plans are required based on resource presence
    foreach ($rtype in $TypeToPlanMap.Keys) {
        $cnt = 0
        if ($subCounts -and $subCounts.ContainsKey($rtype)) { $cnt = [int]$subCounts[$rtype] }

        if ($cnt -gt 0) {
            [void]$requiredPlans.Add([string]$TypeToPlanMap[$rtype])
        }
    }

    if ($requiredPlans.Count -eq 0) {
        return [PSCustomObject]@{
            coverageOk    = $true
            requiredPlans = @()
            missingPlans  = @()
            comment       = $msgTable.NoMappedResourcesOrMappingIncomplete
        }
    }

    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($plan in $requiredPlans) {
        $tier = $null
        if ($PricingByPlan.ContainsKey($plan)) { $tier = $PricingByPlan[$plan] }

        if (-not $tier -or ($tier.ToString().ToLower() -ne "standard")) {
            $missing.Add($plan) | Out-Null
        }
    }

    if ($missing.Count -gt 0) {
        return [PSCustomObject]@{
            coverageOk    = $false
            requiredPlans = @($requiredPlans)
            missingPlans  = @($missing)
            comment       = $msgTable.CwpPlansNotStandard -f ($missing -join ", ")
        }
    }

    return [PSCustomObject]@{
        coverageOk    = $true
        requiredPlans = @($requiredPlans)
        missingPlans  = @()
        comment       = $msgTable.CoverageOk
    }
}


function Get-DFCAcheckComplianceStatus {
        
    <#
    .SYNOPSIS
        Checks Defender for Cloud Alerts (DFCA) notification compliance for a subscription.

    .DESCRIPTION
        Evaluates the security contact configuration for a subscription to ensure compliance with
        notification requirements. Validates that:
        - At least 2 contacts are configured (via email addresses and/or subscription owners)
        - Alert notifications are configured for Medium or Low severity
        - Attack path notifications are configured for Medium or Low risk level

    .PARAMETER apiResponse
        The API response object from the securityContacts REST API containing notification settings.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .PARAMETER subscriptionId
        The Azure subscription ID being evaluated.

    .PARAMETER SubscriptionName
        The display name of the Azure subscription being evaluated.

    .OUTPUTS
        PSCustomObject - An object with properties: Comments (string) and isCompliant (boolean).
    #>
    param(
        [Parameter(Mandatory)]
        [pscustomobject] $apiResponse,
        [Parameter(Mandatory)]
        [hashtable] $msgTable,
        [Parameter (Mandatory)]
        [string] $subscriptionId,
        [Parameter(Mandatory)]
        [string] $SubscriptionName
    )

    $isCompliant = $true
    $Comments = ""

    $notificationSources = $apiResponse.properties.notificationsSources
    $notificationEmails  = $apiResponse.properties.emails
    $ownerRoles          = $apiResponse.properties.notificationsByRole.roles
    $ownerState          = $apiResponse.properties.notificationsByRole.state

    # Filter to get required notification types
    $alertNotification = $notificationSources | Where-Object { $_.sourceType -eq "Alert" -and $_.minimalSeverity -in @("Medium","Low") }
    $attackPathNotification = $notificationSources | Where-Object { $_.sourceType -eq "AttackPath" -and $_.minimalRiskLevel -in @("Medium","Low") }

    $emailCount = 0
    if ($notificationEmails) { $emailCount = ($notificationEmails -split ";").Count }

    $ownerConfigured = ($ownerState -eq "On") -and ($ownerRoles -contains "Owner")


    $ownerContactCount = 0
    if($ownerConfigured){
        #get the actual number of subscription owners
        try{
            $subsOwners = Get-AzRoleAssignment -RoleDefinitionName "Owner" -Scope "/subscriptions/$subscriptionId" -ErrorAction Stop
            if($null -ne $subsOwners ){
                $subsOwnerCount = $subsOwners.Count

                # If only 1 subscription owner, counts as 1 contact; if more than 1 owner, counts as 2 contacts
                if ($subsOwnerCount -eq 1) {
                    $ownerContactCount = 1
                    Write-Verbose "Subscription has 1 owner, counting as 1 contact"
                }
                elseif ($subsOwnerCount -gt 1) {
                    $ownerContactCount = 2
                    Write-Verbose "Subscription has $subsOwnerCount owners, counting as 2 contacts"
                }
                # If $subsOwnerCount is 0, $ownerContactCount remains 0
            }
        }
        catch{
            Write-Verbose "Failed to get owner count for subscription $SubscriptionName : $_"
            # If we can't get owner count, $ownerContactCount remains 0
        }
    }

    # Calculate effective contact count (emails + owner contact equivalent)
    $effectiveContactCount = $emailCount + $ownerContactCount

    # CONDITION: Check if there are at least 2 contacts total
    if ($effectiveContactCount -lt 2) {
        $isCompliant = $false
        $Comments = $msgTable.EmailsOrOwnerNotConfigured -f $SubscriptionName
    }
    
    if ($null -eq $alertNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AlertNotificationNotConfigured
    }

    if ($null -eq $attackPathNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AttackPathNotificationNotConfigured
    }

    if ($isCompliant) {
        $Comments = $msgTable.DefenderCompliant
    }

    return [PSCustomObject]@{
        Comments    = $Comments
        isCompliant = $isCompliant
    }
}


function Get-DefenderForCloudAlerts {
    param (
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [string]$itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $PsObject  = New-Object System.Collections.ArrayList
    $ErrorList = New-Object System.Collections.ArrayList

    # -------------------------
    # 1) Get enabled/disabled subscriptions
    # -------------------------
    try {
        $allSubs = Get-AzSubscription -ErrorAction Stop
        $subs = @($allSubs | Where-Object {$_.State -eq "Enabled"})
        $skippedSubs = @($allSubs | Where-Object {$_.State -ne "Enabled"})
    }
    catch {
        [void]$ErrorList.Add("Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_")
        throw "Error: Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_"
    }

    foreach ($skippedSub in $skippedSubs){
        $notEvaluatedResult = [PSCustomObject]@{
            SubscriptionName = $skippedSub.Name
            ComplianceStatus = $false
            Comments         = ''
            ItemName         = $ItemName
            ControlName      = $ControlName
            itsgcode         = $itsgcode
            ReportTime       = $ReportTime
        }
        $notEvaluatedResult = Set-SubscriptionNotEvaluatedStatus -Result $notEvaluatedResult -SubscriptionName $skippedSub.Name -msgTable $msgTable
        [void]$PsObject.Add($notEvaluatedResult) | Out-Null
    }

    # -------------------------
    # 2) ARG: resource counts (tenant-wide)
    # -------------------------
    $countsBySub = Get-ResourceCountsFromARG -ErrorList $ErrorList

    # -------------------------
    # 3) Define mapping: resourceType -> Defender pricing planName
    # -------------------------
    $TypeToPlanMap = @{
        # Compute
        "microsoft.compute/virtualmachines" = "VirtualMachines"

        # Storage
        "microsoft.storage/storageaccounts" = "StorageAccounts"

        # SQL PaaS
        "microsoft.sql/servers" = "SqlServers"
        "microsoft.sql/managedinstances" = "SqlServers"

        # SQL on VMs
        "microsoft.sqlvirtualmachine/sqlvirtualmachines" = "SqlServerVirtualMachines"

        # Key Vault
        "microsoft.keyvault/vaults" = "KeyVaults"

        # AKS
        "microsoft.containerservice/managedclusters" = "KubernetesService"

        # ACR
        "microsoft.containerregistry/registries" = "ContainerRegistry"

        # App Service
        "microsoft.web/sites" = "AppServices"

        # Cosmos
        "microsoft.documentdb/databaseaccounts" = "CosmosDbs"

        # OSS DBs
        "microsoft.dbforpostgresql/flexibleservers" = "OpenSourceRelationalDatabases"
        "microsoft.dbformysql/flexibleservers" = "OpenSourceRelationalDatabases"
    }

    foreach ($sub in $subs) {
        $subId   = [string]$sub.SubscriptionId
        $subName = [string]$sub.Name

        Write-Verbose "Evaluating subscription: $subName ($subId)"

        try { Set-AzContext -SubscriptionId $subId -ErrorAction Stop | Out-Null } catch {}

        # The PowerShell 7.6 migration also upgrades the Runtime Environment's Az modules.
        # Use their secure token path instead of depending on the older plain-text token response.
        # Reuse the secure ARM token for every REST check below; the Defender compliance logic is unchanged.
        # ErrorAction Stop makes token failures reach the catch block instead of allowing incomplete checks to continue.
        $accessToken = $null
        try {
            $azContext = Get-AzContext
            $accessToken = (Get-AzAccessToken -TenantId $azContext.Subscription.TenantId -AsSecureString -ErrorAction Stop).Token
        }
        catch {
            [void]$ErrorList.Add("Failed to get access token for $subName ($subId): $_")
            $accessToken = $null
        }

        # -------------------------
        # A) Subscription: Defender for Cloud coverage check
        # -------------------------
        $subRegisteredOk = $true
        $subRegisteredComment = $null
        if (-not $accessToken) {
            $subRegisteredOk = $false
            $subRegisteredComment = "Unable to evaluate Defender for Cloud registration (missing auth token)."
        }
        else{  
            # Check if any Defender for Cloud Standard plan is enabled/registered for the subscription
            Write-Verbose "Checking Defender for Cloud registration for subscription: $subName ($subId)"

            $regUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security?api-version=2020-01-01"
            try{
                $response = Invoke-RestMethod -Uri $regUri -Method Get -Authentication Bearer -Token $accessToken -ContentType 'application/json' -ErrorAction Stop
                
                $subRegisteredOk = if($response.registrationState -eq "Registered"){ $true } else { $false }
                if($subRegisteredOk){
                    # Further check if any Standard plan is enabled
                    $defenderPlans = Get-AzSecurityPricing
                    $defenderPlansStandard = $defenderPlans | Where-Object {$_.PricingTier -eq 'Standard'}
                    if ($defenderPlansStandard.Count -eq 0 -or $null -eq $defenderPlansStandard) {
                        $subRegisteredOk = $false
                    }
                }
            }
            catch{
                $subRegisteredOk = $false
                
            }
        }
        
        
        # If not registered, output non-compliant result and continue to next subscription
        if(-not $subRegisteredOk){
            Write-Host "Defender for Cloud (Microsoft.Security) is not registered for subscription $subName ($subId)."
            $Comments = if($subRegisteredComment){ $subRegisteredComment } else { $msgTable.NotAllSubsHaveDefenderPlans }

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $false
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }
            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"
            continue
        }
        else{
            Write-Host "Defender for Cloud (Microsoft.Security) is registered and has Standard plans for subscription $subName ($subId)."

            # -------------------------
            # B) Determine paid tier status (Defender CSPM / CWP)
            # -------------------------
            $pricingByPlan = @{}
            if ($accessToken) {
                $pricingByPlan = Get-DefenderPricingBySubscription -SubscriptionId $subId -AccessToken $accessToken -ErrorList $ErrorList
            }

            # Check if Defender CSPM (paid tier) is active
            $defenderCspmActive = $false
            if ($pricingByPlan.ContainsKey("CloudPosture") -and $pricingByPlan["CloudPosture"] -eq "Standard") {
                $defenderCspmActive = $true
            }

            # Check if any CWP plan is active (Standard tier)
            $cwpPlansActive = $false
            foreach ($plan in ($TypeToPlanMap.Values | Select-Object -Unique)) {
                if ($pricingByPlan.ContainsKey($plan) -and $pricingByPlan[$plan] -eq "Standard") {
                    $cwpPlansActive = $true
                    break
                }
            }

            $anyPaidTierActive = $defenderCspmActive -or $cwpPlansActive

            # -------------------------
            # Track if only free tier is active (informational)
            # -------------------------
            $freeTierInfoComment = $null
            if (-not $anyPaidTierActive) {
                Write-Verbose "Only Foundational CSPM (free tier) active for subscription $subName ($subId). Still checking notifications."
                $freeTierInfoComment = $msgTable.FoundationalCspmOnlyInfo
            }

            # -------------------------
            # C) Notifications / securityContacts check (ARM)
            # -------------------------
            $notifOk = $true
            $notifComment = $null

            if (-not $accessToken) {
                $notifOk = $false
                $notifComment = $msgTable.errorRetrievingNotifications
            }
            else {
                $restUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts/default?api-version=2023-12-01-preview"
                try {
                    $response = Invoke-RestMethod -Uri $restUri -Method Get -Authentication Bearer -Token $accessToken -ContentType 'application/json' -ErrorAction Stop
                    $r = Get-DFCAcheckComplianceStatus -apiResponse $response -msgTable $msgTable -subscriptionId $subId -SubscriptionName $subName
                    $notifOk = [bool]$r.isCompliant
                    $notifComment = $r.Comments
                }
                catch {
                    $restUri2 = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts?api-version=2023-12-01-preview"
                    try {
                        $response2 = Invoke-RestMethod -Uri $restUri2 -Method Get -Authentication Bearer -Token $accessToken -ContentType 'application/json' -ErrorAction Stop
                        if (-not $response2.value -or $response2.value.Count -eq 0) {
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                            Write-Verbose "Notification alert default security contact is not configured properly for $($subName)"
                        }
                        else {
                            # Keeping else condition open to formally identify this probable use case
                            Write-Verbose "Identify use case requirement"
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                        }
                    }
                    catch {
                        $notifOk = $false
                        $notifComment = $msgTable.errorRetrievingNotifications
                        [void]$ErrorList.Add("Error invoking securityContacts for $subName ($subId): $_")
                    }
                }
            }

            # -------------------------
            # D) CWP evaluation - informational only (does NOT affect compliance)
            # -------------------------
            $cwpInfoComment = $null
            if ($cwpPlansActive -and $accessToken) {
                $cov = Get-CwpCoverageForSubscription -SubscriptionId $subId -CountsBySub $countsBySub -TypeToPlanMap $TypeToPlanMap -PricingByPlan $pricingByPlan -msgTable $msgTable
                $cwpInfoComment = $msgTable.CwpInformational -f $cov.comment
                Write-Verbose "CWP informational for $subName : $cwpInfoComment"
            }

            # -------------------------
            # Final compliance (based on notification checks only; CWP is informational)
            # -------------------------
            $isCompliant = $notifOk

            $commentsList = New-Object System.Collections.Generic.List[string]
            if (-not $notifOk -and $notifComment) { $commentsList.Add($notifComment) | Out-Null }

            if ($isCompliant) {
                $commentsList.Add($msgTable.DefenderCompliant) | Out-Null
            }
            elseif ($commentsList.Count -eq 0) {
                $commentsList.Add($msgTable.DefenderEnabledNonCompliant) | Out-Null
            }

            # Append free-tier informational comment if present
            if ($freeTierInfoComment) { $commentsList.Add($freeTierInfoComment) | Out-Null }

            # Append CWP informational comment if present
            if ($cwpInfoComment) { $commentsList.Add($cwpInfoComment) | Out-Null }

            $Comments = ($commentsList | Where-Object { $_ } | Select-Object -Unique) -join " | "

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $isCompliant
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }

            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"

        }
    }

    return [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
}



function Get-ResourceCountsFromARG {
    <#
    .SYNOPSIS
        Retrieves resource counts by type across all subscriptions using Azure Resource Graph.

    .DESCRIPTION
        Queries Azure Resource Graph to count resources grouped by subscription ID and resource type.
        Returns a nested hashtable where the first key is the subscription ID and the second key is
        the resource type, with the count as the value. Supports pagination for large environments.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A nested hashtable with structure: countsBySub[subscriptionId][resourceType] = count
    #>
    param(
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable countsBySub[subscriptionId][resourceType] = count
    $countsBySub = @{}

    $query = @"
resources
| summarize c=count() by subscriptionId, type
"@

    try {
        Write-Verbose "ARG: counting resources by type across tenant..."
        $skipToken = $null
        $pageCount = 0

        do {
            $pageCount++
            if ($skipToken) {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -SkipToken $skipToken -ErrorAction Stop
            } else {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -ErrorAction Stop
            }

            foreach ($row in $results) {
                $sid = [string]$row.subscriptionId
                $rtype = [string]$row.type
                $cnt = [int]$row.c

                if (-not $countsBySub.ContainsKey($sid)) { $countsBySub[$sid] = @{} }
                $countsBySub[$sid][$rtype] = $cnt
            }

            $skipToken = $results.SkipToken
            Write-Verbose "ARG page $pageCount processed. HasSkipToken: $($null -ne $skipToken)"
        } while ($skipToken)

        return $countsBySub
    }
    catch {
        Write-Verbose "ARG resource count query failed: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARG resource count query failed: $_") }
        return @{}
    }
}

function Get-DefenderPricingBySubscription {
    <#
    .SYNOPSIS
        Retrieves Microsoft Defender for Cloud pricing tiers for a specific subscription.

    .DESCRIPTION
        Calls the Azure Management REST API to retrieve the Defender for Cloud pricing configuration
        for the specified subscription. Returns a hashtable mapping each Defender plan name to its
        pricing tier (e.g., 'Free' or 'Standard').

    .PARAMETER SubscriptionId
        The Azure subscription ID to query for Defender pricing information.

    .PARAMETER AuthHeader
        A hashtable containing the Authorization header with a valid Bearer token for Azure REST API calls.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A hashtable with structure: pricingByPlan[planName] = pricingTier
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [hashtable]$AuthHeader,
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable pricingByPlan[planName] = pricingTier
    $pricingByPlan = @{}

    # Use stable API version
    $uri = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Security/pricings?api-version=2023-01-01"

    try {
        $resp = Invoke-RestMethod -Uri $uri -Method Get -Headers $AuthHeader -ErrorAction Stop
        if ($resp -and $resp.value) {
            foreach ($p in $resp.value) {
                $name = [string]$p.name
                $tier = $null
                if ($p.properties -and $p.properties.pricingTier) { $tier = [string]$p.properties.pricingTier }
                if ($name) { $pricingByPlan[$name] = $tier }
            }
        }
    }
    catch {
        Write-Verbose "Failed to get Defender pricings for subscription ${SubscriptionId}: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARM Defender pricings failed for ${SubscriptionId}: $_") }
    }

    return $pricingByPlan
}



function Get-CwpCoverageForSubscription {
    <#
    .SYNOPSIS
        Evaluates Cloud Workload Protection (CWP) coverage for a subscription based on deployed resources.

    .DESCRIPTION
        Determines which Defender for Cloud plans are required based on the types of resources deployed
        in the subscription, then verifies that those plans are enabled at the 'Standard' tier.
        Returns a coverage assessment including required plans, missing plans, and compliance status.

    .PARAMETER SubscriptionId
        The Azure subscription ID to evaluate for CWP coverage.

    .PARAMETER CountsBySub
        A hashtable from Get-ResourceCountsFromARG containing resource counts by subscription and type.

    .PARAMETER TypeToPlanMap
        A hashtable mapping Azure resource types to their corresponding Defender for Cloud plan names.

    .PARAMETER PricingByPlan
        A hashtable from Get-DefenderPricingBySubscription containing plan names and their pricing tiers.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .OUTPUTS
        PSCustomObject - An object with properties: coverageOk, requiredPlans, missingPlans, and comment.
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [hashtable]$CountsBySub,      # output of Get-ResourceCountsFromARG
        [Parameter(Mandatory)]
        [hashtable]$TypeToPlanMap,    
        [Parameter(Mandatory)]
        [hashtable]$PricingByPlan,    # output of Get-DefenderPricingBySubscription
        [Parameter(Mandatory)]
        [hashtable]$msgTable
    )

    $requiredPlans = New-Object System.Collections.Generic.HashSet[string]
    $subCounts = $null
    if ($CountsBySub.ContainsKey($SubscriptionId)) { $subCounts = $CountsBySub[$SubscriptionId] }

    # Determine which plans are required based on resource presence
    foreach ($rtype in $TypeToPlanMap.Keys) {
        $cnt = 0
        if ($subCounts -and $subCounts.ContainsKey($rtype)) { $cnt = [int]$subCounts[$rtype] }

        if ($cnt -gt 0) {
            [void]$requiredPlans.Add([string]$TypeToPlanMap[$rtype])
        }
    }

    if ($requiredPlans.Count -eq 0) {
        return [PSCustomObject]@{
            coverageOk    = $true
            requiredPlans = @()
            missingPlans  = @()
            comment       = $msgTable.NoMappedResourcesOrMappingIncomplete
        }
    }

    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($plan in $requiredPlans) {
        $tier = $null
        if ($PricingByPlan.ContainsKey($plan)) { $tier = $PricingByPlan[$plan] }

        if (-not $tier -or ($tier.ToString().ToLower() -ne "standard")) {
            $missing.Add($plan) | Out-Null
        }
    }

    if ($missing.Count -gt 0) {
        return [PSCustomObject]@{
            coverageOk    = $false
            requiredPlans = @($requiredPlans)
            missingPlans  = @($missing)
            comment       = $msgTable.CwpPlansNotStandard -f ($missing -join ", ")
        }
    }

    return [PSCustomObject]@{
        coverageOk    = $true
        requiredPlans = @($requiredPlans)
        missingPlans  = @()
        comment       = $msgTable.CoverageOk
    }
}


function Get-DFCAcheckComplianceStatus {
        
    <#
    .SYNOPSIS
        Checks Defender for Cloud Alerts (DFCA) notification compliance for a subscription.

    .DESCRIPTION
        Evaluates the security contact configuration for a subscription to ensure compliance with
        notification requirements. Validates that:
        - At least 2 contacts are configured (via email addresses and/or subscription owners)
        - Alert notifications are configured for Medium or Low severity
        - Attack path notifications are configured for Medium or Low risk level

    .PARAMETER apiResponse
        The API response object from the securityContacts REST API containing notification settings.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .PARAMETER subscriptionId
        The Azure subscription ID being evaluated.

    .PARAMETER SubscriptionName
        The display name of the Azure subscription being evaluated.

    .OUTPUTS
        PSCustomObject - An object with properties: Comments (string) and isCompliant (boolean).
    #>
    param(
        [Parameter(Mandatory)]
        [pscustomobject] $apiResponse,
        [Parameter(Mandatory)]
        [hashtable] $msgTable,
        [Parameter (Mandatory)]
        [string] $subscriptionId,
        [Parameter(Mandatory)]
        [string] $SubscriptionName
    )

    $isCompliant = $true
    $Comments = ""

    $notificationSources = $apiResponse.properties.notificationsSources
    $notificationEmails  = $apiResponse.properties.emails
    $ownerRoles          = $apiResponse.properties.notificationsByRole.roles
    $ownerState          = $apiResponse.properties.notificationsByRole.state

    # Filter to get required notification types
    $alertNotification = $notificationSources | Where-Object { $_.sourceType -eq "Alert" -and $_.minimalSeverity -in @("Medium","Low") }
    $attackPathNotification = $notificationSources | Where-Object { $_.sourceType -eq "AttackPath" -and $_.minimalRiskLevel -in @("Medium","Low") }

    $emailCount = 0
    if ($notificationEmails) { $emailCount = ($notificationEmails -split ";").Count }

    $ownerConfigured = ($ownerState -eq "On") -and ($ownerRoles -contains "Owner")


    $ownerContactCount = 0
    if($ownerConfigured){
        #get the actual number of subscription owners
        try{
            $subsOwners = Get-AzRoleAssignment -RoleDefinitionName "Owner" -Scope "/subscriptions/$subscriptionId" -ErrorAction Stop
            if($null -ne $subsOwners ){
                $subsOwnerCount = $subsOwners.Count

                # If only 1 subscription owner, counts as 1 contact; if more than 1 owner, counts as 2 contacts
                if ($subsOwnerCount -eq 1) {
                    $ownerContactCount = 1
                    Write-Verbose "Subscription has 1 owner, counting as 1 contact"
                }
                elseif ($subsOwnerCount -gt 1) {
                    $ownerContactCount = 2
                    Write-Verbose "Subscription has $subsOwnerCount owners, counting as 2 contacts"
                }
                # If $subsOwnerCount is 0, $ownerContactCount remains 0
            }
        }
        catch{
            Write-Verbose "Failed to get owner count for subscription $SubscriptionName : $_"
            # If we can't get owner count, $ownerContactCount remains 0
        }
    }

    # Calculate effective contact count (emails + owner contact equivalent)
    $effectiveContactCount = $emailCount + $ownerContactCount

    # CONDITION: Check if there are at least 2 contacts total
    if ($effectiveContactCount -lt 2) {
        $isCompliant = $false
        $Comments = $msgTable.EmailsOrOwnerNotConfigured -f $SubscriptionName
    }
    
    if ($null -eq $alertNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AlertNotificationNotConfigured
    }

    if ($null -eq $attackPathNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AttackPathNotificationNotConfigured
    }

    if ($isCompliant) {
        $Comments = $msgTable.DefenderCompliant
    }

    return [PSCustomObject]@{
        Comments    = $Comments
        isCompliant = $isCompliant
    }
}


function Get-DefenderForCloudAlerts {
    param (
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [string]$itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $PsObject  = New-Object System.Collections.ArrayList
    $ErrorList = New-Object System.Collections.ArrayList

    # -------------------------
    # 1) Get enabled subscriptions
    # -------------------------
    try {
        $subs = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq "Enabled" }
    }
    catch {
        [void]$ErrorList.Add("Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_")
        throw "Error: Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_"
    }

    # -------------------------
    # 2) ARG: resource counts (tenant-wide)
    # -------------------------
    $countsBySub = Get-ResourceCountsFromARG -ErrorList $ErrorList

    # -------------------------
    # 3) Define mapping: resourceType -> Defender pricing planName
    # -------------------------
    $TypeToPlanMap = @{
        # Compute
        "microsoft.compute/virtualmachines" = "VirtualMachines"

        # Storage
        "microsoft.storage/storageaccounts" = "StorageAccounts"

        # SQL PaaS
        "microsoft.sql/servers" = "SqlServers"
        "microsoft.sql/managedinstances" = "SqlServers"

        # SQL on VMs
        "microsoft.sqlvirtualmachine/sqlvirtualmachines" = "SqlServerVirtualMachines"

        # Key Vault
        "microsoft.keyvault/vaults" = "KeyVaults"

        # AKS
        "microsoft.containerservice/managedclusters" = "KubernetesService"

        # ACR
        "microsoft.containerregistry/registries" = "ContainerRegistry"

        # App Service
        "microsoft.web/sites" = "AppServices"

        # Cosmos
        "microsoft.documentdb/databaseaccounts" = "CosmosDbs"

        # OSS DBs
        "microsoft.dbforpostgresql/flexibleservers" = "OpenSourceRelationalDatabases"
        "microsoft.dbformysql/flexibleservers" = "OpenSourceRelationalDatabases"
    }

    foreach ($sub in $subs) {
        $subId   = [string]$sub.SubscriptionId
        $subName = [string]$sub.Name

        Write-Verbose "Evaluating subscription: $subName ($subId)"

        try { Set-AzContext -SubscriptionId $subId -ErrorAction Stop | Out-Null } catch {}

        # Build auth header once per subscription context
        $authHeader = $null
        try {
            $azContext = Get-AzContext
            $token = Get-AzAccessToken -TenantId $azContext.Subscription.TenantId -ErrorAction Stop
            $authHeader = @{
                'Content-Type'  = 'application/json'
                'Authorization' = 'Bearer ' + $token.Token
            }
        }
        catch {
            [void]$ErrorList.Add("Failed to get access token for $subName ($subId): $_")
            $authHeader = $null
        }

        # -------------------------
        # A) Subscription: Defender for Cloud coverage check
        # -------------------------
        $subRegisteredOk = $true
        $subRegisteredComment = $null
        if (-not $authHeader) {
            $subRegisteredOk = $false
            $subRegisteredComment = "Unable to evaluate Defender for Cloud registration (missing auth token)."
        }
        else{  
            # Check if any Defender for Cloud Standard plan is enabled/registered for the subscription
            Write-Verbose "Checking Defender for Cloud registration for subscription: $subName ($subId)"

            $regUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security?api-version=2020-01-01"
            try{
                $response = Invoke-RestMethod -Uri $regUri -Method Get -Headers $authHeader -ErrorAction Stop
                
                $subRegisteredOk = if($response.registrationState -eq "Registered"){ $true } else { $false }
                if($subRegisteredOk){
                    # Further check if any Standard plan is enabled
                    $defenderPlans = Get-AzSecurityPricing
                    $defenderPlansStandard = $defenderPlans | Where-Object {$_.PricingTier -eq 'Standard'}
                    if ($defenderPlansStandard.Count -eq 0 -or $null -eq $defenderPlansStandard) {
                        $subRegisteredOk = $false
                    }
                }
            }
            catch{
                $subRegisteredOk = $false
                
            }
        }
        
        
        # If not registered, output non-compliant result and continue to next subscription
        if(-not $subRegisteredOk){
            Write-Host "Defender for Cloud (Microsoft.Security) is not registered for subscription $subName ($subId)."
            $Comments = if($subRegisteredComment){ $subRegisteredComment } else { $msgTable.NotAllSubsHaveDefenderPlans }

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $false
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }
            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"
            continue
        }
        else{
            Write-Host "Defender for Cloud (Microsoft.Security) is registered and has Standard plans for subscription $subName ($subId)."
            # -------------------------
            # B) CWP Coverage check (ARG counts + ARM pricing)
            # -------------------------
            $coverageOk = $true
            $coverageComment = $null

            if (-not $authHeader) {
                $coverageOk = $false
                $coverageComment = "Unable to evaluate CWP coverage (missing auth token)."
            }
            else {
                $pricingByPlan = Get-DefenderPricingBySubscription -SubscriptionId $subId -AuthHeader $authHeader -ErrorList $ErrorList
                $cov = Get-CwpCoverageForSubscription -SubscriptionId $subId -CountsBySub $countsBySub -TypeToPlanMap $TypeToPlanMap -PricingByPlan $pricingByPlan -msgTable $msgTable
                $coverageOk = [bool]$cov.coverageOk
                $coverageComment = $cov.comment
            }

            # -------------------------
            # C) Notifications / securityContacts check (ARM)
            # -------------------------
            $notifOk = $true
            $notifComment = $null

            if (-not $authHeader) {
                $notifOk = $false
                $notifComment = $msgTable.errorRetrievingNotifications
            }
            else {
                $restUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts/default?api-version=2023-12-01-preview"
                try {
                    $response = Invoke-RestMethod -Uri $restUri -Method Get -Headers $authHeader -ErrorAction Stop
                    $r = Get-DFCAcheckComplianceStatus -apiResponse $response -msgTable $msgTable -subscriptionId $subId -SubscriptionName $subName
                    $notifOk = [bool]$r.isCompliant
                    $notifComment = $r.Comments
                }
                catch {
                    $restUri2 = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts?api-version=2023-12-01-preview"
                    try {
                        $response2 = Invoke-RestMethod -Uri $restUri2 -Method Get -Headers $authHeader -ErrorAction Stop
                        if (-not $response2.value -or $response2.value.Count -eq 0) {
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                            Write-Verbose "Notification alert default security contact is not configured properly for $($subName)"
                        }
                        else {
                            # Keeping else condition open to formally identify this probable use case
                            Write-Verbose "Identify use case requirement"
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                        }
                    }
                    catch {
                        $notifOk = $false
                        $notifComment = $msgTable.errorRetrievingNotifications
                        [void]$ErrorList.Add("Error invoking securityContacts for $subName ($subId): $_")
                    }
                }
            }
            

            # -------------------------
            # Final compliance (both must pass)
            # -------------------------
            $isCompliant = ($coverageOk -and $notifOk )

            $commentsList = New-Object System.Collections.Generic.List[string]
            if (-not $coverageOk -and $coverageComment) { $commentsList.Add($coverageComment) | Out-Null }
            if (-not $notifOk -and $notifComment) { $commentsList.Add($notifComment) | Out-Null }

            if ($isCompliant) {
                $commentsList.Add($msgTable.DefenderCompliant) | Out-Null
            }
            elseif ($commentsList.Count -eq 0) {
                $commentsList.Add($msgTable.DefenderEnabledNonCompliant) | Out-Null
            }

            $Comments = ($commentsList | Where-Object { $_ } | Select-Object -Unique) -join " | "

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $isCompliant
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }

            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"

        }
    }

    return [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
}

# SIG # Begin signature block
# MIIwawYJKoZIhvcNAQcCoIIwXDCCMFgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAwNyooFw7R6NJX
# 4HmN5ZMzUOe3Zr7tprYR9xq6C9TB1aCCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxghwLMIIcBwIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# SBivcz5YYp3wFFxGQTEk8NQG2lpygittimM/PclBowcwDQYJKoZIhvcNAQEBBQAE
# ggIAWwNK0nE1vN2Y7Bn441O5vH5meOYgiquco0ACnx9eb/5n5uTP3xFy2txcSddL
# Eh9g4S+q0z/CZuXvzZrav/bsIDJWoGQC7vvGacLt3uQ957fi0ZBSMBm1TrLwhOg4
# k9LEdYPse4sXH1XpzWIBQRv29THlu12WmUTZJkA2K3QBM8IdSpFaEZe8AtoZnTZ0
# 92z32HOqiUKd/zdwwXyxVAV4iAf8TbX0vbhqY+6WUMvUPD57nV3CmjjV4XzuMRvq
# ULaHxaX1/PwP+Gw0YawvU1PVFluGUOMbGOM5tpzIN9Dru/H0u9TgUrBOrrG+mCYM
# I5URPAnznryggOCnZcugLupcHQlClrCZk40eOgV6WmwCuE0hjUOx6BiBb4n8O/Mq
# 4ruH4Y7dASmgaPaU3qW2me482I4qXaMX7UvGeYSHo62KZpkuajYi7PE5ipHUsCjV
# EsHmlm6Nkc606P6pGWRxB5Yju7sx33C2ShS2yRoUsogEQIMM7oUZ6kSvVYG3XC6+
# Ssmgw8aJTRxusCdLjQwhmgu+/0QWSbENOsjkH6S0z6Xqy6XAZjOpFK1Ml7P9HCb1
# 8y0+5KOH40vENul0nJNRjGfDl+fUPhHKmdg66Ufb/R6cc3ZBF4Dy3UqYX3KsYxBZ
# JaNXVs1h7RO+uPN0nDqYx9nCmvoSOxjr1U+OfUbqtB8bRLuhghjYMIIY1AYKKwYB
# BAGCNwMDATGCGMQwghjABgkqhkiG9w0BBwKgghixMIIYrQIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH4BgsqhkiG9w0BCRABBKCB6ASB5TCB4gIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCBni5Vkd4r5nWh0NE6jJr7/+p6K4wZn2O141x99/Gl4
# mAIVAINgVPm03sSigzKN4FVeRe5k58UWGA8yMDI2MDIxODIwMzQyOFqgdqR0MHIx
# CzAJBgNVBAYTAkdCMRcwFQYDVQQIEw5XZXN0IFlvcmtzaGlyZTEYMBYGA1UEChMP
# U2VjdGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0
# YW1waW5nIFNpZ25lciBSMzagghMEMIIGYjCCBMqgAwIBAgIRAKQpO24e3denNAiH
# rXpOtyQwDQYJKoZIhvcNAQEMBQAwVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBDQSBSMzYwHhcNMjUwMzI3MDAwMDAwWhcNMzYwMzIxMjM1OTU5WjByMQsw
# CQYDVQQGEwJHQjEXMBUGA1UECBMOV2VzdCBZb3Jrc2hpcmUxGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBTaWduZXIgUjM2MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# 04SV9G6kU3jyPRBLeBIHPNyUgVNnYayfsGOyYEXrn3+SkDYTLs1crcw/ol2swE1T
# zB2aR/5JIjKNf75QBha2Ddj+4NEPKDxHEd4dEn7RTWMcTIfm492TW22I8LfH+A7E
# hz0/safc6BbsNBzjHTt7FngNfhfJoYOrkugSaT8F0IzUh6VUwoHdYDpiln9dh0n0
# m545d5A5tJD92iFAIbKHQWGbCQNYplqpAFasHBn77OqW37P9BhOASdmjp3IijYiF
# dcA0WQIe60vzvrk0HG+iVcwVZjz+t5OcXGTcxqOAzk1frDNZ1aw8nFhGEvG0ktJQ
# knnJZE3D40GofV7O8WzgaAnZmoUn4PCpvH36vD4XaAF2CjiPsJWiY/j2xLsJuqx3
# JtuI4akH0MmGzlBUylhXvdNVXcjAuIEcEQKtOBR9lU4wXQpISrbOT8ux+96GzBq8
# TdbhoFcmYaOBZKlwPP7pOp5Mzx/UMhyBA93PQhiCdPfIVOCINsUY4U23p4KJ3F1H
# qP3H6Slw3lHACnLilGETXRg5X/Fp8G8qlG5Y+M49ZEGUp2bneRLZoyHTyynHvFIS
# pefhBCV0KdRZHPcuSL5OAGWnBjAlRtHvsMBrI3AAA0Tu1oGvPa/4yeeiAyu+9y3S
# LC98gDVbySnXnkujjhIh+oaatsk/oyf5R2vcxHahajMCAwEAAaOCAY4wggGKMB8G
# A1UdIwQYMBaAFF9Y7UwxeqJhQo1SgLqzYZcZojKbMB0GA1UdDgQWBBSIYYyhKjdk
# gShgoZsx0Iz9LALOTzAOBgNVHQ8BAf8EBAMCBsAwDAYDVR0TAQH/BAIwADAWBgNV
# HSUBAf8EDDAKBggrBgEFBQcDCDBKBgNVHSAEQzBBMDUGDCsGAQQBsjEBAgEDCDAl
# MCMGCCsGAQUFBwIBFhdodHRwczovL3NlY3RpZ28uY29tL0NQUzAIBgZngQwBBAIw
# SgYDVR0fBEMwQTA/oD2gO4Y5aHR0cDovL2NybC5zZWN0aWdvLmNvbS9TZWN0aWdv
# UHVibGljVGltZVN0YW1waW5nQ0FSMzYuY3JsMHoGCCsGAQUFBwEBBG4wbDBFBggr
# BgEFBQcwAoY5aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGlt
# ZVN0YW1waW5nQ0FSMzYuY3J0MCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0
# aWdvLmNvbTANBgkqhkiG9w0BAQwFAAOCAYEAAoE+pIZyUSH5ZakuPVKK4eWbzEsT
# RJOEjbIu6r7vmzXXLpJx4FyGmcqnFZoa1dzx3JrUCrdG5b//LfAxOGy9Ph9JtrYC
# hJaVHrusDh9NgYwiGDOhyyJ2zRy3+kdqhwtUlLCdNjFjakTSE+hkC9F5ty1uxOoQ
# 2ZkfI5WM4WXA3ZHcNHB4V42zi7Jk3ktEnkSdViVxM6rduXW0jmmiu71ZpBFZDh7K
# dens+PQXPgMqvzodgQJEkxaION5XRCoBxAwWwiMm2thPDuZTzWp/gUFzi7izCmEt
# 4pE3Kf0MOt3ccgwn4Kl2FIcQaV55nkjv1gODcHcD9+ZVjYZoyKTVWb4VqMQy/j8Q
# 3aaYd/jOQ66Fhk3NWbg2tYl5jhQCuIsE55Vg4N0DUbEWvXJxtxQQaVR5xzhEI+Bj
# JKzh3TQ026JxHhr2fuJ0mV68AluFr9qshgwS5SpN5FFtaSEnAwqZv3IS+mlG50rK
# 7W3qXbWwi4hmpylUfygtYLEdLQukNEX1jiOKMIIGFDCCA/ygAwIBAgIQeiOu2lNp
# lg+RyD5c9MfjPzANBgkqhkiG9w0BAQwFADBXMQswCQYDVQQGEwJHQjEYMBYGA1UE
# ChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1l
# IFN0YW1waW5nIFJvb3QgUjQ2MB4XDTIxMDMyMjAwMDAwMFoXDTM2MDMyMTIzNTk1
# OVowVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoG
# A1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSMzYwggGiMA0G
# CSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQDNmNhDQatugivs9jN+JjTkiYzT7yIS
# gFQ+7yavjA6Bg+OiIjPm/N/t3nC7wYUrUlY3mFyI32t2o6Ft3EtxJXCc5MmZQZ8A
# xCbh5c6WzeJDB9qkQVa46xiYEpc81KnBkAWgsaXnLURoYZzksHIzzCNxtIXnb9nj
# ZholGw9djnjkTdAA83abEOHQ4ujOGIaBhPXG2NdV8TNgFWZ9BojlAvflxNMCOwkC
# nzlH4oCw5+4v1nssWeN1y4+RlaOywwRMUi54fr2vFsU5QPrgb6tSjvEUh1EC4M29
# YGy/SIYM8ZpHadmVjbi3Pl8hJiTWw9jiCKv31pcAaeijS9fc6R7DgyyLIGflmdQM
# wrNRxCulVq8ZpysiSYNi79tw5RHWZUEhnRfs/hsp/fwkXsynu1jcsUX+HuG8FLa2
# BNheUPtOcgw+vHJcJ8HnJCrcUWhdFczf8O+pDiyGhVYX+bDDP3GhGS7TmKmGnbZ9
# N+MpEhWmbiAVPbgkqykSkzyYVr15OApZYK8CAwEAAaOCAVwwggFYMB8GA1UdIwQY
# MBaAFPZ3at0//QET/xahbIICL9AKPRQlMB0GA1UdDgQWBBRfWO1MMXqiYUKNUoC6
# s2GXGaIymzAOBgNVHQ8BAf8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBADATBgNV
# HSUEDDAKBggrBgEFBQcDCDARBgNVHSAECjAIMAYGBFUdIAAwTAYDVR0fBEUwQzBB
# oD+gPYY7aHR0cDovL2NybC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0
# YW1waW5nUm9vdFI0Ni5jcmwwfAYIKwYBBQUHAQEEcDBuMEcGCCsGAQUFBzAChjto
# dHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3RhbXBpbmdS
# b290UjQ2LnA3YzAjBggrBgEFBQcwAYYXaHR0cDovL29jc3Auc2VjdGlnby5jb20w
# DQYJKoZIhvcNAQEMBQADggIBABLXeyCtDjVYDJ6BHSVY/UwtZ3Svx2ImIfZVVGnG
# oUaGdltoX4hDskBMZx5NY5L6SCcwDMZhHOmbyMhyOVJDwm1yrKYqGDHWzpwVkFJ+
# 996jKKAXyIIaUf5JVKjccev3w16mNIUlNTkpJEor7edVJZiRJVCAmWAaHcw9zP0h
# Y3gj+fWp8MbOocI9Zn78xvm9XKGBp6rEs9sEiq/pwzvg2/KjXE2yWUQIkms6+ysl
# CRqNXPjEnBnxuUB1fm6bPAV+Tsr/Qrd+mOCJemo06ldon4pJFbQd0TQVIMLv5kok
# lInHvyaf6vATJP4DfPtKzSBPkKlOtyaFTAjD2Nu+di5hErEVVaMqSVbfPzd6kNXO
# hYm23EWm6N2s2ZHCHVhlUgHaC4ACMRCgXjYfQEDtYEK54dUwPJXV7icz0rgCzs9V
# I29DwsjVZFpO4ZIVR33LwXyPDbYFkLqYmgHjR3tKVkhh9qKV2WCmBuC27pIOx6TY
# vyqiYbntinmpOqh/QPAnhDgexKG9GX/n1PggkGi9HCapZp8fRwg8RftwS21Ln61e
# uBG0yONM6noD2XQPrFwpm3GcuqJMf0o8LLrFkSLRQNwxPDDkWXhW+gZswbaiie5f
# d/W2ygcto78XCSPfFWveUOSZ5SqK95tBO8aTHmEa4lpJVD7HrTEn9jb1EGvxOb1c
# nn0CMIIGgjCCBGqgAwIBAgIQNsKwvXwbOuejs902y8l1aDANBgkqhkiG9w0BAQwF
# ADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcT
# C0plcnNleSBDaXR5MR4wHAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAs
# BgNVBAMTJVVTRVJUcnVzdCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwHhcN
# MjEwMzIyMDAwMDAwWhcNMzgwMTE4MjM1OTU5WjBXMQswCQYDVQQGEwJHQjEYMBYG
# A1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQDEyVTZWN0aWdvIFB1YmxpYyBU
# aW1lIFN0YW1waW5nIFJvb3QgUjQ2MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAiJ3YuUVnnR3d6LkmgZpUVMB8SQWbzFoVD9mUEES0QUCBdxSZqdTkdizI
# CFNeINCSJS+lV1ipnW5ihkQyC0cRLWXUJzodqpnMRs46npiJPHrfLBOifjfhpdXJ
# 2aHHsPHggGsCi7uE0awqKggE/LkYw3sqaBia67h/3awoqNvGqiFRJ+OTWYmUCO2G
# AXsePHi+/JUNAax3kpqstbl3vcTdOGhtKShvZIvjwulRH87rbukNyHGWX5tNK/WA
# BKf+Gnoi4cmisS7oSimgHUI0Wn/4elNd40BFdSZ1EwpuddZ+Wr7+Dfo0lcHflm/F
# DDrOJ3rWqauUP8hsokDoI7D/yUVI9DAE/WK3Jl3C4LKwIpn1mNzMyptRwsXKrop0
# 6m7NUNHdlTDEMovXAIDGAvYynPt5lutv8lZeI5w3MOlCybAZDpK3Dy1MKo+6aEtE
# 9vtiTMzz/o2dYfdP0KWZwZIXbYsTIlg1YIetCpi5s14qiXOpRsKqFKqav9R1R5vj
# 3NgevsAsvxsAnI8Oa5s2oy25qhsoBIGo/zi6GpxFj+mOdh35Xn91y72J4RGOJEoq
# zEIbW3q0b2iPuWLA911cRxgY5SJYubvjay3nSMbBPPFsyl6mY4/WYucmyS9lo3l7
# jk27MAe145GWxK4O3m3gEFEIkv7kRmefDR7Oe2T1HxAnICQvr9sCAwEAAaOCARYw
# ggESMB8GA1UdIwQYMBaAFFN5v1qqK0rPVIDh2JvAnfKyA2bLMB0GA1UdDgQWBBT2
# d2rdP/0BE/8WoWyCAi/QCj0UJTAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUw
# AwEB/zATBgNVHSUEDDAKBggrBgEFBQcDCDARBgNVHSAECjAIMAYGBFUdIAAwUAYD
# VR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC51c2VydHJ1c3QuY29tL1VTRVJUcnVz
# dFJTQUNlcnRpZmljYXRpb25BdXRob3JpdHkuY3JsMDUGCCsGAQUFBwEBBCkwJzAl
# BggrBgEFBQcwAYYZaHR0cDovL29jc3AudXNlcnRydXN0LmNvbTANBgkqhkiG9w0B
# AQwFAAOCAgEADr5lQe1oRLjlocXUEYfktzsljOt+2sgXke3Y8UPEooU5y39rAARa
# AdAxUeiX1ktLJ3+lgxtoLQhn5cFb3GF2SSZRX8ptQ6IvuD3wz/LNHKpQ5nX8hjsD
# LRhsyeIiJsms9yAWnvdYOdEMq1W61KE9JlBkB20XBee6JaXx4UBErc+YuoSb1SxV
# f7nkNtUjPfcxuFtrQdRMRi/fInV/AobE8Gw/8yBMQKKaHt5eia8ybT8Y/Ffa6HAJ
# yz9gvEOcF1VWXG8OMeM7Vy7Bs6mSIkYeYtddU1ux1dQLbEGur18ut97wgGwDiGin
# CwKPyFO7ApcmVJOtlw9FVJxw/mL1TbyBns4zOgkaXFnnfzg4qbSvnrwyj1NiurMp
# 4pmAWjR+Pb/SIduPnmFzbSN/G8reZCL4fvGlvPFk4Uab/JVCSmj59+/mB2Gn6G/U
# YOy8k60mKcmaAZsEVkhOFuoj4we8CYyaR9vd9PGZKSinaZIkvVjbH/3nlLb0a7SB
# IkiRzfPfS9T+JesylbHa1LtRV9U/7m0q7Ma2CQ/t392ioOssXW7oKLdOmMBl14su
# VFBmbzrt5V5cQPnwtd3UOTpS9oCG+ZZheiIvPgkDmA8FzPsnfXW5qHELB43ET7HH
# FHeRPRYrMBKjkb8/IN7Po0d0hQoF4TeMM+zYAJzoKQnVKOLg8pZVPT8xggSSMIIE
# jgIBATBqMFUxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQx
# LDAqBgNVBAMTI1NlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgQ0EgUjM2AhEA
# pCk7bh7d16c0CIetek63JDANBglghkgBZQMEAgIFAKCCAfkwGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yNjAyMTgyMDM0MjhaMD8G
# CSqGSIb3DQEJBDEyBDBGqsnwbHVeaf94LBvWYmaPCDwDkL1a+NOrhHxr2zQ+Di7P
# k+thkmzEJTygJVyJhhIwggF6BgsqhkiG9w0BCRACDDGCAWkwggFlMIIBYTAWBBQ4
# yRSBEES03GY+k9R0S4FBhqm1sTCBhwQUxq5U5HiG8Xw9VRJIjGnDSnr5wt0wbzBb
# pFkwVzELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEuMCwG
# A1UEAxMlU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBSb290IFI0NgIQeiOu
# 2lNplg+RyD5c9MfjPzCBvAQUhT1jLZOCgmF80JA1xJHeksFC2scwgaMwgY6kgYsw
# gYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtK
# ZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYD
# VQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5AhA2wrC9
# fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBAQUABIICAEMlfZ0IoIuL8nv4MP2m3OKS
# JXZ39SZKLxk5oxbisAcERRgquT5ZWeKxGdS3oM9oV0VbHq2gHmvHdx7Cx4bZIQ/3
# YOmYC0w68zNQQNk+7tCs9p5XOezCcxjTCWXw+XrXTc8scIzvdFzHsSVAO0ck/hb1
# /66SJnr+g/muxCcZ65MfJHz+Jk/WK84HTKOqBd3zWaL4pRljXeDyXFMEf5J02Oqi
# IYb9XjwItXtkPlSXuPbN92MoEy9ng872RWELnuRwG+HYtK07D8trpllf7V/+mX/6
# qZWStfnH7mr82xG7Lj4xpo2q6jz4fXfP90d62EL7keJRBNl0oSEiWlWj91UfYTj+
# nToI5E5bo5fRzorfGy2T1ieFnH6QGdWA0evPDp5vNGa/7MJfWZm4UIg8CT4i3Ph6
# RoVi3wM/Br6F24rHOprfGVPCHHOG7Tzi8z1z188Cv1misbUd1Ob/YAfEMCt4fRwS
# wb7s6RgR4nI40F+UUxrPhWRwumCsV0GN4EjxPTAcHu6vGQA+zXVTeXf09D8k2+Ei
# vk5zksHxEWnk1LEen7fLeI965ChWvsrrw1faUr8Vw6Unu4HSo+U+x2eU3S81fcn8
# GNeT37JqczNZELvwildrcCii3gcO7jwZVQuTu+aa5E9FqXR9bO8B9iBNFPOKiS7u
# mvye9Q7NI2F7ja6qxE0e
# SIG # End signature block

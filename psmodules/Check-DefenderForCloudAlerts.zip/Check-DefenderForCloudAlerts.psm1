

function Get-ResourceCountsFromARG {
    <#
    .SYNOPSIS
        Retrieves resource counts by type across all subscriptions using Azure Resource Graph.

    .DESCRIPTION
        Queries Azure Resource Graph to count resources grouped by subscription ID and resource type.
        Returns a nested hashtable where the first key is the subscription ID and the second key is
        the resource type, with the count as the value. Supports pagination for large environments.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A nested hashtable with structure: countsBySub[subscriptionId][resourceType] = count
    #>
    param(
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable countsBySub[subscriptionId][resourceType] = count
    $countsBySub = @{}

    $query = @"
resources
| summarize c=count() by subscriptionId, type
"@

    try {
        Write-Verbose "ARG: counting resources by type across tenant..."
        $skipToken = $null
        $pageCount = 0

        do {
            $pageCount++
            if ($skipToken) {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -SkipToken $skipToken -ErrorAction Stop
            } else {
                $results = Search-AzGraph -UseTenantScope -Query $query -First 1000 -ErrorAction Stop
            }

            foreach ($row in $results) {
                $sid = [string]$row.subscriptionId
                $rtype = [string]$row.type
                $cnt = [int]$row.c

                if (-not $countsBySub.ContainsKey($sid)) { $countsBySub[$sid] = @{} }
                $countsBySub[$sid][$rtype] = $cnt
            }

            $skipToken = $results.SkipToken
            Write-Verbose "ARG page $pageCount processed. HasSkipToken: $($null -ne $skipToken)"
        } while ($skipToken)

        return $countsBySub
    }
    catch {
        Write-Verbose "ARG resource count query failed: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARG resource count query failed: $_") }
        return @{}
    }
}

function Get-DefenderPricingBySubscription {
    <#
    .SYNOPSIS
        Retrieves Microsoft Defender for Cloud pricing tiers for a specific subscription.

    .DESCRIPTION
        Calls the Azure Management REST API to retrieve the Defender for Cloud pricing configuration
        for the specified subscription. Returns a hashtable mapping each Defender plan name to its
        pricing tier (e.g., 'Free' or 'Standard').

    .PARAMETER SubscriptionId
        The Azure subscription ID to query for Defender pricing information.

    .PARAMETER AuthHeader
        A hashtable containing the Authorization header with a valid Bearer token for Azure REST API calls.

    .PARAMETER ErrorList
        An optional ArrayList to collect error messages encountered during execution.

    .OUTPUTS
        Hashtable - A hashtable with structure: pricingByPlan[planName] = pricingTier
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [hashtable]$AuthHeader,
        [AllowEmptyCollection()]
        [System.Collections.ArrayList]$ErrorList
    )

    # Returns: hashtable pricingByPlan[planName] = pricingTier
    $pricingByPlan = @{}

    # Use stable API version
    $uri = "https://management.azure.com/subscriptions/$SubscriptionId/providers/Microsoft.Security/pricings?api-version=2023-01-01"

    try {
        $resp = Invoke-RestMethod -Uri $uri -Method Get -Headers $AuthHeader -ErrorAction Stop
        if ($resp -and $resp.value) {
            foreach ($p in $resp.value) {
                $name = [string]$p.name
                $tier = $null
                if ($p.properties -and $p.properties.pricingTier) { $tier = [string]$p.properties.pricingTier }
                if ($name) { $pricingByPlan[$name] = $tier }
            }
        }
    }
    catch {
        Write-Verbose "Failed to get Defender pricings for subscription ${SubscriptionId}: $_"
        if ($ErrorList) { [void]$ErrorList.Add("ARM Defender pricings failed for ${SubscriptionId}: $_") }
    }

    return $pricingByPlan
}



function Get-CwpCoverageForSubscription {
    <#
    .SYNOPSIS
        Evaluates Cloud Workload Protection (CWP) coverage for a subscription based on deployed resources.

    .DESCRIPTION
        Determines which Defender for Cloud plans are required based on the types of resources deployed
        in the subscription, then verifies that those plans are enabled at the 'Standard' tier.
        Returns a coverage assessment including required plans, missing plans, and compliance status.

    .PARAMETER SubscriptionId
        The Azure subscription ID to evaluate for CWP coverage.

    .PARAMETER CountsBySub
        A hashtable from Get-ResourceCountsFromARG containing resource counts by subscription and type.

    .PARAMETER TypeToPlanMap
        A hashtable mapping Azure resource types to their corresponding Defender for Cloud plan names.

    .PARAMETER PricingByPlan
        A hashtable from Get-DefenderPricingBySubscription containing plan names and their pricing tiers.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .OUTPUTS
        PSCustomObject - An object with properties: coverageOk, requiredPlans, missingPlans, and comment.
    #>
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,
        [Parameter(Mandatory)]
        [hashtable]$CountsBySub,      # output of Get-ResourceCountsFromARG
        [Parameter(Mandatory)]
        [hashtable]$TypeToPlanMap,    
        [Parameter(Mandatory)]
        [hashtable]$PricingByPlan,    # output of Get-DefenderPricingBySubscription
        [Parameter(Mandatory)]
        [hashtable]$msgTable
    )

    $requiredPlans = New-Object System.Collections.Generic.HashSet[string]
    $subCounts = $null
    if ($CountsBySub.ContainsKey($SubscriptionId)) { $subCounts = $CountsBySub[$SubscriptionId] }

    # Determine which plans are required based on resource presence
    foreach ($rtype in $TypeToPlanMap.Keys) {
        $cnt = 0
        if ($subCounts -and $subCounts.ContainsKey($rtype)) { $cnt = [int]$subCounts[$rtype] }

        if ($cnt -gt 0) {
            [void]$requiredPlans.Add([string]$TypeToPlanMap[$rtype])
        }
    }

    if ($requiredPlans.Count -eq 0) {
        return [PSCustomObject]@{
            coverageOk    = $true
            requiredPlans = @()
            missingPlans  = @()
            comment       = $msgTable.NoMappedResourcesOrMappingIncomplete
        }
    }

    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($plan in $requiredPlans) {
        $tier = $null
        if ($PricingByPlan.ContainsKey($plan)) { $tier = $PricingByPlan[$plan] }

        if (-not $tier -or ($tier.ToString().ToLower() -ne "standard")) {
            $missing.Add($plan) | Out-Null
        }
    }

    if ($missing.Count -gt 0) {
        return [PSCustomObject]@{
            coverageOk    = $false
            requiredPlans = @($requiredPlans)
            missingPlans  = @($missing)
            comment       = $msgTable.CwpPlansNotStandard -f ($missing -join ", ")
        }
    }

    return [PSCustomObject]@{
        coverageOk    = $true
        requiredPlans = @($requiredPlans)
        missingPlans  = @()
        comment       = $msgTable.CoverageOk
    }
}


function Get-DFCAcheckComplianceStatus {
        
    <#
    .SYNOPSIS
        Checks Defender for Cloud Alerts (DFCA) notification compliance for a subscription.

    .DESCRIPTION
        Evaluates the security contact configuration for a subscription to ensure compliance with
        notification requirements. Validates that:
        - At least 2 contacts are configured (via email addresses and/or subscription owners)
        - Alert notifications are configured for Medium or Low severity
        - Attack path notifications are configured for Medium or Low risk level

    .PARAMETER apiResponse
        The API response object from the securityContacts REST API containing notification settings.

    .PARAMETER msgTable
        A hashtable containing localized message strings for compliance comments.

    .PARAMETER subscriptionId
        The Azure subscription ID being evaluated.

    .PARAMETER SubscriptionName
        The display name of the Azure subscription being evaluated.

    .OUTPUTS
        PSCustomObject - An object with properties: Comments (string) and isCompliant (boolean).
    #>
    param(
        [Parameter(Mandatory)]
        [pscustomobject] $apiResponse,
        [Parameter(Mandatory)]
        [hashtable] $msgTable,
        [Parameter (Mandatory)]
        [string] $subscriptionId,
        [Parameter(Mandatory)]
        [string] $SubscriptionName
    )

    $isCompliant = $true
    $Comments = ""

    $notificationSources = $apiResponse.properties.notificationsSources
    $notificationEmails  = $apiResponse.properties.emails
    $ownerRoles          = $apiResponse.properties.notificationsByRole.roles
    $ownerState          = $apiResponse.properties.notificationsByRole.state

    # Filter to get required notification types
    $alertNotification = $notificationSources | Where-Object { $_.sourceType -eq "Alert" -and $_.minimalSeverity -in @("Medium","Low") }
    $attackPathNotification = $notificationSources | Where-Object { $_.sourceType -eq "AttackPath" -and $_.minimalRiskLevel -in @("Medium","Low") }

    $emailCount = 0
    if ($notificationEmails) { $emailCount = ($notificationEmails -split ";").Count }

    $ownerConfigured = ($ownerState -eq "On") -and ($ownerRoles -contains "Owner")


    $ownerContactCount = 0
    if($ownerConfigured){
        #get the actual number of subscription owners
        try{
            $subsOwners = Get-AzRoleAssignment -RoleDefinitionName "Owner" -Scope "/subscriptions/$subscriptionId" -ErrorAction Stop
            if($null -ne $subsOwners ){
                $subsOwnerCount = $subsOwners.Count

                # If only 1 subscription owner, counts as 1 contact; if more than 1 owner, counts as 2 contacts
                if ($subsOwnerCount -eq 1) {
                    $ownerContactCount = 1
                    Write-Verbose "Subscription has 1 owner, counting as 1 contact"
                }
                elseif ($subsOwnerCount -gt 1) {
                    $ownerContactCount = 2
                    Write-Verbose "Subscription has $subsOwnerCount owners, counting as 2 contacts"
                }
                # If $subsOwnerCount is 0, $ownerContactCount remains 0
            }
        }
        catch{
            Write-Verbose "Failed to get owner count for subscription $SubscriptionName : $_"
            # If we can't get owner count, $ownerContactCount remains 0
        }
    }

    # Calculate effective contact count (emails + owner contact equivalent)
    $effectiveContactCount = $emailCount + $ownerContactCount

    # CONDITION: Check if there are at least 2 contacts total
    if ($effectiveContactCount -lt 2) {
        $isCompliant = $false
        $Comments = $msgTable.EmailsOrOwnerNotConfigured -f $SubscriptionName
    }
    
    if ($null -eq $alertNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AlertNotificationNotConfigured
    }

    if ($null -eq $attackPathNotification) {
        $isCompliant = $false
        $Comments = $msgTable.AttackPathNotificationNotConfigured
    }

    if ($isCompliant) {
        $Comments = $msgTable.DefenderCompliant
    }

    return [PSCustomObject]@{
        Comments    = $Comments
        isCompliant = $isCompliant
    }
}


function Get-DefenderForCloudAlerts {
    param (
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [string]$itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [string] $CloudUsageProfiles = "3",
        [string] $ModuleProfiles,
        [switch] $EnableMultiCloudProfiles
    )

    $PsObject  = New-Object System.Collections.ArrayList
    $ErrorList = New-Object System.Collections.ArrayList

    # -------------------------
    # 1) Get enabled subscriptions
    # -------------------------
    try {
        $subs = Get-AzSubscription -ErrorAction Stop | Where-Object { $_.State -eq "Enabled" }
    }
    catch {
        [void]$ErrorList.Add("Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_")
        throw "Error: Failed Get-AzSubscription. Verify Az.Resources + permissions. Error: $_"
    }

    # -------------------------
    # 2) ARG: resource counts (tenant-wide)
    # -------------------------
    $countsBySub = Get-ResourceCountsFromARG -ErrorList $ErrorList

    # -------------------------
    # 3) Define mapping: resourceType -> Defender pricing planName
    # -------------------------
    $TypeToPlanMap = @{
        # Compute
        "microsoft.compute/virtualmachines" = "VirtualMachines"

        # Storage
        "microsoft.storage/storageaccounts" = "StorageAccounts"

        # SQL PaaS
        "microsoft.sql/servers" = "SqlServers"
        "microsoft.sql/managedinstances" = "SqlServers"

        # SQL on VMs
        "microsoft.sqlvirtualmachine/sqlvirtualmachines" = "SqlServerVirtualMachines"

        # Key Vault
        "microsoft.keyvault/vaults" = "KeyVaults"

        # AKS
        "microsoft.containerservice/managedclusters" = "KubernetesService"

        # ACR
        "microsoft.containerregistry/registries" = "ContainerRegistry"

        # App Service
        "microsoft.web/sites" = "AppServices"

        # Cosmos
        "microsoft.documentdb/databaseaccounts" = "CosmosDbs"

        # OSS DBs
        "microsoft.dbforpostgresql/flexibleservers" = "OpenSourceRelationalDatabases"
        "microsoft.dbformysql/flexibleservers" = "OpenSourceRelationalDatabases"
    }

    foreach ($sub in $subs) {
        $subId   = [string]$sub.SubscriptionId
        $subName = [string]$sub.Name

        Write-Verbose "Evaluating subscription: $subName ($subId)"

        try { Set-AzContext -SubscriptionId $subId -ErrorAction Stop | Out-Null } catch {}

        # Build auth header once per subscription context
        $authHeader = $null
        try {
            $azContext = Get-AzContext
            $token = Get-AzAccessToken -TenantId $azContext.Subscription.TenantId -ErrorAction Stop
            $authHeader = @{
                'Content-Type'  = 'application/json'
                'Authorization' = 'Bearer ' + $token.Token
            }
        }
        catch {
            [void]$ErrorList.Add("Failed to get access token for $subName ($subId): $_")
            $authHeader = $null
        }

        # -------------------------
        # A) Subscription: Defender for Cloud coverage check
        # -------------------------
        $subRegisteredOk = $true
        $subRegisteredComment = $null
        if (-not $authHeader) {
            $subRegisteredOk = $false
            $subRegisteredComment = "Unable to evaluate Defender for Cloud registration (missing auth token)."
        }
        else{  
            # Check if any Defender for Cloud Standard plan is enabled/registered for the subscription
            Write-Verbose "Checking Defender for Cloud registration for subscription: $subName ($subId)"

            $regUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security?api-version=2020-01-01"
            try{
                $response = Invoke-RestMethod -Uri $regUri -Method Get -Headers $authHeader -ErrorAction Stop
                
                $subRegisteredOk = if($response.registrationState -eq "Registered"){ $true } else { $false }
                if($subRegisteredOk){
                    # Further check if any Standard plan is enabled
                    $defenderPlans = Get-AzSecurityPricing
                    $defenderPlansStandard = $defenderPlans | Where-Object {$_.PricingTier -eq 'Standard'}
                    if ($defenderPlansStandard.Count -eq 0 -or $null -eq $defenderPlansStandard) {
                        $subRegisteredOk = $false
                    }
                }
            }
            catch{
                $subRegisteredOk = $false
                
            }
        }
        
        
        # If not registered, output non-compliant result and continue to next subscription
        if(-not $subRegisteredOk){
            Write-Host "Defender for Cloud (Microsoft.Security) is not registered for subscription $subName ($subId)."
            $Comments = if($subRegisteredComment){ $subRegisteredComment } else { $msgTable.NotAllSubsHaveDefenderPlans }

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $false
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }
            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"
            continue
        }
        else{
            Write-Host "Defender for Cloud (Microsoft.Security) is registered and has Standard plans for subscription $subName ($subId)."

            # -------------------------
            # B) Determine paid tier status (Defender CSPM / CWP)
            # -------------------------
            $pricingByPlan = @{}
            if ($authHeader) {
                $pricingByPlan = Get-DefenderPricingBySubscription -SubscriptionId $subId -AuthHeader $authHeader -ErrorList $ErrorList
            }

            # Check if Defender CSPM (paid tier) is active
            $defenderCspmActive = $false
            if ($pricingByPlan.ContainsKey("CloudPosture") -and $pricingByPlan["CloudPosture"] -eq "Standard") {
                $defenderCspmActive = $true
            }

            # Check if any CWP plan is active (Standard tier)
            $cwpPlansActive = $false
            foreach ($plan in ($TypeToPlanMap.Values | Select-Object -Unique)) {
                if ($pricingByPlan.ContainsKey($plan) -and $pricingByPlan[$plan] -eq "Standard") {
                    $cwpPlansActive = $true
                    break
                }
            }

            $anyPaidTierActive = $defenderCspmActive -or $cwpPlansActive

            # -------------------------
            # Track if only free tier is active (informational)
            # -------------------------
            $freeTierInfoComment = $null
            if (-not $anyPaidTierActive) {
                Write-Verbose "Only Foundational CSPM (free tier) active for subscription $subName ($subId). Still checking notifications."
                $freeTierInfoComment = $msgTable.FoundationalCspmOnlyInfo
            }

            # -------------------------
            # C) Notifications / securityContacts check (ARM)
            # -------------------------
            $notifOk = $true
            $notifComment = $null

            if (-not $authHeader) {
                $notifOk = $false
                $notifComment = $msgTable.errorRetrievingNotifications
            }
            else {
                $restUri = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts/default?api-version=2023-12-01-preview"
                try {
                    $response = Invoke-RestMethod -Uri $restUri -Method Get -Headers $authHeader -ErrorAction Stop
                    $r = Get-DFCAcheckComplianceStatus -apiResponse $response -msgTable $msgTable -subscriptionId $subId -SubscriptionName $subName
                    $notifOk = [bool]$r.isCompliant
                    $notifComment = $r.Comments
                }
                catch {
                    $restUri2 = "https://management.azure.com/subscriptions/$subId/providers/Microsoft.Security/securityContacts?api-version=2023-12-01-preview"
                    try {
                        $response2 = Invoke-RestMethod -Uri $restUri2 -Method Get -Headers $authHeader -ErrorAction Stop
                        if (-not $response2.value -or $response2.value.Count -eq 0) {
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                            Write-Verbose "Notification alert default security contact is not configured properly for $($subName)"
                        }
                        else {
                            # Keeping else condition open to formally identify this probable use case
                            Write-Verbose "Identify use case requirement"
                            $notifOk = $false
                            $notifComment = $msgTable.DefenderEnabledNonCompliant
                        }
                    }
                    catch {
                        $notifOk = $false
                        $notifComment = $msgTable.errorRetrievingNotifications
                        [void]$ErrorList.Add("Error invoking securityContacts for $subName ($subId): $_")
                    }
                }
            }

            # -------------------------
            # D) CWP evaluation - informational only (does NOT affect compliance)
            # -------------------------
            $cwpInfoComment = $null
            if ($cwpPlansActive -and $authHeader) {
                $cov = Get-CwpCoverageForSubscription -SubscriptionId $subId -CountsBySub $countsBySub -TypeToPlanMap $TypeToPlanMap -PricingByPlan $pricingByPlan -msgTable $msgTable
                $cwpInfoComment = $msgTable.CwpInformational -f $cov.comment
                Write-Verbose "CWP informational for $subName : $cwpInfoComment"
            }

            # -------------------------
            # Final compliance (based on notification checks only; CWP is informational)
            # -------------------------
            $isCompliant = $notifOk

            $commentsList = New-Object System.Collections.Generic.List[string]
            if (-not $notifOk -and $notifComment) { $commentsList.Add($notifComment) | Out-Null }

            if ($isCompliant) {
                $commentsList.Add($msgTable.DefenderCompliant) | Out-Null
            }
            elseif ($commentsList.Count -eq 0) {
                $commentsList.Add($msgTable.DefenderEnabledNonCompliant) | Out-Null
            }

            # Append free-tier informational comment if present
            if ($freeTierInfoComment) { $commentsList.Add($freeTierInfoComment) | Out-Null }

            # Append CWP informational comment if present
            if ($cwpInfoComment) { $commentsList.Add($cwpInfoComment) | Out-Null }

            $Comments = ($commentsList | Where-Object { $_ } | Select-Object -Unique) -join " | "

            $C = [PSCustomObject]@{
                SubscriptionName = $subName
                ComplianceStatus = $isCompliant
                ControlName      = $ControlName
                Comments         = $Comments
                ItemName         = $ItemName
                ReportTime       = $ReportTime
                itsgcode         = $itsgcode
            }

            if ($EnableMultiCloudProfiles) {
                $result = Add-ProfileInformation -Result $C -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subId -ErrorList $ErrorList
                [void]$PsObject.Add($result)
            } else {
                [void]$PsObject.Add($C)
            }

            Write-Verbose "Completed compliance output for subscription: $subName"

        }
    }

    return [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors            = $ErrorList
    }
}

# SIG # Begin signature block
# MIIxfgYJKoZIhvcNAQcCoIIxbzCCMWsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD0n+B2G9q3p1d7
# sD7kLEcZu9nqHKNbaWLQv0qCtzS1p6CCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0eMIIdGgIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# 2fJ68EjFE1WsT/WyN4M87KCoiM6JkHDRTsPqoxDjFMgwDQYJKoZIhvcNAQEBBQAE
# ggIAYH+Z27UaUwywKe31Jcn8oqlhCrPA7ri5qAExrSBfnvSShRtaeBe3nx1Xql9h
# P+LBQtJi6QboBABk0vpWSUagufBjQQxcEWi64dV25CIaChP/5l3O9KMPIQ8s/QCc
# z/l0No5qLR/mEVmtI3jphzwifYsMP2ZSbPbomnc62Y3cPJQY6xlijVTgP7gqeMks
# bMEHo5dZnKIRsJDgUkTXJmJmYD4/J0IQmV2L6bHXdPeHj7jop1jn05PZ4pwmkmMY
# bv/7kLdWF5+1yA7D2XYW31Csg+VLcvp0MHb+OQPYPniWNYnHV0uddk++s7W09OOL
# tVzbmDI4xq5vxw6yc4PifnIMiR066xz+UFrt5h+g4KIs/d1kifHSJS6hnaF5e+V/
# x5JZsaa5vQuT931km02BwUgjhxSyZwNkCDS/euJ2vkJS3ofuCBJf1I7Hi17ccj/o
# 3MHnYEWBS2Mdllr/7yzGZX1JlYRZ9/HxPknB4Z+Gj8DrhVdcQEF1qemQM8Yta4hq
# L3MQvERUV78pTStQtgCDcv7TKvWxzqQsnISus8sVvmrOJ5CEfYIYccbjy+XM5roW
# WT3vyU98waXZoQmxxhPO+3tdciB6/ZIxsSUvGQE1pahFS/aiBMo1fVRhGPcF709a
# 4oIam6eRP81FYYesevZgje85KZlFzQ8CiF+iSN1kCo40vnahghnrMIIZ5wYKKwYB
# BAGCNwMDATGCGdcwghnTBgkqhkiG9w0BBwKgghnEMIIZwAIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH3BgsqhkiG9w0BCRABBKCB5wSB5DCB4QIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCCAEEzNhz7IDISFNmqxifylxLNGCu93KRIaiDO+G32a
# egIULMJYazRunQFqzI2f3oMRDykWaKIYDzIwMjYwNzE0MTU0ODQyWqB2pHQwcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDkdyZWF0ZXIgTG9uZG9uMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzN6CCFBcwggbiMIIEyqADAgECAhEA507yVbBQT/rbpt/3
# /IujFTANBgkqhkiG9w0BAQwFADBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIENBIFI0MTAeFw0yNjAzMjUwMDAwMDBaFw0zNzA2MjQyMzU5NTlaMHIxCzAJ
# BgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMPU2Vj
# dGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1w
# aW5nIFNpZ25lciBSMzcwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCy
# /8NtS9xQ2UUtBRF32bj7VK3n4m50Uqjk/zTciSziYV40H1LKah0/oEklYG42E4VC
# P3DvsBUB6DmpCkDZ0jCnZBPIEevaH15ZJOQwFWP2ZXr5YjlJpb68Nlbs+ElNvKx3
# 2/1YHde3qqUSLybjulxPLz6T85+HOIqK7M1Bep8LspyhEP/q6nw5kGxTSrGvufme
# H+JF8CnVBcVMFA40FlIYh0cDJVFhhfTfdWgLy/vWuLMQoKkf3s/FvByf16r0rtby
# Hm/iemwxSioJL9zyZDDKUNAbHXl0dhXo2VxUV2NcPXWXuoKsjL+6cfk6Vm2DHnxA
# lFdFsaBDIF1JOkSnC6PeLlBznZn2buF3vIIYJcq6N/zeFRCk4/HXDz7zgRsRRMdU
# B+rhyk5FoZaBjw0nLq3GZ3fClLUx5es5pUAxzNODMBn7JkFYip2BAGBPER5eV0RO
# hk6tGTG+fUiMiV+vgjg1YnP5FvnYWyEtWeQD/B2hp3vz0RvtdkM0p3igyadzrfpO
# Bq5ppVk/YsuhTQkP99ivneHAGfi5e7lmxJ+meoBPrRLuzMmb81rzzbESjJHMsn5R
# Vtc6Ucs7rcMqQC13PUIO7BbGBETV2ufCmV6lPTp3P7XJOvmnUCRTPbVvMTpxP/z+
# SOHg4/OCBhiqs4FA9+4oQvlkk9w32NGASli9GWrm5wIDAQABo4IBjjCCAYowHwYD
# VR0jBBgwFoAUOnSlDGfGQlDC/bX8x7spNIL0erkwHQYDVR0OBBYEFGEQ6XoSr1HE
# hdTyz6R0D1DNIK/4MA4GA1UdDwEB/wQEAwIGwDAMBgNVHRMBAf8EAjAAMBYGA1Ud
# JQEB/wQMMAoGCCsGAQUFBwMIMEoGA1UdIARDMEEwCAYGZ4EMAQQCMDUGDCsGAQQB
# sjEBAgEDCDAlMCMGCCsGAQUFBwIBFhdodHRwczovL3NlY3RpZ28uY29tL0NQUzBK
# BgNVHR8EQzBBMD+gPaA7hjlodHRwOi8vY3JsLnNlY3RpZ28uY29tL1NlY3RpZ29Q
# dWJsaWNUaW1lU3RhbXBpbmdDQVI0MS5jcmwwegYIKwYBBQUHAQEEbjBsMEUGCCsG
# AQUFBzAChjlodHRwOi8vY3J0LnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1l
# U3RhbXBpbmdDQVI0MS5jcnQwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3Rp
# Z28uY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAD6j2N0azN+hl6k6bKB5/U6VuSOs93
# ZBb3Pczy9VtBIKu4947Z5GwL0aFngIxl+GSuLFrJgPruBCRvKJEJsm7kv+LQ1COV
# CEG9tZ+IRtr4ocUoa53lgdFaENlS0N4wgkZkbQEPv+x+1lSjYh+T4JeL9mUznT7E
# rc6Sp5dWLka5sMP/m3GZi6oJPdPcsCKWagH7m2H2xDGIyHJC5PdH9phvi/Kmhkkt
# iSVTNNqVeV5bWdX2zhRE6UTfz0IcMoCL996lFIydXxOCE4MNDHDM0as4lnTiT/KH
# MccO6l8c9TnUVgmpci9ar1IABZ2U1XUkYjGGSn9MC3EHDP9V39VuBVvZ33/BEV/E
# WSRrf07T7jFplKX+gQr/UOqPGMlE7ZJ72UaUkNJy7bVl3bcLKzdpjIHzLkf/4MVa
# 1V7w8wqCv5W4gOnRGTlud5UMARbRM8BPxR/CXYXoMmIOD8pmTk2axgRL4LG8Xtuc
# hISdCHRmtacAmLGq5XSYSVTHTXADlO48iDKh3HM2r98LSF6f0sG12d8V9Jn7C3wD
# UieOxuKj4MdWrW+hiJU2kF87v6eH00HgCFFc2V0+CvfOCMn7juzS41jLaINcBlKW
# Q/fKb/uDLfWOW73z1I2lFY7Xj8tQ1XYtK5eREjWItM8jpl1cbQOc88btR+0XS2Tm
# boE/141+va2PWzCCBqcwggSPoAMCAQICEQCQrAhyIP3Fp8RrXMcN9z0GMA0GCSqG
# SIb3DQEBDAUAMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0
# ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBS
# NDYwHhcNMjYwMzI1MDAwMDAwWhcNNDEwMzI0MjM1OTU5WjBVMQswCQYDVQQGEwJH
# QjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0aWdvIFB1
# YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAK7kSqIBrYIcYvlmLVuaA8zw1RfBhkn4G1CoemzjcYtML6yNUvKm
# wGH7y6/5MuSC1UYP/+9KYDSqvMQt/1hEKHYxMAD9oZpBkoaDQFEKbOJHelsKe+Ba
# O0ZcENTKfePcraVkA7wrGAW2XHA5gQCQv4IKori/3PNOXxnDMOk8yIMgVrlMeTxq
# fWJ4XkjT1xc2s9DD7URHWWJOFobTPoWs6mrDFlaY9FlAHDYTfbzvxQHVsvRmn3W+
# 5ZmCwyk02I8KgGPT/UX4sTz41GiR+ppwUjQXa1+2tEHZbsdAKUtH3OPEVtZvlt7a
# tx4h83IdRR8oYi8wjY3OjFKXFecWpQbzzsPxbUKPwMWiTrzwkrFa8dH/1pDKRJt3
# 71W62PfqKPayCr/XbnBOlRn8CALSmHnRtGzuAWtTJpcT3BKw6oy8IIL6wSbu938F
# 6ZIbRNIc1dKbIJtr4ULN6R5ZfTdNEhwXctqp3RHDbg4fuOl6LjNoaFwjud92EEDh
# zxFJzE1jqN4csceZIwxOT1aqfsfh0uFQE/lgTBuBs3i6/WL2W1OceWLy3XEdXRK1
# f0EWCuea6dNfX2RRdjUfk5EltFnJkN2+bWhnK14OPRKcyjOv5hKZ0iV4NRNd1+hj
# tva1rPyzb5Bs7EvFxqEQhgZbOq7qH3nm0rBwA0dxniBOYCFPdu246JCxAgMBAAGj
# ggFuMIIBajAfBgNVHSMEGDAWgBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAdBgNVHQ4E
# FgQUOnSlDGfGQlDC/bX8x7spNIL0erkwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB
# /wQIMAYBAf8CAQAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwIwYDVR0gBBwwGjAIBgZn
# gQwBBAIwDgYMKwYBBAGyMQECAQMIMEwGA1UdHwRFMEMwQaA/oD2GO2h0dHA6Ly9j
# cmwuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYu
# Y3JsMHwGCCsGAQUFBwEBBHAwbjBHBggrBgEFBQcwAoY7aHR0cDovL2NydC5zZWN0
# aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0YW1waW5nUm9vdFI0Ni5wN2MwIwYI
# KwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29tMA0GCSqGSIb3DQEBDAUA
# A4ICAQAy3lJHZvGeA2b43yhzoarvobHVzbfl+RfuPDwej0wCQkYAN6scTt2GwFe2
# 2qbOCv/tllqFlLKQZE+E9jVyuPTbyQHwrM7R0oLapAEDC1+CowsqSRf/ptira5Pf
# d4PoHICnb9coPQtyZmHSQp5y9IGvqWf1qNfq7V2fHZ8DvEQrLUzeoGF9BJRYu2Oz
# acW3QQtUum3NOVf0gPRwv6I4991uhncJ6VP4lcpUpHZKB7R3hiIUC09mR9KjzPVn
# XHvL9n2bAwiUECfK5Zezhiw27F2tgi39DETfU8M4n0N6xLgFzsf05M5GURX8C9+I
# X9V6kpmmKtrUzMti4LD66gtmf+mSm934K81NL6YQeMEk1rpYrWPypcW76Mir6wb1
# AgseLIHqn/GkeuQm7zOTDf3f5WoX14qVNjZWNHF3JxkutV6ZnhinfCLfdv5bnwKW
# UfceqOajCVntI6uCbHxjBg6SCsexc5AfIGno7gVFvwifT4XONPsSUaJ71XsJ+Evc
# iVUVnjOO4qxm0fWJTd8a7jP8mc4ZPqwJvQFtOp7+6G+kUJAF0fnE8YgD8uttBReN
# Ta1YmAeFMiqc38e8fI4eLm0zjM/eeGCHasnoqqrbGwcF41iz9HXzFDwN4iD5z3QS
# hp6HRiU3UpTwDJiiXcr0z6pjl7PyzJ3/tmWtGehV7CAfc/WlyzCCBoIwggRqoAMC
# AQICEDbCsL18Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEMBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTIxMDMyMjAwMDAwMFoX
# DTM4MDExODIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28g
# TGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBS
# b290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAIid2LlFZ50d
# 3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYsyAhTXiDQkiUvpVdYqZ1u
# YoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXVydmhx7Dx4IBrAou7hNGs
# KioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjthgF7Hjx4vvyVDQGsd5Ka
# rLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1gASn/hp6IuHJorEu6Eop
# oB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35ZvxQw6zid61qmrlD/IbKJA
# 6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6KdOpuzVDR3ZUwxDKL1wCA
# xgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhLRPb7YkzM8/6NnWH3T9Cl
# mcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb49zYHr7ALL8bAJyPDmub
# NqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRKKsxCG1t6tG9oj7liwPdd
# XEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5e45NuzAHteORlsSuDt5t
# 4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjggEWMIIBEjAfBgNVHSMEGDAW
# gBRTeb9aqitKz1SA4dibwJ3ysgNmyzAdBgNVHQ4EFgQU9ndq3T/9ARP/FqFsggIv
# 0Ao9FCUwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wEwYDVR0lBAww
# CgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMFAGA1UdHwRJMEcwRaBDoEGG
# P2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9VU0VSVHJ1c3RSU0FDZXJ0aWZpY2F0
# aW9uQXV0aG9yaXR5LmNybDA1BggrBgEFBQcBAQQpMCcwJQYIKwYBBQUHMAGGGWh0
# dHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcNAQEMBQADggIBAA6+ZUHt
# aES45aHF1BGH5Lc7JYzrftrIF5Ht2PFDxKKFOct/awAEWgHQMVHol9ZLSyd/pYMb
# aC0IZ+XBW9xhdkkmUV/KbUOiL7g98M/yzRyqUOZ1/IY7Ay0YbMniIibJrPcgFp73
# WDnRDKtVutShPSZQZAdtFwXnuiWl8eFARK3PmLqEm9UsVX+55DbVIz33Mbhba0HU
# TEYv3yJ1fwKGxPBsP/MgTECimh7eXomvMm0/GPxX2uhwCcs/YLxDnBdVVlxvDjHj
# O1cuwbOpkiJGHmLXXVNbsdXUC2xBrq9fLrfe8IBsA4hopwsCj8hTuwKXJlSTrZcP
# RVSccP5i9U28gZ7OMzoJGlxZ5384OKm0r568Mo9TYrqzKeKZgFo0fj2/0iHbj55h
# c20jfxvK3mQi+H7xpbzxZOFGm/yVQkpo+ffv5gdhp+hv1GDsvJOtJinJmgGbBFZI
# ThbqI+MHvAmMmkfb3fTxmSkop2mSJL1Y2x/955S29Gu0gSJIkc3z30vU/iXrMpWx
# 2tS7UVfVP+5tKuzGtgkP7d/doqDrLF1u6Ci3TpjAZdeLLlRQZm867eVeXED58LXd
# 1Dk6UvaAhvmWYXoiLz4JA5gPBcz7J311uahxCweNxE+xxxR3kT0WKzASo5G/PyDe
# z6NHdIUKBeE3jDPs2ACc6CkJ1Sji4PKWVT0/MYIEkzCCBI8CAQEwajBVMQswCQYD
# VQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMSwwKgYDVQQDEyNTZWN0
# aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFI0MQIRAOdO8lWwUE/626bf9/yL
# oxUwDQYJYIZIAWUDBAICBQCgggH6MBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAcBgkqhkiG9w0BCQUxDxcNMjYwNzE0MTU0ODQyWjA/BgkqhkiG9w0BCQQxMgQw
# UwwPn2dvDO3at4Kgzj222amxztne5Su6e1rE12dSmLy6VzOE+74c72gaEo1jq7AD
# MIIBewYLKoZIhvcNAQkQAgwxggFqMIIBZjCCAWIwFgQU6XgYqSjaFQqf4b+czHqr
# uaAO7qwwgYgEFGXDKGlvfU5QLP0Dx8IGlxjK+/dPMHAwW6RZMFcxCzAJBgNVBAYT
# AkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28g
# UHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBSNDYCEQCQrAhyIP3Fp8RrXMcN9z0G
# MIG8BBSFPWMtk4KCYXzQkDXEkd6SwULaxzCBozCBjqSBizCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0plcnNleSBDaXR5MR4w
# HAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNVBAMTJVVTRVJUcnVz
# dCBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkCEDbCsL18Gzrno7PdNsvJdWgw
# DQYJKoZIhvcNAQEBBQAEggIAdauvj1d7OMcT/9UjpG+URGBttNWxVPFjvMuCPJZe
# VxQ71sUXY0ZN3TD/jiYUwgEcewScHEcWToI0wMgPUBp46+9agKiwL+XXVxpCzyeh
# USjKQwHqcSqsMUyIfiHH/bvsP5R66+QumItjDyaiBseEKCls9TfIPgLTXVJBxy2x
# W0YmQW9q4SFnc33H4H2Mx9vFW5XRGJ5wZIfqgTJUSTfSQRHMKO+Y9BkRcUMRHV0y
# agL53arSjnfZjiBFlbYbgAoIGu8zN+NMkD6d6ImWYMuJ/SZOMBsz0XOx1GLinlxw
# gBypLUXWG9but5heIt1DBykZTJ+0qw+X3YDY3MWWJvUPmPq6xx6VNf0K6ePuU8X6
# NLns2howgfEzp07r8PA3UAenKOfK5OaDHWWFL4JouUigid+AfHS0LMqaDfy2BNzb
# BcRMv9tbXJe79GzsnzIhX8/e6ZV8uV1IwpMDU3dae0qjLjMBK9vd9uShvzYFVGvf
# pzDVbdMvCsc7rNG40nnoBsi2i5jNDcYSGl78Hs3sKoxi2129+hxkit3JvlpqKIUd
# f+TN6CXNQc/a8MXjmcHNiWLmOV/MFvT9ouVOTNiw6BKD5jI9jTe09W+MAKO7kjL/
# v3f81EkjaOe8eP0X58I/jGMNDkIkOtL/2BWPTGfJDdDlsrDuZGDCk+BcCB17Z7/J
# rEY=
# SIG # End signature block

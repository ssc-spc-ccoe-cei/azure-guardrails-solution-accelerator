function Get-DefenderForCloudAlerts {
    param (
        [Parameter(Mandatory=$true)]
        [string]$ControlName,
        [Parameter(Mandatory=$true)]
        [string]$ItemName,
        [Parameter(Mandatory=$true)]
        [string]$itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable]$msgTable,
        [Parameter(Mandatory=$true)]
        [string]$ReportTime,
        [string] 
        $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] 
        $EnableMultiCloudProfiles # New feature flag, default to false
    )

    $isCompliant = $false
    $Comments = ""
    $ErrorList = @()
    $subCompliance = @()

    #Get All the Subscriptions
    $subs = Get-AzSubscription -ErrorAction SilentlyContinue| Where-Object {$_.State -eq "Enabled"}

    foreach($subscription in $subs){
        $subId = $subscription.Id
        Set-AzContext -SubscriptionId $subId

        $defenderPlans = Get-AzSecurityPricing
        $defenderEnabled = $defenderPlans | Where-Object {$_.PricingTier -eq 'Standard'} #A paid plan should exist on the sub resource

        if(-not $defenderEnabled){
            $Comments += $msgTable.NotAllSubsHaveDefenderPlans -f $subscription
            break
        }

        $azContext = Get-AzContext
        $token = Get-AzAccessToken -TenantId $azContext.Subscription.TenantId 
        
        $authHeader = @{
            'Content-Type'  = 'application/json'
            'Authorization' = 'Bearer ' + $token.Token
        }

        #Retrieve notifications for alert and attack paths
        $restUri = "https://management.azure.com/subscriptions/$($azContext.Subscription.Id)/providers/Microsoft.Security/securityContacts/default?api-version=2023-12-01-preview"

        try{
            $response = Invoke-RestMethod -Uri $restUri -Method Get -Headers $authHeader
        }
        catch{
            $Comments += $msgTable.errorRetrievingNotifications
            $ErrorList += "Error invoking $restUri for notifications for the subscription: $_"
            break
        }
        
        $notificationSources = $response.properties.notificationsSources
        $notificationEmails = $response.properties.emails
        $ownerRole = $response.properties.notificationsByRole.roles | Where-Object {$_ -eq "Owner"}
        $ownerState = $response.properties.notificationsByRole.State

        #Filter so we get required notification types
        $alertNotification = $notificationSources | Where-Object {$_.sourceType -eq "Alert" -and $_.minimalSeverity -in @("Medium","Low")}
        $attackPathNotification = $notificationSources | Where-Object {$_.sourceType -eq "AttackPath" -and $_.minimalRiskLevel -in @("Medium","Low")}

        $emailCount = ($notificationEmails -split ";").Count

        #Check theres minimum two emails and owner is also notified
        if(($emailCount -lt 2) -or ($ownerState -ne "On" -or $ownerRole -ne "Owner")){
            $Comments += $msgTable.EmailsOrOwnerNotConfigured -f $subscription
            break
        }

        if($null -eq $alertNotification){
            $Comments += $msgTable.AlertNotificationNotConfigured
            break
        }

        if($null -eq $attackPathNotification){
            $Comments += $msgTable.AttackPathNotifictionNotConfigured
            break
        }

        #If it reaches here, then subscription is compliant
        $subCompliance += $true
    }
    
    #Check if all subscriptions are compliant
    if ($subCompliance -notcontains $false -and $null -ne $subCompliance -and $subCompliance.Count -eq $subs.Count){
        $isCompliant = $true
        $Comments += $msgTable.DefenderCompliant
    }

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $isCompliant
        ControlName = $ControlName
        Comments = $Comments
        ItemName = $ItemName
        ReportTime = $ReportTime
        itsgcode = $itsgcode
    }

    # Conditionally add the Profile field based on the feature flag
    if ($EnableMultiCloudProfiles) {
        $evalResult = Get-EvaluationProfile -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles
        if (!$evalResult.ShouldEvaluate) {
            if ($evalResult.Profile -gt 0) {
                $PsObject.ComplianceStatus = "Not Applicable"
                $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
                $PsObject.Comments = "Not evaluated - Profile $($evalResult.Profile) not present in CloudUsageProfiles"
            } else {
                $ErrorList.Add("Error occurred while evaluating profile configuration")
            }
        } else {
            
            $PsObject | Add-Member -MemberType NoteProperty -Name "Profile" -Value $evalResult.Profile
        }
    }
    
    $moduleOutput = [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors = $ErrorList
    }

    return $moduleOutput
}

# SIG # Begin signature block
# MIIyrAYJKoZIhvcNAQcCoIIynTCCMpkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCyBw1CPobwVWpe
# yE8Y59QJTkn0bmKCBolOm3V7c/5XmKCCFpIwggQ+MIIDJqADAgECAgRKU4woMA0G
# CSqGSIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwg
# SW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5
# MDcGA1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVk
# IHVzZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkgLSBHMjAeFw0wOTA3MDcxNzI1NTRaFw0zMDEyMDcxNzU1NTRaMIG+
# MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMf
# U2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIw
# MDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MTIwMAYD
# VQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHMjCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALqEtnLbngxr4pnpMAGnduoy
# uJVBGsnaYU5Ycs/+9oJ5v3NhBgqlJ9izX9NFThxy1k4y8nKKD/eDGdBqgIAARR6w
# x+eavxJXJxyjaC8Kh71qaw5eZfMcd9XUhY1wIbSzMueLotWGOQKxuNJHzuTJScQ7
# p977VH1XvvDobsJ5sjoLVeJQmBYyE1wveFbBwpSz8lrkJ5qfJNfG7NCbJYLjzMLE
# RcWMl3oGayoRn6kKbkg7b9vUERlC948Hv/VTX5w+9Bcs5mmsTjJMYnfqt+jluzS8
# GYuunFHnt361U7EzIuVtz3A8Gvrim2e2g/SNpa9iTE3gWKxkNBID+LaNlGMkpHEC
# AwEAAaNCMEAwDgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0O
# BBYEFGpyJnrQHu995ztpUdRsjZ+QEmarMA0GCSqGSIb3DQEBCwUAA4IBAQB5nx2W
# xrZ5PyKNh9OHAwRgamuaLlmJcxGsQ9H1E/+NOSvA8r1PcIypL+oXxAtUntQblpgz
# PKitYqIAdqtZaW4GHX7EuUSNmK8S1GHbChlGR/Pr92PBQAVApdK39LWaNr+piHaI
# BFUEK5yHfxo3PH4tpRrY1Ileyr2sPWzYba/V83YPzTuIOCKdbJOaxD2/ghtlP6YP
# Xar85bIVyrWtxrw90ITo6gZysE05Mni/PhGcC6SdmiHz8JsLMHjbwdyHQ/68Y5rK
# xcIcyceN/zsSWAjmtj3seixO+4OWzgw8aYdUc6RzwpP/URCsFVQB2PwFsYmhf3SD
# mknX3E57ikhvi0X2MIIF3zCCBMegAwIBAgIQTkDkN1Tt5owAAAAAUdOUfzANBgkq
# hkiG9w0BAQsFADCBvjELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1c3QsIElu
# Yy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVzdC5uZXQvbGVnYWwtdGVybXMxOTA3
# BgNVBAsTMChjKSAyMDA5IEVudHJ1c3QsIEluYy4gLSBmb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTEyMDAGA1UEAxMpRW50cnVzdCBSb290IENlcnRpZmljYXRpb24gQXV0
# aG9yaXR5IC0gRzIwHhcNMjEwNTA3MTU0MzQ1WhcNMzAxMTA3MTYxMzQ1WjBpMQsw
# CQYDVQQGEwJVUzEWMBQGA1UECgwNRW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50
# cnVzdCBDb2RlIFNpZ25pbmcgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAt
# IENTQlIxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAp4GP9xRFtmJD
# 8tiu0yVeSE9Rv8V9n1AcNdHWfmEqlBltJ0akphpd91RRaoAixqhmdU1Ug8leaBur
# 9ltksK2tIL1U70ZrbQLnRa519o6KuTIui7h3HFJNeYhfpToYyVAslyctv9oAfWN/
# 7zLsRodj25qfw1ohNnv5m9XKoG5yLPzh8Z5wTQhWFW+Qq/tIurnXwYJ4hWUuf7XJ
# wOIUtzcRQQbiiuCo9uV+tngFAcNg7U8HQS4KE0njkJt/3b36rL9kUdFcm7T1XOdc
# /zubpaAa130JssK3/24cvMh95ukr/HKzFOlKVRKEnEQldR32KvBPpSA9aCXrYZd8
# D+W2PfOuw8ERvBuOzOBHMF5CAIZx41isBsplH3uUpktXZwx+Xq14Z1tV417rx9js
# TG6Gy/Pc+J+HqnJYEg99pvj4Qjk7PCzkMk1JjODhAMI4oJz6hD5B3G5WrsYaW/Rn
# aAUBzRu/roe8nVP2Lui2a+SZ3sVPh1io0mUeyB/Vcm7uWRxXOwlyndfKt5DGzXtF
# kpFCA0x9P8ryqrjCDobzEJ9GLqRmhmhaaBhwKTgRgGBrikOjc2zjs2s3/+adZwGS
# ht8vSNH7UGDVXP4h0wFCY/7vcLQXwI+o7tPBS18S6v39Lg6HRGDjqfTCGKPj/c4M
# hCIN86d42pPz2zjPuS8zxv8HPF6+RdMCAwEAAaOCASswggEnMA4GA1UdDwEB/wQE
# AwIBhjASBgNVHRMBAf8ECDAGAQH/AgEBMB0GA1UdJQQWMBQGCCsGAQUFBwMDBggr
# BgEFBQcDCDA7BgNVHSAENDAyMDAGBFUdIAAwKDAmBggrBgEFBQcCARYaaHR0cDov
# L3d3dy5lbnRydXN0Lm5ldC9ycGEwMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAwBgNVHR8EKTAnMCWgI6Ahhh9odHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2cyY2EuY3JsMB0GA1UdDgQWBBSCutY9l86fz3Ho
# kjev/bO1aTVXzzAfBgNVHSMEGDAWgBRqciZ60B7vfec7aVHUbI2fkBJmqzANBgkq
# hkiG9w0BAQsFAAOCAQEAH15BBLaDcCRTLFVzHWU6wOy0ewSYXlk4EwmkWZRCXlC/
# T2xuJSCQk1hADfUZtGLuJF7CAVgVAh0QCW+o1PuSfjc4Pi8UfY8dQzZks2YTXxTM
# pXH3WyFLxpe+3JX8cH0RHNMh3dAkOSnF/goapc97ee46b97cv+kR3RaDCNMsjX9N
# qBR5LwVhUjjrYPMUaH3LsoqtwJRc5CYOLIrdRsPO5FZRxVbjhbhNm0VyiwfxivtJ
# uF/R8paBXWlSJPEII9LWIw/ri9d+i8GTa/rxYntY6VCbl24XiA3hxkOY14FhtoWd
# R+yxnq4/IDtDndiiHODUfAjCr3YG+GJmerb3+sivNTCCBfUwggPdoAMCAQICEH9t
# pc0g1hYK1SPEEVZtoXEwDQYJKoZIhvcNAQENBQAwTzELMAkGA1UEBhMCVVMxFjAU
# BgNVBAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWdu
# aW5nIENBIC0gT1ZDUzIwHhcNMjQxMDI5MTQ1NDIyWhcNMjUxMTIzMTQ1NDIwWjBy
# MQswCQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdh
# MR8wHQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFy
# ZWQgU2VydmljZXMgQ2FuYWRhMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKC
# AYEAiojKH+XPe+beyDzVUpIChDDMhep8ENwkPx7hfdmutAWP4h2EE1OaaBJcGm/z
# yRtuYJ64uSmUahu23wueRdhDxkBaJgfDO/AHkT7Q6UC3NgZrsEEe2Mb7nbUui676
# NbEQRLfh+vmW/s+9Vz4psnWK7qCHBn5ypVYjCQSnZGQjng2E0Ko5bZo7hO3itObT
# Ld7xq9Lr1L+FK5hWydu5UAndazONs0IgwqQKgZ0iu52B4dtojGJCNXoN6Z4GOV5O
# PYg0fammJRYHur+wcbGWcC/v5jPvbwfOzAL+J7ZoGnW4SAvolCnW47SAfkwDSzOl
# iMLeCb5zxolBi8kg3sy82stU7VBQxiK9Q/i7eUyhk/Cbxa1+9tTVIVak/RMLXE7h
# nAPEhv/Vds0Zxi+3xfIVM4Yo/JJelzixOHwvfjDdAnn2gjOdHmgXf3qLUd/8VVTI
# NG5ypZIlRTDLjfw5DY7AISYL7T0dMuq2FhD8DE/f/hAYhxRcXgpC5LEzHF13O3JI
# aa59AgMBAAGjggEoMIIBJDAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBSMKfPIWgMV
# dRERIVCRdhTVOQWaPDAfBgNVHSMEGDAWgBTvn7p5sHPyJR54nANSnBtThN6N7TAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwZwYIKwYBBQUHAQEE
# WzBZMCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAyBggrBgEF
# BQcwAoYmaHR0cDovL2FpYS5lbnRydXN0Lm5ldC9vdmNzMi1jaGFpbi5wN2MwMQYD
# VR0fBCowKDAmoCSgIoYgaHR0cDovL2NybC5lbnRydXN0Lm5ldC9vdmNzMi5jcmww
# EwYDVR0gBAwwCjAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBABarCE8pTjYN
# zIJAvqBuEnADo9afVzezReZHOptUpdA1Q6oDBm/7ARFJIiJkQdxnt7aesBETwiV4
# 5wndiZ0rliv4aOMle7oPlMmG1M44bvCDaFwYNxMKqtLWu77lPUUa63XZ0CKRHdHg
# QvjCHnBV7K/JEMT0gvtJ8squJ/o38f507jWKaJATEtYvT8SYjxBk0tXo21Vc9C/C
# xndoIMW6lcVREVwvdL9bClEO8du7x6I1KDBfdIn7/0iokuY+yDbRDKUrr/lJ4ULZ
# AgIldVTRORdR0hYdLDNXOKMdn8p1+V0Xa/2bwX8tch5x9bamaalNlh9vGxack0d/
# tCZ4xHjwchTeBdbVxIDvMeOg+DCKk4OKlNSkl1kCC3dGKLQnl+7S3UHnONffWLFz
# niQ4RuCve3ELt9JhLXdQL/qyHc2J3ZAkvAUMT3kYinQL6JZZmeS/DakrBgI/eLfE
# uv9+Ys10WeB+HnO7tGRFXBuzb7a0HBP02BJXmCnylsM16MuPtpNVsXaNUgzLfe7/
# 5P/fYCGiM4VCLJBNz9paFjZfLaIL38QsPg7BbsE00jT8j97nqKzPZiw8J3tfrN5R
# FP74QQbBaoujXpUmIw4tb6fgw7pjbIXRjJPReDp8rtctaBc8H9rpz0o5x2McMFbL
# ScjxUB5vCttH2p7+m9qRDjuZbzqNB/+CMIIGcDCCBFigAwIBAgIQce9VdK81VMNa
# LGn2b0trzTANBgkqhkiG9w0BAQ0FADBpMQswCQYDVQQGEwJVUzEWMBQGA1UECgwN
# RW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50cnVzdCBDb2RlIFNpZ25pbmcgUm9v
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIENTQlIxMB4XDTIxMDUwNzE5MjA0
# NVoXDTQwMTIyOTIzNTkwMFowTzELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1
# c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZD
# UzIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCemXYXGp5WFwhjLJNN
# g2GEMzQCttlioN7CDrkgTMhXnQ/dVFsNDNYB3S9I4ZEJ4dvIFQSCtnvw2NYwOxlx
# cPuoppf2KV2kDKn0Uz5X2wxObvx2218k6apfQ+OT5w7PyiW8xEwwC1oP5gb05W4M
# mWZYT4NhwnN8XCJvAUXFD/dAT2RL0BcKqQ4eAi+hj0zyZ1DbPuSfwk8/dOsxpNCU
# 0Jm8MJIJasskzaLYdlLQTnWYT2Ra0l6D9FjAXWp1xNg/ZDqLFA3YduHquWvnEXBJ
# EThjE27xxvq9EEU1B+Z2FdB1FqrCQ1f+q/5jc0YioLjz5MdwRgn5qTdBmrNLbB9w
# cqMH9jWSdBFkbvkC1cCSlfGXWX4N7qIl8nFVuJuNv83urt37DOeuMk5QjaHf0XO/
# wc5/ddqrv9CtgjjF54jtom06hhG317DhqIs7DEEXml/kW5jInQCf93PSw+mfBYd5
# IYPWC+3RzAif4PHFyVi6U1/Uh7GLWajSXs1p0D76xDkJr7S17ec8+iKH1nP5F5Vq
# wxz1VXhf1PoLwFs/jHgVDlpMOm7lJpjQJ8wg38CGO3qNZUZ+2WFeqfSuPtT8r0XH
# OrOFBEqLyAlds3sCKFnjhn2AolhAZmLgOFWDq58pQSa6u+nYZPi2uyhzzRVK155z
# 42ZMsVGdgSOLyIZ3srYsNyJwIQIDAQABo4IBLDCCASgwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQU75+6ebBz8iUeeJwDUpwbU4Teje0wHwYDVR0jBBgwFoAU
# grrWPZfOn89x6JI3r/2ztWk1V88wMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAxBgNVHR8EKjAoMCagJKAihiBodHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2NzYnIxLmNybDAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwMwRQYDVR0gBD4wPDAwBgRVHSAAMCgwJgYIKwYBBQUH
# AgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMAgGBmeBDAEEATANBgkqhkiG
# 9w0BAQ0FAAOCAgEAXvOGmTXBee7wEK/XkkPShdBb4Jig4HFRyRTLUJpgDrAEJkmx
# z+m6mwih2kNd1G8jorn4QMdH/k0BC0iQP8jcarQ+UzUovkBKR4VqHndAzIB/YbQ8
# T3mo5qOmoH5EhnG/EhuVgXL3DaXQ3mefxqK48Wr5/P50ZsZk5nk9agNhTksfzCBi
# ywIY7GPtfnE/lroLXmgiZ+wfwNIFFmaxsqTq/MWVo40SpfWN7xsgzZn35zLzWXEf
# 3ZTmeeVSIxBWKvxZOL+/eSWSasf9q2d3cbEEfTWtFME+qPwjF1YIGHzXeiJrkWrM
# NUVtTzudQ50FuJ3z/DQhXAQYMlc4NMHKgyNGpogjIcZ+FICrse+7C6wJP+5TkTGz
# 4lREqrV9MDwsI5zoP6NY6kAIF6MgX3rADNuq/wMWAw10ZCKalF4wNXYT9dPh4+AH
# ytnqRYhGnFTVEOLzMglAtudcFzL+zK/rbc9gPHXz7lxgQFUbtVmvciNoTZx0BAwQ
# ya9QW6cNZg+W5ZqV4CCiGtCw7jhJnipnnpGWbJjbxBBtYHwebkjntn6vMwcSce+9
# lTu+qYPUQn23pzTXX4aRta9WWNpVfRe927zNZEEVjTFRBk+0LrKLPZzzTeNYA1TM
# rIj4UjxOS0YJJRn/FeenmEYufbrq4+N8//m5GZW+drkNebICURpKyJ+IwkMxghtw
# MIIbbAIBATBjME8xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMu
# MSgwJgYDVQQDEx9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyAhB/baXN
# INYWCtUjxBFWbaFxMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIP55FYEHknepFuWgHdfw
# Df2gMXLaGFSbelZEscC6Q2c/MA0GCSqGSIb3DQEBAQUABIIBgAw3vO3mqLhs2Krz
# 38gXyiayepibVzJRiFp/8zUvAoAwNE13Fpe3hBcMUYz7FyKH7LrGGBDfHqP3XLIp
# N7GpE1V6TVULgbU5J+V7sg0WYs3tspX2HU0FHGXeRWEcHd8hIsMjn6pQ5RceybRJ
# 87HSyDcZ9NozQhlJvpcRr4nqEAdiwd7qan0iEtHnugWY/cWfmMABAy7Bc4jkkqMN
# rdxO6Vv9e4FOR7rXWa8XpcX3R5+mBLKK1FfuC9k1YDitVztNqhS5KWkMLZM55h5z
# wAPGbhpvHk2hlABbYnRVdC02KP9o/7UVsGwP2I5c1USap4KefZA6ZE/XGxUlLJBL
# 1jbQ6mLKwjkdYh9MLqITGE8DaAJhNN5ECHA1Kel4tIVrTz15JuSq6RDSGTV7dU3E
# 0iTUFlJ96kly8CyPXRVN0eMqLc7eDS8fE692s6u4p6Ws6eGHqd8QUx6z8LCkf7WO
# nWdrsusjctM4nOcUJvZNoOVC0fTht61PR5EOneaK45z6OGIm66GCGNcwghjTBgor
# BgEEAYI3AwMBMYIYwzCCGL8GCSqGSIb3DQEHAqCCGLAwghisAgEDMQ8wDQYJYIZI
# AWUDBAICBQAwgfcGCyqGSIb3DQEJEAEEoIHnBIHkMIHhAgEBBgorBgEEAbIxAgEB
# MDEwDQYJYIZIAWUDBAIBBQAEIAeSyUjX+67xubw2mSymumLnpWt+pK6+6+KI2Ng2
# tv9PAhQ3kCcmZbs/2DaNWJ1C99wFS0hRZRgPMjAyNTA2MDIxODQxNTlaoHakdDBy
# MQswCQYDVQQGEwJHQjEXMBUGA1UECBMOV2VzdCBZb3Jrc2hpcmUxGDAWBgNVBAoT
# D1NlY3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBT
# dGFtcGluZyBTaWduZXIgUjM2oIITBDCCBmIwggTKoAMCAQICEQCkKTtuHt3XpzQI
# h616TrckMA0GCSqGSIb3DQEBDAUAMFUxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxLDAqBgNVBAMTI1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgQ0EgUjM2MB4XDTI1MDMyNzAwMDAwMFoXDTM2MDMyMTIzNTk1OVowcjEL
# MAkGA1UEBhMCR0IxFzAVBgNVBAgTDldlc3QgWW9ya3NoaXJlMRgwFgYDVQQKEw9T
# ZWN0aWdvIExpbWl0ZWQxMDAuBgNVBAMTJ1NlY3RpZ28gUHVibGljIFRpbWUgU3Rh
# bXBpbmcgU2lnbmVyIFIzNjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# ANOElfRupFN48j0QS3gSBzzclIFTZ2Gsn7BjsmBF659/kpA2Ey7NXK3MP6JdrMBN
# U8wdmkf+SSIyjX++UAYWtg3Y/uDRDyg8RxHeHRJ+0U1jHEyH5uPdk1ttiPC3x/gO
# xIc9P7Gn3OgW7DQc4x07exZ4DX4XyaGDq5LoEmk/BdCM1IelVMKB3WA6YpZ/XYdJ
# 9JueOXeQObSQ/dohQCGyh0FhmwkDWKZaqQBWrBwZ++zqlt+z/QYTgEnZo6dyIo2I
# hXXANFkCHutL8765NBxvolXMFWY8/reTnFxk3MajgM5NX6wzWdWsPJxYRhLxtJLS
# UJJ5yWRNw+NBqH1ezvFs4GgJ2ZqFJ+Dwqbx9+rw+F2gBdgo4j7CVomP49sS7Cbqs
# dybbiOGpB9DJhs5QVMpYV73TVV3IwLiBHBECrTgUfZVOMF0KSEq2zk/Lsfvehswa
# vE3W4aBXJmGjgWSpcDz+6TqeTM8f1DIcgQPdz0IYgnT3yFTgiDbFGOFNt6eCidxd
# R6j9x+kpcN5RwApy4pRhE10YOV/xafBvKpRuWPjOPWRBlKdm53kS2aMh08spx7xS
# EqXn4QQldCnUWRz3Lki+TgBlpwYwJUbR77DAayNwAANE7taBrz2v+MnnogMrvvct
# 0iwvfIA1W8kp155Lo44SIfqGmrbJP6Mn+Udr3MR2oWozAgMBAAGjggGOMIIBijAf
# BgNVHSMEGDAWgBRfWO1MMXqiYUKNUoC6s2GXGaIymzAdBgNVHQ4EFgQUiGGMoSo3
# ZIEoYKGbMdCM/SwCzk8wDgYDVR0PAQH/BAQDAgbAMAwGA1UdEwEB/wQCMAAwFgYD
# VR0lAQH/BAwwCgYIKwYBBQUHAwgwSgYDVR0gBEMwQTA1BgwrBgEEAbIxAQIBAwgw
# JTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMwCAYGZ4EMAQQC
# MEoGA1UdHwRDMEEwP6A9oDuGOWh0dHA6Ly9jcmwuc2VjdGlnby5jb20vU2VjdGln
# b1B1YmxpY1RpbWVTdGFtcGluZ0NBUjM2LmNybDB6BggrBgEFBQcBAQRuMGwwRQYI
# KwYBBQUHMAKGOWh0dHA6Ly9jcnQuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1Rp
# bWVTdGFtcGluZ0NBUjM2LmNydDAjBggrBgEFBQcwAYYXaHR0cDovL29jc3Auc2Vj
# dGlnby5jb20wDQYJKoZIhvcNAQEMBQADggGBAAKBPqSGclEh+WWpLj1SiuHlm8xL
# E0SThI2yLuq+75s11y6SceBchpnKpxWaGtXc8dya1Aq3RuW//y3wMThsvT4fSba2
# AoSWlR67rA4fTYGMIhgzocsids0ct/pHaocLVJSwnTYxY2pE0hPoZAvRebctbsTq
# ENmZHyOVjOFlwN2R3DRweFeNs4uyZN5LRJ5EnVYlcTOq3bl1tI5poru9WaQRWQ4e
# ynXp7Pj0Fz4DKr86HYECRJMWiDjeV0QqAcQMFsIjJtrYTw7mU81qf4FBc4u4swph
# LeKRNyn9DDrd3HIMJ+CpdhSHEGleeZ5I79YDg3B3A/fmVY2GaMik1Vm+FajEMv4/
# EN2mmHf4zkOuhYZNzVm4NrWJeY4UAriLBOeVYODdA1GxFr1ycbcUEGlUecc4RCPg
# YySs4d00NNuicR4a9n7idJlevAJbha/arIYMEuUqTeRRbWkhJwMKmb9yEvppRudK
# yu1t6l21sIuIZqcpVH8oLWCxHS0LpDRF9Y4jijCCBhQwggP8oAMCAQICEHojrtpT
# aZYPkcg+XPTH4z8wDQYJKoZIhvcNAQEMBQAwVzELMAkGA1UEBhMCR0IxGDAWBgNV
# BAoTD1NlY3RpZ28gTGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGlt
# ZSBTdGFtcGluZyBSb290IFI0NjAeFw0yMTAzMjIwMDAwMDBaFw0zNjAzMjEyMzU5
# NTlaMFUxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLDAq
# BgNVBAMTI1NlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgQ0EgUjM2MIIBojAN
# BgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAzZjYQ0GrboIr7PYzfiY05ImM0+8i
# EoBUPu8mr4wOgYPjoiIz5vzf7d5wu8GFK1JWN5hciN9rdqOhbdxLcSVwnOTJmUGf
# AMQm4eXOls3iQwfapEFWuOsYmBKXPNSpwZAFoLGl5y1EaGGc5LByM8wjcbSF52/Z
# 42YaJRsPXY545E3QAPN2mxDh0OLozhiGgYT1xtjXVfEzYBVmfQaI5QL35cTTAjsJ
# Ap85R+KAsOfuL9Z7LFnjdcuPkZWjssMETFIueH69rxbFOUD64G+rUo7xFIdRAuDN
# vWBsv0iGDPGaR2nZlY24tz5fISYk1sPY4gir99aXAGnoo0vX3Okew4MsiyBn5ZnU
# DMKzUcQrpVavGacrIkmDYu/bcOUR1mVBIZ0X7P4bKf38JF7Mp7tY3LFF/h7hvBS2
# tgTYXlD7TnIMPrxyXCfB5yQq3FFoXRXM3/DvqQ4shoVWF/mwwz9xoRku05iphp22
# fTfjKRIVpm4gFT24JKspEpM8mFa9eTgKWWCvAgMBAAGjggFcMIIBWDAfBgNVHSME
# GDAWgBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAdBgNVHQ4EFgQUX1jtTDF6omFCjVKA
# urNhlxmiMpswDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQAwEwYD
# VR0lBAwwCgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMEwGA1UdHwRFMEMw
# QaA/oD2GO2h0dHA6Ly9jcmwuc2VjdGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVT
# dGFtcGluZ1Jvb3RSNDYuY3JsMHwGCCsGAQUFBwEBBHAwbjBHBggrBgEFBQcwAoY7
# aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGltZVN0YW1waW5n
# Um9vdFI0Ni5wN2MwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLnNlY3RpZ28uY29t
# MA0GCSqGSIb3DQEBDAUAA4ICAQAS13sgrQ41WAyegR0lWP1MLWd0r8diJiH2VVRp
# xqFGhnZbaF+IQ7JATGceTWOS+kgnMAzGYRzpm8jIcjlSQ8JtcqymKhgx1s6cFZBS
# fvfeoyigF8iCGlH+SVSo3HHr98NepjSFJTU5KSRKK+3nVSWYkSVQgJlgGh3MPcz9
# IWN4I/n1qfDGzqHCPWZ+/Mb5vVyhgaeqxLPbBIqv6cM74Nvyo1xNsllECJJrOvsr
# JQkajVz4xJwZ8blAdX5umzwFfk7K/0K3fpjgiXpqNOpXaJ+KSRW0HdE0FSDC7+ZK
# JJSJx78mn+rwEyT+A3z7Ss0gT5CpTrcmhUwIw9jbvnYuYRKxFVWjKklW3z83epDV
# zoWJttxFpujdrNmRwh1YZVIB2guAAjEQoF42H0BA7WBCueHVMDyV1e4nM9K4As7P
# VSNvQ8LI1WRaTuGSFUd9y8F8jw22BZC6mJoB40d7SlZIYfaildlgpgbgtu6SDsek
# 2L8qomG57Yp5qTqof0DwJ4Q4HsShvRl/59T4IJBovRwmqWafH0cIPEX7cEttS5+t
# XrgRtMjjTOp6A9l0D6xcKZtxnLqiTH9KPCy6xZEi0UDcMTww5Fl4VvoGbMG2oonu
# X3f1tsoHLaO/Fwkj3xVr3lDkmeUqivebQTvGkx5hGuJaSVQ+x60xJ/Y29RBr8Tm9
# XJ59AjCCBoIwggRqoAMCAQICEDbCsL18Gzrno7PdNsvJdWgwDQYJKoZIhvcNAQEM
# BQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQH
# EwtKZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4w
# LAYDVQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4X
# DTIxMDMyMjAwMDAwMFoXDTM4MDExODIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAW
# BgNVBAoTD1NlY3RpZ28gTGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMg
# VGltZSBTdGFtcGluZyBSb290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCC
# AgoCggIBAIid2LlFZ50d3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYs
# yAhTXiDQkiUvpVdYqZ1uYoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXV
# ydmhx7Dx4IBrAou7hNGsKioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjt
# hgF7Hjx4vvyVDQGsd5KarLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1
# gASn/hp6IuHJorEu6EopoB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35Zv
# xQw6zid61qmrlD/IbKJA6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6K
# dOpuzVDR3ZUwxDKL1wCAxgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhL
# RPb7YkzM8/6NnWH3T9ClmcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb
# 49zYHr7ALL8bAJyPDmubNqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRK
# KsxCG1t6tG9oj7liwPddXEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5
# e45NuzAHteORlsSuDt5t4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjggEW
# MIIBEjAfBgNVHSMEGDAWgBRTeb9aqitKz1SA4dibwJ3ysgNmyzAdBgNVHQ4EFgQU
# 9ndq3T/9ARP/FqFsggIv0Ao9FCUwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wEwYDVR0lBAwwCgYIKwYBBQUHAwgwEQYDVR0gBAowCDAGBgRVHSAAMFAG
# A1UdHwRJMEcwRaBDoEGGP2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9VU0VSVHJ1
# c3RSU0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDA1BggrBgEFBQcBAQQpMCcw
# JQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcN
# AQEMBQADggIBAA6+ZUHtaES45aHF1BGH5Lc7JYzrftrIF5Ht2PFDxKKFOct/awAE
# WgHQMVHol9ZLSyd/pYMbaC0IZ+XBW9xhdkkmUV/KbUOiL7g98M/yzRyqUOZ1/IY7
# Ay0YbMniIibJrPcgFp73WDnRDKtVutShPSZQZAdtFwXnuiWl8eFARK3PmLqEm9Us
# VX+55DbVIz33Mbhba0HUTEYv3yJ1fwKGxPBsP/MgTECimh7eXomvMm0/GPxX2uhw
# Ccs/YLxDnBdVVlxvDjHjO1cuwbOpkiJGHmLXXVNbsdXUC2xBrq9fLrfe8IBsA4ho
# pwsCj8hTuwKXJlSTrZcPRVSccP5i9U28gZ7OMzoJGlxZ5384OKm0r568Mo9TYrqz
# KeKZgFo0fj2/0iHbj55hc20jfxvK3mQi+H7xpbzxZOFGm/yVQkpo+ffv5gdhp+hv
# 1GDsvJOtJinJmgGbBFZIThbqI+MHvAmMmkfb3fTxmSkop2mSJL1Y2x/955S29Gu0
# gSJIkc3z30vU/iXrMpWx2tS7UVfVP+5tKuzGtgkP7d/doqDrLF1u6Ci3TpjAZdeL
# LlRQZm867eVeXED58LXd1Dk6UvaAhvmWYXoiLz4JA5gPBcz7J311uahxCweNxE+x
# xxR3kT0WKzASo5G/PyDez6NHdIUKBeE3jDPs2ACc6CkJ1Sji4PKWVT0/MYIEkjCC
# BI4CAQEwajBVMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVk
# MSwwKgYDVQQDEyNTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIENBIFIzNgIR
# AKQpO24e3denNAiHrXpOtyQwDQYJYIZIAWUDBAICBQCgggH5MBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjUwNjAyMTg0MTU5WjA/
# BgkqhkiG9w0BCQQxMgQwTt1zp+VvIXb9reKT8aUGaj9JpZpQC0vtZRMucEKrPzQj
# aB5rD3LP5vVP5KnSUTCGMIIBegYLKoZIhvcNAQkQAgwxggFpMIIBZTCCAWEwFgQU
# OMkUgRBEtNxmPpPUdEuBQYaptbEwgYcEFMauVOR4hvF8PVUSSIxpw0p6+cLdMG8w
# W6RZMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdvIExpbWl0ZWQxLjAs
# BgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcgUm9vdCBSNDYCEHoj
# rtpTaZYPkcg+XPTH4z8wgbwEFIU9Yy2TgoJhfNCQNcSR3pLBQtrHMIGjMIGOpIGL
# MIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxML
# SmVyc2V5IENpdHkxHjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwG
# A1UEAxMlVVNFUlRydXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eQIQNsKw
# vXwbOuejs902y8l1aDANBgkqhkiG9w0BAQEFAASCAgAAHtwZxrmQ27kCsKwqwKf9
# RJdR8wEDH57rgQF0FqyQ2mUJjTHajAV3PcJFVSaxm6BrcBnL8egcpxpKsq8bLyDH
# j56093gSZMoMZ2Z+gNHC7Ish/cMAVymDbUyJBuXOJdAkDcEcgK4LfQY8Yad7Ef33
# 2dJSzA291tVkpoQV/C9jTgxtrZ9m/yrvsnjreK3F35AqxuqOJ8+uPfAc+pnNcsAv
# LUOk/1lR0kN6rMaFxiRuUc6wg/xni9UIbGNdFulN99CP/qT3GhUfOLuRMqbf3dR5
# tbWg2FXOCWs6sFKrGLCr/G0tePgG1dGnFZZqnZEUYpxdKswdQkxV68Jncfp+M2Gg
# 7LUKQ7gw/Q+qv5UDTfTPA1grDKkqH+y+DJYX+sh3ZqxTdPTayRghr47YVdFFHCnD
# Y4HEnU/wwsyuoZnPRIzRoqE/YjmcPBjc3GO+doUxgTcBMFdap3CPUQ2T8YNpU8Vb
# uo1YWyB0ZReWM28iOk+VIp7+ZxVLYeyrJqjGg4yxlWA7ELqCvIvx7c9KdqWuUdN3
# TWbs9L7es/Hhq8zB8kPqFzpP66QXFMrfjKmO0pWcGntJUHJwFks7h69qhHrvs/Zk
# wSghcu3wGWQ5jQ7m1B1zQ1Be+XpNEjujQKFRob26H07Y0cg4Yq0f9xQprtNc+E5T
# WNINBACDi3ppkkj9QrFfqA==
# SIG # End signature block

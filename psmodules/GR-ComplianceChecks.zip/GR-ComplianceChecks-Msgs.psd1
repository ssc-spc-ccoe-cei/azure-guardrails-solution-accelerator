ConvertFrom-StringData @'

# English strings

CtrName1 = GUARDRAIL 1: PROTECT USER ACCOUNTS AND IDENTITIES
CtrName2 = GUARDRAIL 2: MANAGE ACCESS
CtrName3 = GUARDRAIL 3: SECURE ENDPOINTS
CtrName4 = GUARDRAIL 4: ENTERPRISE MONITORING ACCOUNTS
CtrName5 = GUARDRAIL 5: DATA LOCATION
CtrName6 = GUARDRAIL 6: PROTECTION OF DATA-AT-REST
CtrName7 = GUARDRAIL 7: PROTECTION OF DATA-IN-TRANSIT
CtrName8 = GUARDRAIL 8: SEGMENT AND SEPARATE
CtrName9 = GUARDRAIL 9: NETWORK SECURITY SERVICES
CtrName10 = GUARDRAIL 10: CYBER DEFENSE SERVICES
CtrName11 = GUARDRAIL 11: LOGGING AND MONITORING
CtrName12 = GUARDRAIL 12: CONFIGURATION OF CLOUD MARKETPLACES
CtrName13 = GUARDRAIL 13: PLAN FOR CONTINUITY

# Global
isCompliant = Compliant.
isNotCompliant = Non-compliant.

# Guardrail #1
MSEntIDLicense = Microsoft Entra ID License Type
mfaEnabledFor =  MFA Authentication should not be enabled for BreakGlass account: {0} 
mfaDisabledFor =  MFA Authentication is not enabled for {0}
gaAccntsMFACheck = MFA and Count for Global Administrator Accounts

alertsMonitor = Alerts to Flag Misuse and Suspicious Activities
signInlogsNotCollected = The SignInLogs are currently not enabled. SignInLogs must be enabled to monitor and log user sign-in activities in the environment.
auditlogsNotCollected = The AuditLogs are currently not enabled. AuditLogs must be enabled to capture and log all significant audit events within the environment.
noAlertRules = No alert rules were found for SignInLogs or AuditLogs for the resource group "{0}". Please ensure that alert rules are created and configured to monitor these logs for suspicious activities.
noActionGroupsForBGaccts = No action groups were identified for Break Glass account sign-in activities. Action groups must be configured to receive alerts for Break Glass account sign-in attempts.
noActionGroupsForAuditLogs = No action groups were found for Conditional Access Policy changes and updates. Action groups must be created to receive alerts for Conditional Access Policy changes and updates.
noActionGroups = No action groups were configured for the resource group "{0}". Ensure that action groups are set up to receive alerts for the corresponding resource group's monitored activities.
compliantAlerts = The alerts for Break Glass accounts and audit logs are compliant. Appropriate action groups have been configured and are correctly receiving alerts for each monitored activity.
noAlertRuleforBGaccts = Create an alert for the Breakglass accounts using the SignInLogs. Missing one of the required alerts.
NoAlertRuleforCaps = Create an alert for the Conditional Access Policy changes and updates using the AuditLogs. Missing one of the required alerts.

globalAdminAccntsSurplus = There must be five or fewer global administrator accounts.
globalAdminAccntsMinimum = There are not enough Global Administrator Accounts found with an active status. The solution is assuming that you are using eligible Global Administrator Accounts.
allGAUserHaveMFA = All Azure native global administrator accounts have been identified and secured with at least two authentication methods.
gaUserMisconfiguredMFA = Some (one or more) Azure native global administrator accounts have not properly configured Multi-Factor Authentication (MFA): {0}

allCloudUserAccountsMFACheck = All Cloud User Accounts MFA Conditional Access Policy
allUserAccountsMFACheck = All Cloud User Accounts MFA Check
allUserHaveMFA = Native user accounts have been identified, and all users accounts have 2+ methods of authentication enabled.

userMisconfiguredMFA = One or more Native User Accounts have not configured MFA properly

retentionNotMet = The LAW {0} does not meet data retention requirements
readOnlyLaw = The {0} LAW identified is missing a read-only lock. Add the read-only lock to prevent accidental deletions.
nonCompliantLaw = The LAW {0} does not match the config.json file.
logsNotCollected = Not all of the required logs are being collected.
gcEventLogging = User Account GC Event Logging Check
gcEventLoggingCompliantComment = Logs are collected, stored and retained to meet this control's requirements.
lockLevelApproved = The Log Analytics Workspace {0} has an approved lock level of {1}. 
lockLevelNotApproved = The Log Analytics Workspace {0} has a lock level of {1} which is not approved. Approved lock levels are 'ReadOnly' or 'DeleteOnly'.
tagFound = The Log Analytics Workspace {0} has a resource tag 'sentinel' with a value of 'true' which indicates that it is being used for Sentinel. 'DeleteOnly' lock is recommended. 
sentinelTablesFound = The Log Analytics Workspace {0} has Sentinel tables configured. The Log Analytics Workspace is missing the Sentinel resource tag expected, please update or add the tag to: sentinel=true.
noLockNoTagNoTables = The Log Analytics Workspace {0} does not have an approved  'ReadOnly' or 'DeleteOnly' lock in place. Refer to the Remediation Guide for more information.

dedicatedAdminAccountsCheck = Dedicated user accounts for administration
invalidUserFile = Update the {0} file and list the highly privileged role User Principal Names (UPNs) and their regular role UPNs.
invalidFileHeader = Update the {0} file headers and list the highly privileged role User Principal Names (UPNs) and their regular role UPNs.
dedicatedAdminAccNotExist = There are privileged users identified without a highly privileged role. Review 'Global Administrator' and 'Privileged Role Administrator' role assignments in the environment and ensure that there are dedicated user accounts for highly privileged roles. 
regAccHasHProle = There are non-privileged users identified with a highly privileged role. Review 'Global Administrator' and 'Privileged Role Administrator' role assignments in the environment and ensure that there are dedicated user accounts for highly privileged roles.
dedicatedAccExist = All Cloud Administrators are using dedicated accounts for highly privileged roles.
bgAccExistInUPNlist = Break Glass (BG) User Principal Names (UPNs) exist in the uploaded .csv file. Review the user accounts .csv file and remove the Break Glass (BG) account UPNs.
hpAccNotGA = One or more highly privileged administrators identified in the .csv file are not actively using their Global Administrator role assignments at this time. Confirm that these users have an Eligible Global Administrator Assignment.
dupHPAccount = Review the highly privileged account User Principal Names (UPNs) provided for any duplicates. Remove any UPNs that are repeated.
dupRegAccount = Review the regular account User Principal Names (UPNs) provided for any duplicates. Remove any UPNs that are repeated.
missingHPaccUPN = Missing data in the 'HP_admin_account_UPN' column. Please ensure that this column is filled out before proceeding.
missingRegAccUPN = Missing data in the 'regular_account_UPN' column. Please ensure that this column is filled out before proceeding.

# GuardRail #2
MSEntIDLicenseTypeFound = Found correct license type
MSEntIDLicenseTypeNotFound = Required Microsoft Entra ID license type not found
accountNotDeleted = This user account has been deleted but has not yet been DELETED PERMANENTLY from Microsoft Entra ID
MSEntIDDeletedUser =  Microsoft Entra ID Deleted User
MSEntIDDisabledUsers = Microsoft Entra ID Disabled Users
apiError = API Error
apiErrorMitigation = Please verify existance of the user (more likely) or application permissions.
compliantComment = Didnt find any unsynced deprecated users

mitigationCommands = Verify is the users reported are deprecated.
noncompliantComment = Total Number of non-compliant users {0}. 
noncompliantUsers = The following Users are disabled and not synchronized with Microsoft Entra ID: -

removeDeletedAccount = Permanently remove deleted accounts
removeDeprecatedAccount = Remove deprecated accounts

privilegedAccountManagementPlanLifecycle = Privileged Account Management Plan (Lifecycle of Account Management)
privilegedAccountManagementPlanLPRoleAssignment = Privileged Account Management Plan (Least Privilege Role Assignment)

onlineAttackCounterMeasures = Measures to Counter Online Attacks Check: Lockouts and Banned Password Lists
onlineAttackNonCompliantC1 = The account lockout threshold does not meet the GC Password Guidance.
onlineAttackNonCompliantC2 = The banned password list does not meet the GC Password Guidance.
onlineAttackIsCompliant = The account lockout threshold and banned password list meets the GC Password Guidance. 
onlineAttackNonCompliantC1C2 = Neither the accounts lockouts or the banned password list meets the GC Password Guidance. Review and remediate.

noGuestAccounts = There are currently no GUEST User Accounts in your tenant environment.
guestAccountsNoPermission = There are GUEST User Accounts in the tenant environment and they do not have any permissions in the tenant's Azure subscription(s).
guestAssigned = This GUEST User Account has a role assignment in the tenant's Azure subscriptions.
guestNotAssigned = This GUEST User Account does not have any role assignment in the tenant's Azure subscription(s).
existingGuestAccounts = Existing Guest User Accounts
existingGuestAccountsComment = Review and validate the provided list of GUEST User Accounts. Remove GUEST User Accounts according to your departmental procedures and policies, as needed.

guestAccountsNoPrivilegedPermission = There are GUEST User Accounts in the tenant environment and they do not have any permissions that are considered "privileged" at the Subscription level.
existingPrivilegedGuestAccounts = Privileged Guest User Accounts
existingPrivilegedGuestAccountsComment = Review and validate the provided list of Privileged GUEST User Accounts. Remove Privileged GUEST User Accounts according to your departmental procedures and policies, as needed.
guestHasPrivilegedRole = This Guest user account has one or more privileged roles


accManagementUserGroupsCheck = Account Management: User Groups
userCountGroupNoMatch = Not all users have been assigned to a privileged or non-privileged user group.
noCAPforAnyGroups = None of the conditional access policies refer to one of your user groups (privileged or non-privileged).
userCountOne = There is only one user in the environment. User groups are not required. 
userGroupsMany = The number of user groups is insufficient for the current number of users. At least 2 user groups are needed. 
reqPolicyUserGroupExists = All users have been assigned to a user group, and at least one conditional access policy references a user group for access control. 
userStats = User stats - Total Users: {0}; Group Users (Total - Unique): {1}; Members in Tenants: {2}; Guests in Tenants: {3}
userNotInGroup = User is not associated with any user group.
userInGroup = No users without groups

riskBasedConditionalPolicy = Authentication Mechanisms: Risk Based Conditional Access Policies
locationBasedConditionalPolicy = Authentication Mechanisms: Location Based Conditional Access Policies
nonCompliantC1= Configure the conditional access policy to force password changes based on user risk.
nonCompliantC2= Configure the conditional access policy to prevent sign-in's from unapproved named locations.
compliantC1 = The conditional access policy to force password changes based on user risk has been configured.
compliantC2 = The conditional access policy to prevent sign-in's from unapproved named locations has been configured.

# nonCompliantC1C2 = Configure the conditional access policies outlined in the remediation guidance.
noCompliantPoliciesfound = No compliant policies found. Policies need to have a single location and that location must be Canada Only.
allPoliciesAreCompliant = All the following policies are compliant; {0}.
noCanadaNamedLocationFound = No locations have only Canada in them.
noCAallLocationsNonCompliant = No locations have all countries except Canada in them.
noEnabledPoliciesFound = No enabled conditional access policy found.
noNamedLocationFound = No named location found in the conditional access policies.
approvedIPrangeFileFound = Approved IP range list file '{0}' found and processed.
approvedIPrangeFileNotFound = Approved IP range list file '{0}' not found in container '{1}' of storage account '{2}'. Unable to verify IP range based named locations.
approvedIPrangesNotFound = Approved IP range list not found in file '{0}'. Unable to verify IP range based named locations.
noValidIPLocationsNonCompliant = No valid IP-based named locations found. 

automatedRoleForUsers = Automated Role Reviews: Role Assignments for Users and Global Administrators
noAutomatedAccessReviewForUsers = There are no automated access reviews configured for Microsoft Entra ID directory roles. Set up an annual access review for a highly privileged role.
noInProgressAccessReview = The environment has at least one scheduled role access review for Global Administrators or another Azure built-in role. However, the access review has been identified as either 'completed' or 'not started'. Create a new Global Administrator/Azure built-in role access review to reoccur and be 'in progress'.
noScheduledUserAccessReview = There are no recurring or current automated access reviews for Microsoft Entra ID directory roles. Ensure that reviews are set to recur.
compliantRecurrenceReviews = Existing access reviews meet the requirements for the control.
nonCompliantRecurrenceReviews = One or more existing Access Reviews do not meet the recurrence requirements for the control. Ensure the automated review is 'in progress' and scheduled to reoccur.

automatedRoleForGuests = Automated Guest User Reviews: Role Assignments and Access Requirements
noAutomatedAccessReviewForGuests = There are no automated access reviews configured for Guest User Accounts. Set up an annual access review for Guest Users.
noInProgressGuestAccessReview = The environment has at least one scheduled access review for guest users. However, the access review has been identified as either 'completed' or 'not started'. Create a new guest access review to reoccur and be 'in progress'.
noScheduledGuestAccessReview = The environment has no scheduled guest user access reviews. Configure a guest user access review for all user groups. 
compliantRecurrenceGuestReviews = Existing guest access reviews meet the requirements for the control.


# GuardRail #3
consoleAccessConditionalPolicy = Conditional Access Policy for Cloud Console Access
adminAccessConditionalPolicy = Administrator Access Restrictions Applied - device management/trusted locations

mfaRequiredForAllUsers = Multi-Factor authentication required for all users by Conditional Access Policy
noMFAPolicyForAllUsers = No conditional access policy requiring MFA for all users and applications was found. A Conditional Access Policy meeting the following requirements must be configured: 1. state = 'enabled'; 2. includedUsers = 'All'; 3. includedApplications = 'All'; 4. grantControls.builtInControls contains 'mfa' OR grantControls.authenticationStrength is configured; 5. clientAppTypes contains 'all' or all individual types selected (browser, mobileAppsAndDesktopClients, exchangeActiveSync, other); 6. userRiskLevels = @(); 7. signInRiskLevels = @(); 8. platforms = null; 9. locations = null; 10. devices = null; 11. clientApplications = null
noDeviceFilterPolicies = Missing a required conditional access policy. At least one policy needs to have device filters enabled with target resources, administrator roles included and enabled.
noLocationFilterPolicies = Missing a required conditional access policy. At least one policy needs to check for named/trusted locations with administrator roles included and enabled.
hasRequiredPolicies = Required conditional access policies for administrator access exist. 
noCompliantPoliciesAdmin = No compliant policies found for device filters and named/trusted locations. Please ensure that there is at least one policy of each. One for device filters with a target resource and another for named/trusted locations.

# GuardRail #4
monitorAccount = Monitor Account Creation
checkUserExistsError = API call returned Error {0}. Please Check if the user exists.
checkUserExists = Please Check if the user exists.
ServicePrincipalNameHasNoReaderRole = SPN doesnt have Reader Role on the ROOT Management Group.
ServicePrincipalNameHasReaderRole = SPN has Reader Role on the ROOT Management Group.
ServicePrincipalNameHasNoMarketPlaceAdminRole = SPN doesnt have Marketplace Admin Role on the Marketplace.
ServicePrincipalNameHasMarketPlaceAdminRole = SPN has Marketplace Admin Role on the Marketplace.
NoSPN = SPN doesnt exist.
SPNCredentialsCompliance = SPN Credentials Compliance

SPNSingleValidCredential = SPN has a single valid credential. {0}
SPNMultipleValidCredentials = SPN has multiple valid credentials. {0}
SPNNoValidCredentials = SPN has no valid credentials. {0}
FinOpsToolStatus = FinOps Tool Status
SPNNotExist = Service Principal 'CloudabilityUtilizationDataCollector' does not exist
SPNIncorrectPermissions = Service Principal 'CloudabilityUtilizationDataCollector' does not have the required Reader role
SPNIncorrectRoles = Service Principal does not have the required Cloud Application Administrator and Reports Reader roles.
FinOpsToolCompliant = The FinOps tool is compliant with all requirements.
FinOpsToolNonCompliant = The FinOps tool is not compliant. Reasons: {0}

# GuardRail #5
pbmmCompliance = PBMMPolicy Compliance
policyNotAssigned = The Policy or Initiative is not assigned to the {0}
excludedFromScope = {0} is excluded from the scope of the assignment

policyNotAssignedRootMG = The Policy or Initiative is not assigned on the Root Management Groups
rootMGExcluded =This Root Management Groups is excluded from the scope of the assignment
subscription = subscription
managementGroup = Management Groups
notAllowedLocation =  Location is outside of the allowed locations. 
allowedLocationPolicy = AllowedLocationPolicy
dataAtRest = PROTECTION OF DATA-AT-REST


# GuardRail #6
pbmmApplied = PBMM initiative has been applied.
pbmmNotApplied = PBMM initiative has not been applied. Apply the PBMM initiative.
reqPolicyApplied = All required policies are applied.
reqPolicyNotApplied = The PBMM initiative is missing one or a few of the selected policies for evaluation. Consult the remediation Playbook for more information.
grExemptionFound = Remove the exemption found for {0}. 
grExemptionNotFound = Required Policy Definitions are not exempt.
noResource = No applicable resources for the selected PBMM Initiative's policies to evaluate.
allCompliantResources = All resources are compliant.
allNonCompliantResources = All resources are non-compliant.
hasNonComplianceResource = {0} out of the {1} applicable resources are non-compliant against the selected policies. Follow the Microsoft remediation recommendations.


# GuardRail #7
appGatewayCertValidity = Application Gateway Certificate Validity
noSslListenersFound = No SSL listener found/configured for Application Gateway: {0}. 
expiredCertificateFound = Expired certificate found for listener '{0}' in Application Gateway '{1}'.
unapprovedCAFound = Unapproved Certificate Authority (CA) found for listener '{0}' in Application Gateway '{1}'. Issuer: {2}.
unableToProcessCertData = Unable to process certificate data for listener '{0}' in Application Gateway '{1}'. Error: {2}.
unableToRetrieveCertData = Unable to retrieve certificate data for listener '{0}' in Application Gateway '{1}'.
noHttpsBackendSettingsFound = No HTTPS backend settings found/configured for Application Gateway: {0}.
manualTrustedRootCertsFound = Manual trusted root certificates found for Application Gateway '{0}', backend setting '{1}'.
allBackendSettingsUseWellKnownCA = All backend settings for Application Gateway '{0}' use well‑known Certificate Authority (CA) certificates.
noAppGatewayFound = No Application Gateways found in this subscription: {0}.
allCertificatesValid = All certificates are valid and from approved Certificate Authorities (CAs).
approvedCAFileFound = Approved Certificate Authority (CA) list file '{0}' found and processed.
approvedCAFileNotFound = Approved Certificate Authority (CA) file '{0}' not found in container '{1}' of storage account '{2}'. Unable to verify certificate authorities.
appServiceHttpsConfig = Azure App Service: HTTPS Application Configuration
keyVaultCertValidationFailed = Certificate stored in Key Vault for listener '{0}' in Application Gateway '{1}' could not be validated. The CAC solution requires 'Key Vault Secrets User' permissions on the customer Key Vault to validate certificates. If the vault is in Access Policy mode, grant the Automation Account managed identity the 'Get' permission on Secrets for this Key Vault. Contact your administrator to grant the CAC Automation Account managed identity access to this Key Vault if desired.
keyVaultCertRetrievalFailed = Unable to retrieve certificate from Key Vault for listener '{0}' in Application Gateway '{1}'. Certificate may be stored in Key Vault and requires proper permissions to access.

dataInTransit = Secure Connections for Redis Cache and Storage Accounts

storageAccTLS12 = Storage Accounts TLS 1.2
storageAccValidTLS = All storage accounts are using TLS1.2 or higher. 
storageAccNotValidTLS= One or more storage accounts are using TLS1.1 or less. Update the storage accounts to TLS1.2 or higher.
storageAccNotValidList = The following storage accounts are not valid: {0}

functionAppHttpsConfig = Azure Functions: HTTPS Application Configuration

appServiceTLSConfig = Azure App Service TLS Configuration
functionAppTLSConfig = Azure Functions App TLS Configuration
sqlDbTLSConfig = Azure SQL Database TLS Configuration
appGatewayWAFConfig = Application Gateway WAF TLS Configuration
policyNotConfigured = Required policy is not assigned at tenant level. Please assign the policy to ensure compliance.
policyCompliant = All resources are compliant with the required policy.
policyNotCompliant = Resource is not compliant with the required policy. Please review and remediate.
policyHasExemptions = Policy has exemptions configured. All resources must be evaluated by this policy.
policyNoApplicableResources = No applicable resources found. Policy is assigned at tenant level.


# GuardRail #8
noNSG=No NSG is present.
subnetCompliant = Subnet is compliant.
nsgConfigDenyAll = NSG is present but not properly configured (Missing Deny all last Rule).
nsgCustomRule = NSG is present but not properly configured (Missing Custom Rules).
networkSegmentation = Segmentation
networkSeparation = Separation
routeNVA = Route present but not directed to a Virtual Appliance.
routeNVAMitigation = Update the route to point to a virtual appliance
noUDR = No User defined Route configured.
noUDRMitigation = Please apply a custom route to this subnet, pointing to a virtual appliance.
subnetExcludedByTag = Subnet '{0}' is excluded from compliance because VNET '{1}' has tag '{2}' with a value of 'true'
subnetExcludedByReservedName = Subnet '{0}' is excluded from compliance because its name is in the reserved subnet list '{1}'
subnetExcludedByVNET = Subnet '{0}' is not being checked for compliance because the VNET '{1}' has tag '{2}' with a value of 'true'
networkDiagram = Network architecture diagram
highLevelDesign = High level design documentation
noSubnets = No subnets found in the subscription.
cloudInfrastructureDeployGuide = Cloud Infrastructure Deployment Guide or Applicable Landing Zone Details

# GuardRail #9
ddosPublicIpCheckFailed = Failed to check public IP DDoS protection for subscription '{0}'. Error: {1}
ddosPublicIpCheckFailedNoProtection = Public IP DDoS protection could not be checked for subscription '{0}'. {1} out of {2} included VNet(s) have DDoS protection enabled. Public IP results are unavailable.
ddosSubscriptionNoResources = Subscription '{0}' has no included VNets or public IPs to evaluate.
ddosSubscriptionProtectionFound = Subscription '{0}' has DDoS protection enabled on {1} out of {2} included VNet(s) and {3} out of {4} public IP(s).
ddosSubscriptionProtectionMissing = Subscription '{0}' does not have DDoS protection enabled on any included VNet or public IP. Included VNet(s) protected: {1} out of {2}. Public IP(s) protected: {3} out of {4}.
subscriptionScope = Subscription scope

networkWatcherEnabled=Network Watcher exists for region '{0}'
networkWatcherNotEnabled=Network Watcher not enabled for region '{0}'
noVNets = No VNet found in the subscription.
vnetExcludedByParameter = VNet '{0}' is excluded from compliance because it is in the excluded VNet list '{1}'
vnetExcludedByTag = VNet '{0}' is excluded from compliance because it has tag '{1}' with a value of 'true'
vnetDDosConfig = DDoS Configuration - Subscription
networkWatcherConfig = VNet Network Watcher configuration
networkWatcherConfigNoRegions = Either due to no VNETs or all VNETs being excluded, there are no regions to check for Network Watcher configuration
noFirewallOrGateway = This subscription does not have a firewall or an application gateway in use.
noFirewallOrGatewayCompliant = This subscription is compliant due to the presence of a Firewall, or a Application Gateway (with a Web Application Firewall) in another subscription. Ensure that this subscription is routing source IP Addresses appropriately.
wAFNotEnabled = The application gateway assigned does not have configured Web Application Firewalls (WAFs). Enable a WAF on the application gateway.
firewallFound = There is a {0} associated to this subscription.
wAFEnabled = There is an application gateway associated to this subscription with the appropriate configurations.
networkSecurityTools = Tools In Use For Limiting Access To Authorized Source IP Addresses
networkInterfaceIPs = Policy for Limiting Public IPs
policyNoApplicableResourcesSub = Policy is assigned at the subscription level. No applicable resources found
policyNotConfiguredSub = Required policy is not assigned to this subscription: {0}. Please assign the policy to ensure compliance.
policyAssignedSub = Required policy is assigned at a scope covering this subscription: {0}.

# GuardRail #10
cbsSubDoesntExist = CBS Subscription doesnt exist
cbcSensorsdontExist = The expected CBS sensors do not exist in these subscriptions:
cbssMitigation = Check subscription provided: {0} or check existence of the CBS solution in the provided subscription.
cbssCompliant = Found resources in these subscriptions: 
cbssV3DetectedSuffix = (CBS Sensor V3 detected)
cbssV2DeprecatedWarning = CBS Sensor V2 is deprecated. Please upgrade to CBS Sensor V3.

# GuardRail #11
serviceHealthAlerts = Service Health Alerts and Events Check

createLAW = Please create a log analytics workspace according to guidelines.
connectAutoAcct = Please connect an automation account to the provided workspace.
setRetention730Days = Set retention of the workspace to 730 days for workspace: 
addActivityLogs = Please add the Activity Logs solution to the workspace: 
addUpdatesAndAntiMalware = Please add the both the Updates and Anti-Malware solution to the workspace: 
configTenantDiag = Please configure the Tenant diagnostics to point to the provided workspace: 
addAuditAndSignInsLogs = Please enable Audit Logs and SignInLogs in the Tenant Dianostics settings.

logsAndMonitoringCompliantForDefender = The Logs and Monitoring are compliant for Defender.
createHealthLAW = Please create a workspace for Health Monitoring according to the Guardrails guidelines.
enableAgentHealthSolution = Please enable the Agent Health Assessment solution in the workspace.
lawEnvironmentCompliant = The environment is compliant.

setSecurityContact = Please set a security contact for Defender for Cloud in the subscription. {0}
setDfCToStandard = Please set Defender for Cloud plans to Standard. ({0})

noServiceHealthActionGroups = Missing an action group for Service Health Alerts associated with the subscription: {0}
noEnabledHealthAlert = Service Health Alerts are not enabled for this subscription. Ensure that service health alerts are configured on this subscription and that the action group associated with the alert has at least two different contacts.
EventTypeMissingForAlert = Missing a required event type (Service Issue, Health Advisory, or Security Advisory) for the subscription: {0}
noServiceHealthAlerts = Could not retrieve any configured alerts for the subscription: "{0}". Ensure all subscriptions have Service Health Alerts configured and the action group associated to the alert  has at least two different contacts.
nonCompliantActionGroups = This subscription has Service Health Alerts, but not all action groups are correctly configured. A minimum of two email addresses or subscription owners are required for the action group.
compliantServiceHealthAlerts = This subscription has Service Health Alerts, and the action group has at least two different contacts.

monitoringChecklist = Monitoring Checklist: Use Cases


msDefenderChecks = Microsoft Defender for Cloud Alerts and Events Check
NotAllSubsHaveDefenderPlans = The subscription lack a defender plan. Enable Defender monitoring for this subscription.
errorRetrievingNotifications = Defender alert notifications for this subscription is not configured. Ensure they match the Remediation Guidance requirements.
EmailsOrOwnerNotConfigured = Defender alert notifications for the subscription {0} do not include at least two email addresses or subscription owners. Configure this to ensure alerts are sent correctly.
AlertNotificationNotConfigured = Defender alert notifications are incorrect. Set the severity to Medium or Low and review the Remediation Guidance.
AttackPathNotificationNotConfigured = Defender alerts must include attack path notifications. Ensure that the severity is set to Medium or Low for each subscription's alerts, following the guidelines provided in the Remediation Guidance.
DefenderCompliant = MS Defender for Cloud is enabled for this subscription, and email notifications are properly configured.
DefenderEnabledNonCompliant = MS Defender for Cloud is enabled for this subscription, but the security contact to receive email notifications are not properly configured.
NoMappedResourcesOrMappingIncomplete = There are not any resources (i.e., virtual machines, servers, storage accounts etc.,) being directly protected by Defender for Cloud Workload Protection (CWP) Standard tier service offering.
CwpPlansNotStandard = The following CWP plans in use are not considered Standard tier for Defender for Cloud: {0}.
CoverageOk = All CWP plans are using a Defender for Cloud Workload Protection (CWP) Standard tier service offering and are considered compliant.
FoundationalCspmOnlyInfo = [Informational] Only Foundational CSPM (free tier) is active for this subscription. Defender CSPM and CWP plans are not enabled.
CwpInformational = [Informational] {0}


# GuardRail #12
mktPlaceCreation = MarketPlaceCreation
mktPlaceCreatedEnabled = The Private Marketplace has been created and enabled.
mktPlaceCreatedNotEnabled = The Private Marketplace has been created but not enabled.
mktPlaceNotCreated = The Private Marketplace has not been created.
enableMktPlace = Enable Azure Private MarketPlace as per: https://docs.microsoft.com/en-us/marketplace/create-manage-private-azure-marketplace-new

# Guardrail #13
bgMSEntID = Break Glass Microsoft Entra ID P2
bgProcedure = Break Glass Account Procedure
bgCreation = Break Glass account Creation

bgAccountOwnerContact = Break Glass Account Owners Contact information
bgAccountsCompliance = First Break Glass Account Compliance status = {0}, Second Break Glass Account Compliance status = {1}
bgAccountsCompliance2 = Both accounts are identical, please check the config.json file
bgAuthenticationMeth =  Authentication Methods 
firstBgAccount = First Break Glass Account
secondBgAccount = Second Break Glass Account
bgNoValidLicenseAssigned = No Microsoft Entra ID P2 license assigned to
bgValidLicenseAssigned =  has a valid Microsoft Entra ID P2 assigned
bgAccountHasManager = BG Account {0} has a Manager
bgAccountNoManager = BG Account {0} doesn't have a Manager 
bgBothHaveManager = Both BreakGlass accounts have manager

bgValidSignature = Valid Signatures and Approvals for Break Glass Account Procedure
bgAccountTesting = Break Glass Account Testing Cadence
bgAccountNotExist = One or both of the Break Glass Account User Principal Names (UPNs) provided do not exist in the environment. Review the provided Break Glass Account UPNs for accuracy.
bgAccountLoginNotValid = Last login for the provided Break Glass Accounts is greater than a year. Ensure regular testing of the Break Glass Account procedure and login process.
bgAccountLoginValid = Last login for the provided Break Glass Accounts is within a year. Ensure regular testing of the Break Glass Account procedure and login process.

# GR-Common
procedureFileFound = Compliant. Required file has been uploaded for review by Cloud Security Compliance assessors. '{0}' found.
procedureFileNotFound = Non-compliant. Could not find '{0}'. Create and upload the appropriate file in Container '{1}' in Storage Account '{2}' to become compliant.
procedureFileNotFoundWithCorrectExtension = Non-compliant. Required fileName '{0}' found. However, the extension is not supported. Create and upload the appropriate file in Container '{1}' in Storage Account '{2}' to become compliant.

procedureFileDataInvalid = The global administrator file(s) contain(s) invalid User Principal Names (UPNs). Ensure that UPNs start with a hyphen, and type each of them on a new line.
globalAdminFileFound = File {0} found in Container.
globalAdminFileNotFound = Could not find document for {0}, please create and upload a file with the name '{1}' in Container '{2}' on Storage Account '{3}' to confirm you have completed the Item in the control.
globalAdminFileEmpty = Empty file {0} found in Container.
globalAdminNotExist = Global Administrator accounts not found or declared in file {0}.
globalAdminMFAPassAndMin2Accnts = Two or more global administrator accounts have been identified, and multi-factor authentication (MFA) is enabled for all of them.
globalAdminMinAccnts = There must be at least two global administrator accounts.

globalAdminAccntsMFADisabled1 = The following account: {0} does not have multi-factor authentication (MFA) enabled
globalAdminAccntsMFADisabled2 = The following accounts: {0} do not have multi-factor authentication (MFA) enabled 
globalAdminAccntsMFADisabled3 = None of the global administrator accounts have multi-factor authentication (MFA) enabled 

'@
# SIG # Begin signature block
# MIIxfwYJKoZIhvcNAQcCoIIxcDCCMWwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDmGvu9QFc5tNbE
# Yw3j9jO3CMnrjLgPtIWPEDCaywP1/KCCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0fMIIdGwIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# J0TqseDMWOHtA5/1K+8PkoWE7GkLa5WtJ0+Z4gISmi0wDQYJKoZIhvcNAQEBBQAE
# ggIAKT8SoFcLUH/b3+jSbHCjGhGC0Dpg9LKXzAEnSw7ExmcEtvr90fKfdmqqvotO
# 7GN/rPpVvYh/d9XzksLYyofF58NtXFR1Rt5RBo/ShBjvGCWkLZaoxGIGG3PIOqCh
# GHv+y50Z3MgSSFdzjll4EBPVEbqOzG2UJFqcJa8yiFwc8kvOooof0CuGVQeQGpDg
# CA/BoXmpxR0PPeaBvEsmGspGWYmY5aNRftVszIbx7ar4xstzeWqhb6LN1JlcBRKl
# m3734CKK78npLnQIDbeKAmvH1ILihtrL4Z5znJv7ZdK/G4nVb+JAtpcyqhf13GEz
# UWZ5KilQXoimR+FpFUDR0v6ghwQ+Ij9toKXY2j0/cBEfnSzXaJa1U8Oqbz9Zer+G
# z+p/7ql0EptqEWkT0aR/ClzYmAD8AkECpye4hNBrk9vjsqul+9RivqHM4bSN4IB9
# Gvt4OP0q/DWypqfH1UxtRBYE6nwSVwJlXQny9vWajTRTNWblSh5dSxV0yDzueAbV
# IP9AIhhR3HoSnKn3UpGzFrJhyWioxP1WtgOPergjKZ+1peOu06AMqec5HeqvBV+k
# tKLQo4tEv22Vsn/00noO9xdEH60QsJyFWjqz/x5YrNMQgO6Id8ZeeASbthFr2m+o
# jm0aLUnE64BALsgJLu8ZLNp4qHFsi2m+vyObjs9bYoYONoOhghnsMIIZ6AYKKwYB
# BAGCNwMDATGCGdgwghnUBgkqhkiG9w0BBwKgghnFMIIZwQIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH4BgsqhkiG9w0BCRABBKCB6ASB5TCB4gIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCDA2VCXGp8N8IpMY3G7/qfXWBqVJ9vLnS64jPYE0DZf
# rAIVAP4MN1UQgr8kDGkhvq+2uznXfPB7GA8yMDI2MDcxNDE1NTIxOVqgdqR0MHIx
# CzAJBgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMP
# U2VjdGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0
# YW1waW5nIFNpZ25lciBSMzegghQXMIIG4jCCBMqgAwIBAgIRAOdO8lWwUE/626bf
# 9/yLoxUwDQYJKoZIhvcNAQEMBQAwVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBDQSBSNDEwHhcNMjYwMzI1MDAwMDAwWhcNMzcwNjI0MjM1OTU5WjByMQsw
# CQYDVQQGEwJHQjEXMBUGA1UECBMOR3JlYXRlciBMb25kb24xGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBTaWduZXIgUjM3MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# sv/DbUvcUNlFLQURd9m4+1St5+JudFKo5P803Iks4mFeNB9SymodP6BJJWBuNhOF
# Qj9w77AVAeg5qQpA2dIwp2QTyBHr2h9eWSTkMBVj9mV6+WI5SaW+vDZW7PhJTbys
# d9v9WB3Xt6qlEi8m47pcTy8+k/OfhziKiuzNQXqfC7KcoRD/6up8OZBsU0qxr7n5
# nh/iRfAp1QXFTBQONBZSGIdHAyVRYYX033VoC8v71rizEKCpH97Pxbwcn9eq9K7W
# 8h5v4npsMUoqCS/c8mQwylDQGx15dHYV6NlcVFdjXD11l7qCrIy/unH5OlZtgx58
# QJRXRbGgQyBdSTpEpwuj3i5Qc52Z9m7hd7yCGCXKujf83hUQpOPx1w8+84EbEUTH
# VAfq4cpORaGWgY8NJy6txmd3wpS1MeXrOaVAMczTgzAZ+yZBWIqdgQBgTxEeXldE
# ToZOrRkxvn1IjIlfr4I4NWJz+Rb52FshLVnkA/wdoad789Eb7XZDNKd4oMmnc636
# TgauaaVZP2LLoU0JD/fYr53hwBn4uXu5ZsSfpnqAT60S7szJm/Na882xEoyRzLJ+
# UVbXOlHLO63DKkAtdz1CDuwWxgRE1drnwplepT06dz+1yTr5p1AkUz21bzE6cT/8
# /kjh4OPzggYYqrOBQPfuKEL5ZJPcN9jRgEpYvRlq5ucCAwEAAaOCAY4wggGKMB8G
# A1UdIwQYMBaAFDp0pQxnxkJQwv21/Me7KTSC9Hq5MB0GA1UdDgQWBBRhEOl6Eq9R
# xIXU8s+kdA9QzSCv+DAOBgNVHQ8BAf8EBAMCBsAwDAYDVR0TAQH/BAIwADAWBgNV
# HSUBAf8EDDAKBggrBgEFBQcDCDBKBgNVHSAEQzBBMAgGBmeBDAEEAjA1BgwrBgEE
# AbIxAQIBAwgwJTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMw
# SgYDVR0fBEMwQTA/oD2gO4Y5aHR0cDovL2NybC5zZWN0aWdvLmNvbS9TZWN0aWdv
# UHVibGljVGltZVN0YW1waW5nQ0FSNDEuY3JsMHoGCCsGAQUFBwEBBG4wbDBFBggr
# BgEFBQcwAoY5aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGlt
# ZVN0YW1waW5nQ0FSNDEuY3J0MCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0
# aWdvLmNvbTANBgkqhkiG9w0BAQwFAAOCAgEAA+o9jdGszfoZepOmygef1OlbkjrP
# d2QW9z3M8vVbQSCruPeO2eRsC9GhZ4CMZfhkrixayYD67gQkbyiRCbJu5L/i0NQj
# lQhBvbWfiEba+KHFKGud5YHRWhDZUtDeMIJGZG0BD7/sftZUo2Ifk+CXi/ZlM50+
# xK3OkqeXVi5GubDD/5txmYuqCT3T3LAilmoB+5th9sQxiMhyQuT3R/aYb4vypoZJ
# LYklUzTalXleW1nV9s4UROlE389CHDKAi/fepRSMnV8TghODDQxwzNGrOJZ04k/y
# hzHHDupfHPU51FYJqXIvWq9SAAWdlNV1JGIxhkp/TAtxBwz/Vd/VbgVb2d9/wRFf
# xFkka39O0+4xaZSl/oEK/1DqjxjJRO2Se9lGlJDScu21Zd23Cys3aYyB8y5H/+DF
# WtVe8PMKgr+VuIDp0Rk5bneVDAEW0TPAT8Ufwl2F6DJiDg/KZk5NmsYES+CxvF7b
# nISEnQh0ZrWnAJixquV0mElUx01wA5TuPIgyodxzNq/fC0hen9LBtdnfFfSZ+wt8
# A1Injsbio+DHVq1voYiVNpBfO7+nh9NB4AhRXNldPgr3zgjJ+47s0uNYy2iDXAZS
# lkP3ym/7gy31jlu989SNpRWO14/LUNV2LSuXkRI1iLTPI6ZdXG0DnPPG7UftF0tk
# 5m6BP9eNfr2tj1swgganMIIEj6ADAgECAhEAkKwIciD9xafEa1zHDfc9BjANBgkq
# hkiG9w0BAQwFADBXMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1p
# dGVkMS4wLAYDVQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3Qg
# UjQ2MB4XDTI2MDMyNTAwMDAwMFoXDTQxMDMyNDIzNTk1OVowVTELMAkGA1UEBhMC
# R0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQ
# dWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDEwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQCu5EqiAa2CHGL5Zi1bmgPM8NUXwYZJ+BtQqHps43GLTC+sjVLy
# psBh+8uv+TLkgtVGD//vSmA0qrzELf9YRCh2MTAA/aGaQZKGg0BRCmziR3pbCnvg
# WjtGXBDUyn3j3K2lZAO8KxgFtlxwOYEAkL+CCqK4v9zzTl8ZwzDpPMiDIFa5THk8
# an1ieF5I09cXNrPQw+1ER1liThaG0z6FrOpqwxZWmPRZQBw2E32878UB1bL0Zp91
# vuWZgsMpNNiPCoBj0/1F+LE8+NRokfqacFI0F2tftrRB2W7HQClLR9zjxFbWb5be
# 2rceIfNyHUUfKGIvMI2NzoxSlxXnFqUG887D8W1Cj8DFok688JKxWvHR/9aQykSb
# d+9Vutj36ij2sgq/125wTpUZ/AgC0ph50bRs7gFrUyaXE9wSsOqMvCCC+sEm7vd/
# BemSG0TSHNXSmyCba+FCzekeWX03TRIcF3Laqd0Rw24OH7jpei4zaGhcI7nfdhBA
# 4c8RScxNY6jeHLHHmSMMTk9Wqn7H4dLhUBP5YEwbgbN4uv1i9ltTnHli8t1xHV0S
# tX9BFgrnmunTX19kUXY1H5ORJbRZyZDdvm1oZyteDj0SnMozr+YSmdIleDUTXdfo
# Y7b2taz8s2+QbOxLxcahEIYGWzqu6h955tKwcANHcZ4gTmAhT3btuOiQsQIDAQAB
# o4IBbjCCAWowHwYDVR0jBBgwFoAU9ndq3T/9ARP/FqFsggIv0Ao9FCUwHQYDVR0O
# BBYEFDp0pQxnxkJQwv21/Me7KTSC9Hq5MA4GA1UdDwEB/wQEAwIBhjASBgNVHRMB
# Af8ECDAGAQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMCMGA1UdIAQcMBowCAYG
# Z4EMAQQCMA4GDCsGAQQBsjEBAgEDCDBMBgNVHR8ERTBDMEGgP6A9hjtodHRwOi8v
# Y3JsLnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3RhbXBpbmdSb290UjQ2
# LmNybDB8BggrBgEFBQcBAQRwMG4wRwYIKwYBBQUHMAKGO2h0dHA6Ly9jcnQuc2Vj
# dGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYucDdjMCMG
# CCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0aWdvLmNvbTANBgkqhkiG9w0BAQwF
# AAOCAgEAMt5SR2bxngNm+N8oc6Gq76Gx1c235fkX7jw8Ho9MAkJGADerHE7dhsBX
# ttqmzgr/7ZZahZSykGRPhPY1crj028kB8KzO0dKC2qQBAwtfgqMLKkkX/6bYq2uT
# 33eD6ByAp2/XKD0LcmZh0kKecvSBr6ln9ajX6u1dnx2fA7xEKy1M3qBhfQSUWLtj
# s2nFt0ELVLptzTlX9ID0cL+iOPfdboZ3CelT+JXKVKR2Sge0d4YiFAtPZkfSo8z1
# Z1x7y/Z9mwMIlBAnyuWXs4YsNuxdrYIt/QxE31PDOJ9DesS4Bc7H9OTORlEV/Avf
# iF/VepKZpira1MzLYuCw+uoLZn/pkpvd+CvNTS+mEHjBJNa6WK1j8qXFu+jIq+sG
# 9QILHiyB6p/xpHrkJu8zkw393+VqF9eKlTY2VjRxdycZLrVemZ4Yp3wi33b+W58C
# llH3HqjmowlZ7SOrgmx8YwYOkgrHsXOQHyBp6O4FRb8In0+FzjT7ElGie9V7CfhL
# 3IlVFZ4zjuKsZtH1iU3fGu4z/JnOGT6sCb0BbTqe/uhvpFCQBdH5xPGIA/LrbQUX
# jU2tWJgHhTIqnN/HvHyOHi5tM4zP3nhgh2rJ6Kqq2xsHBeNYs/R18xQ8DeIg+c90
# Eoaeh0YlN1KU8AyYol3K9M+qY5ez8syd/7ZlrRnoVewgH3P1pcswggaCMIIEaqAD
# AgECAhA2wrC9fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBDAUAMIGIMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxMLSmVyc2V5IENpdHkx
# HjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwGA1UEAxMlVVNFUlRy
# dXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0yMTAzMjIwMDAwMDBa
# Fw0zODAxMTgyMzU5NTlaMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdv
# IExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcg
# Um9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCIndi5RWed
# Hd3ouSaBmlRUwHxJBZvMWhUP2ZQQRLRBQIF3FJmp1OR2LMgIU14g0JIlL6VXWKmd
# bmKGRDILRxEtZdQnOh2qmcxGzjqemIk8et8sE6J+N+Gl1cnZocew8eCAawKLu4TR
# rCoqCAT8uRjDeypoGJrruH/drCio28aqIVEn45NZiZQI7YYBex48eL78lQ0BrHeS
# mqy1uXe9xN04aG0pKG9ki+PC6VEfzutu6Q3IcZZfm00r9YAEp/4aeiLhyaKxLuhK
# KaAdQjRaf/h6U13jQEV1JnUTCm511n5avv4N+jSVwd+Wb8UMOs4netapq5Q/yGyi
# QOgjsP/JRUj0MAT9YrcmXcLgsrAimfWY3MzKm1HCxcquinTqbs1Q0d2VMMQyi9cA
# gMYC9jKc+3mW62/yVl4jnDcw6ULJsBkOkrcPLUwqj7poS0T2+2JMzPP+jZ1h90/Q
# pZnBkhdtixMiWDVgh60KmLmzXiqJc6lGwqoUqpq/1HVHm+Pc2B6+wCy/GwCcjw5r
# mzajLbmqGygEgaj/OLoanEWP6Y52Hflef3XLvYnhEY4kSirMQhtberRvaI+5YsD3
# XVxHGBjlIli5u+NrLedIxsE88WzKXqZjj9Zi5ybJL2WjeXuOTbswB7XjkZbErg7e
# beAQUQiS/uRGZ58NHs57ZPUfECcgJC+v2wIDAQABo4IBFjCCARIwHwYDVR0jBBgw
# FoAUU3m/WqorSs9UgOHYm8Cd8rIDZsswHQYDVR0OBBYEFPZ3at0//QET/xahbIIC
# L9AKPRQlMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLnVzZXJ0cnVzdC5jb20vVVNFUlRydXN0UlNBQ2VydGlmaWNh
# dGlvbkF1dGhvcml0eS5jcmwwNQYIKwYBBQUHAQEEKTAnMCUGCCsGAQUFBzABhhlo
# dHRwOi8vb2NzcC51c2VydHJ1c3QuY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAOvmVB
# 7WhEuOWhxdQRh+S3OyWM637ayBeR7djxQ8SihTnLf2sABFoB0DFR6JfWS0snf6WD
# G2gtCGflwVvcYXZJJlFfym1Doi+4PfDP8s0cqlDmdfyGOwMtGGzJ4iImyaz3IBae
# 91g50QyrVbrUoT0mUGQHbRcF57olpfHhQEStz5i6hJvVLFV/ueQ21SM99zG4W2tB
# 1ExGL98idX8ChsTwbD/zIExAopoe3l6JrzJtPxj8V9rocAnLP2C8Q5wXVVZcbw4x
# 4ztXLsGzqZIiRh5i111TW7HV1AtsQa6vXy633vCAbAOIaKcLAo/IU7sClyZUk62X
# D0VUnHD+YvVNvIGezjM6CRpcWed/ODiptK+evDKPU2K6synimYBaNH49v9Ih24+e
# YXNtI38byt5kIvh+8aW88WThRpv8lUJKaPn37+YHYafob9Rg7LyTrSYpyZoBmwRW
# SE4W6iPjB7wJjJpH29308ZkpKKdpkiS9WNsf/eeUtvRrtIEiSJHN899L1P4l6zKV
# sdrUu1FX1T/ubSrsxrYJD+3f3aKg6yxdbugot06YwGXXiy5UUGZvOu3lXlxA+fC1
# 3dQ5OlL2gIb5lmF6Ii8+CQOYDwXM+yd9dbmocQsHjcRPsccUd5E9FiswEqORvz8g
# 3s+jR3SFCgXhN4wz7NgAnOgpCdUo4uDyllU9PzGCBJMwggSPAgEBMGowVTELMAkG
# A1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2Vj
# dGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDECEQDnTvJVsFBP+tum3/f8
# i6MVMA0GCWCGSAFlAwQCAgUAoIIB+jAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDcxNDE1NTIxOVowPwYJKoZIhvcNAQkEMTIE
# MKFcaRVb/kGTQP8HK43DQDiWCLhTpSBfrrtIdpPNieeFgxJ8Tkh1GhVRcyWZwMgF
# ZjCCAXsGCyqGSIb3DQEJEAIMMYIBajCCAWYwggFiMBYEFOl4GKko2hUKn+G/nMx6
# q7mgDu6sMIGIBBRlwyhpb31OUCz9A8fCBpcYyvv3TzBwMFukWTBXMQswCQYDVQQG
# EwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQDEyVTZWN0aWdv
# IFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2AhEAkKwIciD9xafEa1zHDfc9
# BjCBvAQUhT1jLZOCgmF80JA1xJHeksFC2scwgaMwgY6kgYswgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5AhA2wrC9fBs656Oz3TbLyXVo
# MA0GCSqGSIb3DQEBAQUABIICAFf1V1rF8P3bteQSotWj24TmYIVQSqR4JwMD2Tci
# SONOPFeXCcKvGlVU7vpHIk9KcREORi86OFuVtNZvgr8cQ7Td0g23CDmKBwhec2ze
# k06G/BHU28VUX0cTtnKkeGjah+zmzEAF6xEweQXmh1WFyCsVdzs5jueUm5AfP0Sp
# PrAv5+uS5GjDD4x7vS03tLhy5VvvicNVIl7UNZv7zsZmQNkcxK0JWYTGvu9VxQfh
# i2zJNuE8OxBvq/LevPeSeRoPGUJ9Yt5YFIu+uglxzLIt9ZjiLgDGjsNSkd3IHXV2
# x7cwo+Cztz4Q8+6gQnHCcxn4JMVTyqIh8P0LET+bk40MaKyYmNHhJjLmHZas6MVO
# KRqxtUzegp9UrRX5TiIXnAuX6YkxjvAGZa9oQpO276on9wJRDBPVmwsnTZBboA+G
# fsglylMJBJIA6NY7A7uaaFHYFlmgy3jlbvH6GVV2G8VVoQHViNOBemnAUBCou7LD
# y/ojkFLVfzAA4lgYCo97/2P0980c7fJ1ZEe8aln9uzzlEZ/icN/BgdAjFmd+UElf
# zoi3Bz4m+SpA+LUZgjRrSh1988lE3H9O4JihFF1+s/ws7UUlW2Q+G5+qZ9aDM8H2
# h78uuTPOuFXMwLfgipOKMKO9mtXO+aqrlJGFDAiuKFNNQSCM9yW+/hLu64IUIcwj
# mVT/
# SIG # End signature block

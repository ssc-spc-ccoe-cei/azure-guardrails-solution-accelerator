Import-Module "$PSScriptRoot/../Manage-GSATags/Manage-GSATags.psd1"
# import sub-modules
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Confirm-GSAConfigurationParameters\Confirm-GSAConfigurationParameters.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Confirm-GSAPrerequisites\Confirm-GSAPrerequisites.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Show-GSADeploymentSummary\Show-GSADeploymentSummary.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Deploy-GSACoreResources\Deploy-GSACoreResources.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Add-GSAAutomationRunbooks\Add-GSAAutomationRunbooks.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Deploy-GSACentralizedDefenderCustomerComponents\Deploy-GSACentralizedDefenderCustomerComponents.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Deploy-GSACentralizedReportingCustomerComponents\Deploy-GSACentralizedReportingCustomerComponents.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Deploy-GSACentralizedReportingProviderComponents\Deploy-GSACentralizedReportingProviderComponents.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Update-GSACoreResources\Update-GSACoreResources.psd1")
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Update-GSAAutomationRunbooks\Update-GSAAutomationRunbooks.psd1")
# The deployment flow uses this helper to validate the named PowerShell 7.6 environment before updates and runbook starts.
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Manage-GSAAutomationRuntime\Manage-GSAAutomationRuntime.psd1")
# Used by -removeExistingDeployment to tear down a previous installation before a fresh deployment.
Import-Module ((Split-Path $PSScriptRoot -Parent) + "\Remove-GSAExistingDeployment\Remove-GSAExistingDeployment.psd1")

Function Invoke-GSARunbooks {
    param (
        # config object
        [Parameter(Mandatory = $true)]
        [psobject]
        $config
    )

    try {
        Start-AzAutomationRunbook -Name "main" -AutomationAccountName $config['runtime']['autoMationAccountName'] -ResourceGroupName $config['runtime']['resourceGroup'] -ErrorAction Stop | Out-Null
    }
    catch { 
        Write-Error "Error starting 'main' runbook. $_"
    }
    try {
        Start-AzAutomationRunbook -Name "backend" -AutomationAccountName $config['runtime']['autoMationAccountName'] -ResourceGroupName $config['runtime']['resourceGroup'] -ErrorAction Stop | Out-Null
    }
    catch { 
        Write-Error "Error starting 'backend' runbook. $_"
    }
}

function Remove-GSATemporaryDeployerBlobAccess {
    param (
        [Parameter(Mandatory = $true)]
        [psobject]
        $config
    )

    # Only remove the blob role when this deployment created a temporary storage-account assignment for the deployer.
    if (-not $config['runtime']['temporaryDeployerBlobContributorAssigned']) {
        return
    }

    try {
        # Remove the temporary deployer role as soon as the upload step no longer needs blob write access.
        Remove-AzRoleAssignment -ObjectId $config['runtime']['userId'] -RoleDefinitionName "Storage Blob Data Contributor" -Scope $config['runtime']['storageAccountId'] -ErrorAction Stop
        Write-Verbose "Removed temporary 'Storage Blob Data Contributor' role from deployer '$($config['runtime']['userId'])'."
    }
    catch {
        Write-Warning "Failed to remove temporary deployer blob access on storage account '$($config['runtime']['storageAccountName'])'. $_"
    }
}

function Export-GSAConfigToKeyVault {
    param (
        [Parameter(Mandatory = $true)]
        [psobject]
        $config,

        [Parameter(Mandatory = $true)]
        [bool]
        $useVerbose
    )

    Write-Host "Exporting configuration to GSA KeyVault "
    Write-Verbose "Exporting configuration to GSA KeyVault '$($config['runtime']['keyVaultName'])' as secret 'gsaConfigExportLatest'..."

    # Keep the same audit details as the old export. Environment.UserName works in both
    # Windows PowerShell and Linux-based Cloud Shell without separate OS-specific checks.
    $templateParams = @{
        keyVaultName          = $config['runtime']['keyVaultName']
        configValue           = ConvertTo-Json $config -Depth 10
        deploymentTimestamp   = Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'
        deployerLocalUsername = [Environment]::UserName
        deployerAzureId       = $config['runtime']['userId']
    }

    try {
        # The old Set-AzKeyVaultSecret command requested a separate Key Vault token near the end
        # of a long installation. That token request could expire, time out, or trigger a blocked
        # device login. This ARM deployment uses the same Azure session as the rest of the install,
        # so saving the config does not introduce that second Key Vault authentication step.
        $deployment = New-AzResourceGroupDeployment `
            -ResourceGroupName $config['runtime']['resourceGroup'] `
            -Name "guardrails-config-export-$(Get-Date -Format 'yyyyMMddHHmmss')" `
            -TemplateFile "$PSScriptRoot/../../../../setup/IaC/exportedconfig.bicep" `
            -TemplateParameterObject $templateParams `
            -WarningAction SilentlyContinue `
            -ErrorAction Stop `
            -Verbose:$useVerbose

        # Do not report a successful installation unless Azure confirms that it saved the secret.
        if ($deployment.ProvisioningState -ne 'Succeeded') {
            throw "ARM deployment finished with provisioning state '$($deployment.ProvisioningState)'."
        }

        Write-Host "Successfully exported gsaConfigExportLatest to Key Vault '$($config['runtime']['keyVaultName'])'" -ForegroundColor Green
    }
    catch {
        $recoveryMessage = "Run Connect-AzAccount -Tenant '$($config['runtime']['tenantId'])' -Subscription '$($config['runtime']['subscriptionId'])' -Scope Process, then re-run the same deployment command. Existing resources do not need to be deleted. If Cloud Shell or device-code sign-in is blocked by Conditional Access or location policy, run from an approved local PowerShell session or use service principal authentication with ARM deployment access to the Guardrails resource group."
        throw "Failed to export gsaConfigExportLatest to Key Vault '$($config['runtime']['keyVaultName'])' through Azure Resource Manager. $recoveryMessage Last error: $($_.Exception.Message)"
    }
}

Function New-GSACoreResourceDeploymentParamObject {
    param (
        # config object
        [Parameter(Mandatory = $true)]
        [hashtable]
        $config,

        # Empty for component-only updates, which leave installed modules alone.
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [object[]]
        $RuntimeModules,

        # alternate module url
        [Parameter(Mandatory = $false)]
        [string]
        $moduleBaseURL
    )

    Write-Verbose "Creating bicep parameters file for this deployment."
    $templateParameterObject = @{
        'AllowedLocationInitiativeId'           = $config.AllowedLocationInitiativeId
        'AllowedLocationPolicyId'               = $config.AllowedLocationPolicyId
        'automationAccountName'                 = $config['runtime']['autoMationAccountName']
        # Give Bicep the fixed runtime settings that create or reuse the Guardrails PowerShell 7.6 environment.
        'automationRuntimeAzVersion'            = $config['runtime']['automationRuntimeAzVersion']
        'automationRuntimeEnvironmentName'      = $config['runtime']['automationRuntimeEnvironmentName']
        'automationRuntimeVersion'              = $config['runtime']['automationRuntimeVersion']
        'guardrailsRuntimeModules'              = $RuntimeModules
        'breakglassAccount1'                    = $config.firstBreakGlassAccountUPN
        'breakglassAccount2'                    = $config.secondBreakGlassAccountUPN    
        'CBSSubscriptionName'                   = $config.CBSSubscriptionName
        'cloudUsageProfiles'                    = $config.cloudUsageProfiles
        'currentUserObjectId'                   = $config['runtime']['userId']
        'DepartmentNumber'                      = $config.DepartmentNumber
        'DepartmentName'                        = $config['runtime']['departmentName']
        'deployKV'                              = $config['runtime']['deployKV']
        'deployLAW'                             = $config['runtime']['deployLAW']
        'HealthLAWResourceId'                   = $config.HealthLAWResourceId
        'kvName'                                = $config['runtime']['keyVaultName']
        'lighthouseTargetManagementGroupID'     = $config.lighthouseTargetManagementGroupID
        'Locale'                                = $config.Locale
        'location'                              = $config.region
        'logAnalyticsWorkspaceName'             = $config['runtime']['logAnalyticsworkspaceName']
        'PBMMPolicyID'                          = $config.PBMMPolicyID
        'solution'                              = $config['runtime']['tagsTable'].Solution
        'releasedate'                           = $config['runtime']['tagsTable'].ReleaseDate
        'releaseVersion'                        = $config['runtime']['tagsTable'].ReleaseVersion
        'SecurityLAWResourceId'                 = $config.SecurityLAWResourceId
        'SSCReadOnlyServicePrincipalNameAPPID'  = $config.SSCReadOnlyServicePrincipalNameAPPID
        'storageAccountName'                    = $config['runtime']['storageaccountName']
        'subscriptionId'                        = (Get-AzContext).Subscription.Id
        'tenantDomainUPN'                       = $config['runtime']['tenantDomainUPN']
        'securityRetentionDays'                   = $config.securityRetentionDays
        'mfaGracePeriod'                        = $config.mfaGracePeriod
    }
    # Adding URL parameter if specified
    [regex]$moduleURIRegex = '(https://github.com/.+?/(raw|archive)/.*?/psmodules)|(https://.+?\.blob\.core\.windows\.net/psmodules)'
    If (![string]::IsNullOrEmpty($moduleBaseURL)) {
        If ($moduleBaseURL -match $moduleURIRegex) {
            $templateParameterObject += @{ModuleBaseURL = $moduleBaseURL }
        }
        Else {
            Write-Error "-moduleBaseURL provided, but does not match pattern '$moduleURIRegex'" -ErrorAction Stop
        }
    }
    Write-Verbose "templateParameterObject: `n$($templateParameterObject | ConvertTo-Json)"

    [hashtable]$templateParameterObject
}

Function Deploy-GuardrailsSolutionAccelerator {
    <#
    .SYNOPSIS
        Deploy or update the Guardrails Solution Accelerator.
    .DESCRIPTION
        This function will deploy or update the Guardrails Solution Accelerator, depending on the specified parameters. It can also be used to verify deployment parameters and prerequisites. 

        For new deployments, a configuration file must be provided using the -configFilePath parameter. This file is a JSON file specifying the deployment configuration
        and resource naming conventions. See this page for details: https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/blob/main/docs/setup.md.

        For update deployments to an existing environment, either the -ConfigFilePath should be used, or the Get-GSAExportedConfiguration function can be used to retrieve the current 
        deployment's configuration from the specified KeyVault. 

        In order to enable centralized reporting and/or Defender for Cloud access by a managing tenant, specify CentralizedCustomerDefenderForCloudSupport or CentralizedCustomerReportingSupport. This
        can be done separately from a deployment of the core components. 

        If errors are encountered during deployment and a redeployment does not pass prerequisites due to existing resources, the following modules can perform cleanup tasks:
          - Remove-GSACentralizedDefenderCustomerComponents
          - Remove-GSACentralizedReportingCustomerComponents
          - Remove-GSACoreResources

        For unattended redeployments (for example a CI/CD pipeline deploying into a subscription that already holds a manual
        installation), -removeExistingDeployment runs those cleanup steps automatically before the new deployment. This permanently
        deletes the existing Log Analytics workspace data; use -update to keep an existing installation instead.
    .NOTES
        Information or caveats about the function e.g. 'This function is not supported in Linux'
    .LINK
        https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator
    .EXAMPLE 
        # Deploy new GSA instance, with core components only:
        Deploy-GuardrailsSolutionAccelerator -configFilePath "C:\config.json"
    .EXAMPLE
        # Deploy new GSA instance, with core components and Defender for Cloud access delegated to a managing tenant:
        Deploy-GuardrailsSolutionAccelerator -configFilePath "C:\config.json" -newComponents CoreComponents,CentralizedCustomerDefenderForCloudSupport
    .EXAMPLE
        # Pipeline redeployment: remove a previous installation (including one installed manually) and deploy fresh without prompts:
        Deploy-GuardrailsSolutionAccelerator -configFilePath "C:\config.json" -newComponents CoreComponents,CentralizedCustomerReportingSupport -removeExistingDeployment -yes
    .EXAMPLE
        # Validate the contents of a configuration file, but do not deploy anything:
        Deploy-GuardrailsSolutionAccelerator -configFilePath "C:\config.json" -validateConfigFile
    .EXAMPLE
        # Validate that the prerequisites are met for the specified deployment configuration:
        Deploy-GuardrailsSolutionAccelerator -configFilePath "C:\config.json" -validatePrerequisites -newComponents CoreComponents,CentralizedCustomerDefenderForCloudSupport,CentralizedCustomerReportingSupport
    .EXAMPLE
        # Update an existing GSA instance (PowerShell modules, workbooks, and runbooks):
        Get-GSAExportedConfig -KeyVaultName guardrails-12345 | Deploy-GuardrailsSolutionAccelerator -update
    .EXAMPLE
        # Add the CentralizedCustomerDefenderForCloudSupport component to an existing deployment, retrieving the configuration from the existing deployment's Key Vault
        Get-GSAExportedConfig -KeyVaultName guardrails-12345 | deploy-GuardrailsSolutionAccelerator -newComponents CentralizedCustomerDefenderForCloudSupport
    #>

    [CmdletBinding(DefaultParameterSetName = 'newDeployment-configFilePath')]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '')]
    param (
        # path to the configuration file - for new deployments
        [Parameter(mandatory = $true, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $true, ParameterSetName = 'updateDeployment-configFilePath')]
        [Parameter(mandatory = $true, ParameterSetName = 'validateConfigFile')]
        [Parameter(mandatory = $true, ParameterSetName = 'validatePreReqs-configFilePath')]
        [string]
        [Alias(
            'configFileName'
        )]
        $configFilePath,

        # as an alternative to specifying a config file, you can pass a config object directly. This is useful for updating an existing deployment, where the 
        # config file is stored in the deployment's Key Vault and retrieved using Get-GSAExportedConfig command
        [Parameter(mandatory = $true, ParameterSetName = 'newDeployment-configString', ValueFromPipelineByPropertyName = $true)]
        [Parameter(Mandatory = $true, ParameterSetName = 'updateDeployment-configString', ValueFromPipelineByPropertyName = $true)]
        [Parameter(mandatory = $true, ParameterSetName = 'validatePreReqs-configString', ValueFromPipelineByPropertyName = $true)]
        [string]
        $configString,

        # components to be deployed
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        [Parameter(mandatory = $false, ParameterSetName = 'validatePreReqs-configFilePath')]
        [Parameter(mandatory = $false, ParameterSetName = 'validatePreReqs-configString')]
        [Parameter(mandatory = $true, ParameterSetName = 'validateConfigFile')]
        [ValidateSet(
            'CoreComponents',
            'CentralizedCustomerReportingSupport',
            'CentralizedCustomerDefenderForCloudSupport'<#, # TODO: add support for provider-side deployment
            'CentralizedReportingProviderComponents'#>
        )]
        [string[]]
        $newComponents = @('CoreComponents'),

        # components to be updated
        [Parameter(Mandatory = $true, ParameterSetName = 'updateDeployment-configFilePath')]
        [Parameter(Mandatory = $true, ParameterSetName = 'updateDeployment-configString')]
        [switch]
        $update,

        # components to be updated - in most cases, this should not be specified and all components should be updated
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configString')]
        [ValidateSet(
            'CoreComponents',
            'Workbook',
            'GuardrailPowerShellModules',
            'AutomationAccountRunbooks'
        )]
        [string[]]
        $componentsToUpdate = @('Workbook','GuardrailPowerShellModules','AutomationAccountRunbooks', 'CoreComponents'),

        # confirm that config parameters are valid
        [Parameter(mandatory = $true, ParameterSetName = 'validateConfigFile')]
        [switch]
        $validateConfigFile,

        # specify to validate prerequisites without deploying anything (validation always runs when deploying)
        [Parameter(mandatory = $true, ParameterSetName = 'validatePreReqs-configFilePath')]
        [Parameter(mandatory = $true, ParameterSetName = 'validatePreReqs-configString')]
        [switch]
        $validatePrerequisites,

        # specify to source the GSA PowerShell modules from an alternate URL - this is useful for development
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configString')]
        [string]
        $alternatePSModulesURL,

        # Staged Blob modules have no GitHub ref in their URL, so GitHub Actions
        # supplies the checked-out commit here. Deploy-Bootstrap instead supplies
        # its source through the official GitHub module URL, which is parsed below.
        # The ref must exist on the official repository.
        [Parameter(Mandatory = $false)]
        [string]
        $gitHubSourceRef,

        # specify a release to deploy or update to - ex: 'v1.0.9', 'prerelease-v1.0.8.1'. If not specified, the latest release will be used
        # the 'latest' release is typically the last full release, unless a critcal bug fix was applied since the last full release
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configString')]
        [ValidatePattern('(prerelease-)?v\d+\.\d+\.\d+(\.\d+)?')]
        [string]
        $releaseVersion,

        # remove an existing Guardrails deployment (resource group, Lighthouse delegation, Defender for Cloud role
        # assignments, soft-deleted Key Vault) before a new deployment - intended for CI/CD pipelines redeploying into
        # a subscription with a previous manual installation. Permanently deletes the Log Analytics workspace data.
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        [switch]
        $removeExistingDeployment,

        # when used with -removeExistingDeployment, names the resource group of the existing deployment instead of
        # discovering it from the configured resource group name and the Guardrails 'Solution' tag
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        [string]
        $existingResourceGroupName,

        # # if specified, deploy the lastest pre-release version. If used with -releaseVersion, the release version will take precedence
        # [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configFilePath')]
        # [Parameter(Mandatory = $false, ParameterSetName = 'newDeployment-configString')]
        # [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configFilePath')]
        # [Parameter(Mandatory = $false, ParameterSetName = 'updateDeployment-configString')]
        # [switch]
        # $prerelease,

        # proceed through imput prompts - used for deployment via automation or testing
        [Parameter(Mandatory = $false)]
        [Alias('y')]
        [switch]
        $yes
    )

    $ErrorActionPreference = 'Stop'

    If ($existingResourceGroupName -and -not $removeExistingDeployment.IsPresent) {
        throw '-existingResourceGroupName can only be used together with -removeExistingDeployment.'
    }

    #ensures verbose preference is passed through to sub-modules
    If ($PSBoundParameters.ContainsKey('verbose')) {
        $useVerbose = $true
    }
    Else {
        $useVerbose = $false
    }

    # based on parameters, perform validation or deployment/update
    If ($validateConfigFile.IsPresent) {
        $config = Confirm-GSAConfigurationParameters -configFilePath $configFilePath -Verbose:$useVerbose

        Write-Output "Configuration parameters:"
        $config.GetEnumerator() | Sort-Object -Property Name | Format-Table -AutoSize -Wrap
        break
    }
    ElseIf ($validatePrerequisites.IsPresent) {
        Write-Verbose "Validating config parameters before validating prerequisites..."
        If ($PSCmdlet.ParameterSetName -eq 'validatePreReqs-configString') {
            $config = Confirm-GSAConfigurationParameters -configString $configString -Verbose:$useVerbose
        }
        Else {
            $config = Confirm-GSAConfigurationParameters -configFilePath $configFilePath -Verbose:$useVerbose
        }
        Write-Verbose "Completed validating config parameters."

        Confirm-GSAPrerequisites -config $config -newComponents $newComponents -Verbose:$useVerbose
        break
    }
    Else {
        # new deployment or update deployment
        # Resolve and validate the release's module versions once before changing Azure resources.
        # Bootstrap calls this installer too. Updates that leave modules alone do not need this check.
        $runtimeModules = @()
        if (($update.IsPresent -and $componentsToUpdate -contains 'GuardrailPowerShellModules') -or
            (-not $update.IsPresent -and $newComponents -contains 'CoreComponents')) {
            $runtimeModules = @(Get-GSAExpectedAutomationRuntimeModules)
        }

        # confirms the provided values in config.json and appends runtime values, then returns the config object
        If ($PSCmdlet.ParameterSetName -in 'newDeployment-configString','updateDeployment-configString') {
            $config = Confirm-GSAConfigurationParameters -configString $configString -Verbose:$useVerbose
        }
        Else {
            $config = Confirm-GSAConfigurationParameters -configFilePath $configFilePath -Verbose:$useVerbose
        }

        # Error handling for missing or invalid configuration parameters
        try{
            Show-GSADeploymentSummary -deployParams $PSBoundParameters -deployParamSet $PSCmdlet.ParameterSetName -yes:$yes.isPresent -Verbose:$useVerbose
        }
        catch{
            Write-Error "Show-GSADeploymentSummary did not complete sucessfully. Check for errors."
        }
        Write-Verbose "Release version: $releaseVersion"

        # Future updates reuse the named 7.6 environment created by a fresh installation.
        # An older 7.2 installation does not have it, so this read-only check stops before resource changes begin.
        if ($update.IsPresent) {
            Assert-GSAAutomationRuntimeEnvironment -Config $config -Verbose:$useVerbose
        }

        # Previously, source selection only chose where to download modules; tags came
        # from the local configuration. These steps replace that selection with one
        # official GitHub ref for the mandatory tags as well as the default module URL.
        # Deploy-GuardrailsSolutionAccelerator still accepts -releaseVersion or defaults
        # to the latest stable release. Deploy-Bootstrap includes its existing -source
        # in the official module URL. GitHub Actions stages modules in Blob and passes
        # the checked-out commit through -gitHubSourceRef.
        # If both source arguments are supplied, require identical refs rather than
        # silently choosing one and potentially labelling modules as another release.
        $sourceRef = $gitHubSourceRef
        if ($sourceRef -and $releaseVersion -and $sourceRef -cne $releaseVersion) {
            throw '-gitHubSourceRef and -releaseVersion must identify the same source when both are supplied.'
        }
        if (-not $sourceRef) { $sourceRef = $releaseVersion }
        if ($releaseVersion) {
            # Keep Deploy-GuardrailsSolutionAccelerator's published-release check, but look up the
            # requested tag directly instead of searching release display names.
            # The actual tag identifies the files to deploy; GitHub's prerelease flag
            # determines whether to warn. This also applies with an alternate module
            # URL, where -releaseVersion previously had no effect.
            $release = Invoke-RestMethod -Uri ('https://api.github.com/repos/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases/tags/{0}' -f [uri]::EscapeDataString($releaseVersion)) -ErrorAction Stop -Verbose:$false
            if ($release.prerelease) { Write-Warning "Deploying prerelease '$releaseVersion'; prereleases are not recommended for production." }
        }
        # An official GitHub module URL already includes its source ref, so existing
        # callers using this URL need no additional argument. Check any explicit ref
        # against it to keep the module source and mandatory tag source consistent.
        $officialUrl = '^https://github\.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/raw/(.+)/psmodules/?$'
        if ($alternatePSModulesURL -match $officialUrl) {
            $urlSourceRef = [uri]::UnescapeDataString($Matches[1])
            if ($sourceRef -and $sourceRef -cne $urlSourceRef) {
                throw 'The GitHub module URL and tag metadata source must identify the same ref.'
            }
            $sourceRef = $urlSourceRef
        }
        # Blob and other alternate URLs do not identify an official GitHub source.
        # They now need -gitHubSourceRef or a published -releaseVersion. Do not guess
        # the latest release or fall back to editable local mandatory tags: either
        # could describe a different release from the staged modules.
        if (-not $sourceRef -and $alternatePSModulesURL) {
            throw 'An alternate module URL requires -gitHubSourceRef identifying the GitHub source being deployed.'
        }
        # When Deploy-GuardrailsSolutionAccelerator receives no source or alternate URL,
        # use GitHub's latest stable release. Use its tag, not its editable title,
        # so the module download and mandatory tags refer to the same source.
        if (-not $sourceRef) {
            $latestRelease = Invoke-RestMethod 'https://api.github.com/repos/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases/latest' -ErrorAction Stop -Verbose:$false
            $sourceRef = $latestRelease.tag_name
            if ([string]::IsNullOrWhiteSpace($sourceRef)) { throw 'GitHub did not return a release tag.' }
        }
        # For both installs and updates, replace only Solution, ReleaseVersion and
        # ReleaseDate with values from the selected official source, keeping client
        # custom tags. Fetch failures stop deployment instead of trusting local values.
        $config.runtime.tagsTable = Get-GSADeploymentTags -SourceRef $sourceRef -ClientTags $config.runtime.tagsTable
        # Keep an explicitly supplied module download URL; otherwise build it from
        # the resolved ref. The existing deployment code still receives moduleBaseURL.
        $moduleBaseURL = if ($alternatePSModulesURL) { $alternatePSModulesURL } else {
            'https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/raw/{0}/psmodules' -f [uri]::EscapeDataString($sourceRef)
        }
        $params = @{ moduleBaseURL = $moduleBaseURL }

        # if installing from a published release, check that the release contains zip assets
        If (-NOT($alternatePSModulesURL)) {
            # check that the release contains the 'GR-Common.zip' file as an asset. 
            Write-Verbose "Checking that the release contains the 'GR-Common.zip' file as an asset..."
            try {
                $null = Invoke-RestMethod -Method HEAD -Uri "$moduleBaseURL/GR-Common.zip" -ErrorAction Stop -Verbose:$true
            }
            catch {
                Write-Error "The release $releaseVersion does not contain the 'GR-Common.zip' file as an asset. This likely means the release was not properly published, or was published using an older process and is not recommended for new deployments. See: https://github.com/ssc-spc-ccoe-cei/azure-guardrails-solution-accelerator/releases"
                return
            }
            Write-Verbose "The release $releaseVersion contains the 'GR-Common.zip' file as an asset, continuing with `$moduleBaseURL of '$moduleBaseURL'"
        }
        
        $paramObject = New-GSACoreResourceDeploymentParamObject -config $config -RuntimeModules $runtimeModules @params -Verbose:$useVerbose

        # Tear down a previous installation before anything is written. Its leftovers (resource group,
        # Lighthouse delegation, management group role assignments, soft-deleted Key Vault, tag policy
        # assignments on the old resource group) would otherwise fail the tag policy preparation or the
        # prerequisite checks below.
        If (!$update.IsPresent -and $removeExistingDeployment.IsPresent) {
            Write-Host "Removing existing Guardrails Solution Accelerator deployment before the new deployment..." -ForegroundColor Green
            $removeExistingParams = @{
                config        = $config
                newComponents = $newComponents
                force         = $yes.IsPresent
            }
            If ($existingResourceGroupName) {
                $removeExistingParams['existingResourceGroupName'] = $existingResourceGroupName
            }
            Remove-GSAExistingDeployment @removeExistingParams -Verbose:$useVerbose
        }

        # Prepare policy permissions and accepted release values before any resource
        # writes. Failed deployments deliberately retain both sets so the saved
        # baseline remains usable; rerunning the deployment completes the transition.
        Set-GSATagPolicies -Config $config -Prepare -Verbose:$useVerbose

        # A fresh core install saves the config immediately after creating the core resources.
        # Update and non-core paths save it at the shared step below. This flag keeps the export
        # to one successful attempt per deployment while preserving the earlier fail-fast path.
        $configExported = $false

        If (!$update.IsPresent) {
            Write-Host "Deploying Guardrails Solution Accelerator components ($($newComponents -join ','))..." -ForegroundColor Green
            Write-Verbose "Performing a new deployment of the Guardrails Solution Accelerator..."

            # confirms that prerequisites are met and that deployment can proceed
            Confirm-GSAPrerequisites -config $config -newComponents $newComponents -Verbose:$useVerbose
            
            If ($newComponents -contains 'CoreComponents') {
                try {
                    # Deploy the shared resources first so the storage account, automation account, and role assignments exist.
                    Write-Host "Deploying CoreComponents..." -ForegroundColor Green
                    Deploy-GSACoreResources -config $config -paramObject $paramObject -Verbose:$useVerbose

                    # Save the final config as soon as the core resources exist. If authentication
                    # is unavailable, stop here instead of failing after Lighthouse is also deployed.
                    # Saving before runbook setup also guarantees the secret exists before the first run.
                    Export-GSAConfigToKeyVault -config $config -useVerbose $useVerbose
                    $configExported = $true

                    # The runbooks do not read the config while they are uploaded, but they require it
                    # when they run. At this point their first execution cannot race the secret export.
                    Write-Host "Adding runbooks to automation account..." -ForegroundColor Green
                    Add-GSAAutomationRunbooks -config $config -RuntimeModules $runtimeModules -Verbose:$useVerbose
                }
                catch {
                    throw "Error while deploying core components, exporting config, or adding automation runbooks. $_"
                }
                finally {
                    # Always try to drop the deployer's temporary blob role once this block no longer needs it.
                    Remove-GSATemporaryDeployerBlobAccess -config $config
                }
            }
            
            # deploy Lighthouse components
            Write-Host "Deploying Lighthouse components..." -ForegroundColor Green
            If ($newComponents -contains 'CentralizedCustomerReportingSupport') {
                Write-Host "Deploying CentralizedReportingCustomerComponents..." -ForegroundColor Green
                try{
                    Deploy-GSACentralizedReportingCustomerComponents -config $config -Verbose:$useVerbose
                }
                catch{
                    Write-Error "Error in deploying GSA centralized reporting customer components. $_"
                }
            }
            If ($newComponents -contains 'CentralizedCustomerDefenderForCloudSupport') {
                Write-Host "Deploying GSACentralizedDefenderCustomerComponents..." -ForegroundColor Green
                try{
                    Deploy-GSACentralizedDefenderCustomerComponents -config $config -Verbose:$useVerbose
                }
                catch{
                    Write-Error "Error in deploying GSA centralized defender for cloud customer components. $_"
                }
                
            }

            Write-Host "Completed new deployment."
            Write-Verbose "Completed new deployment."
        }
        Else {
            Write-Host "Updating Guardrails Solution Accelerator components ($($componentsToUpdate -join ','))..." -ForegroundColor Green
            Write-Verbose "Updating an existing deployment of the Guardrails Solution Accelerator..."
        
            # skip deployment of LAW and KV as they should exist already
            $paramObject.deployKV = $false
            $paramObject.deployLAW = $false
            $paramObject += @{newDeployment = $false }

            If ($PSBoundParameters.ContainsKey('componentsToUpdate')) {
                Write-Warning "Specifying individual components to update with -componentsToUpdate risks deploying out-of-sync components; ommiting this parameter and updating all components is recommended. You selected to update $($componentsToUpdate -join ', '). Updating individual components should be done with caution. `n`nPress ENTER to continue or CTRL+C to cancel..."
                Read-Host
            }

            $updateBicep = $false # if true, the bicep template will be deploy with the parameters in $paramObject
            # update workbook definitions
            If ($componentsToUpdate -contains 'Workbook') {
                #removing any saved search in the gr_functions category since an incremental deployment fails...
                Write-Verbose "Removing any saved searches in the gr_functions category prior to update (which will redeploy them)..."
                $savedSearches = Get-AzOperationalInsightsSavedSearch -WorkspaceName $config['runtime']['logAnalyticsWorkspaceName'] -ResourceGroupName $config['runtime']['resourceGroup']
                $grfunctions = $savedSearches.Value | Where-Object {
                    $_.Properties.Category -eq 'gr_functions'
                }

                Write-Verbose "Found $($grfunctions.Count) saved searches in the gr_functions category to be removed."
                $grfunctions | ForEach-Object { 
                    Write-Verbose "`tRemoving saved search $($_.Name)..."
                    Remove-AzOperationalInsightsSavedSearch -ResourceGroupName $config['runtime']['resourceGroup'] -WorkspaceName $config['runtime']['logAnalyticsworkspaceName'] -SavedSearchId $_.Name
                }

                $paramObject += @{updateWorkbook = $true }

                $updateBicep = $true
            }

            # update Guardrail powershell modules in AA
            If ($componentsToUpdate -contains 'GuardrailPowerShellModules') {
                $paramObject += @{updatePSModules = $true }

                $updateBicep = $true
            }

            # deploy core resources update
            If ($componentsToUpdate -contains 'CoreComponents') {
                $paramObject += @{updateCoreResources = $true }

                $updateBicep = $true
            }

            # deploy the bicep template with the specified parameters
            If ($updateBicep) {
                Write-Verbose "Deploying core Bicep template with update parameters '$($paramObject.Keys.Where({$_ -like 'update*'}) -join ',')'..."
                try{
                    Update-GSACoreResources -config $config -paramObject $paramObject -Verbose:$useVerbose
                }
                catch{
                    Write-Error "Error in updating GSA core resources. $_"
                }
            }

            # A module update is not complete until Azure reports the requested versions as ready.
            # Other component updates leave modules unchanged, including any one-off client hotfixes.
            If ($componentsToUpdate -contains 'GuardrailPowerShellModules') {
                Wait-GSAAutomationRuntimeModules -Config $config -ExpectedModules $runtimeModules
            }
            
            # update runbook definitions in AA
            If ($componentsToUpdate -contains 'AutomationAccountRunbooks') {
                try{
                    Update-GSAAutomationRunbooks -config $config -Verbose:$useVerbose
                }
                catch{
                    Write-Error "Error in updating Azure automation runbook. $_"
                }
                
            }

            Write-Verbose "Completed update deployment."
        }

        # Updates and deployments without new core resources did not use the early export above.
        # Save their config here so every path completes the export before starting the runbooks.
        if (-not $configExported) {
            Export-GSAConfigToKeyVault -config $config -useVerbose $useVerbose
        }

        # Narrow enforcement only after every selected component and the Key Vault
        # export succeed. This also covers runbook-only and other partial updates:
        # backend repair will bring unchanged resources to the newly saved baseline.
        Set-GSATagPolicies -Config $config -Verbose:$useVerbose

        # Start the runbooks only after the config secret is confirmed. The runbook jobs start in
        # the background, so reversing these steps could let a job read the secret before it exists.
        Write-Host "Invoking manual execution of Azure Automation runbooks..."
        try{
            Invoke-GSARunbooks -config $config -Verbose:$useVerbose
        }
        catch{
            Write-Error "Error in invoking Azure automation runbook. $_"
        }

        Write-Host "Completed deployment of the Guardrails Solution Accelerator!" -ForegroundColor Green
    }
}

# list functions to export from module for public consumption; also update in GuardrailsSolutionAcceleratorSetup.psm1 when making changes
$functionsToExport = @(
    #'Add-GSAAutomationRunbooks'
    'Confirm-GSAConfigurationParameters'
    'Confirm-GSAPrerequisites'
    'Confirm-GSASubscriptionSelection'
    #'Deploy-GSACentralizedDefenderCustomerComponents'
    #'Deploy-GSACentralizedReportingCustomerComponents'
    #'Deploy-GSACentralizedReportingProviderComponents'
    #'Deploy-GSACoreResources'
    'Deploy-GuardrailsSolutionAccelerator'
    #'Remove-GSACentralizedDefenderCustomerComponents'
    #'Remove-GSACentralizedReportingCustomerComponents'
    #'Remove-GSACoreResources'
    #'Show-GSADeploymentSummary'
    #'Update-GSAAutomationRunbooks'
    #'Update-GSAGuardrailPSModules'
    #'Update-GSAWorkbookDefintion
)
Export-ModuleMember -Function $functionsToExport


function Check-AllUserMFARequired {
    param (      
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [Parameter(Mandatory=$true)]
        [string] $FirstBreakGlassUPN,
        [Parameter(Mandatory=$true)] 
        [string] $SecondBreakGlassUPN
    )

    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null

    # list all users
    $urlPath = "/users"
    try {
        $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop
        $data = $response.Content
        if ($null -ne $data -and $null -ne $data.value) {
            $users = $data.value | Select-Object userPrincipalName , displayName, givenName, surname, id, mail
        }
    }
    catch {
        $errorMsg = "Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"                
        $ErrorList.Add($errorMsg)
        Write-Error "Error: $errorMsg"
    }

    # Check all users for MFA
    $allUserUPNs = $users.userPrincipalName
    # remove break glass account UPNs
    if ($allUserUPNs -contains $FirstBreakGlassUPN){
        $allUserUPNs = $allUserUPNs | Where-Object { $_ -ne $FirstBreakGlassUPN }
    }
    if ($allUserUPNs -contains $SecondBreakGlassUPN){
        $allUserUPNs = $allUserUPNs | Where-Object { $_ -ne $SecondBreakGlassUPN }

    }
    # # Test
    # $errorMsg = "Check allUserUPNs : $allUserUPNs"
    # $ErrorList.Add($errorMsg)
    # Write-Error "Error: $errorMsg"  

    $mfaCounter = 0
    $userUPNsMFA = @()

    ForEach ($userAccount in $allUserUPNs) {
        $urlPath = '/users/' + $userAccount + '/authentication/methods'
        
        # create hidden format UPN
        $hiddenUPN = Hide-Email -email $userAccount
        
        try {
            $response = Invoke-GraphQuery -urlPath $urlPath -ErrorAction Stop

        }
        catch {
            $errorMsg = "Failed to call Microsoft Graph REST API at URL '$urlPath'; returned error message: $_"                
            $ErrorList.Add($errorMsg)
            Write-Error "Error: $errorMsg"
        }

        # # To check if MFA is setup for a user, we're checking various authentication methods:
        # # 1. #microsoft.graph.microsoftAuthenticatorAuthenticationMethod
        # # 2. #microsoft.graph.phoneAuthenticationMethod
        # # 3. #microsoft.graph.passwordAuthenticationMethod - not considered for MFA
        # # 4. #microsoft.graph.emailAuthenticationMethod - not considered for MFA
        # # 5. #microsoft.graph.fido2AuthenticationMethod
        # # 6. #microsoft.graph.softwareOathAuthenticationMethod

        if ($null -ne $response) {
            $data = $response.Content
            if ($null -ne $data -and $null -ne $data.value) {
                $authenticationmethods = $data.value
                
                $authFound = $false
                $authCounter = 0
                foreach ($authmeth in $authenticationmethods) {                        
                    if (($($authmeth.'@odata.type') -eq "#microsoft.graph.phoneAuthenticationMethod") -or `
                        ($($authmeth.'@odata.type') -eq "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod") -or`
                        ($($authmeth.'@odata.type') -eq "#microsoft.graph.fido2AuthenticationMethod" ) -or`
                        ($($authmeth.'@odata.type') -eq "#microsoft.graph.softwareOathAuthenticationMethod" ) ) {
                            
                            # need to keep track of mfa auth count for each user
                            $authCounter += 1
                            if ($authCounter -ge 2){
                                #need to keep track of user account mfa in a counter and compare it with the total user count
                                $mfaCounter += 1
                                $authFound = $true
                                # atleast two auth method is true - so we move to the next UPN 
                                break
                            }
                    }

                }
                if($authFound){
                    # This message is being used for debugging
                    Write-Host "Auth method found for $globalAdminAccount"
                }
                else{
                    # This message is being used for debugging
                    Write-Host "$userAccount does not have MFA enabled"

                    # Create an instance of inner list object
                    $userUPNtemplate = [PSCustomObject]@{
                        UPN  = $userAccount
                        MFAStatus   = $false
                        MFAComments = $hiddenUPN 
                    }
                    # Add the list to GA MFA list
                    $userUPNsMFA += $userUPNtemplate
                }
            }
            else {
                $errorMsg = "No authentication methods data found for $userAccount"                
                $ErrorList.Add($errorMsg)
                # Write-Error "Error: $errorMsg"    
            }
        }
        else {
            $errorMsg = "Failed to get response from Graph API for $userAccount"                
            $ErrorList.Add($errorMsg)
            Write-Error "Error: $errorMsg"    
        }    
    }

    # Condition: all users are MFA enabled
    if($mfaCounter -eq $allUserUPNs.Count) {
        # $commentsArray += $msgTable.globalAdminMFAPassAndMin2Accnts
        $commentsArray += ' ' + $msgTable.allUserHaveMFA
        $IsCompliant = $true
    }
    # Condition: GA UPN list has > 2 UPNs and not all UPNs are MFA enabled
    else {
        # This will be used for debugging
        if($userUPNsMFA.Count -eq 0){
            Write-Host "Something is wrong as userUPNsMFA Count equals 0. This output should only execute if there is an error populating userUPNsMFA"
        }
        else {
            $upnString = ($userUPNsMFA | ForEach-Object { $_.UPN }) -join ', '
            $commentsArray += ' ' + $msgTable.userMisconfiguredMFA -f $upnString
            $IsCompliant = $false
        }
    }

    $Comments = $commentsArray -join ";"
    
    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }
    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $PsObject
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }
    return $moduleOutput   
}


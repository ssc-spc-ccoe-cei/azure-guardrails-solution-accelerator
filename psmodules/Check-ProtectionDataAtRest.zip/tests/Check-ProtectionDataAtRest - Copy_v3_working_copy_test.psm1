function Test-ExemptionExists {
    param (
        [string] $ScopeId,
        [array]  $requiredPolicyExemptionIds
    )
    $exemptionsIds=(Get-AzPolicyExemption -Scope $ScopeId).Properties.PolicyDefinitionReferenceIds
    if ($null -ne $exemptionsIds)
    {
        foreach ($exemptionId in $exemptionsIds)
        {
            if ($exemptionId -in $requiredPolicyExemptionIds)
            {
                return $true
            }
        }
    }
    else {
        return $false
    }
    
}
function Check-StatusDataAtRest {
    param (
        [System.Object] $objList,
        [string] $objType, #subscription or management Group
        [array]  $requiredPolicyExemptionIds,
        [string] $PolicyID,
        [string] $ControlName,
        [string] $ItemName,
        [string] $LogType,
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string]
        $ReportTime
    )   
    [PSCustomObject] $tempObjectList = New-Object System.Collections.ArrayList
    $PolicyID = $PolicyID.ToLower()
    foreach ($obj in $objList)
    {
        # # Used for debugging
        # if (!($PolicyID -like "/providers/microsoft.authorization/policysetdefinitions")) {
        #     $PolicyDefinitionID = "/providers/microsoft.authorization/policysetdefinitions/$PolicyID"
        # }
        # Used for debugging
        # Write-Host "PolicyDefinitionID is $PolicyDefinitionID" 
        # Write-Host "PolicyID is $PolicyID"

        if ($objType -eq "subscription"){
            $tempId="/subscriptions/$($obj.Id)"
        }
        else {
            $tempId=$obj.Id                              
        }
        Write-Host "Scope is $tempId"
        
        $AssignedPolicyList = Get-AzPolicyAssignment -scope $tempId -PolicyDefinitionId $PolicyID
        # $AssignedPolicyList = Get-AzPolicyAssignment -scope $tempId -PolicyDefinitionId $PolicyDefinitionID
        If ($null -eq $AssignedPolicyList -or (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))))
        {
            $Comment=$msgTable.pbmmNotApplied 
            $ComplianceStatus=$false
        }
        else {
            #PBMM is applied and not excluded. Testing if specific policies haven't been excluded.
            if (Test-ExemptionExists -ScopeId $tempId -requiredPolicyExemptionIds $requiredPolicyExemptionIds)
            { # boolean, exemption for gr6 required policies exists.
                $ComplianceStatus=$false
                $Comment=$msgTable.grexemptionFound -f $obj.Id,$objType
            }
            else {
                # No exemption exists. 
                # Find compliance details for the PBMM policy
                
                # Check the number of resources and compliance status under each policy in applied PBMM
                if ($objType -eq "subscription"){
                    Write-Host "Subscription : $($obj.Name)"
                    $complianceDetails = (Get-AzPolicyState -SubscriptionId $($obj.Id) ) | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID}
                }
                else {
                    Write-Host "Management Group : $($obj.Name)"
                    $strPattern = "/providers/microsoft.authorization/policysetdefinitions/(.*)"
                    if ($PolicyID -match $strPattern){
                        $PolicyID = $matches[1]
                    }
                    $complianceDetails = (Get-AzPolicyState) | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID}
                    $complianceDetails = $complianceDetails | Where-Object{$_.PolicyAssignmentScope -like "*$tempId*" } 
                }

                if ($null -eq $complianceDetails) {
                    $counterResourceNonCompliant = $null
                    Write-Host "PBMM policy $PolicyId is not applied to this resource with name $($obj.DisplayName) and Id is '$($obj.Name)' "
                }
                else{
                    $requiredPolicyExemptionIds_smallCaps = @()
                    foreach ($str in $requiredPolicyExemptionIds) {
                        $requiredPolicyExemptionIds_smallCaps += $str.ToLower()
                    }
                    # Filter for GR6 required policies
                    $complianceDetails = $complianceDetails | Where-Object{ $_.PolicyDefinitionReferenceId -in $requiredPolicyExemptionIds_smallCaps}
                    # get compliance data including resources
                    $resourceNames = @{}
                    foreach ($resource in $complianceDetails) {
                        $resourcename = ($resource.ResourceId -split '/')[-1]
                        $resourceNames[$resource.ResourceId] = $resourcename
                    }
                    $result = $complianceDetails | ForEach-Object {
                        [PSCustomObject]@{
                            Timestamp                   = $_.Timestamp
                            ResourceId                  = $_.ResourceId
                            ResourceLocation            = $_.ResourceLocation
                            ResourceType                = $_.ResourceType
                            SubscriptionId              = $_.SubscriptionId
                            ResourceGroup               = $_.ResourceGroup
                            PolicyDefinitionName        = $_.PolicyDefinitionName
                            ManagementGroupIds          = $_.ManagementGroupIds
                            PolicyAssignmentScope       = $_.PolicyAssignmentScope
                            IsCompliant                 = $_.IsCompliant
                            ComplianceState             = $_.ComplianceState
                            PolicyDefinitionAction      = $_.PolicyDefinitionAction
                            PolicyDefinitionReferenceId = $_.PolicyDefinitionReferenceId
                            ResourceTags                = $_.ResourceTags
                            ResourceName                = $resourceNames[$_.ResourceId] 
                        }
                    }

                    # When ManagementGroupIds column have multiple value
                    if ($objType -ne "subscription") {
                        # Define an array to store the modified data
                        $modifiedData = @()

                        # Iterate through each row in the CSV data
                        foreach ($row in $result) {
                            # Check if the column you want to split contains a comma
                            if ($row.ManagementGroupIds -match ',') {
                                # Split the value of the column based on comma
                                $splitValues = $row.ManagementGroupIds -split ','

                                # Create a new row for each split value
                                foreach ($value in $splitValues) {
                                    # Create a new row by cloning the current row object
                                    $newRow = $row.PSObject.Copy()

                                    # Assign the split value to the column
                                    $newRow.ManagementGroupIds = $value

                                    # Add the new row to the modified data array
                                    $modifiedData += $newRow
                                }
                            } else {
                                # If the column does not contain a comma, add the row as it is
                                $modifiedData += $row
                            }
                        }
                    }
                    else {
                        $modifiedData = $result
                    }
                    
                    ## check the non-compliant & compliant resources only for $requiredPolicyExemptionIds policies

                    # count non-compliant resources
                    $resourceNonCompliant = $modifiedData | Where-Object {$_.ComplianceState -eq "NonCompliant" -and $_.ResourceName -ne $obj.Id}
                    $counterResourceNonCompliant = $resourceNonCompliant.count

                    # count compliant resource
                    $resourceCompliant = $modifiedData | Where-Object {$_.ComplianceState -eq "Compliant" -and $_.ResourceName -ne $obj.Id}
                    $counterResourceCompliant = $resourceCompliant.count
                }
                if ($null -eq $counterResourceNonCompliant) {
                    $ComplianceStatus=$false
                    $Comment=$msgTable.isNullCompliantResource -f $PolicyId, $($obj.Name), $($obj.DisplayName)
                }
                elseif ($counterResourceNonCompliant -eq 0) {
                    $ComplianceStatus=$true
                    $Comment=$msgTable.isCompliantResource -f $counterResourceCompliant 
                }
                else {
                    $ComplianceStatus=$false
                    $Comment=$msgTable.isNotCompliantResource -f $counterResourceNonCompliant, $modifiedData.Count
                }
            }
        }
        if ($obj.DisplayName -eq $null)
        {
            $DisplayName=$obj.Name
        }
        else {
            $DisplayName=$obj.DisplayName
        }

        $c = New-Object -TypeName PSCustomObject -Property @{ 
            Type = [string]$objType
            Id = [string]$obj.Id
            Name = [string]$obj.Name
            DisplayName = [string]$DisplayName
            ComplianceStatus = [boolean]$ComplianceStatus
            Comments = [string]$Comment
            ItemName = [string]$ItemName
            itsgcode = [string]$itsgcode
            ControlName = [string]$ControlName
            ReportTime = [string]$ReportTime
        }

        $tempObjectList.add($c)| Out-Null
    }
    return $tempObjectList
}
function Verify-ProtectionDataAtRest {
    param (
            [string] $ControlName,
            [string]$ItemName,
            [string] $PolicyID, 
            [string] $itsgcode, 
            [hashtable] $msgTable,
            [Parameter(Mandatory=$true)]
            [string]
            $ReportTime,
            [Parameter(Mandatory=$false)]
            [string]
            $CBSSubscriptionName
    )
    [PSCustomObject] $ObjectList = New-Object System.Collections.ArrayList
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    $grRequiredPolicies=@("TransparentDataEncryptionOnSqlDatabasesShouldBeEnabled","DiskEncryptionShouldBeAppliedOnVirtualMachines")
    # $grRequiredPolicies=@("TransparentDataEncryptionOnSqlDatabasesShouldBeEnabled","DiskEncryptionShouldBeAppliedOnVirtualMachines","AuditUnrestrictedNetworkAccessToStorageAccounts","SecureTransferToStorageAccountsShouldBeEnabled")
    
    #Check Subscriptions
    try {
        $objs = Get-AzSubscription -ErrorAction Stop| Where-Object {$_.State -eq "Enabled"} 
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzSubscription' command--verify your permissions and the installion of `
            the Az.Resources module; returned error message: $_")
        throw "Error: Failed to execute the 'Get-AzSubscription' command--verify your permissions and the installion of the `
            Az.Resources module; returned error message: $_"
    }
    [string]$type = "subscription"
    $ObjectList+=Check-StatusDataAtRest -objList $objs -objType $type -itsgcode $itsgcode -requiredPolicyExemptionIds $grRequiredPolicies -PolicyID $PolicyID -ReportTime $ReportTime -ItemName $ItemName -LogType $LogType -msgTable $msgTable  -ControlName $ControlName
    
    #Check management groups
    try {
        $objs = Get-AzManagementGroup -ErrorAction Stop
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of `
            the Az.Resources module; returned error message: $_")
        throw "Error: Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of the  `
            Az.Resources module; returned error message: $_"
    }
    [string]$type = "Management Group"  
    $ObjectList+=Check-StatusDataAtRest -objList $objs -itsgcode $itsgcode -objType $type -requiredPolicyExemptionIds $grRequiredPolicies -PolicyID $PolicyID -ReportTime $ReportTime -ItemName $ItemName -LogType $LogType -msgTable $msgTable -ControlName $ControlName
    
    
    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $ObjectList 
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }

    return $moduleOutput  
}


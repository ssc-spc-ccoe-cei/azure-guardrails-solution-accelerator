function Test-ExemptionExists {
    param (
        [string] $ScopeId,
        [array]  $requiredPolicyExemptionIds
    )
    $exemptionsIds=(Get-AzPolicyExemption -Scope $ScopeId).Properties.PolicyDefinitionReferenceIds
    if ($null -ne $exemptionsIds)
    {
        foreach ($exemptionId in $exemptionsIds)
        {
            if ($exemptionId -in $requiredPolicyExemptionIds)
            {
                return $true
            }
        }
    }
    else {
        return $false
    }
    
}
function Check-StatusDataAtRest {
    param (
        [System.Object] $objList,
        [string] $objType, #subscription or management Group
        [array]  $requiredPolicyExemptionIds,
        [string] $PolicyID,
        [string] $ControlName,
        [string] $ItemName,
        [string] $LogType,
        [string] $itsgcode,
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string]
        $ReportTime
    )   
    [PSCustomObject] $tempObjectList = New-Object System.Collections.ArrayList
    $PolicyID = "4c4a5f27-de81-430b-b4e5-9cbd50595a87" # debug
    foreach ($obj in $objList)
    {
        if (!($PolicyID -like "/providers/Microsoft.Authorization/policySetDefinitions")) {
            $PolicyDefinitionID = "/providers/Microsoft.Authorization/policySetDefinitions/$PolicyID"
        }
        # will be used for debugging
        Write-Host "PolicyDefinitionID is $PolicyDefinitionID" 
        Write-Host "PolicyID is $PolicyID"                     
        if ($objType -eq "subscription"){
            $tempId="/subscriptions/$($obj.Id)"
        }
        else {
            $tempId=$obj.Id                              
        }
        Write-Host "Scope is $tempId"
        
        # $AssignedPolicyList = Get-AzPolicyAssignment -scope $tempId -PolicyDefinitionId $PolicyID
        $AssignedPolicyList = Get-AzPolicyAssignment -scope $tempId -PolicyDefinitionId $PolicyDefinitionID
        If ($null -eq $AssignedPolicyList -or (-not ([string]::IsNullOrEmpty(($AssignedPolicyList.Properties.NotScopesScope)))))
        {
            $Comment=$msgTable.pbmmNotApplied 
            $ComplianceStatus=$false
        }
        else {
            #PBMM is applied and not excluded. Testing if specific policies haven't been excluded.
            if (Test-ExemptionExists -ScopeId $tempId -requiredPolicyExemptionIds $requiredPolicyExemptionIds)
            { # boolean, exemption for gr6 required policies exists.
                $ComplianceStatus=$false
                $Comment=$msgTable.grexemptionFound -f $obj.Id,$objType
            }
            else {
                # No exemption exists. 

                # # Needed for DEBUG:
                # $currentDateTime = Get-Date -Format "yyyyMMdd"
                # $folderPath = "./GR6_output_folder/Excel-output-$obj.Name-$currentDateTime"
                # # create a new folder with timestamp
                # New-Item -ItemType Directory -Path $folderPath
                    

                # get compliance details for the PBMM policy
                
                # Check the number of resources and compliance status under each policy in applied PBMM
                if ($objType -eq "subscription"){
                    Write-Host "Subscription : $($obj.Name)"
                    $complianceDetails = (Get-AzPolicyState -SubscriptionId $($obj.Id) ) | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID}
                    
                }
                else {
                    Write-Host "Management Group : $($obj.Name)"
                    $complianceDetails = (Get-AzPolicyState) | Where-Object{ $_.PolicySetDefinitionName -eq $PolicyID}
                    $complianceDetails = $complianceDetails | Where-Object{$_.PolicyAssignmentScope -like "*$tempId*" } 
                }

                if ($null -eq $complianceDetails) {
                    $counterResourceNonCompliant = $null
                    Write-Host "PBMM policy $PolicyId is not applied to this resource with name $($obj.DisplayName) and Id $($obj.Name) "
                }
                else{
                    $requiredPolicyExemptionIds_smallCaps = @()
                    foreach ($str in $requiredPolicyExemptionIds) {
                        $requiredPolicyExemptionIds_smallCaps += $str.ToLower()
                    }
                    # Filter for GR6 required policies
                    $complianceDetails = $complianceDetails | Where-Object{ $_.PolicyDefinitionReferenceId -in $requiredPolicyExemptionIds_smallCaps}
                    # get compliance data including resources
                    $resourceNames = @{}
                    foreach ($resource in $complianceDetails) {
                        $resourcename = ($resource.ResourceId -split '/')[-1]
                        $resourceNames[$resource.ResourceId] = $resourcename
                    }
                    $result = $complianceDetails | ForEach-Object {
                        [PSCustomObject]@{
                            Timestamp                   = $_.Timestamp
                            ResourceId                  = $_.ResourceId
                            ResourceLocation            = $_.ResourceLocation
                            ResourceType                = $_.ResourceType
                            SubscriptionId              = $_.SubscriptionId
                            ResourceGroup               = $_.ResourceGroup
                            PolicyDefinitionName        = $_.PolicyDefinitionName
                            ManagementGroupIds          = $_.ManagementGroupIds
                            PolicyAssignmentScope       = $_.PolicyAssignmentScope
                            IsCompliant                 = $_.IsCompliant
                            ComplianceState             = $_.ComplianceState
                            PolicyDefinitionAction      = $_.PolicyDefinitionAction
                            PolicyDefinitionReferenceId = $_.PolicyDefinitionReferenceId
                            ResourceTags                = $_.ResourceTags
                            ResourceName                = $resourceNames[$_.ResourceId] 
                        }
                    }
                    
                    # # Needed for debug: Export the result to CSV
                    # # This will save the file in setup folder during localExecution
                    # $result | Export-Csv -NoTypeInformation -Path "$folderPath/result.csv"

                    # When ManagementGroupIds column have multiple value
                    if ($objType -ne "subscription") {
                        # Define an array to store the modified data
                        $modifiedData = @()

                        # Iterate through each row in the CSV data
                        foreach ($row in $result) {
                            # Check if the column you want to split contains a comma
                            if ($row.ManagementGroupIds -match ',') {
                                # Split the value of the column based on comma
                                $splitValues = $row.ManagementGroupIds -split ','

                                # Create a new row for each split value
                                foreach ($value in $splitValues) {
                                    # Create a new row by cloning the current row object
                                    $newRow = $row.PSObject.Copy()

                                    # Assign the split value to the column
                                    $newRow.ManagementGroupIds = $value

                                    # Add the new row to the modified data array
                                    $modifiedData += $newRow
                                }
                            } else {
                                # If the column does not contain a comma, add the row as it is
                                $modifiedData += $row
                            }
                        }

                        # # Export the modified data to a new CSV file
                        # $modifiedData | Export-CSV -NoTypeInformation -Path "$folderPath/modified_result.csv"
                        }
                    else {
                        $modifiedData = $result
                    }
                    
                    ## check the non-compliant & compliant resources only for $requiredPolicyExemptionIds policies

                    # count non-compliant resources
                    $resourceNonCompliant = $modifiedData | Where-Object {$_.ComplianceState -eq "NonCompliant" -and $_.ResourceName -ne $obj.Id}
                    $counterResourceNonCompliant = $resourceNonCompliant.count

                    # count compliant resource
                    $resourceCompliant = $modifiedData | Where-Object {$_.ComplianceState -eq "Compliant" -and $_.ResourceName -ne $obj.Id}
                    $counterResourceCompliant = $resourceCompliant.count
                }
                if ($null -eq $counterResourceNonCompliant) {
                    $ComplianceStatus=$false
                    $Comment=$msgTable.isNullCompliantResource -f $PolicyId, $($obj.Name), $($obj.DisplayName)
                }
                elseif ($counterResourceNonCompliant -eq 0) {
                    $ComplianceStatus=$true
                    $Comment=$msgTable.isCompliantResource -f $counterResourceCompliant 
                }
                else {
                    $ComplianceStatus=$false
                    $Comment=$msgTable.isNotCompliantResource -f $counterResourceNonCompliant, $modifiedData.Count
                }
                
                
                # # Find compliance states only for available policies
                # $PolicyState = Get-AzPolicyState | Where-object{$_.PolicySetDefinitionName} 
                # # Filter for PBMM policy
                # $PolicyState = $PolicyState | Where-object{$_.PolicySetDefinitionName -like $PolicyID} 
                # # Filter for Scope tempId
                # $PolicyState = $PolicyState | Where-Object{$_.PolicyAssignmentScope -like "*$tempId*" } 
                # $PolicyState = $PolicyState | Where-Object{$_.PolicyAssignmentName -like $AssignedPolicyList.ResourceName }
                
                # $counterResourceCompliant = 0
                # $counterResourceNonCompliant = 0
                # # if the total resources is zero
                # if ($PolicyState.Count -eq 0) {
                #     $ComplianceStatus=$true
                #     $Comment=$msgTable.isCompliant -f $counterResourceCompliant 
                # }
                # elseif ($PolicyState.Count -gt 0) {
                #     # $resourceIsCompliant = $false
                #     # $resourceComlianceFound = $false
                    
                #     # $counterResourceCompliant = 0
                #     # $counterResourceNonCompliant = 0
                
                #     foreach ($policy in $PolicyState) {
                #         if ($policy.ComplianceState -eq "Compliant") {
                #             $counterResourceCompliant += 1
                #         }
                #         else {
                #             $counterResourceNonCompliant += 1
                #         }
                #     }

                #     if ($counterResourceCompliant -eq $PolicyState.Count) {
                #         $ComplianceStatus=$true
                #         $Comment=$msgTable.isCompliant -f $counterResourceCompliant
                #     }
                #     else {
                #         $ComplianceStatus=$false
                #         $Comment=$msgTable.isNotCompliant -f $counterResourceNonCompliant -f $PolicyState.Count
                #     }
                # }
                    
                # # }
                # # catch {
                # #     $string_err = $_ | Out-String
                # #     write-host $string_err
                # #     $Errorlist.Add("Failed to execute the 'Get-AzPolicyState' command--verify your permissions and the installion of `
                # #         the Az.Resources module; returned error message: $string_err")
                # #     throw "Error: Failed to execute the 'Get-AzPolicyState' command--verify your permissions and the installion of the  `
                # #         Az.Resources module; returned error message: $string_err"
                # # }
            }
        }
        if ($obj.DisplayName -eq $null)
        {
            $DisplayName=$obj.Name
        }
        else {
            $DisplayName=$obj.DisplayName
        }

        $c = New-Object -TypeName PSCustomObject -Property @{ 
            Type = [string]$objType
            Id = [string]$obj.Id
            Name = [string]$obj.Name
            DisplayName = [string]$DisplayName
            ComplianceStatus = [boolean]$ComplianceStatus
            Comments = [string]$Comment
            ItemName = [string]$ItemName
            itsgcode = [string]$itsgcode
            ControlName = [string]$ControlName
            ReportTime = [string]$ReportTime
            # ResourceName = [string]$ResourceName
            # ResourceGroup = [string]$PolicyState.ResourceGroup
            # ResourceType = [string]$PolicyState.ResourceType
            # PolicyDefinitionReferenceId = [string]$PolicyState.PolicyDefinitionReferenceId

        }

        $tempObjectList.add($c)| Out-Null
    }
    return $tempObjectList
}
function Verify-ProtectionDataAtRest {
    param (
            [string] $ControlName,
            [string]$ItemName,
            [string] $PolicyID, 
            [string] $itsgcode, 
            [hashtable] $msgTable,
            [Parameter(Mandatory=$true)]
            [string]
            $ReportTime,
            [Parameter(Mandatory=$false)]
            [string]
            $CBSSubscriptionName
    )
    [PSCustomObject] $ObjectList = New-Object System.Collections.ArrayList
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    # $grRequiredPolicies=@("TransparentDataEncryptionOnSqlDatabasesShouldBeEnabled","DiskEncryptionShouldBeAppliedOnVirtualMachines")
    $grRequiredPolicies=@("TransparentDataEncryptionOnSqlDatabasesShouldBeEnabled","DiskEncryptionShouldBeAppliedOnVirtualMachines","AuditUnrestrictedNetworkAccessToStorageAccounts","SecureTransferToStorageAccountsShouldBeEnabled")
    
    #Check management groups
    try {
        $objs = Get-AzManagementGroup -ErrorAction Stop
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of `
            the Az.Resources module; returned error message: $_")
        throw "Error: Failed to execute the 'Get-AzManagementGroup' command--verify your permissions and the installion of the  `
            Az.Resources module; returned error message: $_"
    }
    [string]$type = "Management Group"  
    $ObjectList+=Check-StatusDataAtRest -objList $objs -itsgcode $itsgcode -objType $type -requiredPolicyExemptionIds $grRequiredPolicies -PolicyID $PolicyID -ReportTime $ReportTime -ItemName $ItemName -LogType $LogType -msgTable $msgTable -ControlName $ControlName
    #Check Subscriptions
    try {
        $objs = Get-AzSubscription -ErrorAction Stop| Where-Object {$_.State -eq "Enabled"} 
    }
    catch {
        $Errorlist.Add("Failed to execute the 'Get-AzSubscription' command--verify your permissions and the installion of `
            the Az.Resources module; returned error message: $_")
        throw "Error: Failed to execute the 'Get-AzSubscription' command--verify your permissions and the installion of the `
            Az.Resources module; returned error message: $_"
    }
    [string]$type = "subscription"
    $ObjectList+=Check-StatusDataAtRest -objList $objs -objType $type -itsgcode $itsgcode -requiredPolicyExemptionIds $grRequiredPolicies -PolicyID $PolicyID -ReportTime $ReportTime -ItemName $ItemName -LogType $LogType -msgTable $msgTable  -ControlName $ControlName
    
    
    $moduleOutput= [PSCustomObject]@{ 
        ComplianceResults = $ObjectList 
        Errors=$ErrorList
        AdditionalResults = $AdditionalResults
    }
    # # Needed for DEBUG:
    # $currentDateTime = Get-Date -Format "yyyyMMdd"
    # $folderPath = "./GR6_output_folder/module$currentDateTime"
    # # create a new folder with timestamp
    # New-Item -ItemType Directory -Path $folderPath
    # $moduleOutput.ComplianceResults | Export-CSV "$folderPath/GR6ModuleOutput.csv"

    return $moduleOutput  
}


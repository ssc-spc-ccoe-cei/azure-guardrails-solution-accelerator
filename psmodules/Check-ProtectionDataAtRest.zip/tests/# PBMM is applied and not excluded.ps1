# PBMM is applied and not excluded. Testing if specific policies haven't been excluded.
            if (Test-ExemptionExists -ScopeId $tempId -requiredPolicyExemptionIds $requiredPolicyExemptionIds){   
                # boolean, exemption for gr6 required policies exists.
                $ComplianceStatus=$false
                $Comment += $msgTable.grexemptionFound -f $obj.Id,$objType
            }
            else {
                # Required Policy Definitions are not exempt. Find compliance details for the assigned PBMM policy
                $Comment += ' ' + $msgTable.grexemptionNotFound
                # Check the number of resources and compliance for the required policies in applied PBMM initiative

                # ----------------#
                # Subscription
                # ----------------#
                if ($objType -eq "subscription"){
                    Write-Host "Find compliance details for Subscription : $($obj.Name)"
                    $subscription = @()
                    $subscription += New-Object -TypeName psobject -Property ([ordered]@{'DisplayName'=$obj.Name;'SubscriptionID'=$obj.Id})
                    
                    $currentSubscription = Get-AzContext
                    if($currentSubscription.Subscription.Id -ne $subscription.SubscriptionId){
                        # Set Az context to the this subscription
                        Set-AzContext -SubscriptionId $subscription.SubscriptionID
                        Write-Host "AzContext set to $($subscription.DisplayName)"
                    }

                    $complianceDetailsSubscription = Test-ComplianceForSubscription -obj $obj -subscription $subscription -PolicyID $PolicyID -requiredPolicyExemptionIds $requiredPolicyExemptionIds -objType $objType
                    if ($null -eq $complianceDetailsSubscription) {
                        Write-Host "Compliance details for $($subscription.DisplayName) outputs as NULL"
                        $complianceDetailsList = $null
                    }
                    else{
                        $complianceDetailsList = $complianceDetailsSubscription | Select-Object `
                            Timestamp, ResourceId, ResourceLocation, ResourceType, SubscriptionId, `
                            ResourceGroup, PolicyDefinitionName, ManagementGroupIds, PolicyAssignmentScope, IsCompliant, `
                            ComplianceState, PolicyDefinitionAction, PolicyDefinitionReferenceId, ResourceTags, ResourceName
                    } 
                }
                # ----------------#
                # Management Group
                # ----------------#
                else {
                    Write-Host "Find compliance details for Management Group : $($obj.Name)"
                    # get all subscription under this management group: $obj
                    $topLvlMgmtGrp =  $obj.Name        
                    $allSubscriptions = @()                   

                    # Collect data from managementgroups
                    $mgmtGroups = Get-AzManagementGroup -GroupId $topLvlMgmtGrp -Expand -Recurse
                    if( $null -eq $mgmtGroups){
                        Write-Host "mgmtGroups outputs as null"
                    }

                    $children = $true
                    while ($children) {
                        $children = $false
                        $firstrun = $true
                        foreach ($entry in $mgmtGroups) {
                            if ($firstrun) {Clear-Variable mgmtGroups ; $firstrun = $false}
                            if ($entry.Children.length -gt 0) {
                                # Add management group to data that is being looped through
                                $children       = $true
                                $mgmtGroups    += $entry.Children
                            }
                            elseif ($entry.type -ne "Microsoft.Management/managementGroups") {
                                # Add subscription to output object
                                $allSubscriptions += New-Object -TypeName psobject -Property ([ordered]@{'DisplayName'=$entry.DisplayName;'SubscriptionID'=$entry.Name})
                            }
                        }
                    }
                    
                    Write-Host "Loop through all Subscriptions within $($obj.Name) "
                    $complianceDetailsList = @()
                    foreach ($subscription in $allSubscriptions) {
                        $complianceDetailsList_by_subscription = @()
                        Write-Host "Subscription ID: $($subscription.SubscriptionId)"
                        
                        # Set context to the current subscription
                        Set-AzContext -SubscriptionId $subscription.SubscriptionID
                        Write-Host "AzContext set to $($subscription.DisplayName)"
                        $complianceDetailsSubscription = Test-ComplianceForSubscription -obj $obj -subscription $subscription -PolicyID $PolicyID -requiredPolicyExemptionIds $requiredPolicyExemptionIds -objType $objType
                        Write-Host "complianceDetailsSubscription count: $($complianceDetailsSubscription.count)"
                        
                        if ($null -eq $complianceDetailsSubscription) {
                            Write-Host "Compliance details for $($subscription.DisplayName) outputs as NULL"
                            $complianceDetailsList_by_subscription = $null
                        }
                        else{
                            $comD = $complianceDetailsSubscription | ForEach-Object {
                                [PSCustomObject]@{
                                    Timestamp                   = $_.Timestamp
                                    ResourceId                  = $_.ResourceId
                                    ResourceLocation            = $_.ResourceLocation
                                    ResourceType                = $_.ResourceType
                                    SubscriptionId              = $_.SubscriptionId
                                    ResourceGroup               = $_.ResourceGroup
                                    PolicyDefinitionName        = $_.PolicyDefinitionName
                                    ManagementGroupIds          = $_.ManagementGroupIds
                                    PolicyAssignmentScope       = $_.PolicyAssignmentScope
                                    IsCompliant                 = $_.IsCompliant
                                    ComplianceState             = $_.ComplianceState
                                    PolicyDefinitionAction      = $_.PolicyDefinitionAction
                                    PolicyDefinitionReferenceId = $_.PolicyDefinitionReferenceId
                                    ResourceTags                = $_.ResourceTags
                                    ResourceName                = $_.ResourceId
                                }
                            }
                            Write-Host "comD count: $($comD.count)"
                            foreach($c in $comD){
                                [array]$complianceDetailsList_by_subscription += $c
                            }
                        }
                        
                        if (-not $null -eq $complianceDetailsList_by_subscription){
                            foreach($cDetails in $complianceDetailsList_by_subscription){
                                [array]$complianceDetailsList += $cDetails
                            }
                        }
                    }
                }
function Check-UserGroups {
    param (
        [Parameter(Mandatory=$true)]
        [string] $ControlName,
        [Parameter(Mandatory=$true)]
        [string] $ItemName,
        [Parameter(Mandatory=$true)]
        [string] $itsgcode,
        [Parameter(Mandatory=$true)]
        [hashtable] $msgTable,
        [Parameter(Mandatory=$true)]
        [string] $ReportTime,
        [string] $CloudUsageProfiles = "3",  # Passed as a string
        [string] $ModuleProfiles,  # Passed as a string
        [switch] $EnableMultiCloudProfiles # New feature flag, default to false
    )

    # High-level flow:
    # 1. Load the IDs of all current Member and Guest users into one "uncovered" set.
    # 2. For a large tenant, sample up to 40 users to find groups that may cover a large part of that set.
    # 3. Scan useful broad groups first and remove every user ID found from the set.
    # 4. Finish by checking the remaining users directly or by scanning the remaining groups,
    #    whichever is estimated to require fewer Microsoft Graph requests.
    # 5. Report coverage only when every required Graph read completes; an empty set proves that
    #    every in-scope user belongs to at least one group.
    [PSCustomObject] $ErrorList = New-Object System.Collections.ArrayList
    [bool] $IsCompliant = $false
    [string] $Comments = $null
    [PSCustomObject] $AdditionalResults = $null
    $commentsArray = @()
    $implementationId = 'IdBaselineDynamicV1'
    # Keep detailed validation diagnostics for the first representative scale runs. After those
    # results answer the open tuning questions, change this to Operational to reduce routine output.
    $diagnosticLevel = 'Validation'
    # Microsoft Graph returns these large collections in pages. Using 999 records per page stays
    # within the endpoint limit while minimizing the number of sequential page requests.
    $userPageSize = 999
    $membershipPageSize = 999
    # Forty users require only two Graph batches and give a more stable tenant-wide sample than 20.
    # Groups must appear for at least 10% of the sample, and only the best 20 candidates are retained.
    $probeSampleSize = 40
    $probeCandidateLimit = 20
    $probeFrequencyPercent = 10
    # On small tenants, probing costs about as much as simply completing the scan, so skip it when
    # no more than 40 users or 60 groups remain.
    $smallUserThreshold = 40
    $smallGroupThreshold = 60
    # Run at most one fresh probe when the original sample has fewer than 10 uncovered users left,
    # more than 1,000 real users remain, and either fallback would still take at least six rounds.
    $reprobeMinimumUsers = 1000
    $reprobeMinimumRounds = 6
    $minimumResidualSampleSize = 10
    # During a full group scan, reconsider the cheaper completion path every 250 completed groups
    # or every five minutes so a long-tail tenant can switch to direct user checks when that becomes faster.
    $groupPathRecheckInterval = 250

    # Graph accepts at most 20 inner requests. Known full continuation pages use a lower cap
    # because several 999-record responses in one batch create a much larger memory spike.
    $graphBatchRequestSize = 20
    $fullContinuationBatchSize = 5
    # Send one outer Graph batch at a time. This avoids multiplying inner request concurrency and
    # keeps response memory bounded while the first scale tests establish safe tenant limits.
    $concurrentGraphBatchCalls = 1
    # Retry transient Graph failures no more than three times, using five seconds when Graph does
    # not supply its own Retry-After value.
    $defaultMaxRetries = 3
    $defaultRetryDelaySeconds = 5
    # Keep diagnostics useful but bounded so logging does not become part of the scale problem.
    $remediationSampleLimit = 20
    $slowGroupDiagnosticThresholdSeconds = 30
    $slowBatchDiagnosticThresholdSeconds = 30
    # Separate limits preserve high-value group diagnostics even when retries are frequent.
    $detailedDiagnosticBudgets = @{
        Retry            = [PSCustomObject]@{ Limit = 5;  LinesWritten = 0; SuppressionLogged = $false }
        MultiPage        = [PSCustomObject]@{ Limit = 10; LinesWritten = 0; SuppressionLogged = $false }
        NoteworthyGroup  = [PSCustomObject]@{ Limit = 10; LinesWritten = 0; SuppressionLogged = $false }
        NoteworthyBatch  = [PSCustomObject]@{ Limit = 10; LinesWritten = 0; SuppressionLogged = $false }
        Failure          = [PSCustomObject]@{ Limit = 20; LinesWritten = 0; SuppressionLogged = $false }
    }
    $overallProgressMinuteInterval = 5
    # Refresh with a wide safety margin so a slow batch is unlikely to reach token expiry.
    $tokenRefreshIntervalMinutes = 30
    $moduleStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $diagnosticMetrics = [PSCustomObject]@{
        Lines      = 0
        Characters = 0
        WriteMs    = 0.0
    }
    $graphMetrics = [PSCustomObject]@{
        DirectAttempts                = 0
        SingleRequestDirectCalls      = 0
        BatchCalls                    = 0
        InnerAttempts                 = 0
        Retries                       = 0
        Throttles429                  = 0
        ResourceUnits                 = 0.0
        MaximumThrottlePercentage     = 0.0
        MaximumBatchRecords           = 0
    }
    $scanMetrics = [PSCustomObject]@{
        UserBaselinePages        = 0
        UserRecordsReturned      = 0
        SkippedUserRecords       = 0
        ProbeRuns                = 0
        ProbeTruncatedResponses  = 0
        GroupListPages           = 0
        GroupsStarted            = 0
        GroupsCompleted          = 0
        MembershipPages          = 0
        FirstPages               = 0
        ContinuationPages        = 0
        MembershipRecords        = 0
        DirectUsersChecked       = 0
        Reprobes                 = 0
        SelectedPath             = 'NotSelected'
        SinglePageGroups         = 0
        TwoToFivePageGroups      = 0
        SixToTwentyPageGroups    = 0
        OverTwentyPageGroups     = 0
    }
    # Failures are collected by category first so a tenant-wide outage cannot create thousands
    # of Log Analytics exception rows. Optional read failures are promoted only if coverage remains unknown.
    $terminalFailureStore = [PSCustomObject]@{
        Total      = 0
        Categories = @{}
        Details    = [System.Collections.Generic.List[string]]::new()
    }
    $pendingFailureStore = [PSCustomObject]@{
        Total      = 0
        Categories = @{}
        Details    = [System.Collections.Generic.List[string]]::new()
    }
    $planningFailureStore = [PSCustomObject]@{
        Total      = 0
        Categories = @{}
        Details    = [System.Collections.Generic.List[string]]::new()
    }

    # Use the matching localization package for operator-facing compliance and statistics text.
    $userGroupScanIncompleteMessage = [string]$msgTable['userGroupScanIncomplete']
    $userStatsMessageTemplate = [string]$msgTable['userStats']

    # Capture both working-set and private memory because Azure's sandbox limit does not map cleanly
    # to one process metric. Processor time helps show whether Graph waits or local CPU dominate.
    function Get-GroupScanResourceSnapshot {
        $process = [System.Diagnostics.Process]::GetCurrentProcess()
        try {
            return [PSCustomObject]@{
                CurrentMb       = [Math]::Round(($process.WorkingSet64 / 1MB), 1)
                PeakMb          = [Math]::Round(($process.PeakWorkingSet64 / 1MB), 1)
                PrivateMb       = [Math]::Round(($process.PrivateMemorySize64 / 1MB), 1)
                ProcessorSeconds = [Math]::Round($process.TotalProcessorTime.TotalSeconds, 3)
            }
        }
        finally {
            $process.Dispose()
        }
    }

    # Send diagnostics to a stream that Azure Automation preserves in exported job logs.
    # Warning records stay separate from the module's structured return value and do not change compliance results.
    function Write-CheckUserGroupDiagnostic {
        param(
            [Parameter(Mandatory=$true)]
            [string] $Message
        )

        $diagnosticStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $formattedMessage = "[Diagnostic] $Message"
        Write-Warning $formattedMessage
        $diagnosticMetrics.Lines++
        $diagnosticMetrics.Characters += $formattedMessage.Length
        $diagnosticMetrics.WriteMs += $diagnosticStopwatch.Elapsed.TotalMilliseconds
    }

    # Mark the start and end of major stages so the last job-output line identifies where a stopped run was working.
    function Write-CheckUserGroupStage {
        param(
            [Parameter(Mandatory=$true)]
            [string] $Stage,
            [Parameter(Mandatory=$true)]
            [string] $State,
            [Parameter(Mandatory=$true)]
            [System.Diagnostics.Stopwatch] $Stopwatch,
            [string] $Details
        )

        $memory = Get-GroupScanResourceSnapshot
        $message = "Check-UserGroups stage: Stage=$Stage; State=$State; StageElapsed=$($Stopwatch.Elapsed); TotalElapsed=$($moduleStopwatch.Elapsed); Memory=$($memory.CurrentMb) MB; PeakMemory=$($memory.PeakMb) MB; PrivateMemory=$($memory.PrivateMb) MB; ProcessorSeconds=$($memory.ProcessorSeconds)"
        if ($Details) {
            $message += "; $Details"
        }
        Write-CheckUserGroupDiagnostic -Message $message
    }

    # Cap detailed event lines so heavy Graph throttling cannot flood the Azure Automation output stream.
    # Periodic progress and final aggregate summaries continue after this limit is reached.
    function Test-GroupDiagnosticDetailAllowed {
        param(
            [Parameter(Mandatory=$true)]
            [ValidateSet('Retry', 'MultiPage', 'NoteworthyGroup', 'NoteworthyBatch', 'Failure')]
            [string] $Category
        )

        $categoryState = $detailedDiagnosticBudgets[$Category]
        if ($categoryState.LinesWritten -lt $categoryState.Limit) {
            $categoryState.LinesWritten++
            return $true
        }

        if (-not $categoryState.SuppressionLogged) {
            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups $Category diagnostics capped at $($categoryState.Limit) lines; periodic and final summaries will continue."
            $categoryState.SuppressionLogged = $true
        }
        return $false
    }

    Write-CheckUserGroupStage -Stage 'Module' -State 'Started' -Stopwatch $moduleStopwatch -Details "Implementation=$implementationId; DiagnosticLevel=$diagnosticLevel; UserPageSize=$userPageSize; MembershipPageSize=$membershipPageSize; GraphBatchLimit=$graphBatchRequestSize; FullContinuationLimit=$fullContinuationBatchSize; ConcurrentBatchCalls=$concurrentGraphBatchCalls"

    # Keep one placeholder row so the Log Analytics remediation table continues to exist on passing
    # runs. A complete scan that finds uncovered users replaces it with up to 20 examples.
    $AdditionalResults = [PSCustomObject]@{
        logType = "GR2UsersWithoutGroups"
        records = @([PSCustomObject]@{
            UserId            = "N/A"
            DisplayName       = "N/A"
            GivenName         = "N/A"
            UserPrincipalName = "N/A"
            Comments          = $msgTable.userInGroup
            ReportTime        = $ReportTime
            itsgcode          = $itsgcode
        })
    }

    # Managed identity issues the token, but the bearer token in the header can expire during a long scan.
    function Get-GraphAuthorizationHeader {
        try {
            # Az.Accounts versions differ on whether Token is plain text or SecureString.
            # Requesting a SecureString first and converting it here keeps the header valid in either runtime.
            $tokenResponse = Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com/' -AsSecureString -ErrorAction Stop
            $accessToken = [System.Net.NetworkCredential]::new('', $tokenResponse.Token).Password
        }
        catch {
            $tokenResponse = Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com/' -ErrorAction Stop
            if ($tokenResponse.Token -is [System.Security.SecureString]) {
                $accessToken = [System.Net.NetworkCredential]::new('', $tokenResponse.Token).Password
            }
            else {
                $accessToken = [string]$tokenResponse.Token
            }
        }

        return "Bearer $accessToken"
    }

    $authenticationStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    Write-CheckUserGroupStage -Stage 'GraphAuthentication' -State 'Started' -Stopwatch $authenticationStopwatch
    try {
        $headers = @{
            Authorization    = (Get-GraphAuthorizationHeader)
            ConsistencyLevel = "eventual"
        }
        $tokenRefreshStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-CheckUserGroupStage -Stage 'GraphAuthentication' -State 'Completed' -Stopwatch $authenticationStopwatch
    }
    catch {
        Write-CheckUserGroupStage -Stage 'GraphAuthentication' -State 'Failed' -Stopwatch $authenticationStopwatch -Details "Error=$($_.Exception.Message)"
        [void]$ErrorList.Add("Failed to get access token for Microsoft Graph API: $_")
        $AdditionalResults.records[0].Comments = $userGroupScanIncompleteMessage
        $authenticationFailureResult = [PSCustomObject]@{
            ComplianceStatus = $false
            ControlName      = $ControlName
            ItemName         = $ItemName
            Comments         = "$($msgTable.isNotCompliant) $userGroupScanIncompleteMessage"
            ReportTime       = $ReportTime
            itsgcode         = $itsgcode
        }
        Write-CheckUserGroupStage -Stage 'Module' -State 'CompletedWithErrors' -Stopwatch $moduleStopwatch -Details 'IsCompliant=False; Failure=GraphAuthentication'
        return [PSCustomObject]@{
            ComplianceResults = $authenticationFailureResult
            Errors            = $ErrorList
            AdditionalResults = $AdditionalResults
        }
    }

    # Refresh the token between batch calls so long scans do not fail when the original token expires.
    function Invoke-GraphAuthorizationRefresh {
        param(
            [Parameter(Mandatory=$true)]
            [string] $Trigger
        )

        $tokenRefreshStageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-CheckUserGroupStage -Stage 'GraphTokenRefresh' -State 'Started' -Stopwatch $tokenRefreshStageStopwatch -Details "Trigger=$Trigger"
        try {
            $newAuthorizationHeader = Get-GraphAuthorizationHeader
            $headers.Authorization = $newAuthorizationHeader
            $tokenRefreshStopwatch.Restart()
            Write-CheckUserGroupStage -Stage 'GraphTokenRefresh' -State 'Completed' -Stopwatch $tokenRefreshStageStopwatch -Details "Trigger=$Trigger"
            return $true
        }
        catch {
            Write-CheckUserGroupStage -Stage 'GraphTokenRefresh' -State 'Failed' -Stopwatch $tokenRefreshStageStopwatch -Details "Trigger=$Trigger; Error=$($_.Exception.Message)"
            return $false
        }
    }

    # Graph may return request-cost and throttle-percentage headers. They are tuning evidence only;
    # missing or malformed optional headers never change compliance or retry behavior.
    function Add-GraphHeaderMetric {
        param($ResponseHeaders)

        if ($null -eq $ResponseHeaders) {
            return
        }

        $getHeaderValue = {
            param($Headers, [string] $Name)

            if ($Headers -is [System.Collections.IDictionary]) {
                foreach ($key in $Headers.Keys) {
                    if ([string]$key -ieq $Name) {
                        return @($Headers[$key]) | Select-Object -First 1
                    }
                }
            }

            $property = $Headers.PSObject.Properties |
                Where-Object { $_.Name -ieq $Name } |
                Select-Object -First 1
            if ($property) {
                return @($property.Value) | Select-Object -First 1
            }

            return $null
        }

        $resourceUnitText = & $getHeaderValue $ResponseHeaders 'x-ms-resource-unit'
        $resourceUnits = 0.0
        if ($null -ne $resourceUnitText -and
            [double]::TryParse([string]$resourceUnitText, [ref]$resourceUnits)) {
            $graphMetrics.ResourceUnits += $resourceUnits
        }

        $throttleText = & $getHeaderValue $ResponseHeaders 'x-ms-throttle-limit-percentage'
        $throttlePercentage = 0.0
        if ($null -ne $throttleText -and
            [double]::TryParse(([string]$throttleText).TrimEnd('%'), [ref]$throttlePercentage)) {
            $graphMetrics.MaximumThrottlePercentage = [Math]::Max($graphMetrics.MaximumThrottlePercentage, $throttlePercentage)
        }
    }

    # Graph 429 responses can include Retry-After, which tells us how long to wait.
    # This helps large scans back off cleanly instead of retrying too quickly.
    function Get-GraphRetryDelay {
        param(
            [Parameter(Mandatory=$true)]
            $ErrorRecord,
            [int] $DefaultDelaySeconds = 5
        )

        $retryAfter = $null
        if ($ErrorRecord.Exception.Response -and $ErrorRecord.Exception.Response.Headers) {
            $retryAfterValues = $null
            try {
                if ($ErrorRecord.Exception.Response.Headers.TryGetValues('Retry-After', [ref]$retryAfterValues)) {
                    $retryAfter = $retryAfterValues | Select-Object -First 1
                }
            } catch {
                $retryAfter = $null
            }
        }

        $retryAfterSeconds = 0
        if ($null -ne $retryAfter -and [int]::TryParse([string]$retryAfter, [ref]$retryAfterSeconds) -and $retryAfterSeconds -gt 0) {
            return $retryAfterSeconds
        }

        return $DefaultDelaySeconds
    }

    # Read one Graph page directly with bounded retries. This is used for sequential paging and for
    # one-request work where wrapping the request in JSON batching would add latency without parallel work.
    function Invoke-GraphGetWithRetry {
        param (
            [Parameter(Mandatory=$true)]
            [string] $Uri,
            [Parameter(Mandatory=$true)]
            [hashtable] $Headers,
            [ValidateRange(1, 10)]
            [int] $MaxRetries = $defaultMaxRetries,
            [ValidateRange(0, 300)]
            [int] $RetryDelaySeconds = $defaultRetryDelaySeconds
        )

        for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
            try {
                $responseHeaders = $null
                $graphMetrics.DirectAttempts++
                $response = Invoke-RestMethod -Method Get -Uri $Uri -Headers $Headers -ResponseHeadersVariable responseHeaders -ErrorAction Stop
                Add-GraphHeaderMetric -ResponseHeaders $responseHeaders
                if ($null -eq $response) {
                    throw "Microsoft Graph returned an empty response for '$Uri'."
                }
                return $response
            } catch {
                $statusCode = $null
                if ($_.Exception.Response -and $null -ne $_.Exception.Response.StatusCode) {
                    $statusCode = [int]$_.Exception.Response.StatusCode
                }

                if ($statusCode -eq 429) {
                    $graphMetrics.Throttles429++
                }

                $isRetryable = $null -eq $statusCode -or $statusCode -in @(401, 429, 500, 502, 503, 504)
                if (-not $isRetryable -or $attempt -eq $MaxRetries) {
                    throw
                }

                $delaySeconds = Get-GraphRetryDelay -ErrorRecord $_ -DefaultDelaySeconds $RetryDelaySeconds
                if ($statusCode -eq 401) {
                    if (-not (Invoke-GraphAuthorizationRefresh -Trigger 'DirectRequest401')) {
                        throw
                    }
                    $delaySeconds = 0
                }

                $graphMetrics.Retries++
                if (Test-GroupDiagnosticDetailAllowed -Category 'Retry') {
                    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups Graph retry: Scope=Direct; Attempt=$attempt/$MaxRetries; StatusCode=$statusCode; DelaySeconds=$delaySeconds; Endpoint=$(([Uri]$Uri).AbsolutePath)"
                }
                if ($delaySeconds -gt 0) {
                    Start-Sleep -Seconds $delaySeconds
                }
            }
        }

        # Parameter validation does not validate a default value, so never allow an empty loop to return null silently.
        throw "Graph request to '$Uri' ended without making a retry attempt. MaxRetries must be at least 1."
    }

    # Graph returns absolute nextLink URLs, while an inner JSON batch request needs a URL relative
    # to the v1.0 endpoint. Keeping only the path and query also avoids copying host details into batches.
    function ConvertTo-GraphBatchRelativeUrl {
        param(
            [Parameter(Mandatory=$true)]
            [string] $Url
        )

        if ([Uri]::IsWellFormedUriString($Url, [UriKind]::Absolute)) {
            $relativeUrl = ([Uri]$Url).PathAndQuery
        }
        else {
            $relativeUrl = $Url
        }

        if ($relativeUrl.StartsWith('/v1.0/', [System.StringComparison]::OrdinalIgnoreCase)) {
            return $relativeUrl.Substring('/v1.0'.Length)
        }

        return $relativeUrl
    }

    # Direct requests need an absolute URL. Reuse the batch URL normalization so an initial
    # relative path and a later absolute nextLink resolve to the same Microsoft Graph endpoint.
    function ConvertTo-GraphAbsoluteUrl {
        param(
            [Parameter(Mandatory=$true)]
            [string] $Url
        )

        $relativeUrl = ConvertTo-GraphBatchRelativeUrl -Url $Url
        if (-not $relativeUrl.StartsWith('/')) {
            $relativeUrl = "/$relativeUrl"
        }

        return "https://graph.microsoft.com/v1.0$relativeUrl"
    }

    # Retry-After is carried inside each JSON batch response rather than on the outer HTTP response.
    function Get-GraphBatchResponseRetryDelay {
        param(
            [Parameter(Mandatory=$true)]
            [AllowNull()]
            $BatchResponse,
            [int] $DefaultDelaySeconds = 5
        )

        $retryAfter = $null
        if ($null -ne $BatchResponse -and $BatchResponse.headers) {
            $retryAfterProperty = $BatchResponse.headers.PSObject.Properties |
                Where-Object { $_.Name -ieq 'Retry-After' } |
                Select-Object -First 1
            if ($retryAfterProperty) {
                $retryAfter = @($retryAfterProperty.Value) | Select-Object -First 1
            }
        }

        $retryAfterSeconds = 0
        if ($null -ne $retryAfter -and
            [int]::TryParse([string]$retryAfter, [ref]$retryAfterSeconds) -and
            $retryAfterSeconds -gt 0) {
            return $retryAfterSeconds
        }

        return $DefaultDelaySeconds
    }

    # Submit one bounded JSON batch. Only the outer HTTP call is retried here; failed inner
    # membership requests are retried individually by the queue that owns their group/page state.
    function Invoke-GraphJsonBatchWithRetry {
        param(
            [Parameter(Mandatory=$true)]
            [object[]] $Requests,
            [Parameter(Mandatory=$true)]
            [hashtable] $Headers,
            [ValidateRange(1, 10)]
            [int] $MaxRetries = $defaultMaxRetries,
            [ValidateRange(0, 300)]
            [int] $RetryDelaySeconds = $defaultRetryDelaySeconds
        )

        $batchUri = 'https://graph.microsoft.com/v1.0/$batch'
        $batchPayload = @{ requests = $Requests } | ConvertTo-Json -Depth 8 -Compress

        for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
            try {
                $batchHeaders = @{ Authorization = $Headers.Authorization }
                $responseHeaders = $null
                $graphMetrics.BatchCalls++
                $response = Invoke-RestMethod -Method Post -Uri $batchUri -Headers $batchHeaders -ContentType 'application/json' -Body $batchPayload -ResponseHeadersVariable responseHeaders -ErrorAction Stop
                Add-GraphHeaderMetric -ResponseHeaders $responseHeaders
                if ($null -eq $response -or $null -eq $response.responses) {
                    throw 'Microsoft Graph returned an empty JSON batch response.'
                }

                return [PSCustomObject]@{
                    Response = $response
                }
            }
            catch {
                $statusCode = $null
                if ($_.Exception.Response -and $null -ne $_.Exception.Response.StatusCode) {
                    $statusCode = [int]$_.Exception.Response.StatusCode
                }
                if ($statusCode -eq 429) {
                    $graphMetrics.Throttles429++
                }

                $isRetryable = $null -eq $statusCode -or $statusCode -in @(401, 429, 500, 502, 503, 504)
                if (-not $isRetryable -or $attempt -eq $MaxRetries) {
                    throw
                }

                $delaySeconds = Get-GraphRetryDelay -ErrorRecord $_ -DefaultDelaySeconds $RetryDelaySeconds
                if ($statusCode -eq 401) {
                    if (-not (Invoke-GraphAuthorizationRefresh -Trigger 'OuterBatch401')) {
                        throw
                    }
                    $delaySeconds = 0
                }

                if (Test-GroupDiagnosticDetailAllowed -Category 'Retry') {
                    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups Graph batch retry: Scope=Outer; Attempt=$attempt/$MaxRetries; StatusCode=$statusCode; InnerRequests=$($Requests.Count); DelaySeconds=$delaySeconds"
                }
                $graphMetrics.Retries++
                if ($delaySeconds -gt 0) {
                    Start-Sleep -Seconds $delaySeconds
                }
            }
        }

        throw 'Microsoft Graph JSON batch ended without making a retry attempt.'
    }

    # Extract enough Graph error context to group repeated failures without retaining every response body.
    function Get-GraphFailureContext {
        param($ErrorRecord)

        $statusCode = 'NoStatus'
        if ($ErrorRecord.Exception.Response -and $null -ne $ErrorRecord.Exception.Response.StatusCode) {
            $statusCode = [string][int]$ErrorRecord.Exception.Response.StatusCode
        }

        $graphCode = 'NoCode'
        if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) {
            try {
                $errorBody = $ErrorRecord.ErrorDetails.Message | ConvertFrom-Json -ErrorAction Stop
                if ($errorBody.error.code) {
                    $graphCode = [string]$errorBody.error.code
                }
            }
            catch {
                $graphCode = 'NoCode'
            }
        }

        return [PSCustomObject]@{
            StatusCode = $statusCode
            GraphCode  = $graphCode
            Message    = [string]$ErrorRecord.Exception.Message
        }
    }

    # Count every failure for compliance, but keep only bounded examples for Log Analytics.
    # Pending failures come from optional paths and are promoted only if exact coverage remains unproved.
    function Add-CheckUserGroupFailure {
        param(
            [Parameter(Mandatory=$true)]
            [ValidateSet('Terminal', 'Pending', 'Planning')]
            [string] $Kind,
            [Parameter(Mandatory=$true)]
            [string] $Stage,
            [Parameter(Mandatory=$true)]
            [string] $Endpoint,
            [Parameter(Mandatory=$true)]
            [string] $StatusCode,
            [Parameter(Mandatory=$true)]
            [string] $GraphCode,
            [string] $EntityId,
            [Parameter(Mandatory=$true)]
            [string] $Message
        )

        $store = switch ($Kind) {
            'Terminal' { $terminalFailureStore }
            'Pending'  { $pendingFailureStore }
            default    { $planningFailureStore }
        }
        $categoryKey = "$Stage|$Endpoint|$StatusCode|$GraphCode"
        if (-not $store.Categories.ContainsKey($categoryKey)) {
            $store.Categories[$categoryKey] = [PSCustomObject]@{
                Stage      = $Stage
                Endpoint   = $Endpoint
                StatusCode = $StatusCode
                GraphCode  = $GraphCode
                Count      = 0
                DetailCount = 0
                EntityIds  = [System.Collections.Generic.List[string]]::new()
            }
        }

        $category = $store.Categories[$categoryKey]
        $store.Total++
        $category.Count++
        if ($EntityId -and $category.EntityIds.Count -lt 10 -and -not $category.EntityIds.Contains($EntityId)) {
            [void]$category.EntityIds.Add($EntityId)
        }

        if ($store.Details.Count -lt 20 -and $category.DetailCount -lt 10) {
            $detail = "Stage=$Stage; Endpoint=$Endpoint; HTTP=$StatusCode; GraphCode=$GraphCode"
            if ($EntityId) {
                $detail += "; EntityId=$EntityId"
            }
            $detail += "; Error=$Message"
            [void]$store.Details.Add($detail)
            $category.DetailCount++
        }

        if (Test-GroupDiagnosticDetailAllowed -Category 'Failure') {
            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups Graph failure: Kind=$Kind; Stage=$Stage; Endpoint=$Endpoint; HTTP=$StatusCode; GraphCode=$GraphCode; EntityId=$EntityId; Error=$Message"
        }
    }

    # Convert a normal PowerShell web error into the same bounded failure format used for JSON batch
    # errors. Keeping one format makes incomplete reads visible without producing one error row per group.
    function Add-ErrorRecordFailure {
        param(
            [Parameter(Mandatory=$true)]
            [ValidateSet('Terminal', 'Pending', 'Planning')]
            [string] $Kind,
            [Parameter(Mandatory=$true)]
            [string] $Stage,
            [Parameter(Mandatory=$true)]
            [string] $Endpoint,
            [string] $EntityId,
            [Parameter(Mandatory=$true)]
            $ErrorRecord
        )

        $context = Get-GraphFailureContext -ErrorRecord $ErrorRecord
        Add-CheckUserGroupFailure -Kind $Kind -Stage $Stage -Endpoint $Endpoint -StatusCode $context.StatusCode -GraphCode $context.GraphCode -EntityId $EntityId -Message $context.Message
    }

    # Materialize bounded detail and summary rows only once, after the final result is known.
    function Write-StructuredFailure {
        foreach ($detail in $terminalFailureStore.Details) {
            [void]$ErrorList.Add($detail)
        }

        $categories = @($terminalFailureStore.Categories.Values | Sort-Object -Property Count -Descending)
        $categoryLimit = [Math]::Min(20, $categories.Count)
        for ($index = 0; $index -lt $categoryLimit; $index++) {
            $category = $categories[$index]
            $sampleIds = if ($category.EntityIds.Count -gt 0) { $category.EntityIds -join ',' } else { 'N/A' }
            [void]$ErrorList.Add("Failure summary: Stage=$($category.Stage); Endpoint=$($category.Endpoint); HTTP=$($category.StatusCode); GraphCode=$($category.GraphCode); Affected=$($category.Count); SampleEntityIds=$sampleIds")
        }

        if ($categories.Count -gt $categoryLimit) {
            $overflowCount = [int](($categories[$categoryLimit..($categories.Count - 1)] | Measure-Object -Property Count -Sum).Sum)
            [void]$ErrorList.Add("Failure summary: AdditionalCategories=$($categories.Count - $categoryLimit); Affected=$overflowCount")
        }
    }

    # Execute independent Graph requests in batches of at most 20. A one-request set uses a direct
    # GET because wrapping one dependent page in JSON batching added substantial client latency.
    # Both paths use the same bounded retries and return shape, so coverage logic remains unchanged.
    function Invoke-GraphBatchRequestSet {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [object[]] $Items,
            [Parameter(Mandatory=$true)]
            [string] $Stage,
            [Parameter(Mandatory=$true)]
            [string] $Endpoint,
            [ValidateSet('Terminal', 'Pending', 'Planning')]
            [string] $FailureKind = 'Terminal'
        )

        $successfulResults = [System.Collections.Generic.List[object]]::new()
        $failedResults = [System.Collections.Generic.List[object]]::new()
        $pendingItems = [System.Collections.Generic.List[object]]::new()
        foreach ($item in @($Items)) {
            # Keep caller-specific page state (for example PageNumber and KnownFullContinuation)
            # while adding retry state used only by this helper.
            $pendingItem = $item.PSObject.Copy()
            $pendingItem | Add-Member -MemberType NoteProperty -Name Attempt -Value 1 -Force
            [void]$pendingItems.Add($pendingItem)
        }

        while ($pendingItems.Count -gt 0) {
            if ($tokenRefreshStopwatch.Elapsed.TotalMinutes -ge $tokenRefreshIntervalMinutes) {
                if (-not (Invoke-GraphAuthorizationRefresh -Trigger "$Stage-BeforeBatch")) {
                    foreach ($pendingItem in $pendingItems) {
                        Add-CheckUserGroupFailure -Kind $FailureKind -Stage $Stage -Endpoint $Endpoint -StatusCode 'NoStatus' -GraphCode 'TokenRefreshFailed' -EntityId $pendingItem.EntityId -Message 'Microsoft Graph access token refresh failed.'
                        [void]$failedResults.Add([PSCustomObject]@{ Item = $pendingItem; Status = $null; GraphCode = 'TokenRefreshFailed' })
                    }
                    break
                }
            }

            $nextPendingItems = [System.Collections.Generic.List[object]]::new()
            $maximumRetryDelaySeconds = 0
            $inner401RefreshSucceeded = $null
            for ($offset = 0; $offset -lt $pendingItems.Count; $offset += $graphBatchRequestSize) {
                $lastIndex = [Math]::Min($offset + $graphBatchRequestSize - 1, $pendingItems.Count - 1)
                $chunk = @($pendingItems[$offset..$lastIndex])

                # A single nextLink is sequential work and gains nothing from a JSON batch wrapper.
                # Read it directly to reduce latency while retaining the existing retry and token-refresh behavior.
                if ($chunk.Count -eq 1) {
                    $pendingItem = $chunk[0]
                    # A request that already failed inside a batch keeps only its unused attempts,
                    # preventing the direct fallback from silently expanding the three-attempt limit.
                    $remainingAttempts = [Math]::Max(1, $defaultMaxRetries - [int]$pendingItem.Attempt + 1)
                    $graphMetrics.SingleRequestDirectCalls++
                    try {
                        $directResponse = Invoke-GraphGetWithRetry -Uri (ConvertTo-GraphAbsoluteUrl -Url $pendingItem.Url) -Headers $headers -MaxRetries $remainingAttempts
                        [void]$successfulResults.Add([PSCustomObject]@{
                            Item   = $pendingItem
                            Status = 200
                            Body   = $directResponse
                        })
                    }
                    catch {
                        $failureContext = Get-GraphFailureContext -ErrorRecord $_
                        Add-CheckUserGroupFailure -Kind $FailureKind -Stage $Stage -Endpoint $Endpoint -StatusCode $failureContext.StatusCode -GraphCode $failureContext.GraphCode -EntityId $pendingItem.EntityId -Message $failureContext.Message
                        [void]$failedResults.Add([PSCustomObject]@{
                            Item      = $pendingItem
                            Status    = $failureContext.StatusCode
                            GraphCode = $failureContext.GraphCode
                        })
                    }
                    continue
                }

                $batchRequests = [System.Collections.Generic.List[object]]::new()
                $itemByRequestId = @{}
                $requestId = 1
                foreach ($pendingItem in $chunk) {
                    $requestKey = [string]$requestId
                    $itemByRequestId[$requestKey] = $pendingItem
                    [void]$batchRequests.Add(@{
                        id      = $requestKey
                        method  = 'GET'
                        url     = (ConvertTo-GraphBatchRelativeUrl -Url $pendingItem.Url)
                        headers = @{ ConsistencyLevel = 'eventual' }
                    })
                    $requestId++
                    $graphMetrics.InnerAttempts++
                }

                try {
                    $batchResult = Invoke-GraphJsonBatchWithRetry -Requests $batchRequests.ToArray() -Headers $headers
                }
                catch {
                    foreach ($pendingItem in $chunk) {
                        Add-ErrorRecordFailure -Kind $FailureKind -Stage $Stage -Endpoint $Endpoint -EntityId $pendingItem.EntityId -ErrorRecord $_
                        [void]$failedResults.Add([PSCustomObject]@{ Item = $pendingItem; Status = $null; GraphCode = 'OuterBatchFailed' })
                    }
                    continue
                }

                $responsesById = @{}
                foreach ($innerResponse in @($batchResult.Response.responses)) {
                    $responsesById[[string]$innerResponse.id] = $innerResponse
                }

                foreach ($requestKey in $itemByRequestId.Keys) {
                    $pendingItem = $itemByRequestId[$requestKey]
                    $innerResponse = $responsesById[$requestKey]
                    $statusCode = if ($null -ne $innerResponse -and $null -ne $innerResponse.status) { [int]$innerResponse.status } else { $null }
                    Add-GraphHeaderMetric -ResponseHeaders $innerResponse.headers

                    if ($statusCode -ge 200 -and $statusCode -lt 300 -and $null -ne $innerResponse.body) {
                        [void]$successfulResults.Add([PSCustomObject]@{
                            Item   = $pendingItem
                            Status = $statusCode
                            Body   = $innerResponse.body
                        })
                        continue
                    }

                    $graphCode = if ($innerResponse.body.error.code) { [string]$innerResponse.body.error.code } else { 'NoCode' }
                    $errorMessage = if ($innerResponse.body.error.message) { [string]$innerResponse.body.error.message } else { 'Microsoft Graph returned no response body.' }
                    if ($statusCode -eq 429) {
                        $graphMetrics.Throttles429++
                    }

                    $isRetryable = $null -eq $statusCode -or $statusCode -in @(401, 429, 500, 502, 503, 504)
                    if ($isRetryable -and $pendingItem.Attempt -lt $defaultMaxRetries) {
                        $delaySeconds = Get-GraphBatchResponseRetryDelay -BatchResponse $innerResponse -DefaultDelaySeconds $defaultRetryDelaySeconds
                        if ($statusCode -eq 401) {
                            # One expired batch can return many 401 responses. Refresh once, then let
                            # every affected inner request retry with the same new token.
                            if ($null -eq $inner401RefreshSucceeded) {
                                $inner401RefreshSucceeded = Invoke-GraphAuthorizationRefresh -Trigger "$Stage-Inner401"
                            }
                            if (-not $inner401RefreshSucceeded) {
                                $isRetryable = $false
                            }
                            $delaySeconds = 0
                        }

                        if ($isRetryable) {
                            $pendingItem.Attempt++
                            $graphMetrics.Retries++
                            if (Test-GroupDiagnosticDetailAllowed -Category 'Retry') {
                                Write-CheckUserGroupDiagnostic -Message "Check-UserGroups Graph retry: Scope=Inner; Stage=$Stage; EntityId=$($pendingItem.EntityId); Attempt=$($pendingItem.Attempt)/$defaultMaxRetries; HTTP=$statusCode; DelaySeconds=$delaySeconds"
                            }
                            $maximumRetryDelaySeconds = [Math]::Max($maximumRetryDelaySeconds, $delaySeconds)
                            [void]$nextPendingItems.Add($pendingItem)
                            continue
                        }
                    }

                    Add-CheckUserGroupFailure -Kind $FailureKind -Stage $Stage -Endpoint $Endpoint -StatusCode $(if ($null -eq $statusCode) { 'NoStatus' } else { [string]$statusCode }) -GraphCode $graphCode -EntityId $pendingItem.EntityId -Message $errorMessage
                    [void]$failedResults.Add([PSCustomObject]@{ Item = $pendingItem; Status = $statusCode; GraphCode = $graphCode })
                }
            }

            # Inner requests share one retry window. Waiting once for the longest Retry-After avoids
            # multiplying a 60-second throttle delay by every failed request in the same batch.
            if ($nextPendingItems.Count -gt 0 -and $maximumRetryDelaySeconds -gt 0) {
                Start-Sleep -Seconds $maximumRetryDelaySeconds
            }

            $pendingItems = $nextPendingItems
        }

        return [PSCustomObject]@{
            Successful = $successfulResults.ToArray()
            Failed     = $failedResults.ToArray()
        }
    }

    # Reservoir sampling keeps a fixed-size, uniformly mixed sample while walking a HashSet once.
    # One random generator is reused for the full walk so rapid clock-based reseeding cannot bias the sample.
    function Get-UniformUserSample {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UserIds,
            [ValidateRange(1, 1000)]
            [int] $Limit = $probeSampleSize
        )

        $sample = [System.Collections.Generic.List[Guid]]::new($Limit)
        $random = [System.Random]::new()
        $seen = 0
        foreach ($userId in $UserIds) {
            $seen++
            if ($sample.Count -lt $Limit) {
                [void]$sample.Add($userId)
                continue
            }

            $replacementIndex = $random.Next(0, $seen)
            if ($replacementIndex -lt $Limit) {
                $sample[$replacementIndex] = $userId
            }
        }

        return [Guid[]]$sample.ToArray()
    }

    # Probe a uniform user sample for direct group IDs. This is an ordering hint only: the probe
    # reads one page per user and exact group/user paths still decide compliance if it misses a group.
    function Find-BroadGroupCandidate {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UncoveredUserIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $CompletedGroupIds,
            [Parameter(Mandatory=$true)]
            [int] $ProbeNumber,
            [Parameter(Mandatory=$true)]
            [string] $Reason
        )

        $probeStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $sampleIds = Get-UniformUserSample -UserIds $UncoveredUserIds -Limit $probeSampleSize
        $scanMetrics.ProbeRuns++
        Write-CheckUserGroupStage -Stage 'BroadGroupProbe' -State 'Started' -Stopwatch $probeStopwatch -Details "Probe=$ProbeNumber; Reason=$Reason; SampleSize=$($sampleIds.Count); Uncovered=$($UncoveredUserIds.Count)"
        if ($diagnosticLevel -eq 'Validation' -and $sampleIds.Count -gt 0) {
            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups probe sample: Probe=$ProbeNumber; UserIds=$($sampleIds -join ',')"
        }

        # Keep only the bounded sample's user-to-group arrays plus one integer per observed group. Creating a
        # separate HashSet for every possible group would add avoidable object overhead in memory.
        $groupFrequency = [System.Collections.Generic.Dictionary[Guid, int]]::new()
        $sampleGroupsByUser = [System.Collections.Generic.Dictionary[Guid, Guid[]]]::new()
        for ($offset = 0; $offset -lt $sampleIds.Count; $offset += $graphBatchRequestSize) {
            $lastIndex = [Math]::Min($offset + $graphBatchRequestSize - 1, $sampleIds.Count - 1)
            $items = [System.Collections.Generic.List[object]]::new()
            foreach ($userId in @($sampleIds[$offset..$lastIndex])) {
                [void]$items.Add([PSCustomObject]@{
                    EntityId = [string]$userId
                    Url      = "/users/$userId/memberOf/microsoft.graph.group?`$select=id&`$top=$membershipPageSize&`$count=true"
                })
            }

            $probeResult = Invoke-GraphBatchRequestSet -Items $items.ToArray() -Stage 'BroadGroupProbe' -Endpoint 'UserMemberOfProbe' -FailureKind 'Planning'
            foreach ($success in @($probeResult.Successful)) {
                $sampleUserId = [Guid]$success.Item.EntityId
                $groupsForUser = [System.Collections.Generic.List[Guid]]::new()
                if ($success.Body.'@odata.nextLink') {
                    $scanMetrics.ProbeTruncatedResponses++
                }

                foreach ($group in @($success.Body.value)) {
                    $groupId = [Guid]::Empty
                    if (-not [Guid]::TryParse([string]$group.id, [ref]$groupId) -or $CompletedGroupIds.Contains($groupId)) {
                        continue
                    }

                    [void]$groupsForUser.Add($groupId)
                    if ($groupFrequency.ContainsKey($groupId)) {
                        $groupFrequency[$groupId]++
                    }
                    else {
                        $groupFrequency[$groupId] = 1
                    }
                }
                $sampleGroupsByUser[$sampleUserId] = $groupsForUser.ToArray()
            }
        }

        # Require a group to contain at least two sampled users and at least 10% of the sample. This
        # filters incidental memberships while retaining groups likely to remove substantial work.
        $minimumHits = [Math]::Max(2, [int][Math]::Ceiling($sampleIds.Count * ($probeFrequencyPercent / 100.0)))
        $rankedGroupIds = @($groupFrequency.GetEnumerator() |
            Where-Object { $_.Value -ge $minimumHits } |
            Sort-Object -Property @{ Expression = { $_.Value }; Descending = $true }, @{ Expression = { [string]$_.Key }; Descending = $false } |
            Select-Object -First $probeCandidateLimit |
            ForEach-Object { [Guid]$_.Key })
        $candidateById = @{}
        foreach ($groupId in $rankedGroupIds) {
            $candidateById[[string]$groupId] = [PSCustomObject]@{
                GroupId       = $groupId
                SampleUserIds = [System.Collections.Generic.HashSet[Guid]]::new()
            }
        }
        foreach ($sampleUserId in $sampleGroupsByUser.Keys) {
            foreach ($groupId in $sampleGroupsByUser[$sampleUserId]) {
                $candidate = $candidateById[[string]$groupId]
                if ($candidate) {
                    [void]$candidate.SampleUserIds.Add($sampleUserId)
                }
            }
        }
        $candidates = @($rankedGroupIds | ForEach-Object { $candidateById[[string]$_] })

        Write-CheckUserGroupStage -Stage 'BroadGroupProbe' -State 'Completed' -Stopwatch $probeStopwatch -Details "Probe=$ProbeNumber; Candidates=$($candidates.Count); MinimumHits=$minimumHits; TruncatedResponses=$($scanMetrics.ProbeTruncatedResponses); PlanningFailures=$($planningFailureStore.Total)"
        return [PSCustomObject]@{
            SampleIds  = [Guid[]]$sampleIds
            Candidates = $candidates
        }
    }

    # Candidate counts estimate scan cost only. The exact ID set, never these eventually consistent
    # counts, determines whether every current Member/Guest user was covered.
    function Add-BroadGroupCandidateCount {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [object[]] $Candidates
        )

        if ($Candidates.Count -eq 0) {
            return @()
        }

        $items = [System.Collections.Generic.List[object]]::new()
        foreach ($candidate in $Candidates) {
            [void]$items.Add([PSCustomObject]@{
                EntityId = [string]$candidate.GroupId
                Url      = "/groups/$($candidate.GroupId)/members/microsoft.graph.user?`$select=id&`$top=1&`$count=true"
            })
        }

        $countResult = Invoke-GraphBatchRequestSet -Items $items.ToArray() -Stage 'CandidatePlanning' -Endpoint 'GroupUserCount' -FailureKind 'Planning'
        $countByGroup = @{}
        foreach ($success in @($countResult.Successful)) {
            $countValue = 0L
            if ($null -ne $success.Body.'@odata.count' -and [long]::TryParse([string]$success.Body.'@odata.count', [ref]$countValue)) {
                $countByGroup[[string]$success.Item.EntityId] = $countValue
            }
        }

        $countedCandidates = [System.Collections.Generic.List[object]]::new()
        foreach ($candidate in $Candidates) {
            $candidateKey = [string]$candidate.GroupId
            if (-not $countByGroup.ContainsKey($candidateKey)) {
                continue
            }
            [void]$countedCandidates.Add([PSCustomObject]@{
                GroupId       = $candidate.GroupId
                SampleUserIds = $candidate.SampleUserIds
                DirectUserCount = [long]$countByGroup[$candidateKey]
                EstimatedPages  = [Math]::Max(1, [int][Math]::Ceiling($countByGroup[$candidateKey] / [double]$membershipPageSize))
            })
        }

        return $countedCandidates.ToArray()
    }

    # Scan direct user members for one or more groups. nextLink pages return to the queue so one
    # very large group cannot permanently block other groups that may cover the remaining users.
    function Invoke-GroupMembershipScan {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [Guid[]] $GroupIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UncoveredUserIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $CompletedGroupIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $AttemptedGroupIds,
            [Parameter(Mandatory=$true)]
            [string] $Source,
            [ValidateSet('Terminal', 'Pending')]
            [string] $FailureKind = 'Pending',
            [bool] $AllowDirectSwitch = $false,
            [int] $TotalGroupCount = 0
        )

        $stageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $progressStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $queue = [System.Collections.Generic.Queue[object]]::new()
        $groupStates = @{}
        foreach ($groupId in $GroupIds) {
            if ($CompletedGroupIds.Contains($groupId) -or $groupStates.ContainsKey([string]$groupId)) {
                continue
            }

            $groupKey = [string]$groupId
            $groupStates[$groupKey] = [PSCustomObject]@{
                PageCount     = 0
                RecordCount   = 0
                NewlyCovered  = 0
                StartedAt     = $null
            }
            $queue.Enqueue([PSCustomObject]@{
                EntityId              = $groupKey
                Url                   = "/groups/$groupKey/members/microsoft.graph.user?`$select=id&`$top=$membershipPageSize&`$count=true"
                GroupId               = $groupId
                PageNumber            = 1
                KnownFullContinuation = $false
            })
        }

        Write-CheckUserGroupStage -Stage 'GroupMembership' -State 'Started' -Stopwatch $stageStopwatch -Details "Source=$Source; GroupsQueued=$($queue.Count); Uncovered=$($UncoveredUserIds.Count)"
        $failedGroups = [System.Collections.Generic.HashSet[Guid]]::new()
        $switchToDirect = $false
        $lastPathCheckGroups = $scanMetrics.GroupsCompleted

        while ($queue.Count -gt 0 -and $UncoveredUserIds.Count -gt 0 -and -not $switchToDirect) {
            $batchItems = [System.Collections.Generic.List[object]]::new()
            $knownFullContinuations = 0
            while ($queue.Count -gt 0 -and $batchItems.Count -lt $graphBatchRequestSize) {
                $item = $queue.Dequeue()
                if ($item.KnownFullContinuation -and $knownFullContinuations -ge $fullContinuationBatchSize) {
                    # Rotate this large continuation to the back and submit the bounded batch now.
                    # This avoids walking a very large queue just to defer every remaining item.
                    $queue.Enqueue($item)
                    break
                }

                [void]$batchItems.Add($item)
                if ($item.KnownFullContinuation) {
                    $knownFullContinuations++
                }
            }
            if ($batchItems.Count -eq 0) {
                continue
            }

            foreach ($batchItem in $batchItems) {
                if ($batchItem.PageNumber -eq 1 -and $AttemptedGroupIds.Add([Guid]$batchItem.GroupId)) {
                    $scanMetrics.GroupsStarted++
                }
                $groupState = $groupStates[[string]$batchItem.GroupId]
                if ($null -eq $groupState.StartedAt) {
                    $groupState.StartedAt = [DateTime]::UtcNow
                }
            }

            $batchStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
            $batchResult = Invoke-GraphBatchRequestSet -Items $batchItems.ToArray() -Stage 'GroupMembership' -Endpoint 'GroupMembers' -FailureKind $FailureKind
            $batchRecordCount = 0
            foreach ($failure in @($batchResult.Failed)) {
                [void]$failedGroups.Add([Guid]$failure.Item.EntityId)
            }

            foreach ($success in @($batchResult.Successful)) {
                $item = $success.Item
                $groupId = [Guid]$item.EntityId
                $groupState = $groupStates[[string]$groupId]
                $users = @($success.Body.value)
                $batchRecordCount += $users.Count
                $beforeCount = $UncoveredUserIds.Count
                # Remove every returned ID from the uncovered set. HashSet removal is safe when the
                # same user belongs to several groups: the first match removes it and later matches do nothing.
                foreach ($user in $users) {
                    $userId = [Guid]::Empty
                    if ([Guid]::TryParse([string]$user.id, [ref]$userId)) {
                        [void]$UncoveredUserIds.Remove($userId)
                    }
                }

                $groupState.PageCount++
                $groupState.RecordCount += $users.Count
                $groupState.NewlyCovered += ($beforeCount - $UncoveredUserIds.Count)
                $scanMetrics.MembershipPages++
                $scanMetrics.MembershipRecords += $users.Count
                if ($item.PageNumber -eq 1) { $scanMetrics.FirstPages++ } else { $scanMetrics.ContinuationPages++ }

                $nextLink = [string]$success.Body.'@odata.nextLink'
                if ($nextLink -and $UncoveredUserIds.Count -gt 0) {
                    $queue.Enqueue([PSCustomObject]@{
                        EntityId              = [string]$groupId
                        Url                   = $nextLink
                        GroupId               = $groupId
                        PageNumber            = $item.PageNumber + 1
                        KnownFullContinuation = $users.Count -ge $membershipPageSize
                    })
                    if ($item.PageNumber -eq 1 -and (Test-GroupDiagnosticDetailAllowed -Category 'MultiPage')) {
                        Write-CheckUserGroupDiagnostic -Message "Check-UserGroups multi-page group: Source=$Source; GroupId=$groupId; FirstPageRecords=$($users.Count); NewlyCovered=$($beforeCount - $UncoveredUserIds.Count)"
                    }
                }
                else {
                    [void]$CompletedGroupIds.Add($groupId)
                    $scanMetrics.GroupsCompleted++
                    if ($groupState.PageCount -eq 1) { $scanMetrics.SinglePageGroups++ }
                    elseif ($groupState.PageCount -le 5) { $scanMetrics.TwoToFivePageGroups++ }
                    elseif ($groupState.PageCount -le 20) { $scanMetrics.SixToTwentyPageGroups++ }
                    else { $scanMetrics.OverTwentyPageGroups++ }

                    $groupDuration = ([DateTime]::UtcNow - $groupState.StartedAt).TotalSeconds
                    if (($groupState.PageCount -gt 1 -or $groupDuration -ge $slowGroupDiagnosticThresholdSeconds) -and
                        (Test-GroupDiagnosticDetailAllowed -Category 'NoteworthyGroup')) {
                        Write-CheckUserGroupDiagnostic -Message "Check-UserGroups noteworthy group: Source=$Source; GroupId=$groupId; Pages=$($groupState.PageCount); Records=$($groupState.RecordCount); NewlyCovered=$($groupState.NewlyCovered); DurationSec=$([Math]::Round($groupDuration, 1)); Uncovered=$($UncoveredUserIds.Count)"
                    }
                }
            }

            $graphMetrics.MaximumBatchRecords = [Math]::Max($graphMetrics.MaximumBatchRecords, $batchRecordCount)
            if ($batchStopwatch.Elapsed.TotalSeconds -ge $slowBatchDiagnosticThresholdSeconds -and
                (Test-GroupDiagnosticDetailAllowed -Category 'NoteworthyBatch')) {
                $batchMemory = Get-GroupScanResourceSnapshot
                Write-CheckUserGroupDiagnostic -Message "Check-UserGroups noteworthy batch: Source=$Source; Requests=$($batchItems.Count); Records=$batchRecordCount; DurationSec=$([Math]::Round($batchStopwatch.Elapsed.TotalSeconds, 1)); Queue=$($queue.Count); Uncovered=$($UncoveredUserIds.Count); PrivateMemory=$($batchMemory.PrivateMb) MB"
            }

            if (($scanMetrics.GroupsCompleted - $lastPathCheckGroups -ge $groupPathRecheckInterval) -or
                $progressStopwatch.Elapsed.TotalMinutes -ge $overallProgressMinuteInterval) {
                $progressMemory = Get-GroupScanResourceSnapshot
                Write-CheckUserGroupDiagnostic -Message "Check-UserGroups group progress: Source=$Source; GroupsStarted=$($scanMetrics.GroupsStarted); GroupsCompleted=$($scanMetrics.GroupsCompleted); Pages=$($scanMetrics.MembershipPages); Records=$($scanMetrics.MembershipRecords); Queue=$($queue.Count); Uncovered=$($UncoveredUserIds.Count); Retries=$($graphMetrics.Retries); Throttles429=$($graphMetrics.Throttles429); Elapsed=$($stageStopwatch.Elapsed); PrivateMemory=$($progressMemory.PrivateMb) MB; PeakMemory=$($progressMemory.PeakMb) MB"
                $lastPathCheckGroups = $scanMetrics.GroupsCompleted
                $progressStopwatch.Restart()

                if ($AllowDirectSwitch -and $TotalGroupCount -gt 0) {
                    $directRounds = [int][Math]::Ceiling($UncoveredUserIds.Count / [double]$graphBatchRequestSize)
                    $remainingGroups = [Math]::Max(0, $TotalGroupCount - $AttemptedGroupIds.Count)
                    # Add known continuation/queued requests to unstarted first pages. This keeps the
                    # comparison from making the group path look cheaper after many large groups start.
                    $knownRemainingGroupRequests = $remainingGroups + $queue.Count
                    $groupRounds = [int][Math]::Ceiling($knownRemainingGroupRequests / [double]$graphBatchRequestSize)
                    if ($directRounds -le $groupRounds) {
                        $switchToDirect = $true
                    }
                }
            }
        }

        $state = if ($failedGroups.Count -gt 0) { 'CompletedWithErrors' } elseif ($switchToDirect) { 'SwitchedToDirect' } elseif ($UncoveredUserIds.Count -eq 0) { 'CoverageProven' } else { 'Completed' }
        Write-CheckUserGroupStage -Stage 'GroupMembership' -State $state -Stopwatch $stageStopwatch -Details "Source=$Source; FailedGroups=$($failedGroups.Count); Uncovered=$($UncoveredUserIds.Count); SwitchToDirect=$switchToDirect"
        return [PSCustomObject]@{
            FailedGroupIds = [Guid[]]@($failedGroups)
            SwitchToDirect = $switchToDirect
        }
    }

    # Check the remaining users directly and request only one group because the answer needed is
    # simply "does this user belong to any group?" The endpoint is cast to groups so directory roles
    # and administrative units cannot incorrectly count as group coverage.
    function Invoke-DirectUserCompletion {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UncoveredUserIds
        )

        $stageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $userIds = [Guid[]]@($UncoveredUserIds)
        Write-CheckUserGroupStage -Stage 'DirectUserCompletion' -State 'Started' -Stopwatch $stageStopwatch -Details "Users=$($userIds.Count)"
        for ($offset = 0; $offset -lt $userIds.Count; $offset += $graphBatchRequestSize) {
            $lastIndex = [Math]::Min($offset + $graphBatchRequestSize - 1, $userIds.Count - 1)
            $items = [System.Collections.Generic.List[object]]::new()
            foreach ($userId in @($userIds[$offset..$lastIndex])) {
                [void]$items.Add([PSCustomObject]@{
                    EntityId = [string]$userId
                    Url      = "/users/$userId/memberOf/microsoft.graph.group?`$select=id&`$top=1&`$count=true"
                })
            }

            $directResult = Invoke-GraphBatchRequestSet -Items $items.ToArray() -Stage 'DirectUserCompletion' -Endpoint 'UserMemberOf' -FailureKind 'Terminal'
            foreach ($success in @($directResult.Successful)) {
                $scanMetrics.DirectUsersChecked++
                if (@($success.Body.value).Count -gt 0) {
                    [void]$UncoveredUserIds.Remove([Guid]$success.Item.EntityId)
                }
            }

            if ((($offset / $graphBatchRequestSize) + 1) % 25 -eq 0 -or $lastIndex -eq $userIds.Count - 1) {
                $memory = Get-GroupScanResourceSnapshot
                Write-CheckUserGroupDiagnostic -Message "Check-UserGroups direct-user progress: Completed=$($lastIndex + 1)/$($userIds.Count); Uncovered=$($UncoveredUserIds.Count); Retries=$($graphMetrics.Retries); Throttles429=$($graphMetrics.Throttles429); Elapsed=$($stageStopwatch.Elapsed); PrivateMemory=$($memory.PrivateMb) MB"
            }
        }

        $state = if ($terminalFailureStore.Total -gt 0) { 'CompletedWithErrors' } else { 'Completed' }
        Write-CheckUserGroupStage -Stage 'DirectUserCompletion' -State $state -Stopwatch $stageStopwatch -Details "UsersChecked=$($scanMetrics.DirectUsersChecked); Uncovered=$($UncoveredUserIds.Count)"
    }

    # Enumerate tenant groups only after the group path is selected. Two directory pages are kept
    # at a time, which bounds queued group state while still giving JSON batches enough independent work.
    function Invoke-FullTenantGroupCompletion {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UncoveredUserIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $CompletedGroupIds,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $AttemptedGroupIds,
            [Parameter(Mandatory=$true)]
            [int] $TotalGroupCount
        )

        $stageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-CheckUserGroupStage -Stage 'FullGroupCompletion' -State 'Started' -Stopwatch $stageStopwatch -Details "Groups=$TotalGroupCount; Uncovered=$($UncoveredUserIds.Count)"
        $groupsUrl = "https://graph.microsoft.com/v1.0/groups?`$select=id&`$top=$membershipPageSize"
        $listComplete = $true
        $switchToDirect = $false

        while ($groupsUrl -and $UncoveredUserIds.Count -gt 0 -and -not $switchToDirect) {
            $windowGroupIds = [System.Collections.Generic.List[Guid]]::new()
            for ($pageInWindow = 0; $pageInWindow -lt 2 -and $groupsUrl; $pageInWindow++) {
                $pageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
                try {
                    $groupResponse = Invoke-GraphGetWithRetry -Uri $groupsUrl -Headers $headers
                }
                catch {
                    $listComplete = $false
                    Add-ErrorRecordFailure -Kind 'Pending' -Stage 'FullGroupCompletion' -Endpoint 'GroupList' -ErrorRecord $_
                    $groupsUrl = $null
                    break
                }

                $scanMetrics.GroupListPages++
                foreach ($group in @($groupResponse.value)) {
                    $groupId = [Guid]::Empty
                    if ([Guid]::TryParse([string]$group.id, [ref]$groupId) -and -not $CompletedGroupIds.Contains($groupId)) {
                        [void]$windowGroupIds.Add($groupId)
                    }
                }
                $groupsUrl = [string]$groupResponse.'@odata.nextLink'

                if ($diagnosticLevel -eq 'Validation') {
                    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups group-list page: Page=$($scanMetrics.GroupListPages); GroupsQueued=$($windowGroupIds.Count); HasNextPage=$([bool]$groupsUrl); Duration=$($pageStopwatch.Elapsed)"
                }
            }

            if ($windowGroupIds.Count -gt 0) {
                $scanResult = Invoke-GroupMembershipScan -GroupIds $windowGroupIds.ToArray() -UncoveredUserIds $UncoveredUserIds -CompletedGroupIds $CompletedGroupIds -AttemptedGroupIds $AttemptedGroupIds -Source 'TenantGroups' -FailureKind 'Pending' -AllowDirectSwitch $true -TotalGroupCount $TotalGroupCount
                $switchToDirect = $scanResult.SwitchToDirect
            }
        }

        $state = if (-not $listComplete) { 'CompletedWithErrors' } elseif ($switchToDirect) { 'SwitchedToDirect' } elseif ($UncoveredUserIds.Count -eq 0) { 'CoverageProven' } else { 'Completed' }
        Write-CheckUserGroupStage -Stage 'FullGroupCompletion' -State $state -Stopwatch $stageStopwatch -Details "GroupListPages=$($scanMetrics.GroupListPages); Uncovered=$($UncoveredUserIds.Count); SwitchToDirect=$switchToDirect; ListComplete=$listComplete"
        return [PSCustomObject]@{
            ListComplete   = $listComplete
            SwitchToDirect = $switchToDirect
        }
    }

    # Fetch full profiles only for up to 20 proved-uncovered users. These examples help operators
    # remediate the finding; they do not participate in the compliance decision.
    function Get-UserWithoutGroupAdditionalResult {
        param(
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $UncoveredUserIds
        )

        $sampleIds = [Guid[]]@($UncoveredUserIds | Select-Object -First $remediationSampleLimit)
        if ($sampleIds.Count -eq 0) {
            return $null
        }

        $stageStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-CheckUserGroupStage -Stage 'RemediationSample' -State 'Started' -Stopwatch $stageStopwatch -Details "Maximum=$remediationSampleLimit; Selected=$($sampleIds.Count)"
        $items = [System.Collections.Generic.List[object]]::new()
        foreach ($userId in $sampleIds) {
            [void]$items.Add([PSCustomObject]@{
                EntityId = [string]$userId
                Url      = "/users/$($userId)?`$select=id,displayName,givenName,userPrincipalName"
            })
        }

        $detailsResult = Invoke-GraphBatchRequestSet -Items $items.ToArray() -Stage 'RemediationSample' -Endpoint 'UserDetails' -FailureKind 'Planning'
        $detailsById = @{}
        foreach ($success in @($detailsResult.Successful)) {
            $detailsById[[string]$success.Item.EntityId] = $success.Body
        }

        $records = [System.Collections.Generic.List[object]]::new()
        foreach ($userId in $sampleIds) {
            $user = $detailsById[[string]$userId]
            [void]$records.Add([PSCustomObject]@{
                UserId            = [string]$userId
                DisplayName       = if ($user) { $user.displayName } else { 'N/A' }
                GivenName         = if ($user) { $user.givenName } else { 'N/A' }
                UserPrincipalName = if ($user) { $user.userPrincipalName } else { 'N/A' }
                Comments          = $msgTable.userNotInGroup
                ReportTime        = $ReportTime
                itsgcode          = $itsgcode
            })
        }

        Write-CheckUserGroupStage -Stage 'RemediationSample' -State 'Completed' -Stopwatch $stageStopwatch -Details "Selected=$($sampleIds.Count); DetailsLoaded=$($detailsById.Count); DetailFailures=$($detailsResult.Failed.Count)"
        return [PSCustomObject]@{
            records = $records.ToArray()
            logType = 'GR2UsersWithoutGroups'
        }
    }

    # Estimate how many Graph batch rounds remain for two exact options: ask each uncovered user
    # whether it belongs to a group, or scan the remaining groups. Choose the smaller estimate and
    # use direct users for a tie. This affects speed only; exact user IDs still decide compliance.
    function Get-CompletionPlan {
        param(
            [Parameter(Mandatory=$true)]
            [long] $UncoveredCount,
            [Parameter(Mandatory=$true)]
            [int] $TotalGroupCount,
            [Parameter(Mandatory=$true)]
            [AllowEmptyCollection()]
            [System.Collections.Generic.HashSet[Guid]] $CompletedGroupIds,
            [AllowEmptyCollection()]
            [object[]] $KnownCandidates = @()
        )

        $directRounds = [int][Math]::Ceiling($UncoveredCount / [double]$graphBatchRequestSize)
        $remainingGroups = [Math]::Max(0, $TotalGroupCount - $CompletedGroupIds.Count)
        $groupRounds = [int][Math]::Ceiling($remainingGroups / [double]$graphBatchRequestSize)
        $largestKnownChain = 0
        foreach ($candidate in @($KnownCandidates)) {
            if (-not $CompletedGroupIds.Contains([Guid]$candidate.GroupId)) {
                $largestKnownChain = [Math]::Max($largestKnownChain, [int]$candidate.EstimatedPages)
            }
        }
        $groupRounds = [Math]::Max($groupRounds, $largestKnownChain)
        $selectedPath = if ($directRounds -le $groupRounds) { 'DirectUsers' } else { 'TenantGroups' }

        return [PSCustomObject]@{
            DirectRounds      = $directRounds
            GroupRounds       = $groupRounds
            RemainingGroups   = $remainingGroups
            LargestKnownChain = $largestKnownChain
            SelectedPath      = $selectedPath
            CheapestRounds    = [Math]::Min($directRounds, $groupRounds)
        }
    }

    # Build one exact, ID-only baseline. Storing GUIDs instead of full profiles keeps memory bounded,
    # while Member/Guest totals come from the same records that the compliance decision evaluates.
    $baselineStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    Write-CheckUserGroupStage -Stage 'UserBaseline' -State 'Started' -Stopwatch $baselineStopwatch -Details "PageSize=$userPageSize"
    $uncoveredUserIds = [System.Collections.Generic.HashSet[Guid]]::new()
    $baselineComplete = $true
    $memberCount = 0
    $guestCount = 0
    $usersUrl = 'https://graph.microsoft.com/v1.0/users?$select=id,userType&$top={0}' -f $userPageSize
    do {
        $userResponse = $null
        try {
            $userResponse = Invoke-GraphGetWithRetry -Uri $usersUrl -Headers $headers
        }
        catch {
            $baselineComplete = $false
            Add-ErrorRecordFailure -Kind 'Terminal' -Stage 'UserBaseline' -Endpoint 'Users' -ErrorRecord $_
            break
        }

        $scanMetrics.UserBaselinePages++
        $users = @($userResponse.value)
        $scanMetrics.UserRecordsReturned += $users.Count
        foreach ($user in $users) {
            if ($user.userType -notin @('Member', 'Guest')) {
                $scanMetrics.SkippedUserRecords++
                continue
            }

            $userId = [Guid]::Empty
            if (-not [Guid]::TryParse([string]$user.id, [ref]$userId)) {
                $baselineComplete = $false
                Add-CheckUserGroupFailure -Kind 'Terminal' -Stage 'UserBaseline' -Endpoint 'Users' -StatusCode 'NoStatus' -GraphCode 'InvalidUserId' -EntityId ([string]$user.id) -Message 'Microsoft Graph returned a Member/Guest user without a valid GUID.'
                continue
            }

            if ($uncoveredUserIds.Add($userId)) {
                if ($user.userType -eq 'Member') { $memberCount++ } else { $guestCount++ }
            }
        }

        $usersUrl = [string]$userResponse.'@odata.nextLink'
        if ($scanMetrics.UserBaselinePages % 25 -eq 0 -or -not $usersUrl) {
            $baselineMemory = Get-GroupScanResourceSnapshot
            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups baseline progress: Pages=$($scanMetrics.UserBaselinePages); Records=$($scanMetrics.UserRecordsReturned); InScope=$($uncoveredUserIds.Count); Members=$memberCount; Guests=$guestCount; Skipped=$($scanMetrics.SkippedUserRecords); HasNextPage=$([bool]$usersUrl); Elapsed=$($baselineStopwatch.Elapsed); PrivateMemory=$($baselineMemory.PrivateMb) MB"
        }
    } while ($usersUrl)

    $allUserCount = $uncoveredUserIds.Count
    Write-CheckUserGroupStage -Stage 'UserBaseline' -State $(if ($baselineComplete) { 'Completed' } else { 'CompletedWithErrors' }) -Stopwatch $baselineStopwatch -Details "Pages=$($scanMetrics.UserBaselinePages); Users=$allUserCount; Members=$memberCount; Guests=$guestCount; Skipped=$($scanMetrics.SkippedUserRecords)"

    # The exact group total remains required by the inherited minimum-two-groups rule. It is also a
    # planning hint, but it is never used as proof that a particular user has group coverage.
    $groupCountStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    Write-CheckUserGroupStage -Stage 'GroupCount' -State 'Started' -Stopwatch $groupCountStopwatch
    $groupCount = 0
    $groupCountComplete = $true
    try {
        $groupCountResponse = Invoke-GraphGetWithRetry -Uri 'https://graph.microsoft.com/v1.0/groups/$count' -Headers $headers
        if ($null -eq $groupCountResponse -or -not [int]::TryParse([string]$groupCountResponse, [ref]$groupCount)) {
            throw 'Microsoft Graph returned an invalid group count.'
        }
    }
    catch {
        $groupCountComplete = $false
        Add-ErrorRecordFailure -Kind 'Terminal' -Stage 'GroupCount' -Endpoint 'GroupsCount' -ErrorRecord $_
    }
    Write-CheckUserGroupStage -Stage 'GroupCount' -State $(if ($groupCountComplete) { 'Completed' } else { 'Failed' }) -Stopwatch $groupCountStopwatch -Details "Groups=$groupCount"

    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups directory summary: Members=$memberCount; Guests=$guestCount; InScopeUsers=$allUserCount; Groups=$groupCount; BaselineComplete=$baselineComplete; GroupCountComplete=$groupCountComplete"
    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups scan settings: Implementation=$implementationId; GraphBatchLimit=$graphBatchRequestSize; FullContinuationLimit=$fullContinuationBatchSize; ConcurrentBatchCalls=$concurrentGraphBatchCalls; ProbeSample=$probeSampleSize; CandidateLimit=$probeCandidateLimit; MaxRetries=$defaultMaxRetries"

    $completedGroupIds = [System.Collections.Generic.HashSet[Guid]]::new()
    $attemptedGroupIds = [System.Collections.Generic.HashSet[Guid]]::new()
    $completionReadComplete = $baselineComplete -and $groupCountComplete
    # Fewer than two groups already fails the inherited minimum-group rule, so a tenant-wide
    # membership scan cannot change the result and would only add avoidable Graph work.
    $coverageWorkRequired = $completionReadComplete -and $allUserCount -gt 1 -and $groupCount -ge 2
    $candidatePool = @()
    $probeState = $null
    $reprobeUsed = $false

    if ($coverageWorkRequired -and $uncoveredUserIds.Count -gt 0) {
        # Probe only when both sides are large enough that choosing better work can save meaningful time.
        if ($uncoveredUserIds.Count -gt $smallUserThreshold -and $groupCount -gt $smallGroupThreshold) {
            $probeNumber = 1
            while ($true) {
                $probeReason = if ($probeNumber -eq 1) { 'InitialAutomaticDiscovery' } else { 'ResidualSampleTooSmall' }
                $probeState = Find-BroadGroupCandidate -UncoveredUserIds $uncoveredUserIds -CompletedGroupIds $completedGroupIds -ProbeNumber $probeNumber -Reason $probeReason
                $candidatePool = @(Add-BroadGroupCandidateCount -Candidates $probeState.Candidates)

                while ($candidatePool.Count -gt 0 -and $uncoveredUserIds.Count -gt 0) {
                    $remainingSampleIds = @($probeState.SampleIds | Where-Object { $uncoveredUserIds.Contains($_) })
                    if ($remainingSampleIds.Count -eq 0) {
                        break
                    }

                    $currentPlan = Get-CompletionPlan -UncoveredCount $uncoveredUserIds.Count -TotalGroupCount $groupCount -CompletedGroupIds $completedGroupIds -KnownCandidates $candidatePool
                    $evaluatedCandidates = [System.Collections.Generic.List[object]]::new()
                    foreach ($candidate in $candidatePool) {
                        if ($completedGroupIds.Contains([Guid]$candidate.GroupId)) {
                            continue
                        }

                        $remainingHits = @($candidate.SampleUserIds | Where-Object { $uncoveredUserIds.Contains($_) }).Count
                        if ($remainingHits -eq 0) {
                            continue
                        }

                        # Estimate how much work this candidate could remove from the remaining exact scan.
                        # Scan it only when the expected saving is at least twice its own page cost, which
                        # avoids spending time on broad-looking groups that are unlikely to improve runtime.
                        $estimatedCoverage = [long][Math]::Ceiling($uncoveredUserIds.Count * ($remainingHits / [double]$remainingSampleIds.Count))
                        $estimatedCoverage = [Math]::Min($uncoveredUserIds.Count, [Math]::Min([long]$candidate.DirectUserCount, $estimatedCoverage))
                        $projectedUncovered = [Math]::Max(0, $uncoveredUserIds.Count - $estimatedCoverage)
                        $remainingCandidates = @($candidatePool | Where-Object { $_.GroupId -ne $candidate.GroupId })
                        $projectedPlan = Get-CompletionPlan -UncoveredCount $projectedUncovered -TotalGroupCount $groupCount -CompletedGroupIds $completedGroupIds -KnownCandidates $remainingCandidates
                        $expectedSavings = [Math]::Max(0, $currentPlan.CheapestRounds - $projectedPlan.CheapestRounds)
                        $requiredSavings = 2 * [int]$candidate.EstimatedPages
                        $qualifies = $expectedSavings -ge $requiredSavings
                        [void]$evaluatedCandidates.Add([PSCustomObject]@{
                            Candidate         = $candidate
                            RemainingHits     = $remainingHits
                            EstimatedCoverage = $estimatedCoverage
                            ExpectedSavings   = $expectedSavings
                            RequiredSavings   = $requiredSavings
                            Qualifies         = $qualifies
                        })

                        if ($diagnosticLevel -eq 'Validation') {
                            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups candidate plan: Probe=$probeNumber; GroupId=$($candidate.GroupId); SampleHits=$remainingHits/$($remainingSampleIds.Count); DirectUserCount=$($candidate.DirectUserCount); Pages=$($candidate.EstimatedPages); EstimatedCoverage=$estimatedCoverage; CurrentPlan=$($currentPlan.SelectedPath)/$($currentPlan.CheapestRounds); ExpectedSavings=$expectedSavings; RequiredSavings=$requiredSavings; Action=$(if ($qualifies) { 'Eligible' } else { 'Skip' })"
                        }
                    }

                    $selectedCandidate = $evaluatedCandidates |
                        Where-Object { $_.Qualifies } |
                        Sort-Object -Property @{ Expression = { $_.ExpectedSavings }; Descending = $true }, @{ Expression = { $_.RemainingHits }; Descending = $true }, @{ Expression = { $_.Candidate.DirectUserCount }; Descending = $true } |
                        Select-Object -First 1
                    if (-not $selectedCandidate) {
                        break
                    }

                    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups candidate selected: Probe=$probeNumber; GroupId=$($selectedCandidate.Candidate.GroupId); EstimatedPages=$($selectedCandidate.Candidate.EstimatedPages); EstimatedCoverage=$($selectedCandidate.EstimatedCoverage); ExpectedSavings=$($selectedCandidate.ExpectedSavings); RequiredSavings=$($selectedCandidate.RequiredSavings); UncoveredBefore=$($uncoveredUserIds.Count)"
                    $candidateScan = Invoke-GroupMembershipScan -GroupIds ([Guid[]]@($selectedCandidate.Candidate.GroupId)) -UncoveredUserIds $uncoveredUserIds -CompletedGroupIds $completedGroupIds -AttemptedGroupIds $attemptedGroupIds -Source 'BroadCandidate' -FailureKind 'Pending'
                    if ($uncoveredUserIds.Count -eq 0) {
                        $scanMetrics.SelectedPath = 'BroadCandidate'
                    }
                    $candidatePool = @($candidatePool | Where-Object { $_.GroupId -ne $selectedCandidate.Candidate.GroupId })
                    if ($candidateScan.FailedGroupIds.Count -gt 0) {
                        Write-CheckUserGroupDiagnostic -Message "Check-UserGroups candidate failed: GroupId=$($selectedCandidate.Candidate.GroupId); Action=ContinueWithExactFallback"
                    }
                }

                if ($uncoveredUserIds.Count -eq 0) {
                    break
                }

                $remainingSampleCount = if ($probeState) {
                    @($probeState.SampleIds | Where-Object { $uncoveredUserIds.Contains($_) }).Count
                }
                else { 0 }
                $fallbackPlan = Get-CompletionPlan -UncoveredCount $uncoveredUserIds.Count -TotalGroupCount $groupCount -CompletedGroupIds $completedGroupIds -KnownCandidates $candidatePool
                # A broad group may remove most sampled users while thousands of other users remain.
                # Take one fresh sample only when the old sample is too small to guide an expensive fallback.
                $shouldReprobe = -not $reprobeUsed -and
                    $remainingSampleCount -lt $minimumResidualSampleSize -and
                    $uncoveredUserIds.Count -gt $reprobeMinimumUsers -and
                    $fallbackPlan.CheapestRounds -ge $reprobeMinimumRounds
                if (-not $shouldReprobe) {
                    break
                }

                $reprobeUsed = $true
                $scanMetrics.Reprobes++
                $probeNumber++
                Write-CheckUserGroupDiagnostic -Message "Check-UserGroups re-probe decision: Action=Run; RemainingSample=$remainingSampleCount; Uncovered=$($uncoveredUserIds.Count); CheapestFallbackRounds=$($fallbackPlan.CheapestRounds)"
                $probeState = $null
                $candidatePool = @()
            }
        }

        # Broad candidates are only an optimization. If IDs remain, always finish with an exact user
        # or group path so sampling can never decide the compliance result by itself.
        if ($uncoveredUserIds.Count -gt 0) {
            $completionPlan = Get-CompletionPlan -UncoveredCount $uncoveredUserIds.Count -TotalGroupCount $groupCount -CompletedGroupIds $completedGroupIds -KnownCandidates $candidatePool
            $scanMetrics.SelectedPath = $completionPlan.SelectedPath
            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups path selected: Path=$($completionPlan.SelectedPath); DirectUserRounds=$($completionPlan.DirectRounds); GroupRoundsLowerBound=$($completionPlan.GroupRounds); RemainingGroups=$($completionPlan.RemainingGroups); LargestKnownChain=$($completionPlan.LargestKnownChain); Uncovered=$($uncoveredUserIds.Count); TieRule=DirectUsers"

            if ($completionPlan.SelectedPath -eq 'DirectUsers') {
                # Direct checks independently complete the proof, so earlier optional group failures no longer matter.
                $pendingFailureStore.Total = 0
                $pendingFailureStore.Categories.Clear()
                $pendingFailureStore.Details.Clear()
                Invoke-DirectUserCompletion -UncoveredUserIds $uncoveredUserIds
                if ($terminalFailureStore.Total -gt 0) {
                    $completionReadComplete = $false
                }
            }
            else {
                # Try any unscanned high-value candidates before paying to enumerate all tenant groups.
                $priorityFallbackIds = [Guid[]]@($candidatePool |
                    Where-Object { -not $completedGroupIds.Contains([Guid]$_.GroupId) } |
                    Sort-Object -Property DirectUserCount -Descending |
                    ForEach-Object { [Guid]$_.GroupId })
                if ($priorityFallbackIds.Count -gt 0) {
                    [void](Invoke-GroupMembershipScan -GroupIds $priorityFallbackIds -UncoveredUserIds $uncoveredUserIds -CompletedGroupIds $completedGroupIds -AttemptedGroupIds $attemptedGroupIds -Source 'CandidateFallback' -FailureKind 'Pending')
                }

                if ($uncoveredUserIds.Count -gt 0) {
                    $revisedPlan = Get-CompletionPlan -UncoveredCount $uncoveredUserIds.Count -TotalGroupCount $groupCount -CompletedGroupIds $completedGroupIds
                    if ($revisedPlan.SelectedPath -eq 'DirectUsers') {
                        $scanMetrics.SelectedPath = 'DirectUsersAfterCandidates'
                        $pendingFailureStore.Total = 0
                        $pendingFailureStore.Categories.Clear()
                        $pendingFailureStore.Details.Clear()
                        Invoke-DirectUserCompletion -UncoveredUserIds $uncoveredUserIds
                        if ($terminalFailureStore.Total -gt 0) {
                            $completionReadComplete = $false
                        }
                    }
                    else {
                        # Full enumeration retries candidate groups that failed earlier, so clear
                        # their provisional failures before this required complete path starts.
                        $pendingFailureStore.Total = 0
                        $pendingFailureStore.Categories.Clear()
                        $pendingFailureStore.Details.Clear()
                        $fullGroupResult = Invoke-FullTenantGroupCompletion -UncoveredUserIds $uncoveredUserIds -CompletedGroupIds $completedGroupIds -AttemptedGroupIds $attemptedGroupIds -TotalGroupCount $groupCount
                        if ($fullGroupResult.SwitchToDirect -and $uncoveredUserIds.Count -gt 0) {
                            $scanMetrics.SelectedPath = 'DirectUsersAfterGroupProgress'
                            $pendingFailureStore.Total = 0
                            $pendingFailureStore.Categories.Clear()
                            $pendingFailureStore.Details.Clear()
                            Invoke-DirectUserCompletion -UncoveredUserIds $uncoveredUserIds
                            if ($terminalFailureStore.Total -gt 0) {
                                $completionReadComplete = $false
                            }
                        }
                        elseif (-not $fullGroupResult.ListComplete -or $pendingFailureStore.Total -gt 0) {
                            # A failed group read does not have to end as inconclusive. Direct checks
                            # for only the remaining users can still prove coverage independently.
                            Write-CheckUserGroupDiagnostic -Message "Check-UserGroups recovery path: Trigger=IncompleteGroupPath; Action=DirectUsers; Uncovered=$($uncoveredUserIds.Count); PendingFailures=$($pendingFailureStore.Total)"
                            $scanMetrics.SelectedPath = 'DirectUsersAfterGroupFailure'
                            $pendingFailureStore.Total = 0
                            $pendingFailureStore.Categories.Clear()
                            $pendingFailureStore.Details.Clear()
                            Invoke-DirectUserCompletion -UncoveredUserIds $uncoveredUserIds
                            if ($terminalFailureStore.Total -gt 0) {
                                $completionReadComplete = $false
                            }
                        }
                    }
                }
            }
        }
    }

    # Once exact coverage is proved, optional planning failures cannot invalidate it. If a required
    # read is incomplete and IDs remain, report the check as incomplete/non-compliant and do not name
    # those users as violations because the missing Graph data may be the reason they remain.
    $coverageProven = $baselineComplete -and $uncoveredUserIds.Count -eq 0
    if ($coverageProven) {
        $pendingFailureStore.Total = 0
        $pendingFailureStore.Categories.Clear()
        $pendingFailureStore.Details.Clear()
    }
    $totalCoveredUsers = [Math]::Max(0, $allUserCount - $uncoveredUserIds.Count)
    $coverageIncomplete = -not $baselineComplete -or -not $groupCountComplete -or (-not $coverageProven -and -not $completionReadComplete)

    $complianceStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'Started' -Stopwatch $complianceStopwatch -Details "Baseline=$allUserCount; Covered=$totalCoveredUsers; Uncovered=$($uncoveredUserIds.Count); RequiredReadsComplete=$(-not $coverageIncomplete)"
    if ($coverageIncomplete) {
        $IsCompliant = $false
        $commentsArray += "$($msgTable.isNotCompliant) $userGroupScanIncompleteMessage"
        $AdditionalResults.records[0].Comments = $userGroupScanIncompleteMessage
        Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'Incomplete' -Stopwatch $complianceStopwatch -Details "Uncovered=$($uncoveredUserIds.Count); TerminalFailures=$($terminalFailureStore.Total)"
    }
    elseif ($allUserCount -le 1) {
        # Preserve the existing edge rule: a tenant with at most one in-scope user passes this item.
        $IsCompliant = $true
        $commentsArray += "$($msgTable.isCompliant) $($msgTable.userCountOne)"
        Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'PassedSingleUserRule' -Stopwatch $complianceStopwatch
    }
    elseif ($groupCount -lt 2) {
        # Preserve the existing minimum-two-groups rule independently of user coverage.
        $IsCompliant = $false
        $commentsArray += "$($msgTable.isNotCompliant) $($msgTable.userGroupsMany)"
        $AdditionalResults.records[0].Comments = $msgTable.userGroupsMany
        Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'FailedMinimumGroups' -Stopwatch $complianceStopwatch -Details "Groups=$groupCount; Uncovered=$($uncoveredUserIds.Count)"
    }
    elseif (-not $coverageProven) {
        $IsCompliant = $false
        $commentsArray += "$($msgTable.isNotCompliant) $($msgTable.userCountGroupNoMatch)"
        $AdditionalResults = Get-UserWithoutGroupAdditionalResult -UncoveredUserIds $uncoveredUserIds
        Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'FailedUncoveredUsers' -Stopwatch $complianceStopwatch -Details "Uncovered=$($uncoveredUserIds.Count); RemediationLimit=$remediationSampleLimit"
    }
    else {
        # Coverage and the minimum-group rule passed. Preserve the existing CAP requirement:
        # at least one enabled Conditional Access policy must include or exclude a group.
        Write-CheckUserGroupStage -Stage 'CoverageEvaluation' -State 'Passed' -Stopwatch $complianceStopwatch
        $conditionalAccessStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        Write-CheckUserGroupStage -Stage 'ConditionalAccessPolicyCheck' -State 'Started' -Stopwatch $conditionalAccessStopwatch
        $capPolicyCount = 0
        $validPolicyCount = 0
        try {
            $capResponse = Invoke-GraphQueryEX -urlPath '/identity/conditionalAccess/policies' -ErrorAction Stop
            $capData = $capResponse.Content
            if ($null -eq $capData -or $null -eq $capData.value) {
                throw 'Microsoft Graph returned no Conditional Access policy collection.'
            }

            $policies = @($capData.value)
            $capPolicyCount = $policies.Count
            $validPolicies = @($policies | Where-Object {
                $_.state -eq 'enabled' -and
                ($_.conditions.users.includeGroups.Count -ge 1 -or $_.conditions.users.excludeGroups.Count -ge 1)
            })
            $validPolicyCount = $validPolicies.Count
            if ($validPolicyCount -gt 0) {
                $IsCompliant = $true
                $commentsArray += "$($msgTable.isCompliant) $($msgTable.reqPolicyUserGroupExists)"
                Write-CheckUserGroupStage -Stage 'ConditionalAccessPolicyCheck' -State 'Passed' -Stopwatch $conditionalAccessStopwatch -Details "Policies=$capPolicyCount; Qualifying=$validPolicyCount"
            }
            else {
                $IsCompliant = $false
                $commentsArray += "$($msgTable.isNotCompliant) $($msgTable.noCAPforAnyGroups)"
                Write-CheckUserGroupStage -Stage 'ConditionalAccessPolicyCheck' -State 'FailedNoQualifyingPolicy' -Stopwatch $conditionalAccessStopwatch -Details "Policies=$capPolicyCount; Qualifying=0"
            }
        }
        catch {
            $IsCompliant = $false
            Add-ErrorRecordFailure -Kind 'Terminal' -Stage 'ConditionalAccessPolicyCheck' -Endpoint 'ConditionalAccessPolicies' -ErrorRecord $_
            $commentsArray += "$($msgTable.isNotCompliant) $userGroupScanIncompleteMessage"
            Write-CheckUserGroupStage -Stage 'ConditionalAccessPolicyCheck' -State 'Incomplete' -Stopwatch $conditionalAccessStopwatch -Details "Policies=$capPolicyCount; Error=$($_.Exception.Message)"
        }
    }

    $commentsArray += ($userStatsMessageTemplate -f $allUserCount, $totalCoveredUsers, $memberCount, $guestCount)
    $Comments = $commentsArray -join '; '
    Write-StructuredFailure

    $finalMemory = Get-GroupScanResourceSnapshot
    $diagnosticPercent = if ($moduleStopwatch.Elapsed.TotalMilliseconds -gt 0) {
        [Math]::Round(($diagnosticMetrics.WriteMs / $moduleStopwatch.Elapsed.TotalMilliseconds) * 100, 3)
    }
    else { 0 }
    Write-CheckUserGroupDiagnostic -Message "Check-UserGroups final summary: Implementation=$implementationId; Path=$($scanMetrics.SelectedPath); Users=$allUserCount; Covered=$totalCoveredUsers; Uncovered=$($uncoveredUserIds.Count); Groups=$groupCount; UserPages=$($scanMetrics.UserBaselinePages); GroupListPages=$($scanMetrics.GroupListPages); GroupsStarted=$($scanMetrics.GroupsStarted); GroupsCompleted=$($scanMetrics.GroupsCompleted); MembershipPages=$($scanMetrics.MembershipPages); FirstPages=$($scanMetrics.FirstPages); ContinuationPages=$($scanMetrics.ContinuationPages); PageBuckets=1:$($scanMetrics.SinglePageGroups),2-5:$($scanMetrics.TwoToFivePageGroups),6-20:$($scanMetrics.SixToTwentyPageGroups),21Plus:$($scanMetrics.OverTwentyPageGroups); MembershipRecords=$($scanMetrics.MembershipRecords); DirectUsersChecked=$($scanMetrics.DirectUsersChecked); ProbeRuns=$($scanMetrics.ProbeRuns); Reprobes=$($scanMetrics.Reprobes); BatchCalls=$($graphMetrics.BatchCalls); InnerAttempts=$($graphMetrics.InnerAttempts); DirectAttempts=$($graphMetrics.DirectAttempts); SingleRequestDirectCalls=$($graphMetrics.SingleRequestDirectCalls); Retries=$($graphMetrics.Retries); Throttles429=$($graphMetrics.Throttles429); MaximumBatchRecords=$($graphMetrics.MaximumBatchRecords); ResourceUnits=$([Math]::Round($graphMetrics.ResourceUnits, 1)); MaximumThrottlePercentage=$($graphMetrics.MaximumThrottlePercentage); PlanningFailures=$($planningFailureStore.Total); TerminalFailures=$($terminalFailureStore.Total); StructuredErrors=$($ErrorList.Count); IsCompliant=$IsCompliant; Elapsed=$($moduleStopwatch.Elapsed); PrivateMemory=$($finalMemory.PrivateMb) MB; PeakMemory=$($finalMemory.PeakMb) MB; ProcessorSeconds=$($finalMemory.ProcessorSeconds); DiagnosticLines=$($diagnosticMetrics.Lines + 1); DiagnosticCharacters=$($diagnosticMetrics.Characters); DiagnosticWriteMs=$([Math]::Round($diagnosticMetrics.WriteMs, 1)); DiagnosticRuntimePercent=$diagnosticPercent"

    $PsObject = [PSCustomObject]@{
        ComplianceStatus = $IsCompliant
        ControlName      = $ControlName
        ItemName         = $ItemName
        Comments         = $Comments
        ReportTime       = $ReportTime
        itsgcode         = $itsgcode
    }

    # Add profile information if MCUP feature is enabled
    if ($EnableMultiCloudProfiles) {
        $profileStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $profileErrorStart = $ErrorList.Count
        Write-CheckUserGroupStage -Stage 'ProfileEnrichment' -State 'Started' -Stopwatch $profileStopwatch
        $result = Add-ProfileInformation -Result $PsObject -CloudUsageProfiles $CloudUsageProfiles -ModuleProfiles $ModuleProfiles -SubscriptionId $subscriptionId -ErrorList $ErrorList
        Write-Host "$result"
        $profileState = if ($ErrorList.Count -gt $profileErrorStart) { 'CompletedWithErrors' } else { 'Completed' }
        Write-CheckUserGroupStage -Stage 'ProfileEnrichment' -State $profileState -Stopwatch $profileStopwatch
    }

    $moduleOutput = [PSCustomObject]@{
        ComplianceResults = $PsObject
        Errors            = $ErrorList
        AdditionalResults = $AdditionalResults
    }
    $moduleState = if ($ErrorList.Count -gt 0) { 'CompletedWithErrors' } else { 'Completed' }
    Write-CheckUserGroupStage -Stage 'Module' -State $moduleState -Stopwatch $moduleStopwatch -Details "IsCompliant=$IsCompliant; TotalErrors=$($ErrorList.Count)"
    return $moduleOutput
}
# SIG # Begin signature block
# MIIxfwYJKoZIhvcNAQcCoIIxcDCCMWwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA87Eff/8XhP2ix
# td9KviY5pZj9bAsRO2AlUNLDPC2Vc6CCE7YwggWQMIIDeKADAgECAhAFmxtXno4h
# MuI5B72nd3VcMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0xMzA4MDExMjAwMDBaFw0z
# ODAxMTUxMjAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/z
# G6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZ
# anMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7s
# Wxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL
# 2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfb
# BHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3
# JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3c
# AORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqx
# YxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0
# viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aL
# T8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjQjBAMA8GA1Ud
# EwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgGGMB0GA1UdDgQWBBTs1+OC0nFdZEzf
# Lmc/57qYrhwPTzANBgkqhkiG9w0BAQwFAAOCAgEAu2HZfalsvhfEkRvDoaIAjeNk
# aA9Wz3eucPn9mkqZucl4XAwMX+TmFClWCzZJXURj4K2clhhmGyMNPXnpbWvWVPjS
# PMFDQK4dUPVS/JA7u5iZaWvHwaeoaKQn3J35J64whbn2Z006Po9ZOSJTROvIXQPK
# 7VB6fWIhCoDIc2bRoAVgX+iltKevqPdtNZx8WorWojiZ83iL9E3SIAveBO6Mm0eB
# cg3AFDLvMFkuruBx8lbkapdvklBtlo1oepqyNhR6BvIkuQkRUNcIsbiJeoQjYUIp
# 5aPNoiBB19GcZNnqJqGLFNdMGbJQQXE9P01wI4YMStyB0swylIQNCAmXHE/A7msg
# dDDS4Dk0EIUhFQEI6FUy3nFJ2SgXUE3mvk3RdazQyvtBuEOlqtPDBURPLDab4vri
# RbgjU2wGb2dVf0a1TD9uKFp5JtKkqGKX0h7i7UqLvBv9R0oN32dmfrJbQdA75PQ7
# 9ARj6e/CVABRoIoqyc54zNXqhwQYs86vSYiv85KZtrPmYQ/ShQDnUBrkG5WdGaG5
# nLGbsQAe79APT0JsyQq87kP6OnGlyE0mpTX9iV28hWIdMtKgK1TtmlfB2/oQzxm3
# i0objwG2J5VT6LaJbVu8aNQj6ItRolb58KaAoNYes7wPD1N1KarqE3fk3oyBIa0H
# EEcRrYc9B9F1vM/zZn4wggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggdqMIIFUqADAgECAhAM+W8SEle7oW9cSQcQFCGYMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjYwMjE4MDAwMDAwWhcNMjcwMjE3MjM1OTU5WjByMQsw
# CQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMR8w
# HQYDVQQKExZTaGFyZWQgU2VydmljZXMgQ2FuYWRhMR8wHQYDVQQDExZTaGFyZWQg
# U2VydmljZXMgQ2FuYWRhMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# p8rZ+fUrVkpVLy9TmvLMwozFMk+tXGUOnIaCNLTdF9nUEW9NVhIxC0/QnDuMaDFX
# ZyXbeFIrqW28FbAgSLl9Qsup/nf5p3HLMorB64Jk5vHkpgosATJc/gXbFMCy+D9D
# EldSP5+A12Ec8scBKd0nBh+1RPzRJTssHOSiGRMJiUZyn1rzB122AsGTbUiY+Jn2
# f7RjXWrr4EZSODqFoHv5UT06pr9+gZAzvIU7acfQiOImin6KoPg5DrSRjiGI72MP
# TFjW//oeds3uN9LF0hj2Wvt5QbClWJlOCBkSNMEUUpGmvPHl19y7zvUDiU0RozRE
# bZ8cPZLF6dQT+Jg5/iyTNqZd9+zkriu5lqjxs9BFLG71QJMevESI94YUuOM9YTQm
# 8orLuDQF1aevMlzrpK3zDOKJNaWZbdP8wIuotOGvtt7N3GZ+3LOBM+iuyoJ/cnM/
# 6k9NoGVQEvB7MehgZb7MPDOt7PN6pkxROSrDf/S8dBmvKAu6NvkBRLQKX9H8X1sB
# UYcC9UL2hoQGMJ8pRYV6t1+XR/CmQYVaKcmBN+rVYnQb7BY2StWwXPgl0St4+O/T
# A5G4sP1yL0hb2o/SYSW4rczdGzbrc9H4gf+DIrA87ir/9wQpMvM6BNHc81JSh1pa
# 4IeHKLnffd3O/MV99TBI3VRbnRSKCHyij+k8p8z35jECAwEAAaOCAgMwggH/MB8G
# A1UdIwQYMBaAFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB0GA1UdDgQWBBTvE4A8xmrI
# Tmp1SFqp4KNi39hH8DA+BgNVHSAENzA1MDMGBmeBDAEEATApMCcGCCsGAQUFBwIB
# FhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwDgYDVR0PAQH/BAQDAgeAMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMIG1BgNVHR8Ega0wgaowU6BRoE+GTWh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3JsMFOgUaBPhk1odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQy
# MDIxQ0ExLmNybDCBlAYIKwYBBQUHAQEEgYcwgYQwJAYIKwYBBQUHMAGGGGh0dHA6
# Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBcBggrBgEFBQcwAoZQaHR0cDovL2NhY2VydHMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2
# U0hBMzg0MjAyMUNBMS5jcnQwCQYDVR0TBAIwADANBgkqhkiG9w0BAQsFAAOCAgEA
# LDV4ZSNIGeoWgeDrmX2p13Lc1BOCbwC1u2FnHkySLlvoJPpVJ64tS8oG7MRpEJrd
# BEnUdPqEcNbxBfygnm2Esurg+shZQ0Q8qJGyJFnzqy7F659ftMNCbSREWrEDztS7
# 1ya6VpFK7I6ODwCz11JPZxZ7ZUUoZyJBvXKb+hGUxCAetp/s35gBJbT3eRaid0go
# lGobxeqMT3YhlTt2iUxW2azwHsGcg3i1CQB33tXVJqL7fk2Iv+Hry6ijfCCrddwM
# oSpxnwJmjxk6hyvyakN6/ab5AuLEtSLX7pGtTMIReC3Xr686qC81653RLfLcGKfo
# 5ydKvZI9tyT+EXWibdm6aB6tqYjsnGBkSdCnzou5EFNVRpEsRspujjr3g5BVAfJM
# 0QxhICfqTZlpUPjMxcSbi6mT5vSbbAq/2JhGW5RlHW3fu5WVZbQtTDXL4pFp+rsB
# Z+MY0z3AEtKZAIvSdkYRCryHM+9ZCWjbPxtPHklnu1Uk9ip0TimjnqXOFlh/XdQa
# Ly7PZUj1uzLWsm0c+B5m+TJ1/ORvzlkUDTGLDleCG+TFSYZ3K9AFuKem93WPZiqz
# 62rgBvWaaHZbEOmRH3UylTlNVetBN6XXS8ymj0T/BFwSEAU7bZmRG8Q+wz8JKYoM
# LV3h8P2i0HPry4seckuxiVugCApz8/ubH/HIxhH5nVMxgh0fMIIdGwIBATB9MGkx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEzODQg
# MjAyMSBDQTECEAz5bxISV7uhb1xJBxAUIZgwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# Rm9mvg685JD3mnDX9mm/yzLJi7bHoG/tQ+qOPvghp1EwDQYJKoZIhvcNAQEBBQAE
# ggIAjmrrvh2XH61boFmoDZbN9hO8vB4eEI+G04aoz6Jgp4YEYusJdDHRWCKB58+s
# gG6viANWvSGlg+AXfAtyNzoe7wGHJyoI/FWQjWKrRenKYgp7zOgOmBbY4MnNQuyi
# iIFBoFB4Pxase28V+//wiBZWNx8WwcI5HckSDdFhhdS4R5D9HDC2ISsjiFLUTZc/
# G0T1P0UZITX8CjU3nsS0p2FXc1S4FWtzY8OD57PZ5LUXMHgdhtUeVFliFGiCo4/i
# kcKFu8ZNHq6T8IpP0Dy04/M7FzaqTVL60jzEB9B5lh9hgYH5pq2OvTLSdEKw+n7l
# 2EAw7bsuS+xFWU7gXoDltfJTkBCJfIC6qhASgAYRjelcFXF2S8LsBSFEeYrlmHzf
# UIKtOFwM7RWxfEptso7vVagXn1+asHhdR+o+yAr9mwfqUF8Vn9es6InxKALBD5ck
# +NwE90arZ5FJspHZoS6eRFmcLOfkVr69Q2O/nRM3hdTVRuBTFYKNJXNb14T/pBG7
# xrKQYy7jK0OMkL6wyfzqH7z2USXm1W1Wkdkos80yxIixPr8hFtIQz/GSxeDFm96z
# d0Pry3cetJoKiYHlT507Gul19uKUeVNgSq/54223KoHzht+0u7J1LA+8HYFkDp6D
# dZwuJp8U5wFF28CBy9efRnK692B+MvpPfCdzsxgXhlSw/iOhghnsMIIZ6AYKKwYB
# BAGCNwMDATGCGdgwghnUBgkqhkiG9w0BBwKgghnFMIIZwQIBAzEPMA0GCWCGSAFl
# AwQCAgUAMIH4BgsqhkiG9w0BCRABBKCB6ASB5TCB4gIBAQYKKwYBBAGyMQIBATAx
# MA0GCWCGSAFlAwQCAQUABCDmwpni4/YdtPeli04JL75qs6N7jqatN7djETxhMf2M
# 4AIVAJZW0e+0SooW1Qhp9wOCFBDR8TKdGA8yMDI2MTAyMTE3MjgwNVqgdqR0MHIx
# CzAJBgNVBAYTAkdCMRcwFQYDVQQIEw5HcmVhdGVyIExvbmRvbjEYMBYGA1UEChMP
# U2VjdGlnbyBMaW1pdGVkMTAwLgYDVQQDEydTZWN0aWdvIFB1YmxpYyBUaW1lIFN0
# YW1waW5nIFNpZ25lciBSMzegghQXMIIG4jCCBMqgAwIBAgIRAOdO8lWwUE/626bf
# 9/yLoxUwDQYJKoZIhvcNAQEMBQAwVTELMAkGA1UEBhMCR0IxGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBDQSBSNDEwHhcNMjYwMzI1MDAwMDAwWhcNMzcwNjI0MjM1OTU5WjByMQsw
# CQYDVQQGEwJHQjEXMBUGA1UECBMOR3JlYXRlciBMb25kb24xGDAWBgNVBAoTD1Nl
# Y3RpZ28gTGltaXRlZDEwMC4GA1UEAxMnU2VjdGlnbyBQdWJsaWMgVGltZSBTdGFt
# cGluZyBTaWduZXIgUjM3MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# sv/DbUvcUNlFLQURd9m4+1St5+JudFKo5P803Iks4mFeNB9SymodP6BJJWBuNhOF
# Qj9w77AVAeg5qQpA2dIwp2QTyBHr2h9eWSTkMBVj9mV6+WI5SaW+vDZW7PhJTbys
# d9v9WB3Xt6qlEi8m47pcTy8+k/OfhziKiuzNQXqfC7KcoRD/6up8OZBsU0qxr7n5
# nh/iRfAp1QXFTBQONBZSGIdHAyVRYYX033VoC8v71rizEKCpH97Pxbwcn9eq9K7W
# 8h5v4npsMUoqCS/c8mQwylDQGx15dHYV6NlcVFdjXD11l7qCrIy/unH5OlZtgx58
# QJRXRbGgQyBdSTpEpwuj3i5Qc52Z9m7hd7yCGCXKujf83hUQpOPx1w8+84EbEUTH
# VAfq4cpORaGWgY8NJy6txmd3wpS1MeXrOaVAMczTgzAZ+yZBWIqdgQBgTxEeXldE
# ToZOrRkxvn1IjIlfr4I4NWJz+Rb52FshLVnkA/wdoad789Eb7XZDNKd4oMmnc636
# TgauaaVZP2LLoU0JD/fYr53hwBn4uXu5ZsSfpnqAT60S7szJm/Na882xEoyRzLJ+
# UVbXOlHLO63DKkAtdz1CDuwWxgRE1drnwplepT06dz+1yTr5p1AkUz21bzE6cT/8
# /kjh4OPzggYYqrOBQPfuKEL5ZJPcN9jRgEpYvRlq5ucCAwEAAaOCAY4wggGKMB8G
# A1UdIwQYMBaAFDp0pQxnxkJQwv21/Me7KTSC9Hq5MB0GA1UdDgQWBBRhEOl6Eq9R
# xIXU8s+kdA9QzSCv+DAOBgNVHQ8BAf8EBAMCBsAwDAYDVR0TAQH/BAIwADAWBgNV
# HSUBAf8EDDAKBggrBgEFBQcDCDBKBgNVHSAEQzBBMAgGBmeBDAEEAjA1BgwrBgEE
# AbIxAQIBAwgwJTAjBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMw
# SgYDVR0fBEMwQTA/oD2gO4Y5aHR0cDovL2NybC5zZWN0aWdvLmNvbS9TZWN0aWdv
# UHVibGljVGltZVN0YW1waW5nQ0FSNDEuY3JsMHoGCCsGAQUFBwEBBG4wbDBFBggr
# BgEFBQcwAoY5aHR0cDovL2NydC5zZWN0aWdvLmNvbS9TZWN0aWdvUHVibGljVGlt
# ZVN0YW1waW5nQ0FSNDEuY3J0MCMGCCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0
# aWdvLmNvbTANBgkqhkiG9w0BAQwFAAOCAgEAA+o9jdGszfoZepOmygef1OlbkjrP
# d2QW9z3M8vVbQSCruPeO2eRsC9GhZ4CMZfhkrixayYD67gQkbyiRCbJu5L/i0NQj
# lQhBvbWfiEba+KHFKGud5YHRWhDZUtDeMIJGZG0BD7/sftZUo2Ifk+CXi/ZlM50+
# xK3OkqeXVi5GubDD/5txmYuqCT3T3LAilmoB+5th9sQxiMhyQuT3R/aYb4vypoZJ
# LYklUzTalXleW1nV9s4UROlE389CHDKAi/fepRSMnV8TghODDQxwzNGrOJZ04k/y
# hzHHDupfHPU51FYJqXIvWq9SAAWdlNV1JGIxhkp/TAtxBwz/Vd/VbgVb2d9/wRFf
# xFkka39O0+4xaZSl/oEK/1DqjxjJRO2Se9lGlJDScu21Zd23Cys3aYyB8y5H/+DF
# WtVe8PMKgr+VuIDp0Rk5bneVDAEW0TPAT8Ufwl2F6DJiDg/KZk5NmsYES+CxvF7b
# nISEnQh0ZrWnAJixquV0mElUx01wA5TuPIgyodxzNq/fC0hen9LBtdnfFfSZ+wt8
# A1Injsbio+DHVq1voYiVNpBfO7+nh9NB4AhRXNldPgr3zgjJ+47s0uNYy2iDXAZS
# lkP3ym/7gy31jlu989SNpRWO14/LUNV2LSuXkRI1iLTPI6ZdXG0DnPPG7UftF0tk
# 5m6BP9eNfr2tj1swgganMIIEj6ADAgECAhEAkKwIciD9xafEa1zHDfc9BjANBgkq
# hkiG9w0BAQwFADBXMQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1p
# dGVkMS4wLAYDVQQDEyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3Qg
# UjQ2MB4XDTI2MDMyNTAwMDAwMFoXDTQxMDMyNDIzNTk1OVowVTELMAkGA1UEBhMC
# R0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2VjdGlnbyBQ
# dWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDEwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQCu5EqiAa2CHGL5Zi1bmgPM8NUXwYZJ+BtQqHps43GLTC+sjVLy
# psBh+8uv+TLkgtVGD//vSmA0qrzELf9YRCh2MTAA/aGaQZKGg0BRCmziR3pbCnvg
# WjtGXBDUyn3j3K2lZAO8KxgFtlxwOYEAkL+CCqK4v9zzTl8ZwzDpPMiDIFa5THk8
# an1ieF5I09cXNrPQw+1ER1liThaG0z6FrOpqwxZWmPRZQBw2E32878UB1bL0Zp91
# vuWZgsMpNNiPCoBj0/1F+LE8+NRokfqacFI0F2tftrRB2W7HQClLR9zjxFbWb5be
# 2rceIfNyHUUfKGIvMI2NzoxSlxXnFqUG887D8W1Cj8DFok688JKxWvHR/9aQykSb
# d+9Vutj36ij2sgq/125wTpUZ/AgC0ph50bRs7gFrUyaXE9wSsOqMvCCC+sEm7vd/
# BemSG0TSHNXSmyCba+FCzekeWX03TRIcF3Laqd0Rw24OH7jpei4zaGhcI7nfdhBA
# 4c8RScxNY6jeHLHHmSMMTk9Wqn7H4dLhUBP5YEwbgbN4uv1i9ltTnHli8t1xHV0S
# tX9BFgrnmunTX19kUXY1H5ORJbRZyZDdvm1oZyteDj0SnMozr+YSmdIleDUTXdfo
# Y7b2taz8s2+QbOxLxcahEIYGWzqu6h955tKwcANHcZ4gTmAhT3btuOiQsQIDAQAB
# o4IBbjCCAWowHwYDVR0jBBgwFoAU9ndq3T/9ARP/FqFsggIv0Ao9FCUwHQYDVR0O
# BBYEFDp0pQxnxkJQwv21/Me7KTSC9Hq5MA4GA1UdDwEB/wQEAwIBhjASBgNVHRMB
# Af8ECDAGAQH/AgEAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMCMGA1UdIAQcMBowCAYG
# Z4EMAQQCMA4GDCsGAQQBsjEBAgEDCDBMBgNVHR8ERTBDMEGgP6A9hjtodHRwOi8v
# Y3JsLnNlY3RpZ28uY29tL1NlY3RpZ29QdWJsaWNUaW1lU3RhbXBpbmdSb290UjQ2
# LmNybDB8BggrBgEFBQcBAQRwMG4wRwYIKwYBBQUHMAKGO2h0dHA6Ly9jcnQuc2Vj
# dGlnby5jb20vU2VjdGlnb1B1YmxpY1RpbWVTdGFtcGluZ1Jvb3RSNDYucDdjMCMG
# CCsGAQUFBzABhhdodHRwOi8vb2NzcC5zZWN0aWdvLmNvbTANBgkqhkiG9w0BAQwF
# AAOCAgEAMt5SR2bxngNm+N8oc6Gq76Gx1c235fkX7jw8Ho9MAkJGADerHE7dhsBX
# ttqmzgr/7ZZahZSykGRPhPY1crj028kB8KzO0dKC2qQBAwtfgqMLKkkX/6bYq2uT
# 33eD6ByAp2/XKD0LcmZh0kKecvSBr6ln9ajX6u1dnx2fA7xEKy1M3qBhfQSUWLtj
# s2nFt0ELVLptzTlX9ID0cL+iOPfdboZ3CelT+JXKVKR2Sge0d4YiFAtPZkfSo8z1
# Z1x7y/Z9mwMIlBAnyuWXs4YsNuxdrYIt/QxE31PDOJ9DesS4Bc7H9OTORlEV/Avf
# iF/VepKZpira1MzLYuCw+uoLZn/pkpvd+CvNTS+mEHjBJNa6WK1j8qXFu+jIq+sG
# 9QILHiyB6p/xpHrkJu8zkw393+VqF9eKlTY2VjRxdycZLrVemZ4Yp3wi33b+W58C
# llH3HqjmowlZ7SOrgmx8YwYOkgrHsXOQHyBp6O4FRb8In0+FzjT7ElGie9V7CfhL
# 3IlVFZ4zjuKsZtH1iU3fGu4z/JnOGT6sCb0BbTqe/uhvpFCQBdH5xPGIA/LrbQUX
# jU2tWJgHhTIqnN/HvHyOHi5tM4zP3nhgh2rJ6Kqq2xsHBeNYs/R18xQ8DeIg+c90
# Eoaeh0YlN1KU8AyYol3K9M+qY5ez8syd/7ZlrRnoVewgH3P1pcswggaCMIIEaqAD
# AgECAhA2wrC9fBs656Oz3TbLyXVoMA0GCSqGSIb3DQEBDAUAMIGIMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIGA1UEBxMLSmVyc2V5IENpdHkx
# HjAcBgNVBAoTFVRoZSBVU0VSVFJVU1QgTmV0d29yazEuMCwGA1UEAxMlVVNFUlRy
# dXN0IFJTQSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0yMTAzMjIwMDAwMDBa
# Fw0zODAxMTgyMzU5NTlaMFcxCzAJBgNVBAYTAkdCMRgwFgYDVQQKEw9TZWN0aWdv
# IExpbWl0ZWQxLjAsBgNVBAMTJVNlY3RpZ28gUHVibGljIFRpbWUgU3RhbXBpbmcg
# Um9vdCBSNDYwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCIndi5RWed
# Hd3ouSaBmlRUwHxJBZvMWhUP2ZQQRLRBQIF3FJmp1OR2LMgIU14g0JIlL6VXWKmd
# bmKGRDILRxEtZdQnOh2qmcxGzjqemIk8et8sE6J+N+Gl1cnZocew8eCAawKLu4TR
# rCoqCAT8uRjDeypoGJrruH/drCio28aqIVEn45NZiZQI7YYBex48eL78lQ0BrHeS
# mqy1uXe9xN04aG0pKG9ki+PC6VEfzutu6Q3IcZZfm00r9YAEp/4aeiLhyaKxLuhK
# KaAdQjRaf/h6U13jQEV1JnUTCm511n5avv4N+jSVwd+Wb8UMOs4netapq5Q/yGyi
# QOgjsP/JRUj0MAT9YrcmXcLgsrAimfWY3MzKm1HCxcquinTqbs1Q0d2VMMQyi9cA
# gMYC9jKc+3mW62/yVl4jnDcw6ULJsBkOkrcPLUwqj7poS0T2+2JMzPP+jZ1h90/Q
# pZnBkhdtixMiWDVgh60KmLmzXiqJc6lGwqoUqpq/1HVHm+Pc2B6+wCy/GwCcjw5r
# mzajLbmqGygEgaj/OLoanEWP6Y52Hflef3XLvYnhEY4kSirMQhtberRvaI+5YsD3
# XVxHGBjlIli5u+NrLedIxsE88WzKXqZjj9Zi5ybJL2WjeXuOTbswB7XjkZbErg7e
# beAQUQiS/uRGZ58NHs57ZPUfECcgJC+v2wIDAQABo4IBFjCCARIwHwYDVR0jBBgw
# FoAUU3m/WqorSs9UgOHYm8Cd8rIDZsswHQYDVR0OBBYEFPZ3at0//QET/xahbIIC
# L9AKPRQlMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMBEGA1UdIAQKMAgwBgYEVR0gADBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLnVzZXJ0cnVzdC5jb20vVVNFUlRydXN0UlNBQ2VydGlmaWNh
# dGlvbkF1dGhvcml0eS5jcmwwNQYIKwYBBQUHAQEEKTAnMCUGCCsGAQUFBzABhhlo
# dHRwOi8vb2NzcC51c2VydHJ1c3QuY29tMA0GCSqGSIb3DQEBDAUAA4ICAQAOvmVB
# 7WhEuOWhxdQRh+S3OyWM637ayBeR7djxQ8SihTnLf2sABFoB0DFR6JfWS0snf6WD
# G2gtCGflwVvcYXZJJlFfym1Doi+4PfDP8s0cqlDmdfyGOwMtGGzJ4iImyaz3IBae
# 91g50QyrVbrUoT0mUGQHbRcF57olpfHhQEStz5i6hJvVLFV/ueQ21SM99zG4W2tB
# 1ExGL98idX8ChsTwbD/zIExAopoe3l6JrzJtPxj8V9rocAnLP2C8Q5wXVVZcbw4x
# 4ztXLsGzqZIiRh5i111TW7HV1AtsQa6vXy633vCAbAOIaKcLAo/IU7sClyZUk62X
# D0VUnHD+YvVNvIGezjM6CRpcWed/ODiptK+evDKPU2K6synimYBaNH49v9Ih24+e
# YXNtI38byt5kIvh+8aW88WThRpv8lUJKaPn37+YHYafob9Rg7LyTrSYpyZoBmwRW
# SE4W6iPjB7wJjJpH29308ZkpKKdpkiS9WNsf/eeUtvRrtIEiSJHN899L1P4l6zKV
# sdrUu1FX1T/ubSrsxrYJD+3f3aKg6yxdbugot06YwGXXiy5UUGZvOu3lXlxA+fC1
# 3dQ5OlL2gIb5lmF6Ii8+CQOYDwXM+yd9dbmocQsHjcRPsccUd5E9FiswEqORvz8g
# 3s+jR3SFCgXhN4wz7NgAnOgpCdUo4uDyllU9PzGCBJMwggSPAgEBMGowVTELMAkG
# A1UEBhMCR0IxGDAWBgNVBAoTD1NlY3RpZ28gTGltaXRlZDEsMCoGA1UEAxMjU2Vj
# dGlnbyBQdWJsaWMgVGltZSBTdGFtcGluZyBDQSBSNDECEQDnTvJVsFBP+tum3/f8
# i6MVMA0GCWCGSAFlAwQCAgUAoIIB+jAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwHAYJKoZIhvcNAQkFMQ8XDTI2MTAyMTE3MjgwNVowPwYJKoZIhvcNAQkEMTIE
# MMI/ZAqkr+isJKXr76RfdBckPuyT/XW/D+tTp1ZAF6eYy73jZTRwI1RWQTGHUR6L
# TjCCAXsGCyqGSIb3DQEJEAIMMYIBajCCAWYwggFiMBYEFOl4GKko2hUKn+G/nMx6
# q7mgDu6sMIGIBBRlwyhpb31OUCz9A8fCBpcYyvv3TzBwMFukWTBXMQswCQYDVQQG
# EwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQDEyVTZWN0aWdv
# IFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2AhEAkKwIciD9xafEa1zHDfc9
# BjCBvAQUhT1jLZOCgmF80JA1xJHeksFC2scwgaMwgY6kgYswgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEe
# MBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1
# c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5AhA2wrC9fBs656Oz3TbLyXVo
# MA0GCSqGSIb3DQEBAQUABIICALH16M/3LJjCVr78z/ddJLypCFFQMD7+X1LdMtPY
# cvO119KHTYfniQLHKcXNIdqwD+HhGdINNzpdTm++zDckdiOpUyr603cxE4C1PMhA
# NPulgApIJeaGRq2rrN7fdrOfk9KJwGUL2R/tfIqQDWMk5k/cYyBES5qT/GxXPtZ5
# 9HjDpP744wGmo3xtmiMhRkiLf0zbAZPV5NyHvKcZZICc12k3zMlA3xf2t3WEbcD/
# /PhoOENqqhTM61P+S64eEv6uCg/gzZfnxBNbELiO2vCcFo6ELM/ss0Kd6LScsYuw
# f66WmK6RSXDiJfzj+GCg/Mi6HWoQ5T+I+HIQhKMkUmUf8ZelXhfcnSXtDtoca19p
# iXUi8jyiJYnzY/FYmu9KnyC6T/qiLHo2LrZ0l3R4wmpkyjQ7AxZDBmunena0rQbk
# 46JqISjuXlOJjvcJ+6M+Lmvot7Rfo6E+690TirX5EicYYH6tMKEGdN2m9RRHHPJ4
# Pw2e/vqg003vh5mmwdgs0D2EcuNSs26CcXt8YYXz+63r9cN7sAbw6JCKIwJYGD39
# eXtBBBG+f6LHzPFkJ7smHSA77zvgLgRPXRA5qViOsfnQQytPL2xdtzi1Iit0KVyd
# XviSaVz2jcdMi4skQiMyAZlWhApawKKaWnm3GAAKi6yXW1ggoCLB5J/q9axmCz6B
# BbNY
# SIG # End signature block

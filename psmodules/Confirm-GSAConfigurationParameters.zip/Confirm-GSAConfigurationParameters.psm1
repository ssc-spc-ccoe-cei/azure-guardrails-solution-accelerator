Function Confirm-GSASubscriptionSelection {
    param (
        # config object
        [Parameter(Mandatory = $false)]
        [hashtable]
        $config = @{},

        # confirm the subscription selection, even if there is only one subscription
        [Parameter(Mandatory = $false)]
        [switch]
        $confirmSingleSubscription
    )
    $ErrorActionPreference = 'Stop'

    $subs = Get-AzSubscription -ErrorAction SilentlyContinue
    if (-not($subs)) {
        Connect-AzAccount | Out-Null
    }
    if ([string]::IsNullOrEmpty($config.subscriptionId)) {
        $subs = Get-AzSubscription -ErrorAction SilentlyContinue  | Where-Object {$_.State -eq "Enabled"} | Sort-Object -Property Name
        if ($subs.count -gt 1) {
            Write-Host "More than one subscription detected. Current subscription $((get-azcontext).Name)"
            Write-Host "Please select subscription for deployment or Enter to keep current one:"
            $i = 1
            $subs | ForEach-Object { Write-Host "$i - $($_.Name) - $($_.SubscriptionId)"; $i++ }
            [int]$selection = Read-Host "Select Subscription number: (1 - $($i-1))"
        }
        else { $selection = 0 }
        if ($selection -ne 0) {
            if ($selection -gt 0 -and $selection -le ($i - 1)) { 
                $null = Select-AzSubscription -SubscriptionObject $subs[$selection - 1]
                
                $config['runtime']['subscriptionId'] = $subs[$selection - 1].Id
            }
            else {
                Write-Host "Invalid selection. ($selection)"
                break
            }
        }
        else {
            If ($confirmSingleSubscription.IsPresent) {
                do { $prompt = Read-Host -Prompt "Do you want to continue with the current subscription ($($subs[0].Name))? (y/n)" }
                until ($prompt -match '[yn]')

                if ($prompt -eq 'y') {
                    Write-Verbose "Using current subscription '$($subs[0].Name)'"

                    $config['runtime']['subscriptionId'] = $subs[0].Id
                }
                elseif ($prompt -eq 'n') {
                    Write-Host "Exiting without modifying Guardrails Solution Accelerator..."
                    break
                }
            }
            Else {
                $config['runtime']['subscriptionId'] = $subs[0].Id
            }
        }
    }
    else {
        Write-Host "Selecting subscription: '$($config.subscriptionId)'"
        try {
            $context = Select-AzSubscription -Subscription $config.subscriptionId
            $config['runtime']['subscriptionId'] = $context.Subscription.Id
        }
        catch {
            Write-error "Error selecting provided subscription."
            break
        }
    }
}
Function Confirm-GSAConfigurationParameters {
    <#
.SYNOPSIS
    Verifies that the configuration parameters in the config file specified with -configFilePath are valid.
.DESCRIPTION
    
.NOTES
    
.LINK

.INPUTS
    A configuration JSON file at the path specified with configFilePath.

.OUTPUTS
    Outputs a verified object containing the configuration values.
    
.EXAMPLE
    Confirm-GSAConfigurationParameters -configFilePath
#>
    param (
        [Parameter(mandatory = $true, parameterSetName = 'configFile')]
        [string]
        $configFilePath,

        [Parameter(mandatory = $true, parameterSetName = 'configString')]
        [string]
        $configString
    )

    $ErrorActionPreference = 'Stop'

    Write-Verbose "Starting validation of configuration file/string and parameters..."

    If ($configFilePath) {
        # verify path is valid
        Write-Verbose "Verifying that the file specified by -configFilePath exists at '$configFilePath'"
        If (-NOT (Test-Path -Path $configFilePath -PathType Leaf)) {
            Write-Error "File specified with -configFilePath does not exist, you do not have access, or it is not a file."
            break
        }

        Write-Verbose "Reading contents of '$configFilePath'"
        $configString = Get-Content -Path $configFilePath -Raw
    }

    # verify file is a valid JSON file
    Write-Verbose "Verifying that the contents of '$configFilePath'/-configString is a valid JSON document"
    If (-NOT(Test-Json -Json $configString)) {
        Write-Error "Content of '$configFilePath' is not a valid JSON document; verify the file syntax and formatting."
        break
    }

    # import config and create a hashtable object
    Write-Verbose "Creating config hashtable object"
    $config = @{}
    $configObject = $configString | ConvertFrom-Json
    $configObject.PSObject.Properties | ForEach-Object {
        $config += @{ $_.Name = $_.Value }
    }

    # verify standard config parameters
    if ($config.SecurityLAWResourceId.split("/").Count -ne 9) {
        Write-Output "Error in SecurityLAWResourceId ID ('$($config.SecurityLAWResourceId)'). Parameter needs to be a full resource Id. (/subscriptions/<subid>/...)"
        Break
    }
    if ( $config.HealthLAWResourceId.Split("/").Count -ne 9) {
        Write-Output "Error in HealthLAWResourceId ID ('$($config.HealthLAWResourceId)'). Parameter needs to be a full resource Id. (/subscriptions/<subid>/...)"
        Break
    }

    # verify that Department Number has an associated Department Name, get name value for AA variable
    try {
        $uri = 'https://donnees-data.tpsgc-pwgsc.gc.ca/ba1/min-dept/min-dept.csv'
        $response = Invoke-RestMethod -Method GET -Uri $uri -StatusCodeVariable statusCode -ErrorAction Stop -ResponseHeadersVariable h
    }
    catch {
        Write-Error "Error retrieving department list from '$uri'. Verify that you have access to the internet. Falling back to local department list, which may be outdated."
        
        $departmentList = Import-Csv -Path "$PSScriptRoot/../../../../setup/departmentList.csv"
    }
    If ($statusCode -eq 200) {
        try {
            $departmentList = $response | ConvertFrom-CSV -ErrorAction Stop
        }
        catch {
            Write-Error "Error converting department list from CSV to hashtable. Verify that the CSV format and response is valid!"
            break
        }
        
        If ($departmentList.'Department_number-Ministère_numéro' -notcontains $config.DepartmentNumber) {
            Write-Error "Department Number '$($config.DepartmentNumber)' is not a valid department number or is not found in this GOC-published list: $uri. Verify that the department number is correct and that the published list is accurate."
            $departmentName = 'Department_Name_Unknown'
        }
        Else {
            $departmentName = $departmentList | Where-Object { $_.'Department_number-Ministère_numéro' -eq $config.DepartmentNumber } | 
                Select-Object -ExpandProperty 'Department-name_English-Ministère_nom_anglais'
        }
    }

    # get tenant id from curent context
    $context = Get-AzContext
    $tenantId = $context.Tenant.Id

    # verify Lighthouse config parameters
    $lighthouseServiceProviderTenantID = $config.lighthouseServiceProviderTenantID
    $lighthousePrincipalDisplayName = $config.lighthousePrincipalDisplayName
    $lighthousePrincipalId = $config.lighthousePrincipalId
    $lighthouseTargetManagementGroupID = $config.lighthouseTargetManagementGroupID
    If ($configureLighthouseAccessDelegation.isPresent) {
        # verify input from config.json
        if ([string]::IsNullOrEmpty($lighthouseServiceProviderTenantID) -or !($lighthouseServiceProviderTenantID -as [guid])) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthouseServiceProviderTenantID' has a value of '$lighthouseServiceProviderTenantID'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthousePrincipalDisplayName)) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthousePrincipalDisplayName' has a value of '$lighthousePrincipalDisplayName'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthousePrincipalId) -or !($lighthousePrincipalId -as [guid])) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthousePrincipalId' has a value of '$lighthousePrincipalId'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthouseTargetManagementGroupID)) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthouseTargetManagementGroupID' has a value of '$lighthouseTargetManagementGroupID'"
            break
        }
    }

    # generate run-time config parameters
    $config['runtime'] = @{}

    ## add department name
    $config['runtime']['DepartmentName'] = $departmentName

    ## confirm subscription selection
    Confirm-GSASubscriptionSelection -config $config
    
    ## get tenant default domain - use Graph to support SPNs
    $response = Invoke-AzRestMethod -Method get -uri 'https://graph.microsoft.com/v1.0/organization' | Select-Object -expand Content | convertfrom-json -Depth 10
    $tenantDomainUPN = $response.value.verifiedDomains | Where-Object { $_.isDefault } | Select-Object -ExpandProperty name # onmicrosoft.com is verified and default by default

    ## get executing user identifier
    If ($context.Account -match '^MSI@') {
        # running in Cloud Shell, finding delegated user ID
        $userId = (Get-AzAdUser -SignedIn).Id
    }
    ElseIf ($context.Account.Type -eq 'ServicePrincipal') {
        $sp = Get-AzADServicePrincipal -ApplicationId $context.Account.Id
        $userId = $sp.Id
    }
    Else {
        # running locally
        $userId = (Get-AzAdUser -SignedIn).Id
    }

    ## gets tags information from tags.json, including version and release date.
    $tagsTable = get-content -path "$PSScriptRoot/../../../../setup/tags.json" | convertfrom-json -AsHashtable

    ## unique resource name suffix, default to last segment of tenant ID
    If ([string]::IsNullOrEmpty($config.uniqueNameSuffix)) {
        $uniqueNameSuffix = '-' + $tenantId.Split("-")[0]
    }
    Else {
        $uniqueNameSuffix = '-' + $config.uniqueNameSuffix
    }

    ## generate resource names
    #TO-DO: switch to keyVaulNamePrefix, etc and existingKeyVauleName in config.json
    $config['runtime']['keyVaultName'] = $config.KeyVaultName + $uniqueNameSuffix
    $config['runtime']['logAnalyticsWorkspaceName'] = $config.logAnalyticsWorkspaceName + $uniqueNameSuffix
    $config['runtime']['resourceGroup'] = $config.resourceGroup + $uniqueNameSuffix
    $config['runtime']['automationAccountName'] = $config.automationAccountName + $uniqueNameSuffix
    $config['runtime']['storageAccountName'] = $config.storageAccountName + $uniqueNameSuffix.replace('-', '') # remove hyphen, which is not supported in storage account name

    # add values to config object
    $config['runtime']['tenantId'] = $tenantId
    $config['runtime']['tenantDomainUPN'] = $tenantDomainUPN
    $config['runtime']['tenantRootManagementGroupId'] = '/providers/Microsoft.Management/managementGroups/{0}' -f $tenantId
    $config['runtime']['userId'] = $userId
    $config['runtime']['tagsTable'] = $tagsTable
    $config['runtime']['deployLAW'] = $true
    $config['runtime']['deployKV'] = $true
    
    # output the configuration as an object
    Write-Host "Validation of configuration parameters completed successfully!" -ForegroundColor Green

    Write-Verbose "Returning config object: `n $($config.GetEnumerator() | Sort-Object -Property Name | Out-String)"
    Write-Verbose "Returning config object (runtime values): `n $($config.runtime.GetEnumerator() | Sort-Object -Property Name | Out-String)"

    $config

    Write-Verbose "Validation of configuration file and parameters complete"
}

# SIG # Begin signature block
# MIInogYJKoZIhvcNAQcCoIInkzCCJ48CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDtl/CJOtiXfnWX
# DPV9/nZ26CgR62Yw1lk1pwgA30Ukn6CCDYUwggYDMIID66ADAgECAhMzAAACzfNk
# v/jUTF1RAAAAAALNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NjAyWhcNMjMwNTExMjA0NjAyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDrIzsY62MmKrzergm7Ucnu+DuSHdgzRZVCIGi9CalFrhwtiK+3FIDzlOYbs/zz
# HwuLC3hir55wVgHoaC4liQwQ60wVyR17EZPa4BQ28C5ARlxqftdp3H8RrXWbVyvQ
# aUnBQVZM73XDyGV1oUPZGHGWtgdqtBUd60VjnFPICSf8pnFiit6hvSxH5IVWI0iO
# nfqdXYoPWUtVUMmVqW1yBX0NtbQlSHIU6hlPvo9/uqKvkjFUFA2LbC9AWQbJmH+1
# uM0l4nDSKfCqccvdI5l3zjEk9yUSUmh1IQhDFn+5SL2JmnCF0jZEZ4f5HE7ykDP+
# oiA3Q+fhKCseg+0aEHi+DRPZAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU0WymH4CP7s1+yQktEwbcLQuR9Zww
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ3MDUzMDAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE7LSuuNObCBWYuttxJAgilXJ92GpyV/fTiyXHZ/9LbzXs/MfKnPwRydlmA2ak0r
# GWLDFh89zAWHFI8t9JLwpd/VRoVE3+WyzTIskdbBnHbf1yjo/+0tpHlnroFJdcDS
# MIsH+T7z3ClY+6WnjSTetpg1Y/pLOLXZpZjYeXQiFwo9G5lzUcSd8YVQNPQAGICl
# 2JRSaCNlzAdIFCF5PNKoXbJtEqDcPZ8oDrM9KdO7TqUE5VqeBe6DggY1sZYnQD+/
# LWlz5D0wCriNgGQ/TWWexMwwnEqlIwfkIcNFxo0QND/6Ya9DTAUykk2SKGSPt0kL
# tHxNEn2GJvcNtfohVY/b0tuyF05eXE3cdtYZbeGoU1xQixPZAlTdtLmeFNly82uB
# VbybAZ4Ut18F//UrugVQ9UUdK1uYmc+2SdRQQCccKwXGOuYgZ1ULW2u5PyfWxzo4
# BR++53OB/tZXQpz4OkgBZeqs9YaYLFfKRlQHVtmQghFHzB5v/WFonxDVlvPxy2go
# a0u9Z+ZlIpvooZRvm6OtXxdAjMBcWBAsnBRr/Oj5s356EDdf2l/sLwLFYE61t+ME
# iNYdy0pXL6gN3DxTVf2qjJxXFkFfjjTisndudHsguEMk8mEtnvwo9fOSKT6oRHhM
# 9sZ4HTg/TTMjUljmN3mBYWAWI5ExdC1inuog0xrKmOWVMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAALN82S/+NRMXVEAAAAA
# As0wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPeJ
# hr6W+zD355CD1wLPpdL6jFRGeIqoR7Gzm2v145ipMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEADs0fAU0gidkJW3tJk8/Ho0tmLgbJQDPUG0jl
# U2tOEAOSr3ETv1Y8zGg7YFRrzi9BvSqBx/Q19U2g7vJq8XQLoLNBlMNhyGO5Pnrk
# E1qJXji3TGTDiFU4ljqfq/K8kKVT3QHE3nWIaH46AC8tRYlqQYHmr1/izFSzJgdP
# Uhc20qQ0N73mtPkrIa8aZVmblZ5dvdP44ZUF3F7w4xw99BNS6p/I4tF/ZEUbccfU
# 1f9t+UCe+W/8goSMrhX1KpckJInygqQycTUjJxBQInBPrSqwARCjIEDUTh4tugtG
# dB3kAQj0oGT5WuvJOy+RqrlDgvW0Uhq0/q0uUcqfWpJ9NtpnNaGCFv0wghb5Bgor
# BgEEAYI3AwMBMYIW6TCCFuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCAJB0QIH9PMCKEN9UxNHc8IQlpOg5NxQkC1
# VAAQIH7/zQIGZDfpZ/MWGBMyMDIzMDUwMTE3MjE1MS4yMTRaMASAAgH0oIHQpIHN
# MIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpFNUE2LUUyN0MtNTkyRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCEVQwggcMMIIE9KADAgECAhMzAAABvvQgou6W1iDWAAEA
# AAG+MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIyMTEwNDE5MDEyMloXDTI0MDIwMjE5MDEyMlowgcoxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3
# Qy01OTJFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApV/y2z7Da7nMu0tykLY8olh7
# Z03EqFNz3iFlMp9gOfVmZABmheCc87RuPdQ2P+OHUJiqCQAWNuNSoI/Q1ixEw9AA
# 657ldD8Z3/EktpmxKHHavOhwQSFPcpTGFVXIxKCwoO824giyHPG84dfhdi6WU7f7
# D+85LaPB0dOsPHKKMGlC9p66Lv9yQzvAhZGFmFhlusCy/egrz6JX/OHOT9qCwugh
# rL0IPf47ULe1pQSEEihy438JwS+rZU4AVyvQczlMC26XsTuDPgEQKlzx9ru7EvNV
# 99l/KCU9bbFf5SnkN1moUgKUq09NWlKxzLGEvhke2QNMopn86Jh1fl/PVevN/xrZ
# SpV23rM4lB7lh7XSsCPeFslTYojKN2ioOC6p3By7kEmvZCh6rAsPKsARJISdzKQC
# Mq+mqDuiP6mr/LvuWKinP+2ZGmK/C1/skvlTjtIehu50yoXNDlh1CN9B3QLglQY+
# UCBEqJog/BxAn3pWdR01o/66XIacgXI/d0wG2/x0OtbjEGAkacfQlmw0bDc02dhQ
# Fki/1Q9Vbwh4kC7VgAiJA8bC5zEIYWHNU7C+He69B4/2dZpRjgd5pEpHbF9OYiAf
# 7s5MnYEnHN/5o/bGO0ajAb7VI4f9av62sC6xvhKTB5R4lhxEMWF0z4v7BQ5CHyMN
# kL+oTnzJLqnLVdXnuM0CAwEAAaOCATYwggEyMB0GA1UdDgQWBBTrKiAWoYRBoPGt
# bwvbhhX6a2+iqjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNV
# HR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
# bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYI
# KwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAy
# MDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0G
# CSqGSIb3DQEBCwUAA4ICAQDHlfu9c0ImhdBis1yj56bBvOSyGpC/rSSty+1F49Tf
# 6fmFEeqxhwTTHVHOeIRNd8gcDLSz0d79mXCqq8ynq6gJgy2u4LyyAr2LmwzFVuux
# oGVR8YuUnRtvsDH5J+unye/nMkwHiC+G82h3uQ8fcGj+2H0nKPmUpUtfQruMUXvz
# LjV5NyRjDiCL5c/f5ecmz01dnpnCvE6kIz/FTpkvOeVJk22I2akFZhPz24D6OT6K
# kTtwBRpSEHDYqCQ4cZ+7SXx7jzzd7b+0p9vDboqCy7SwWgKpGQG+wVbKrTm4hKkZ
# DzcdAEgYqehXz78G00mYILiDTyUikwQpoZ7am9pA6BdTPY+o1v6CRzcneIOnJYan
# HWz0R+KER/ZRFtLCyBMvLzSHEn0sR0+0kLklncKjGdA1YA42zOb611UeIGytZ9Vh
# Nwn4ws5GJ6n6PJmMPO+yPEkOy2f8OBiuhaqlipiWhzGtt5UsC0geG0sW9qwa4QAW
# 1sQWIrhSl24MOOVwNl/Am9/ZqvLRWr1x4nupeR8G7+DNyn4MTg28yFZRU1ktSvyB
# MUSvN2K99BO6p1gSx/wvSsR45dG33PDG5fKqHOgDxctjBU5bX49eJqjNL7S/UndL
# F7S0OWL9mdk/jPVHP2I6XtN0K4VjdRwvIgr3jNib3GZyGJnORp/ZMbY2Dv1mKcx7
# dTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQEL
# BQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNV
# BAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4X
# DTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM
# 57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm
# 95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzB
# RMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBb
# fowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCO
# Mcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYw
# XE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW
# /aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/w
# EPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPK
# Z6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2
# BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfH
# CBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYB
# BAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8v
# BO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYM
# KwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEF
# BQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBW
# BgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUH
# AQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# L2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsF
# AAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518Jx
# Nj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+
# iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2
# pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefw
# C2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7
# T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFO
# Ry3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhL
# mm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3L
# wUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5
# m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE
# 0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIB
# ATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046RTVBNi1FMjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAGitWlL3vPu8
# ENOAe+i2+4wfTMB7oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQEFBQACBQDn+iJRMCIYDzIwMjMwNTAxMTkzNDQxWhgPMjAy
# MzA1MDIxOTM0NDFaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOf6IlECAQAwBwIB
# AAICHWEwBwIBAAICIrAwCgIFAOf7c9ECAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQAcl0i18ht45uFKrbSa4XSIy2X1rIGKiBTTvRyEzL04RqTcDGeXFAVKgHIH
# SVzfGAEMhb4hTqFe86nScHv4Sm22Wzm+YivExQP3Q8Ro+38XkHr5QgPlyZvHvlyy
# 8eUQwGq90+KCwlNIubbQKahmHskCGEJNHHszesbVEj0o62Nz+zGCBA0wggQJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABvvQgou6W1iDW
# AAEAAAG+MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIAzLSpYqspeLu4DWYauCWWI+98XEP00mFKfp
# ICZTpNK3MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQglO6Kr632/Oy9ZbXP
# rhEPidNAg/Fef7K3SZg+DxjhDC8wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAb70IKLultYg1gABAAABvjAiBCCEM5bvOL8r0yNcXmhp
# T13SOVf17c4a/ASeftvALOMPJTANBgkqhkiG9w0BAQsFAASCAgBCGpKN5Aj2h7lZ
# hAAWw65GEnmKcK5kelNkgU7JEHa1PoaeBmjd2hf4Lk2J4th0J/W01IseDR3IY92v
# 25Pj1utQxiFVEdXpjcMdkOO9KzxXGtWDgoG2Niz32DLBSueHXUGWg167BUIzGHuo
# eT6MBIUJsx4nhvuLlOV3IwrRoTdM8T3rIkGOr5Ie1a33ZAlqb9S0kuWYn7Bla1q/
# MJnneg5CuDAVkrEHKSlocTq9yNAXhycg6J4e3xZL1a9fjcx3vghWmhMClBYfjW/Q
# XySf+1ixAczJnHhvsP8+INiE6HP6/abG/fyi7e/oSXsFiv/WMAo1UIGKh2TQgx7P
# T4puQhHWSBZq6DDbWdbafJCImAHLCfwziOC1Fj9vZSkFHFYhvl+bfRP0AMSqiHw6
# v6dDDOTVDf9Wir0dennuTvNz7dXcgR1qve1Q/JgnQEIaAlnh6sDLScNdxFqv3h84
# UtlhsE6tNCwHFL3tKlfqH5bBp4xMcIwbuqTc1cKz1O7LIw15SZ6ehILynJYBFcjB
# vhHaPpxG/udN7MnbWEGSt4Lqf7NUbO6ja56TcG+f1eFIaf9sql4GChW0xJVPGQaz
# 74pmBrBqokWsyA06Ox9Sly7pcs4u9Twdz3j7yvH3pQIQbhhwpN3+o8CEvTYOZ4ak
# b3eNRSYRw4lfbzFcJcB3CgfyhEzHLQ==
# SIG # End signature block

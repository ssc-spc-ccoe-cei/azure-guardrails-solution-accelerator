Function Confirm-GSASubscriptionSelection {
    param (
        # config object
        [Parameter(Mandatory = $false)]
        [hashtable]
        $config = @{},

        # confirm the subscription selection, even if there is only one subscription
        [Parameter(Mandatory = $false)]
        [switch]
        $confirmSingleSubscription
    )
    $ErrorActionPreference = 'Stop'

    $subs = Get-AzSubscription -ErrorAction SilentlyContinue
    if (-not($subs)) {
        Connect-AzAccount | Out-Null
    }
    if ([string]::IsNullOrEmpty($config.subscriptionId)) {
        $subs = Get-AzSubscription -ErrorAction SilentlyContinue | Sort-Object -Property Name
        if ($subs.count -gt 1) {
            Write-Host "More than one subscription detected. Current subscription $((get-azcontext).Name)"
            Write-Host "Please select subscription for deployment or Enter to keep current one:"
            $i = 1
            $subs | ForEach-Object { Write-Host "$i - $($_.Name) - $($_.SubscriptionId)"; $i++ }
            [int]$selection = Read-Host "Select Subscription number: (1 - $($i-1))"
        }
        else { $selection = 0 }
        if ($selection -ne 0) {
            if ($selection -gt 0 -and $selection -le ($i - 1)) { 
                $null = Select-AzSubscription -SubscriptionObject $subs[$selection - 1]
                
                $config['runtime']['subscriptionId'] = $subs[$selection - 1].Id
            }
            else {
                Write-Host "Invalid selection. ($selection)"
                break
            }
        }
        else {
            If ($confirmSingleSubscription.IsPresent) {
                do { $prompt = Read-Host -Prompt "Do you want to continue with the current subscription ($($subs[0].Name))? (y/n)" }
                until ($prompt -match '[yn]')

                if ($prompt -eq 'y') {
                    Write-Verbose "Using current subscription '$($subs[0].Name)'"

                    $config['runtime']['subscriptionId'] = $subs[0].Id
                }
                elseif ($prompt -eq 'n') {
                    Write-Host "Exiting without modifying Guardrails Solution Accelerator..."
                    break
                }
            }
            Else {
                $config['runtime']['subscriptionId'] = $subs[0].Id
            }
        }
    }
    else {
        Write-Host "Selecting subscription: '$($config.subscriptionId)'"
        try {
            $context = Select-AzSubscription -Subscription $config.subscriptionId
            $config['runtime']['subscriptionId'] = $context.Subscription.Id
        }
        catch {
            Write-error "Error selecting provided subscription."
            break
        }
    }
}
Function Confirm-GSAConfigurationParameters {
    <#
.SYNOPSIS
    Verifies that the configuration parameters in the config file specified with -configFilePath are valid.
.DESCRIPTION
    
.NOTES
    
.LINK

.INPUTS
    A configuration JSON file at the path specified with configFilePath.

.OUTPUTS
    Outputs a verified object containing the configuration values.
    
.EXAMPLE
    Confirm-GSAConfigurationParameters -configFilePath
#>
    param (
        [Parameter(mandatory = $true, parameterSetName = 'configFile')]
        [string]
        $configFilePath,

        [Parameter(mandatory = $true, parameterSetName = 'configString')]
        [string]
        $configString
    )

    $ErrorActionPreference = 'Stop'

    Write-Verbose "Starting validation of configuration file/string and parameters..."

    If ($configFilePath) {
        # verify path is valid
        Write-Verbose "Verifying that the file specified by -configFilePath exists at '$configFilePath'"
        If (-NOT (Test-Path -Path $configFilePath -PathType Leaf)) {
            Write-Error "File specified with -configFilePath does not exist, you do not have access, or it is not a file."
            break
        }

        Write-Verbose "Reading contents of '$configFilePath'"
        $configString = Get-Content -Path $configFilePath -Raw
    }

    # verify file is a valid JSON file
    Write-Verbose "Verifying that the contents of '$configFilePath'/-configString is a valid JSON document"
    If (-NOT(Test-Json -Json $configString)) {
        Write-Error "Content of '$configFilePath' is not a valid JSON document; verify the file syntax and formatting."
        break
    }

    # import config and create a hashtable object
    Write-Verbose "Creating config hashtable object"
    $config = @{}
    $configObject = $configString | ConvertFrom-Json
    $configObject.PSObject.Properties | ForEach-Object {
        $config += @{ $_.Name = $_.Value }
    }

    # verify standard config parameters
    if ($config.SecurityLAWResourceId.split("/").Count -ne 9) {
        Write-Output "Error in SecurityLAWResourceId ID ('$($config.SecurityLAWResourceId)'). Parameter needs to be a full resource Id. (/subscriptions/<subid>/...)"
        Break
    }
    if ( $config.HealthLAWResourceId.Split("/").Count -ne 9) {
        Write-Output "Error in HealthLAWResourceId ID ('$($config.HealthLAWResourceId)'). Parameter needs to be a full resource Id. (/subscriptions/<subid>/...)"
        Break
    }

    # verify that Department Number has an associated Department Name, get name value for AA variable
    try {
        $uri = 'https://donnees-data.tpsgc-pwgsc.gc.ca/ba1/min-dept/min-dept.csv'
        $response = Invoke-RestMethod -Method GET -Uri $uri -StatusCodeVariable statusCode -ErrorAction Stop -ResponseHeadersVariable h
    }
    catch {
        Write-Error "Error retrieving department list from '$uri'. Verify that you have access to the internet. Falling back to local department list, which may be outdated."
        
        $departmentList = Import-Csv -Path "$PSScriptRoot/../../../../setup/departmentList.csv"
    }
    If ($statusCode -eq 200) {
        try {
            $departmentList = $response | ConvertFrom-CSV -ErrorAction Stop
        }
        catch {
            Write-Error "Error converting department list from CSV to hashtable. Verify that the CSV format and response is valid!"
            break
        }
        
        If ($departmentList.'ï»¿Department_number-MinistÃ¨re_numÃ©ro' -notcontains $config.DepartmentNumber) {
            Write-Error "Department Number '$($config.DepartmentNumber)' is not a valid department number or is not found in this GOC-published list: $uri. Verify that the department number is correct and that the published list is accurate."
            $departmentName = 'Department_Name_Unknown'
        }
        Else {
            $departmentName = $departmentList | Where-Object { $_.'ï»¿Department_number-MinistÃ¨re_numÃ©ro' -eq $config.DepartmentNumber } | Select-Object -ExpandProperty 'Department-name_English-MinistÃ¨re_nom_anglais'
        }
    }

    # get tenant id from curent context
    $context = Get-AzContext
    $tenantId = $context.Tenant.Id

    # verify Lighthouse config parameters
    $lighthouseServiceProviderTenantID = $config.lighthouseServiceProviderTenantID
    $lighthousePrincipalDisplayName = $config.lighthousePrincipalDisplayName
    $lighthousePrincipalId = $config.lighthousePrincipalId
    $lighthouseTargetManagementGroupID = $config.lighthouseTargetManagementGroupID
    If ($configureLighthouseAccessDelegation.isPresent) {
        # verify input from config.json
        if ([string]::IsNullOrEmpty($lighthouseServiceProviderTenantID) -or !($lighthouseServiceProviderTenantID -as [guid])) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthouseServiceProviderTenantID' has a value of '$lighthouseServiceProviderTenantID'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthousePrincipalDisplayName)) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthousePrincipalDisplayName' has a value of '$lighthousePrincipalDisplayName'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthousePrincipalId) -or !($lighthousePrincipalId -as [guid])) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthousePrincipalId' has a value of '$lighthousePrincipalId'"
            break
        }
        if ([string]::IsNullOrEmpty($lighthouseTargetManagementGroupID)) {
            Write-Error "Lighthouse delegation cannot be configured when config.json parameter 'lighthouseTargetManagementGroupID' has a value of '$lighthouseTargetManagementGroupID'"
            break
        }
    }

    # generate run-time config parameters
    $config['runtime'] = @{}

    ## add department name
    $config['runtime']['DepartmentName'] = $departmentName

    ## confirm subscription selection
    Confirm-GSASubscriptionSelection -config $config
    
    ## get tenant default domain - use Graph to support SPNs
    $response = Invoke-AzRestMethod -Method get -uri 'https://graph.microsoft.com/v1.0/organization' | Select-Object -expand Content | convertfrom-json -Depth 10
    $tenantDomainUPN = $response.value.verifiedDomains | Where-Object { $_.isDefault } | Select-Object -ExpandProperty name # onmicrosoft.com is verified and default by default

    ## get executing user identifier
    If ($context.Account -match '^MSI@') {
        # running in Cloud Shell, finding delegated user ID
        $userId = (Get-AzAdUser -SignedIn).Id
    }
    ElseIf ($context.Account.Type -eq 'ServicePrincipal') {
        $sp = Get-AzADServicePrincipal -ApplicationId $context.Account.Id
        $userId = $sp.Id
    }
    Else {
        # running locally
        $userId = (Get-AzAdUser -SignedIn).Id
    }

    ## gets tags information from tags.json, including version and release date.
    $tagsTable = get-content -path "$PSScriptRoot/../../../../setup/tags.json" | convertfrom-json -AsHashtable

    ## unique resource name suffix, default to last segment of tenant ID
    If ([string]::IsNullOrEmpty($config.uniqueNameSuffix)) {
        $uniqueNameSuffix = '-' + $tenantId.Split("-")[0]
    }
    Else {
        $uniqueNameSuffix = '-' + $config.uniqueNameSuffix
    }

    ## generate resource names
    #TO-DO: switch to keyVaulNamePrefix, etc and existingKeyVauleName in config.json
    $config['runtime']['keyVaultName'] = $config.KeyVaultName + $uniqueNameSuffix
    $config['runtime']['logAnalyticsWorkspaceName'] = $config.logAnalyticsWorkspaceName + $uniqueNameSuffix
    $config['runtime']['resourceGroup'] = $config.resourceGroup + $uniqueNameSuffix
    $config['runtime']['automationAccountName'] = $config.automationAccountName + $uniqueNameSuffix
    $config['runtime']['storageAccountName'] = $config.storageAccountName + $uniqueNameSuffix.replace('-', '') # remove hyphen, which is not supported in storage account name

    # add values to config object
    $config['runtime']['tenantId'] = $tenantId
    $config['runtime']['tenantDomainUPN'] = $tenantDomainUPN
    $config['runtime']['tenantRootManagementGroupId'] = '/providers/Microsoft.Management/managementGroups/{0}' -f $tenantId
    $config['runtime']['userId'] = $userId
    $config['runtime']['tagsTable'] = $tagsTable
    $config['runtime']['deployLAW'] = $true
    $config['runtime']['deployKV'] = $true
    
    # output the configuration as an object
    Write-Host "Validation of configuration parameters completed successfully!" -ForegroundColor Green

    Write-Verbose "Returning config object: `n $($config.GetEnumerator() | Sort-Object -Property Name | Out-String)"
    Write-Verbose "Returning config object (runtime values): `n $($config.runtime.GetEnumerator() | Sort-Object -Property Name | Out-String)"

    $config

    Write-Verbose "Validation of configuration file and parameters complete"
}

# SIG # Begin signature block
# MIInsQYJKoZIhvcNAQcCoIInojCCJ54CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBEBzMdMt5jc41x
# lhLE+WSaAL6ykmRZdCaHI+EH5pQlmqCCDYUwggYDMIID66ADAgECAhMzAAACzfNk
# v/jUTF1RAAAAAALNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NjAyWhcNMjMwNTExMjA0NjAyWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDrIzsY62MmKrzergm7Ucnu+DuSHdgzRZVCIGi9CalFrhwtiK+3FIDzlOYbs/zz
# HwuLC3hir55wVgHoaC4liQwQ60wVyR17EZPa4BQ28C5ARlxqftdp3H8RrXWbVyvQ
# aUnBQVZM73XDyGV1oUPZGHGWtgdqtBUd60VjnFPICSf8pnFiit6hvSxH5IVWI0iO
# nfqdXYoPWUtVUMmVqW1yBX0NtbQlSHIU6hlPvo9/uqKvkjFUFA2LbC9AWQbJmH+1
# uM0l4nDSKfCqccvdI5l3zjEk9yUSUmh1IQhDFn+5SL2JmnCF0jZEZ4f5HE7ykDP+
# oiA3Q+fhKCseg+0aEHi+DRPZAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU0WymH4CP7s1+yQktEwbcLQuR9Zww
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ3MDUzMDAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AE7LSuuNObCBWYuttxJAgilXJ92GpyV/fTiyXHZ/9LbzXs/MfKnPwRydlmA2ak0r
# GWLDFh89zAWHFI8t9JLwpd/VRoVE3+WyzTIskdbBnHbf1yjo/+0tpHlnroFJdcDS
# MIsH+T7z3ClY+6WnjSTetpg1Y/pLOLXZpZjYeXQiFwo9G5lzUcSd8YVQNPQAGICl
# 2JRSaCNlzAdIFCF5PNKoXbJtEqDcPZ8oDrM9KdO7TqUE5VqeBe6DggY1sZYnQD+/
# LWlz5D0wCriNgGQ/TWWexMwwnEqlIwfkIcNFxo0QND/6Ya9DTAUykk2SKGSPt0kL
# tHxNEn2GJvcNtfohVY/b0tuyF05eXE3cdtYZbeGoU1xQixPZAlTdtLmeFNly82uB
# VbybAZ4Ut18F//UrugVQ9UUdK1uYmc+2SdRQQCccKwXGOuYgZ1ULW2u5PyfWxzo4
# BR++53OB/tZXQpz4OkgBZeqs9YaYLFfKRlQHVtmQghFHzB5v/WFonxDVlvPxy2go
# a0u9Z+ZlIpvooZRvm6OtXxdAjMBcWBAsnBRr/Oj5s356EDdf2l/sLwLFYE61t+ME
# iNYdy0pXL6gN3DxTVf2qjJxXFkFfjjTisndudHsguEMk8mEtnvwo9fOSKT6oRHhM
# 9sZ4HTg/TTMjUljmN3mBYWAWI5ExdC1inuog0xrKmOWVMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGYIwghl+AgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAALN82S/+NRMXVEAAAAA
# As0wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIC5x
# vrTh+F2aOkOjqpqu0Mv4bk9E1C2JHl6Y2wYw916qMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAATtTfthOYeuaAxHBsiLKxisXLaIWd8iwnrqH
# OfqSHZiAnI26LVpP3JRxX3bHeOC+eQh/fIG+38zy5tK1NqujacGjbKK8XYgs8WI2
# CTW+7xcsCNDHeCylGXkpR9g027f6WYSvN1KBLZOcelDPPFiooKD02jsSmc1RDe9t
# valLz/QulPm4vJx7Ia0qc4MdBJtc0Co/egv1Hm7NMOK/FQlKirhB5IOWNJX645Oi
# 9eVt+IkxLC4Y0eldbqiMYeF1OFeqOLaDU6VbGc4/3P3V7DxS01tviDJZoDDo/q2b
# COLwk2dxAwTaYr4rZvj1jsEOjhqDB/wVTNcHQpd5Nq4xNDcU2qGCFwwwghcIBgor
# BgEEAYI3AwMBMYIW+DCCFvQGCSqGSIb3DQEHAqCCFuUwghbhAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFVBgsqhkiG9w0BCRABBKCCAUQEggFAMIIBPAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCCbUjhZE57R8hlonXaKJdhhJoaXkIhLnkOr
# mZN1+GAFRQIGY3PaOLS8GBMyMDIyMTEzMDE4MTEzMy44NDZaMASAAgH0oIHUpIHR
# MIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQL
# EyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046RDlERS1FMzlBLTQzRkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2WgghFfMIIHEDCCBPigAwIBAgITMwAAAaxmvIciXd49
# ewABAAABrDANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMDAeFw0yMjAzMDIxODUxMjlaFw0yMzA1MTExODUxMjlaMIHOMQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQg
# T3BlcmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046
# RDlERS1FMzlBLTQzRkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDHeAtQxRdi7sdx
# zCvABJTHUxeIhvUTsikFhXoU13vhF9UDq0wRZ4TACjRyEFqMZCtVutv6EEEJrSB6
# PLKYTLdVqZCzbwpty2vLHVS97fwQMe1FpJn77oydyg2koLd3JXObjT1I+3t9lOJ/
# xKfaDnPj7/xB3O1xh9Xxkby0WM8KMT9cZCpXrrGyM0/2ip+lgtgYID84x14p/ShO
# 5K4grqgPiTYbJJHnUxyUCKLW5Ufq2XLHsU0pozvme0dJn3h4lPA57b2b2f/WnfV1
# IQ8FCRSmfGWb8Z6p2V8BWJAyjWoGPINOgRdbw7pW5QLOgOIbj9Xu6bShaaQdVWZC
# 1AJiFtccSRrN5HonQE1iFcdtrBlcnpmk9vTX7Q6f40bA8P2ocL9TZL+lr8pKLytJ
# AzyGPUwlvXEW71HhJZPvglTO3CKq5fEGN5oBEPKIuOVcxAV7mNOGNSoo2xi2ERTV
# MqVzEQwKVfpHIxvLkk9d5kgn9ojIVkUS8/f48iMHu5Zl8+M1MmHJK/tjZvBq0quX
# 1QD7ISDvAG/2jqOv6Htxt2PnIpfIskSSyTcWzGMYkCSmb28ZQiKfqRiJ2g9d+9zO
# yjzxf8l3k+IRtC6lyr3pZILZac3nz65lFbqY2E4Hhn7qVMBc8pkpOCUTTtbYUQdG
# wygyMjTFahLr1dVMXXK4nFdKI4HiRwIDAQABo4IBNjCCATIwHQYDVR0OBBYEFFgR
# n3cEyx9AZ0o8fElamFrAQI5NMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1
# GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEp
# LmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUy
# MFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggIBAHnQtQJYVVxwpXZPLaCMwFvUMiE3EXso
# VKbNbg+u8wgt9PH0c2BREv9rzF+6NDmyYMwsU9Z4tL5HLPFhtjFCLJPdUQjyHg80
# 0CLSKY/WU8/YdLbn3Chpt2oZJ0bNYaFddo0RZHGqlyaNX7MrqCoA/hU09pTr6xLD
# YyYecBLIvjwf5lZofyWtFbvI4VCXNYawVEOWIrEODdNLJ2cITqAnj123Q+hxrNXJ
# rF2W65E/LzT2FfC5yOJcbif2GmEttKkK+mPQyBxQzWMWW05bEHl7Pyo54UTXRYgh
# qAHCx1sHlnkbM4dolITH2Nf+/Xe7KJn48emciT2Tq+HxNFE9pf6wWgU66D6Qzr6W
# jrGOhP7XiyzH8p6+lDkHhOJUYsOfbIlRsgBqqUwU23cwBSwRR+NLm6+1RJXZo4h2
# teBJGcWL3IMysSqrm+Mqymn6P4/WlG8C6y9lTB1nKWtfCYb+syI3dNSBpFHY91Cf
# iSkDQM+Xsj8kEmT7fcLPG8p6HRpTOZ2JBwcu6z74+Ocvmc+46y4I4L2SIsRrM8Ki
# siieOwDx8ax/BowkLrG71vTReCwGCqGWRo+z8JkAPl5sA+bX1ENCrszERZjKTlM7
# YkwICY0H/UzLnN6WJqRVhK/JLGHcK463VmACwlwPyEFxHQIrEMI+WM07IeEMU1Kv
# r0UsbPd8gd5yMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+
# F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU
# 88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqY
# O7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzp
# cGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0Xn
# Rm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1
# zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZN
# N3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLR
# vWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTY
# uVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUX
# k8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB
# 2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKR
# PEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0g
# BFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQE
# AwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQ
# W9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNv
# bS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBa
# BggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqG
# SIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOX
# PTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6c
# qYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/z
# jj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz
# /AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyR
# gNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdU
# bZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo
# 3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4K
# u+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10Cga
# iQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9
# vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGC
# AtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8g
# UmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDlERS1FMzlBLTQzRkUxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMC
# GgMVALEa0hOwuLBJ/egDIYzZF2dGNYqgoIGDMIGApH4wfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDnMXYhMCIYDzIwMjIxMTMw
# MTAyNjQxWhgPMjAyMjEyMDExMDI2NDFaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIF
# AOcxdiECAQAwCgIBAAICFhwCAf8wBwIBAAICEPgwCgIFAOcyx6ECAQAwNgYKKwYB
# BAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGG
# oDANBgkqhkiG9w0BAQUFAAOBgQC/orF5XCSSH4IrCQ33jY1PXiGQmF3uu3x/LqGD
# UloDGmfDb+O4WvB95QC31JX5uQNv2/eAWW0GrJ1q48/gBtKqyRdpW8s1DeSGBvbm
# jiAYfBqO/n9DXnGPFDEm1mArmKCtLg6NwukXoIETdgO/JEEmMBbmfENREoVOc4kA
# i55+tTGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABrGa8hyJd3j17AAEAAAGsMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG
# 9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIBhHm+XcizwecAKL
# zrun1/z5Afe9uGV2Nk+An0dcFTCzMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCB
# vQQg+bcBkoM4LwlxAHK1c+epu/T6fm0CX/tPi4Nn2gQswvUwgZgwgYCkfjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAaxmvIciXd49ewABAAABrDAi
# BCC/B//kosSGCqaxoDoXiZShkmU8EN82EgC/1C6J6D363TANBgkqhkiG9w0BAQsF
# AASCAgA8bbvbZj/WfMBqAQURwzGu85w3LVzM+6atV2aQWQgJl+D38praGeryjexV
# 5yMRtVWHl9T5tGos6FbgsajG+12+d3JlbleTQ6jFEnr1G6o443b9gDJiIZI3L2uZ
# tuAcQfbkjdcXz/gbM0Ec6azqZnztpqTtn/8WXTUrtakO2tEmxZt4fUZ3Oi5EDs2d
# xEz9ZBdQ3p30yRGn7wMl/4bHTZWr4d35QlGywqDXeqrMg193UkNFk/LdoxB8O0z2
# LM7hRTpkWsOMi1taQR8JFeEnFQFFnKMr3zTYm6UIAaeXGwNHLVbtw9lY1vnZVpe3
# zVIscbJ0kbHQKatiIeObxqQyEAHumgWDv4o46WAe7aV0klJARMfIhcyKpB80ylvL
# E35Y2xSMay2NmLwl2vYjc9clxlnuz01AtGVbJzwh4wpkDQBE1SrQmj6hosVussg4
# BtZhRkSG45ULhXnlWXB7Rw+909g6gLFrSjf+YZZHDEJVpNqvkKzwT/NXNGBuTYDG
# ux5G4kSePfl9+/YB8DHnTu5pBBg12agzIAXl9b2Koop6FXDLh8qBjSz3pKcRKZ3l
# jcBTcVq1v7MrWCgulv6SGAgLhpqYqOC0M+VRJ1gKeetghRUdFHB1haGytojB3gqm
# EQI/sCCxry9J8gebM+cCaJCtcCzNt1kZ10x1+PScHsSKxaRbiw==
# SIG # End signature block

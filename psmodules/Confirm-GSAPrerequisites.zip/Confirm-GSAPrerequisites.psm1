
Function Confirm-GSAPrerequisites {

    param (
        # config
        [Parameter(mandatory = $true)]
        [psobject]
        $config,

        # optional components included in the install
        [Parameter(Mandatory = $false)]
        [string[]]
        $newComponents
    )

    $ErrorActionPreference = 'Stop'

    Write-Verbose "Starting verification of the Guardrails Solution Accelerator prerequisites."

    If ($newComponents -contains 'CoreComponents') {
        Write-Verbose "Verifying prerequisites for Core Components..."

        # confirm that executing user required permission to complete the deployment
        Write-Verbose "Checking that user '$($config['runtime']['userId'])' has role 'User Access Administrator' or 'Owner' assigned at the root management group scope (id: '$($config['runtime']['tenantRootManagementGroupId'])')"
        Write-Verbose "`t Getting role assignments with cmd: Get-AzRoleAssignment -Scope $($config['runtime']['tenantRootManagementGroupId']) -RoleDefinitionName 'User Access Administrator' -ObjectId $($config['runtime']['userId']) -ErrorAction Continue"
        Write-Verbose "`t Getting role assignments with cmd: Get-AzRoleAssignment -Scope $($config['runtime']['tenantRootManagementGroupId']) -RoleDefinitionName 'Owner' -ObjectId $($config['runtime']['userId']) -ErrorAction Continue"
        $roleAssignments = @()
        $roleAssignments += Get-AzRoleAssignment -Scope $config['runtime']['tenantRootManagementGroupId'] -RoleDefinitionName 'User Access Administrator' -ObjectId $config['runtime']['userId'] -ErrorAction Continue
        $roleAssignments += Get-AzRoleAssignment -Scope $config['runtime']['tenantRootManagementGroupId'] -RoleDefinitionName 'Owner' -ObjectId $config['runtime']['userId'] -ErrorAction Continue

        Write-Verbose "`t Count of role assignments '$($roleAssignments.Count)'"
        if ($roleAssignments.count -eq 0) {
            Write-Error "Specified user ID '$($config['runtime']['userId'])' does not have role 'User Access Administrator' or 'Owner' assigned at the root management group scope!"
            Break                                                
        }
        Else {
            Write-Verbose "`t Sufficent role assignment for current user exists..."
        }

        ## resource providers - proactively registers RPs if missing
        Write-Verbose "Verifying that required resource providers are pre-registered..."
        "Microsoft.Network","Microsoft.Security","Microsoft.Management", "Microsoft.Storage", "Microsoft.KeyVault" | ForEach-Object {
            Write-Verbose "`tChecking that resource provider '$_' is registered..."

            $rpStatus = Get-AzResourceProvider -ProviderNamespace $_
            If ($rpStatus.RegistrationState -eq 'Registered') {
                Write-Verbose "`t`tResource provider '$_' is already registered."
            }
            ElseIf ($_ -in ("Microsoft.Storage", "Microsoft.KeyVault")) {
                Write-Verbose "`t`tRegistering resource provider '$_', waiting for completion."
                Register-AzResourceProvider -ProviderNamespace $_ | Out-Null
            }
            Else {
                Write-Verbose "`t`tRegistering resource provider '$_' as background job."
                Register-AzResourceProvider -ProviderNamespace $_ -AsJob | Out-Null
            }
        }

        # confirm that target resources do not already exist

        ## storage account
        Write-Verbose "Verifying that storage account name '$($config['runtime']['storageAccountName'])' is available"
        $nameAvailability = Get-AzStorageAccountNameAvailability -Name $config['runtime']['storageaccountName']
        if (($nameAvailability).NameAvailable -eq $false) {
            Write-Error "Storage account $($config['runtime']['storageaccountName']) is not available. Message: $($nameAvailability.Message)"
            break
        }
        Else {
            Write-Verbose "Storage account name '$($config['runtime']['storageAccountName'])' is available"
        }

        ## keyvault
        Write-Verbose "Verifying the Key Vault name '$($config['runtime']['keyVaultName'])' is available"
        $kvContent = ((Invoke-AzRest -Uri "https://management.azure.com/subscriptions/$($config['runtime']['subscriptionId'])/providers/Microsoft.KeyVault/checkNameAvailability?api-version=2021-11-01-preview" `
                    -Method Post -Payload "{""name"": ""$config['runtime']['keyVaultName']"",""type"": ""Microsoft.KeyVault/vaults""}").Content | ConvertFrom-Json).NameAvailable
        if (!($kvContent) -and $deployKV) {
            write-output "Error: keyvault name '$($config['runtime']['keyVaultName'])' is not available. Specify another prefix in config.json or a different unique resource name suffix"
            break
        }
    }

    # confirm lighthouse prereqs met
    If (($newComponents -contains 'CentralizedCustomerReportingSupport') -or ($newComponents -contains 'CentralizedCustomerDefenderForCloudSupport')) {
        # verify Lighthouse config parameters
        $lighthouseServiceProviderTenantID = $config.lighthouseServiceProviderTenantID
        $lighthousePrincipalDisplayName = $config.lighthousePrincipalDisplayName
        $lighthousePrincipalId = $config.lighthousePrincipalId
        $lighthouseTargetManagementGroupID = $config.lighthouseTargetManagementGroupID

        If ($newComponents -contains 'CentralizedCustomerReportingSupport') {
            Write-Verbose "Verifying prerequisites for Centralized Customer Reporting Support..."

            Write-Verbose "Confirming that the GSA core resources exist or will be deployed..."
            If ($newComponents -notcontains 'CoreComponents') {
                If (-NOT (Get-AzResourceGroup -Name $config['runtime']['resourceGroup'] -ErrorAction SilentlyContinue)) {
                    Write-Error "Unable to locate the resource group '$($config['runtime']['resourceGroup'])'; deployment of the centralized management components require that the core components be deployed first."
                    break
                }
                Else {
                    Write-Verbose "`tFound resource group '$($config['runtime']['resourceGroup'])'"
                }

                If (-NOT (Get-AzOperationalInsightsWorkspace -ResourceGroupName $config['runtime']['resourceGroup'] -Name $config['runtime']['logAnalyticsWorkspaceName'] -ErrorAction SilentlyContinue)) {
                    Write-Error "Unable to locate the Log Analytics workspace '$($config['runtime']['logAnalyticsWorkspaceName'])'; deployment of the centralized management components require that the core components be deployed first."
                    break
                }
                Else {
                    Write-Verbose "`tFound Log Analytics workspace '$($config['runtime']['logAnalyticsWorkspaceName'])'"
                }
            }

            # get lighthouse definitions for the managing tenant
            Write-Verbose "Checking for lighthouse registration definitions for managing tenant '$lighthouseServiceProviderTenantID'..."

            $uri = 'https://management.azure.com/subscriptions/{0}/providers/Microsoft.ManagedServices/registrationdefinitions?api-version=2022-01-01-preview&$filter=managedByTenantId eq {1}' -f `
                $config['runtime']['subscriptionId'], "'$lighthouseServiceProviderTenantID'"
            $response = Invoke-AzRestMethod -Method GET -Uri $uri

            If ($response.StatusCode -notin '200', '404') {
                Write-Error "An error occurred while retrieving Lighthouse registration definitions. Error: $($response.Content)"
                break
            }

            Write-Verbose "Found $($response.Content.value.Count) registration definitions for managing tenant '$lighthouseServiceProviderTenantID', filtering for registration definitions with the name 'SSC CSPM - Read Guardrail Status'..."
            $definitionsValue = $response.Content | ConvertFrom-Json | Select-Object -ExpandProperty value
            $guardrailReaderDefinitions = $definitionsValue | Where-Object { $_.Properties.registrationDefinitionName -eq 'SSC CSPM - Read Guardrail Status' }

            If ($guardrailReaderDefinitions.count -eq 0) {
                Write-Verbose "No Lighthouse registration definitions found for the managing tenant ID '$lighthouseServiceProviderTenantID'."
            }
            ElseIf (($guardrailReaderDefinitions.count -gt 1)) {
                Write-Error "More than 1 Lighthouse registration definition found for the managing tenant ID '$lighthouseServiceProviderTenantID' with the description 'SSC CSPM - Read Guardrail Status', please remove these registrations before continuing..."
                break
            }
            Else {
                Write-Verbose "Found '$($guardrailReaderDefinitions.count)' Lighthouse registration definitions for the managing tenant ID '$lighthouseServiceProviderTenantID' with the description 'SSC CSPM - Read Guardrail Status'."
                #remove lighthouse assignments
                Write-Verbose "Checking for Lighthouse assignments for managing tenant '$lighthouseServiceProviderTenantID' and definition ID '$($guardrailReaderDefinitions.id)'..."
                $uri = 'https://management.azure.com/subscriptions/{0}/providers/Microsoft.ManagedServices/registrationAssignments?api-version=2022-01-01-preview&$filter=registrationDefinitionId eq {1}' -f `
                    $config['runtime']['subscriptionId'], "'$($guardrailReaderDefinitions.id)'"
                $response = Invoke-AzRestMethod -Method GET -Uri $uri -Verbose

                If ($response.StatusCode -notin '200', '404') {
                    Write-Error "An error occurred while retrieving Lighthouse assignments. Error: $($response.Content)"
                    break
                }

                $assignmentValue = $response.Content | ConvertFrom-Json

                If ($assignmentValue.count -gt 0) {
                    Write-Error "Found $($assignmentValue.count) Lighthouse assignments for the managing tenant ID '$lighthouseServiceProviderTenantID' and definition ID '$($guardrailReaderDefinitions.id)', please remove these assignments before continuing."
                    break
                }
            }
        }
    
        If ($newComponents -contains 'CentralizedCustomerDefenderForCloudSupport') {
            Write-Verbose "Verifying prerequisites for Centralized Customer Defender for Cloud Support..."
            # check that user has correct permissions for deploying to tenant root mgmt group
            ## this permission is required so that a Policy Definition and Assignment can be deployed at the target management group, applying to all subscriptions in the tenant
            if ($lighthouseTargetManagementGroupID -eq $config['runtime']['tenantId']) {
                Write-Verbose "lighthouseTargetManagementGroupID is the tenant root managment group, which requires explicit owner permissions for the exeucting user; verifying..."
        
                $existingAssignment = Get-AzRoleAssignment -Scope '/' -RoleDefinitionName Owner -ObjectId $config['runtime']['userId'] | Where-Object { $_.Scope -eq '/' }
                If (!$existingAssignment) {
                    Write-Error "In order to deploy resources at the Tenant Root Management Group '$lighthouseTargetManagementGroupID', the executing user must be explicitly granted Owner 
                        rights at the root level. To create this role assignment, run 'New-AzRoleAssignment -Scope '/' -RoleDefinitionName Owner -ObjectId $($config['runtime']['userId'])' 
                        then execute this script again. This role assignment only needs to exist during the Lighthouse resource deployments and can (and should) be removed after this script completes."
                    Exit
                }
            }
        
            If ($lighthouseTargetManagementGroupID -eq $config['runtime']['tenantId']) {
                $assignmentScopeMgmtmGroupId = '/'
            }
            Else {
                $assignmentScopeMgmtmGroupId = $lighthouseTargetManagementGroupID
            }

            # check if a lighthouse defender for cloud policy MSI role assignment already exists - assignment name always 2cb8e1b1-fcf1-439e-bab7-b1b8b008c294 
            Write-Verbose "Checking for role assignments at management group '$assignmentScopeMgmtmGroupId' for role 'Owner'"
            $uri = 'https://management.azure.com/providers/Microsoft.Management/managementGroups/{0}/providers/Microsoft.Authorization/roleAssignments/{1}?&api-version=2015-07-01' -f $lighthouseTargetManagementGroupID, '2cb8e1b1-fcf1-439e-bab7-b1b8b008c294'
            $roleAssignments = Invoke-AzRestMethod -Uri $uri -Method GET | Select-Object -Expand Content | ConvertFrom-Json
            If ($roleAssignments.id) {
                Write-Verbose "role assignment: '$roleAssignments.id'"
                Write-Error "A role assignment exists with the name '2cb8e1b1-fcf1-439e-bab7-b1b8b008c294' at the Management group '$lighthouseTargetManagementGroupID'. This was likely
                created by a previous Guardrails deployment and must be removed. Navigate to the Managment Group in the Portal and delete the Owner role assignment listed as 'Identity Not Found'"
                Exit
            }
    
            # check if lighthouse Custom-RegisterLighthouseResourceProvider exists at a different scope
            Write-Verbose "Checking for existing role definitions with name 'Custom-RegisterLighthouseResourceProvider'"
            $roleDef = Get-AzRoleDefinition -Name 'Custom-RegisterLighthouseResourceProvider'
            $targetAssignableScope = "/providers/Microsoft.Management/managementGroups/$lighthouseTargetManagementGroupID"
            
            Write-Verbose "Found '$($roleDef.count)' role definitions with name 'Custom-RegisterLighthouseResourceProvider'. Verifying assignable scopes includes '$targetAssignableScope'"
            If ($roleDef -and $roleDef.AssignableScopes -notcontains $targetAssignableScope) {
                Write-Error "Role definition name 'Custom-RegisterLighthouseResourceProvider' already exists and has an assignable scope of '$($roleDef.AssignableScopes)'. Assignable scopes
                should include '$targetAssignableScope'. Delete the role definition (and any assignments) and run the script again."
                Exit
            }
    
            # check if a lighthouse Azure Automation MSI role assignment to register the Lighthouse resource provider already exists - assignment name always  5de3f84b-8866-4432-8811-24859ccf8146
            Write-Verbose "Checking for role assignments at management group '$assignmentScopeMgmtmGroupId' for role 'Custom-RegisterLighthouseResourceProvider'"
            $uri = 'https://management.azure.com/providers/Microsoft.Management/managementGroups/{0}/providers/Microsoft.Authorization/roleAssignments/{1}?&api-version=2015-07-01' -f $lighthouseTargetManagementGroupID, '5de3f84b-8866-4432-8811-24859ccf8146'
            $roleAssignments = Invoke-AzRestMethod -Uri $uri -Method GET | Select-Object -Expand Content | ConvertFrom-Json   
            If ($roleAssignments.id) {  
                Write-Verbose "role assignment: $(($roleAssignments).id)"  
                Write-Error "A role assignment exists with the name '5de3f84b-8866-4432-8811-24859ccf8146' at the Management group '$lighthouseTargetManagementGroupID'. This was likely
                created by a previous Guardrails deployment and must be removed. Navigate to the Managment Group in the Portal and delete the 'Custom-RegisterLighthouseResourceProvider' role assignment listed as 'Identity Not Found'"
                Exit
            
            }
        }
    }
    
    Write-Host "Prerequisite validation completed successfully!" -ForegroundColor Green

    Write-Verbose "Completed verification of the Guardrails Solution Accelerator prerequisites."
}
